#!/usr/bin/env python3
import json, os, subprocess, sys, tempfile, shutil, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
EVO=ROOT/'evolution.py'
TMP=Path(tempfile.mkdtemp(prefix='wb-evo-v22-'))
STATE=TMP/'state'
PROJ=TMP/'project'
ENV=os.environ.copy(); ENV['WORKBUDDY_EVOLUTION_HOME']=str(STATE); ENV['CODEBUDDY_PROJECT_DIR']=str(PROJ)


def run(*args, ok=(0,)):
    p=subprocess.run([sys.executable,str(EVO),*args],env=ENV,text=True,capture_output=True)
    if p.returncode not in ok:
        raise AssertionError(f"CMD FAIL {args}\nRC={p.returncode}\nOUT={p.stdout}\nERR={p.stderr}")
    try: return json.loads(p.stdout)
    except Exception: return p.stdout.strip()


def load(name): return json.loads((STATE/name).read_text(encoding='utf-8'))

try:
    # Legacy migration fixture before initialization.
    legacy=PROJ/'.workbuddy'/'evolution-kernel'; legacy.mkdir(parents=True)
    (legacy/'ERROR_LEDGER.json').write_text(json.dumps([{'id':'ERR-LEGACY-1','canonical_task_type':'legacy','summary':'old','expected':'old expected','tags':['legacy']}],ensure_ascii=False),encoding='utf-8')
    (legacy/'REGRESSION_CASES.json').write_text(json.dumps([{'id':'TEST-LEGACY-1','error_id':'ERR-LEGACY-1','status':'active','assertions':[{'id':'ASSERT-LEGACY-1','text':'legacy expected'}]}],ensure_ascii=False),encoding='utf-8')
    d=run('doctor')
    assert d['version']=='2.2.0'
    assert any(x.get('id')=='ERR-LEGACY-1' for x in load('ERRORS.json'))
    assert any(x.get('id')=='TEST-LEGACY-1' for x in load('REGRESSIONS.json'))
    print('V22_LEGACY_MIGRATION_PASS')

    # One correction creates one rule and one regression case with two assertions.
    c1=run('record-correction','--task-type','tongdaxin_formula','--summary','过滤假信号时错误修改原图结构','--expected','保持原绘图结构不变；只修改信号过滤条件','--root-cause','范围控制失败','--severity','P1','--tags','通达信,原图,假信号')
    assert c1['rule_id'] and c1['regression_id'] and c1['repeat_count']==1
    err_id,rule_id,case_id=c1['error_id'],c1['rule_id'],c1['regression_id']
    case=next(x for x in load('REGRESSIONS.json') if x['id']==case_id)
    assert len(case['assertions'])==2

    # Same semantic error under a different task type must merge, not duplicate.
    before_rules=len(load('RULES.json')); before_regs=len(load('REGRESSIONS.json'))
    c2=run('record-correction','--task-type','指标公式优化','--summary','优化假信号时又改动了原图和绘图结构','--expected','保持原绘图结构不变；只修改信号过滤条件','--root-cause','没有执行范围检查','--severity','P1','--tags','通达信,原图,假信号')
    assert c2['error_id']==err_id and c2['SELF_EVOLUTION_FAILURE'] is True and c2['repeat_count']==2
    assert len(load('RULES.json'))==before_rules and len(load('REGRESSIONS.json'))==before_regs
    print('V22_CROSS_TASK_DEDUP_PASS')

    # Alias registration.
    run('register-alias','--canonical','tongdaxin_formula','--alias','通达信公式','--alias','tdx_formula')

    # Begin must surface learned hard rule and regression.
    b=run('begin-task','--task-type','tdx_formula','--task','优化通达信假信号并保持原图','--review-policy','adaptive','--expect-artifact','yes')
    tid=b['task_id']; hard_ids=[x['id'] for x in b['hard_rules']]
    assert rule_id in hard_ids and case_id in [x['id'] for x in b['regression_cases']]

    art=TMP/'indicator.txt'; art.write_text('ORIGINAL\nFILTER=V2',encoding='utf-8')
    run('execute-task','--task-id',tid,'--summary','完成过滤逻辑修改','--evidence','已比对绘图段','--artifact',str(art))

    # Reviewer cannot omit any hard rule.
    one=hard_ids[0]
    bad=run('submit-review','--task-id',tid,'--reviewer','self-adversarial','--mode','self-adversarial','--rule-check',f'{one}=pass:已检查这一条规则','--notes','对抗式复核',ok=(1,))
    assert 'MISSING_HARD_RULE_CHECKS' in bad['error']

    review_args=['submit-review','--task-id',tid,'--reviewer','self-adversarial','--mode','self-adversarial','--notes','重新从目标和产物逐项核对，没有发现违反硬规则']
    for rid in hard_ids: review_args += ['--rule-check',f'{rid}=pass:已逐项核对产物与要求相符']
    run(*review_args)

    # Regression cannot omit assertions.
    a_ids=[x['id'] for x in case['assertions']]
    bad=run('record-regression','--task-id',tid,'--case-id',case_id,'--check',f'{a_ids[0]}=pass:验证原绘图结构保持不变',ok=(1,))
    assert 'MISSING_ASSERTION_CHECKS' in bad['error']
    reg_args=['record-regression','--task-id',tid,'--case-id',case_id,'--evidence-file',str(art)]
    for aid in a_ids: reg_args += ['--check',f'{aid}=pass:逐项核对对应约束并确认满足']
    run(*reg_args)
    print('V22_ASSERTION_GATE_PASS')

    # Artifact tamper after validation must be caught at close.
    art.write_text('TAMPERED',encoding='utf-8')
    closed=run('close-task','--task-id',tid,ok=(2,))
    assert closed['GATE_PASS'] is False and any('ARTIFACT_EVIDENCE_INVALID' in x for x in closed['reasons'])
    print('V22_EVIDENCE_REVERIFY_PASS')

    # Re-execution invalidates old reviewer/regression; only new revision may pass.
    art.write_text('ORIGINAL\nFILTER=V3',encoding='utf-8')
    run('execute-task','--task-id',tid,'--summary','修复后重新执行','--evidence','重新验证','--artifact',str(art))
    blocked=run('close-task','--task-id',tid,ok=(2,))
    assert 'NO_CURRENT_REVIEW' in blocked['reasons'] and any('MISSING_CURRENT_REGRESSION' in x for x in blocked['reasons'])
    review_args=['submit-review','--task-id',tid,'--reviewer','self-adversarial','--mode','self-adversarial','--notes','重执行后重新完成全量审查']
    for rid in hard_ids: review_args += ['--rule-check',f'{rid}=pass:新版本重新核对并通过']
    run(*review_args)
    reg_args=['record-regression','--task-id',tid,'--case-id',case_id,'--evidence-file',str(art)]
    for aid in a_ids: reg_args += ['--check',f'{aid}=pass:新版本重新逐断言验证通过']
    run(*reg_args)
    final=run('close-task','--task-id',tid)
    assert final['GATE_PASS'] is True
    print('V22_REVISION_INVALIDATION_PASS')

    # Large directory must not produce a 'complete' partial fingerprint.
    sys.path.insert(0,str(ROOT)); import evolution
    oldmax=evolution.MAX_DIR_ENTRIES; evolution.MAX_DIR_ENTRIES=3
    big=TMP/'big'; big.mkdir()
    for i in range(5): (big/f'{i}.txt').write_text(str(i))
    fp=evolution.fingerprint(big); evolution.MAX_DIR_ENTRIES=oldmax
    assert fp['complete'] is False and 'too_many_entries' in fp['reason']
    print('V22_LARGE_DIRECTORY_GUARD_PASS')

    # Rule lifecycle: deprecated rule no longer loads.
    run('deprecate-rule','--rule-id',rule_id,'--reason','测试废止生命周期')
    b2=run('begin-task','--task-type','tdx_formula','--task','优化通达信假信号并保持原图')
    assert rule_id not in [x['id'] for x in b2['hard_rules']]
    print('V22_RULE_LIFECYCLE_PASS')

    # Secret redaction.
    secret='sk-ABCDEFGHIJKLMNOPQRSTUVWXYZ123456'
    run('record-correction','--task-type','secret_test','--summary',f'api_key={secret}','--expected','不得保存敏感密钥','--root-cause','secret leak','--severity','P1','--tags','secret,key')
    raw='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in STATE.glob('*.json'))
    assert secret not in raw and '<REDACTED>' in raw
    print('V22_REDACTION_PASS')

    # Candidate versioning + duplicate candidate prevention.
    for idx in (1,2,3):
        run('record-correction','--task-type','quant_system','--summary',f'独立错误{idx}导致评分偏差','--expected',f'必须验证独立约束{idx}','--root-cause','规则缺失','--severity','P1','--tags',f'quant,rule{idx},case{idx}')
    cand=run('candidate','--task-type','quant_system','--min-rules','3')
    assert cand['version']=='1.0.0'
    # Same candidate again must be refused.
    dup=run('candidate','--task-type','quant_system','--min-rules','3',ok=(1,)); assert 'DUPLICATE_CANDIDATE_RULESET' in dup['error']
    regs={x['id']:x for x in load('REGRESSIONS.json')}
    for cid in cand['case_ids']:
        args=['candidate-regression','--candidate-id',cand['id'],'--case-id',cid]
        for a in regs[cid]['assertions']: args += ['--check',f"{a['id']}=pass:实际回放并确认该断言满足"]
        run(*args)
    prom=run('promote','--candidate-id',cand['id'])
    zp=Path(prom['artifact']); assert zp.exists() and prom['version']=='1.0.0'
    with zipfile.ZipFile(zp) as z:
        names=z.namelist(); assert len(names)==1 and names[0].endswith('/SKILL.md') and names[0].count('/')==1
    # New rule => patch version increment.
    run('record-correction','--task-type','quant_system','--summary','第四类独立错误导致评分漂移','--expected','必须验证独立约束4','--root-cause','规则缺失','--severity','P1','--tags','quant,rule4,case4')
    cand2=run('candidate','--task-type','quant_system','--min-rules','3'); assert cand2['version']=='1.0.1'
    print('V22_CANDIDATE_VERSIONING_PASS')

    # Snapshot / rollback sanity.
    run('snapshot','--name','before-test-change')
    before=len(load('ERRORS.json'))
    run('record-correction','--task-type','rollback_test','--summary','临时错误','--expected','临时约束','--root-cause','test','--severity','P3','--tags','rollback,temp')
    assert len(load('ERRORS.json'))==before+1
    run('rollback','--name','before-test-change')
    assert len(load('ERRORS.json'))==before
    print('V22_SNAPSHOT_ROLLBACK_PASS')

    print('ALL_TESTS_PASSED')
finally:
    shutil.rmtree(TMP,ignore_errors=True)
