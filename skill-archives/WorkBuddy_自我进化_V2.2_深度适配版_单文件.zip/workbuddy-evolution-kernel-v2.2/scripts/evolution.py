#!/usr/bin/env python3
import argparse, json, os, re, sys, hashlib, shutil, tempfile, time, uuid, zipfile
from pathlib import Path
from datetime import datetime, timezone

VERSION='2.2.0'
MAX_DIR_ENTRIES=5000
SECRET_PATTERNS=[
    re.compile(r'(?i)(password|passwd|pwd|token|api[_ -]?key|secret)\s*[:=]\s*([^\s,;]+)'),
    re.compile(r'\bsk-[A-Za-z0-9_-]{12,}\b'),
    re.compile(r'(?i)bearer\s+[A-Za-z0-9._-]{10,}'),
]


def now(): return datetime.now(timezone.utc).isoformat()
def uid(prefix): return f"{prefix}-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:8]}"
def redact(s):
    s=s or ''
    for p in SECRET_PATTERNS:
        s=p.sub(lambda m: (m.group(1)+'=<REDACTED>') if m.lastindex and m.lastindex>=2 else '<REDACTED>', s)
    return s

def state_home():
    env=os.getenv('WORKBUDDY_EVOLUTION_HOME')
    if env: return Path(env).expanduser().resolve()
    if os.getenv('WORKBUDDY_EVOLUTION_SCOPE','').lower()=='project' and os.getenv('CODEBUDDY_PROJECT_DIR'):
        return (Path(os.environ['CODEBUDDY_PROJECT_DIR'])/'.workbuddy'/'evolution-kernel').resolve()
    return (Path.home()/'.workbuddy-evolution').resolve()

STATE_FILES=['RULES.json','ERRORS.json','REGRESSIONS.json','TASKS.json','ALIASES.json','CANDIDATES.json','REGISTRY.json','REVIEWS.json','AUDITS.json','MIGRATION.json']

def default_data(name):
    if name=='ALIASES.json': return {}
    if name=='REGISTRY.json': return {}
    if name=='MIGRATION.json': return {'version':VERSION,'events':[]}
    return []

def atomic_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_name(path.name+'.tmp-'+uuid.uuid4().hex[:8])
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,path)

def load(name):
    p=state_home()/name
    if not p.exists(): return default_data(name)
    try: return json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: raise RuntimeError(f'CORRUPT_STATE:{name}:{e}')

def save(name,data): atomic_write(state_home()/name,data)

class Lock:
    def __init__(self,timeout=10): self.p=state_home()/'.lock'; self.timeout=timeout
    def __enter__(self):
        state_home().mkdir(parents=True,exist_ok=True)
        start=time.time()
        while True:
            try:
                os.mkdir(self.p)
                (self.p/'owner').write_text(f'{os.getpid()} {time.time()}',encoding='utf-8')
                return self
            except FileExistsError:
                try:
                    age=time.time()-(self.p/'owner').stat().st_mtime
                    if age>60: shutil.rmtree(self.p,ignore_errors=True); continue
                except Exception: pass
                if time.time()-start>self.timeout: raise TimeoutError('STATE_LOCK_TIMEOUT')
                time.sleep(.05)
    def __exit__(self,*_): shutil.rmtree(self.p,ignore_errors=True)

def normalize_type(s):
    s=(s or '').strip().lower()
    s=re.sub(r'\s+','_',s)
    s=re.sub(r'[^0-9a-z_\-\u4e00-\u9fff]+','',s)
    aliases=load('ALIASES.json') if state_home().exists() else {}
    return aliases.get(s,s or 'general')

def semantic_tokens(text):
    t=(text or '').lower()
    toks=set(re.findall(r'[a-z0-9_\-]{3,}',t))
    for seq in re.findall(r'[\u4e00-\u9fff]{2,}',t):
        if len(seq)<=4: toks.add(seq)
        else:
            for n in (2,3):
                for i in range(len(seq)-n+1): toks.add(seq[i:i+n])
    return toks

def tagset(s): return {x.strip().lower() for x in re.split(r'[,，;；\n]+',s or '') if x.strip()}
def jaccard(a,b): return len(a&b)/max(1,len(a|b))
def correction_similarity(a,b):
    ta=set(a.get('tags',[])); tb=set(b.get('tags',[]))
    texta=semantic_tokens((a.get('summary','')+' '+a.get('expected','')))
    textb=semantic_tokens((b.get('summary','')+' '+b.get('expected','')))
    tagscore=jaccard(ta,tb) if ta and tb else 0.0
    textscore=jaccard(texta,textb)
    bonus=.10 if a.get('canonical_task_type')==b.get('canonical_task_type') else 0.0
    if ta and tb: return min(1.0,.75*tagscore+.25*textscore+bonus)
    return min(1.0,textscore+bonus)

def split_assertions(expected):
    parts=[x.strip(' -\t') for x in re.split(r'[;；\n]+',expected or '') if x.strip(' -\t')]
    if not parts and expected.strip(): parts=[expected.strip()]
    return parts

def file_hash(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def fingerprint(path):
    p=Path(path).expanduser().resolve()
    if not p.exists(): return {'path':str(p),'exists':False,'complete':False,'reason':'missing'}
    if p.is_file():
        return {'path':str(p),'exists':True,'kind':'file','sha256':file_hash(p),'size':p.stat().st_size,'complete':True}
    if p.is_dir():
        files=[]
        for root,dirs,names in os.walk(p):
            dirs.sort(); names.sort()
            for n in names:
                q=Path(root)/n
                if q.is_symlink():
                    rel=str(q.relative_to(p)); files.append(('L',rel,os.readlink(q)))
                elif q.is_file():
                    rel=str(q.relative_to(p)); files.append(('F',rel,q.stat().st_size,file_hash(q)))
                if len(files)>MAX_DIR_ENTRIES:
                    return {'path':str(p),'exists':True,'kind':'dir','complete':False,'reason':f'too_many_entries>{MAX_DIR_ENTRIES}','entries_scanned':len(files)}
        h=hashlib.sha256(json.dumps(files,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
        return {'path':str(p),'exists':True,'kind':'dir','sha256':h,'entries':len(files),'complete':True}
    return {'path':str(p),'exists':True,'kind':'other','complete':False,'reason':'unsupported_path_type'}

def fp_equal(old,new):
    return old.get('complete') and new.get('complete') and old.get('sha256')==new.get('sha256') and old.get('kind')==new.get('kind')

def ensure_base_rules():
    rules=load('RULES.json')
    existing={r['id'] for r in rules}
    bases=[
      {'id':'RULE-BASE-SCOPE-001','level':'HARD','scope':'global','statement':'只修改用户授权范围，禁止擅自扩大修改范围。'},
      {'id':'RULE-BASE-VERIFY-001','level':'HARD','scope':'global','statement':'未经实际验证不得宣称完成、正确、可用或已通过测试。'},
      {'id':'RULE-BASE-CORRECTION-001','level':'HARD','scope':'global','statement':'用户明确纠错必须固化；重复高严重度错误必须审计纠错链。'},
      {'id':'RULE-BASE-DELIVERY-001','level':'HARD','scope':'global','statement':'禁止把计划、待办或承诺当成已完成交付。'},
      {'id':'RULE-BASE-HOST-001','level':'HARD','scope':'global','statement':'本地规则不得覆盖 WorkBuddy 宿主安全、权限和系统级约束。'},
    ]
    changed=False
    for b in bases:
        if b['id'] not in existing:
            b.update({'status':'active','source':'base','created_at':now(),'repeat_count':0,'trigger_terms':[]})
            rules.append(b); changed=True
    if changed: save('RULES.json',rules)

def merge_list_by_id(dst,src):
    ids={x.get('id') for x in dst if isinstance(x,dict)}
    for x in src:
        if isinstance(x,dict) and x.get('id') not in ids:
            dst.append(x); ids.add(x.get('id'))
    return dst

def parse_jsonl(path):
    out=[]
    for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
        try:
            x=json.loads(line)
            if isinstance(x,dict): out.append(x)
        except Exception: pass
    return out

def migrate_legacy():
    mig=load('MIGRATION.json')
    marker='auto-migrate-v22'
    if any(e.get('marker')==marker for e in mig.get('events',[])): return
    target=state_home().resolve()
    candidates=[]
    proj=os.getenv('CODEBUDDY_PROJECT_DIR')
    if proj: candidates.append((Path(proj)/'.workbuddy'/'evolution-kernel').resolve())
    candidates.append((Path.home()/'.workbuddy-evolution-v2').resolve())
    # In-place old schemas in target are handled too.
    merged={'rules':0,'errors':0,'regressions':0}
    with Lock():
        rules=load('RULES.json'); errors=load('ERRORS.json'); regs=load('REGRESSIONS.json')
        # In-place legacy error ledger
        for lp in [target/'ERROR_LEDGER.jsonl', target/'ERROR_LEDGER.json']:
            if lp.exists():
                old=parse_jsonl(lp) if lp.suffix=='.jsonl' else json.loads(lp.read_text(encoding='utf-8'))
                before=len(errors); errors=merge_list_by_id(errors,old); merged['errors']+=len(errors)-before
        for lp in [target/'REGRESSION_CASES.json']:
            if lp.exists():
                old=json.loads(lp.read_text(encoding='utf-8'))
                before=len(regs); regs=merge_list_by_id(regs,old); merged['regressions']+=len(regs)-before
        for c in candidates:
            if c==target or not c.exists(): continue
            try:
                if (c/'RULES.json').exists():
                    old=json.loads((c/'RULES.json').read_text(encoding='utf-8')); before=len(rules); rules=merge_list_by_id(rules,old); merged['rules']+=len(rules)-before
                for nm in ['ERRORS.json','ERROR_LEDGER.json']:
                    if (c/nm).exists():
                        old=json.loads((c/nm).read_text(encoding='utf-8')); before=len(errors); errors=merge_list_by_id(errors,old); merged['errors']+=len(errors)-before
                if (c/'ERROR_LEDGER.jsonl').exists():
                    old=parse_jsonl(c/'ERROR_LEDGER.jsonl'); before=len(errors); errors=merge_list_by_id(errors,old); merged['errors']+=len(errors)-before
                for nm in ['REGRESSIONS.json','REGRESSION_CASES.json']:
                    if (c/nm).exists():
                        old=json.loads((c/nm).read_text(encoding='utf-8')); before=len(regs); regs=merge_list_by_id(regs,old); merged['regressions']+=len(regs)-before
            except Exception: pass
        save('RULES.json',rules); save('ERRORS.json',errors); save('REGRESSIONS.json',regs)
        mig=load('MIGRATION.json'); mig.setdefault('events',[]).append({'marker':marker,'at':now(),'merged':merged,'sources':[str(x) for x in candidates]}); save('MIGRATION.json',mig)


def normalize_state_schema():
    """Normalize legacy V1/V2 records into the V2.2 executable schema."""
    with Lock():
        rules=load('RULES.json'); errors=load('ERRORS.json'); regs=load('REGRESSIONS.json')
        changed=False
        for r in rules:
            if not r.get('id'): r['id']=uid('RULE'); changed=True
            if not r.get('status'): r['status']='active'; changed=True
            if not r.get('level'): r['level']='HARD' if str(r.get('severity','')).upper() in ('P0','P1') else 'SOFT'; changed=True
            if not r.get('scope'): r['scope']='task' if r.get('canonical_task_type') or r.get('task_type') else 'global'; changed=True
            if r.get('task_type') and not r.get('canonical_task_type'): r['canonical_task_type']=normalize_type(r['task_type']); changed=True
            if not isinstance(r.get('trigger_terms',[]),list): r['trigger_terms']=list(r.get('trigger_terms') or []); changed=True
        for e in errors:
            if not e.get('id'): e['id']=uid('ERR'); changed=True
            if not e.get('canonical_task_type'): e['canonical_task_type']=normalize_type(e.get('task_type','general')); changed=True
            if not isinstance(e.get('tags',[]),list): e['tags']=sorted(tagset(str(e.get('tags','')))); changed=True
            if 'repeat_count' not in e: e['repeat_count']=1; changed=True
        for c in regs:
            if not c.get('id'): c['id']=uid('TEST'); changed=True
            if not c.get('status'): c['status']='active'; changed=True
            if c.get('task_type') and not c.get('canonical_task_type'): c['canonical_task_type']=normalize_type(c['task_type']); changed=True
            arr=c.get('assertions')
            if isinstance(arr,list):
                new=[]
                for a in arr:
                    if isinstance(a,str): new.append({'id':uid('ASSERT'),'text':a}); changed=True
                    elif isinstance(a,dict):
                        if not a.get('id'): a['id']=uid('ASSERT'); changed=True
                        if not a.get('text'):
                            a['text']=str(a.get('expected') or a.get('description') or '必须复核该历史断言')
                            changed=True
                        new.append(a)
                c['assertions']=new
            else:
                source=(c.get('expected') or c.get('expected_behavior') or c.get('correct_behavior') or c.get('acceptance_criteria') or c.get('user_requirement') or c.get('description') or '必须确认对应历史错误没有再次发生')
                vals=source if isinstance(source,list) else split_assertions(str(source))
                c['assertions']=[{'id':uid('ASSERT'),'text':str(x)} for x in vals if str(x).strip()]
                changed=True
        if changed:
            save('RULES.json',rules); save('ERRORS.json',errors); save('REGRESSIONS.json',regs)

def init_state():
    h=state_home(); h.mkdir(parents=True,exist_ok=True)
    for n in STATE_FILES:
        p=h/n
        if not p.exists(): save(n,default_data(n))
    (h/'snapshots').mkdir(exist_ok=True); (h/'released').mkdir(exist_ok=True)
    migrate_legacy(); normalize_state_schema(); ensure_base_rules()
    return h

def applicable_rules(task_type,task):
    ct=normalize_type(task_type); toks=semantic_tokens(task+' '+task_type)
    out=[]
    for r in load('RULES.json'):
        if r.get('status','active')!='active': continue
        if r.get('scope')=='global': out.append(r); continue
        if r.get('canonical_task_type')==ct: out.append(r); continue
        trig=set(r.get('trigger_terms',[]))
        if trig and (trig & toks): out.append(r)
    return out

def relevant_regs(task_type,task):
    ct=normalize_type(task_type); toks=semantic_tokens(task+' '+task_type)
    out=[]
    errors={e.get('id'):e for e in load('ERRORS.json')}
    for c in load('REGRESSIONS.json'):
        if c.get('status','active')!='active': continue
        e=errors.get(c.get('error_id'),{})
        if e.get('canonical_task_type')==ct or c.get('canonical_task_type')==ct or (set(e.get('tags',[])) & toks): out.append(c)
    return out

def parse_rule_checks(values):
    out={}
    for v in values or []:
        m=re.match(r'^([^=]+)=(pass|fail):(.*)$',v,re.I)
        if not m: raise ValueError(f'INVALID_RULE_CHECK:{v}')
        rid,status,notes=m.groups(); notes=notes.strip()
        if len(notes)<6: raise ValueError(f'RULE_CHECK_NOTES_TOO_SHORT:{rid}')
        out[rid]={'passed':status.lower()=='pass','notes':redact(notes)}
    return out

def parse_assertion_checks(values):
    out={}
    for v in values or []:
        m=re.match(r'^([^=]+)=(pass|fail):(.*)$',v,re.I)
        if not m: raise ValueError(f'INVALID_ASSERTION_CHECK:{v}')
        aid,status,notes=m.groups(); notes=notes.strip()
        if len(notes)<6: raise ValueError(f'ASSERTION_CHECK_NOTES_TOO_SHORT:{aid}')
        out[aid]={'passed':status.lower()=='pass','notes':redact(notes)}
    return out

def cmd_doctor(args):
    init_state()
    result={'version':VERSION,'python':sys.version.split()[0],'state_home':str(state_home()),'writable':os.access(state_home(),os.W_OK),'codebuddy_skill_dir':os.getenv('CODEBUDDY_SKILL_DIR'),'codebuddy_project_dir':os.getenv('CODEBUDDY_PROJECT_DIR'),'scope':os.getenv('WORKBUDDY_EVOLUTION_SCOPE','user-global')}
    print(json.dumps(result,ensure_ascii=False,indent=2))

def cmd_begin(args):
    init_state(); rules=applicable_rules(args.task_type,args.task); regs=relevant_regs(args.task_type,args.task)
    t={'id':uid('TASK'),'task_type':args.task_type,'canonical_task_type':normalize_type(args.task_type),'task':redact(args.task),'review_policy':args.review_policy,'expect_artifact':args.expect_artifact=='yes','created_at':now(),'revision':0,'status':'open','hard_rule_ids':[r['id'] for r in rules if r.get('level')=='HARD'],'regression_case_ids':[r['id'] for r in regs],'execution':None,'review_id':None,'regression_results':{},'gate':None}
    with Lock():
        tasks=load('TASKS.json'); tasks.append(t); save('TASKS.json',tasks)
    print(json.dumps({'task_id':t['id'],'hard_rules':[{'id':r['id'],'statement':r.get('statement')} for r in rules if r.get('level')=='HARD'],'regression_cases':[{'id':c['id'],'assertions':c.get('assertions',[])} for c in regs]},ensure_ascii=False,indent=2))

def find_task(tasks,tid):
    for t in tasks:
        if t.get('id')==tid: return t
    raise KeyError('TASK_NOT_FOUND')

def cmd_execute(args):
    init_state(); fps=[]
    for p in (args.artifact or []): fps.append(fingerprint(p))
    efs=[]
    for p in (args.evidence_file or []): efs.append(fingerprint(p))
    with Lock():
        tasks=load('TASKS.json'); t=find_task(tasks,args.task_id); t['revision']=int(t.get('revision',0))+1
        t['execution']={'revision':t['revision'],'at':now(),'summary':redact(args.summary),'evidence':redact(args.evidence),'artifacts':fps,'evidence_files':efs}
        t['review_id']=None; t['regression_results']={}; t['gate']=None; t['status']='executed'; save('TASKS.json',tasks)
    print(json.dumps({'task_id':t['id'],'revision':t['revision'],'artifacts':fps,'old_validation_invalidated':True},ensure_ascii=False,indent=2))

def cmd_review(args):
    init_state(); checks=parse_rule_checks(args.rule_check)
    with Lock():
        tasks=load('TASKS.json'); t=find_task(tasks,args.task_id)
        required=set(t.get('hard_rule_ids',[])); missing=sorted(required-set(checks)); fails=sorted(k for k,v in checks.items() if k in required and not v['passed'])
        if missing: raise ValueError('MISSING_HARD_RULE_CHECKS:'+','.join(missing))
        passed=not fails
        r={'id':uid('REVIEW'),'task_id':t['id'],'revision':t['revision'],'mode':args.mode,'reviewer':redact(args.reviewer),'notes':redact(args.notes),'checks':checks,'passed':passed,'at':now()}
        reviews=load('REVIEWS.json'); reviews.append(r); save('REVIEWS.json',reviews); t['review_id']=r['id']; t['gate']=None; save('TASKS.json',tasks)
    print(json.dumps({'review_id':r['id'],'passed':passed,'failed_rules':fails},ensure_ascii=False,indent=2))

def get_reg(caseid):
    for c in load('REGRESSIONS.json'):
        if c.get('id')==caseid:return c
    raise KeyError('REGRESSION_NOT_FOUND')

def cmd_regression(args):
    init_state(); checks=parse_assertion_checks(args.check); case=get_reg(args.case_id)
    required={a['id'] for a in case.get('assertions',[])}; missing=sorted(required-set(checks)); extra=set(checks)-required
    if missing: raise ValueError('MISSING_ASSERTION_CHECKS:'+','.join(missing))
    if extra: raise ValueError('UNKNOWN_ASSERTION_CHECKS:'+','.join(sorted(extra)))
    fps=[fingerprint(p) for p in (args.evidence_file or [])]
    passed=all(v['passed'] for v in checks.values())
    with Lock():
        tasks=load('TASKS.json'); t=find_task(tasks,args.task_id)
        t.setdefault('regression_results',{})[case['id']]={'revision':t['revision'],'at':now(),'checks':checks,'passed':passed,'evidence_files':fps}; t['gate']=None; save('TASKS.json',tasks)
    print(json.dumps({'case_id':case['id'],'passed':passed,'assertions':len(required)},ensure_ascii=False,indent=2))

def reverify_fps(fps):
    issues=[]
    for old in fps or []:
        if not old.get('complete'): issues.append({'path':old.get('path'),'reason':'initial_fingerprint_incomplete'}); continue
        new=fingerprint(old.get('path'))
        if not fp_equal(old,new): issues.append({'path':old.get('path'),'reason':'missing_or_changed','current':new})
    return issues

def cmd_close(args):
    init_state(); tasks=load('TASKS.json'); t=find_task(tasks,args.task_id); reasons=[]
    ex=t.get('execution')
    if not ex or ex.get('revision')!=t.get('revision'): reasons.append('NO_CURRENT_EXECUTION')
    if ex:
        if t.get('expect_artifact') and not ex.get('artifacts'): reasons.append('EXPECTED_ARTIFACT_MISSING')
        reasons += ['ARTIFACT_EVIDENCE_INVALID:'+json.dumps(x,ensure_ascii=False) for x in reverify_fps(ex.get('artifacts',[])+ex.get('evidence_files',[]))]
    reviews=load('REVIEWS.json'); rv=next((r for r in reviews if r.get('id')==t.get('review_id')),None)
    if not rv or rv.get('revision')!=t.get('revision'): reasons.append('NO_CURRENT_REVIEW')
    else:
        if not rv.get('passed'): reasons.append('REVIEW_FAILED')
        req=set(t.get('hard_rule_ids',[])); got=set(rv.get('checks',{})); miss=req-got
        if miss: reasons.append('REVIEW_MISSING_HARD_RULES:'+','.join(sorted(miss)))
        for rid in req:
            if rid in rv.get('checks',{}) and not rv['checks'][rid].get('passed'): reasons.append('HARD_RULE_FAILED:'+rid)
        if t.get('review_policy')=='strict' and rv.get('mode')!='independent': reasons.append('STRICT_REQUIRES_INDEPENDENT_REVIEW')
    for cid in t.get('regression_case_ids',[]):
        rr=t.get('regression_results',{}).get(cid)
        if not rr or rr.get('revision')!=t.get('revision'): reasons.append('MISSING_CURRENT_REGRESSION:'+cid); continue
        if not rr.get('passed'): reasons.append('REGRESSION_FAILED:'+cid)
        case=get_reg(cid); req={a['id'] for a in case.get('assertions',[])}; got=set(rr.get('checks',{}));
        if req-got: reasons.append('REGRESSION_ASSERTIONS_MISSING:'+cid)
        reasons += ['REGRESSION_EVIDENCE_INVALID:'+cid+':'+json.dumps(x,ensure_ascii=False) for x in reverify_fps(rr.get('evidence_files',[]))]
    passed=not reasons
    with Lock():
        tasks=load('TASKS.json'); t=find_task(tasks,args.task_id); t['gate']={'revision':t['revision'],'passed':passed,'reasons':reasons,'at':now(),'assurance_level':'high' if rv and rv.get('mode')=='independent' else 'standard'}; t['status']='closed' if passed else 'blocked'; save('TASKS.json',tasks)
    print(json.dumps({'GATE_PASS':passed,'task_id':args.task_id,'reasons':reasons,'assurance_level':t['gate']['assurance_level']},ensure_ascii=False,indent=2))
    if not passed: sys.exit(2)

def cmd_correction(args):
    init_state(); new={'canonical_task_type':normalize_type(args.task_type),'summary':redact(args.summary),'expected':redact(args.expected),'tags':sorted(tagset(args.tags))}
    errors=load('ERRORS.json'); best=None; bestscore=0
    for e in errors:
        s=correction_similarity(new,e)
        if s>bestscore: best,bestscore=e,s
    threshold=.55 if new['tags'] else .68
    sev=args.severity.upper(); repeated=False
    with Lock():
        errors=load('ERRORS.json'); rules=load('RULES.json'); regs=load('REGRESSIONS.json')
        if best and bestscore>=threshold:
            e=next(x for x in errors if x['id']==best['id']); e['repeat_count']=int(e.get('repeat_count',1))+1; e['last_seen']=now(); e['tags']=sorted(set(e.get('tags',[]))|set(new['tags'])); e['summary_latest']=new['summary']; e['expected_latest']=new['expected']; repeated=sev in ('P0','P1','P2')
            rid=e.get('rule_id'); cid=e.get('regression_id')
            if rid:
                r=next((x for x in rules if x.get('id')==rid),None)
                if r:
                    r['repeat_count']=e['repeat_count']; r['trigger_terms']=sorted(set(r.get('trigger_terms',[]))|semantic_tokens(args.tags+' '+args.summary)); r['updated_at']=now()
            if cid:
                c=next((x for x in regs if x.get('id')==cid),None)
                if c:
                    existing={a['text'] for a in c.get('assertions',[])}
                    for text in split_assertions(new['expected']):
                        if text not in existing: c.setdefault('assertions',[]).append({'id':uid('ASSERT'),'text':text}); existing.add(text)
                    c['updated_at']=now()
            out=e
        else:
            eid=uid('ERR'); rid=None; cid=None
            if sev in ('P0','P1','P2'):
                rid=uid('RULE')
                rules.append({'id':rid,'level':'HARD' if sev in ('P0','P1') else 'SOFT','scope':'task','canonical_task_type':new['canonical_task_type'],'statement':new['expected'],'status':'active','source':'correction','error_id':eid,'trigger_terms':sorted(semantic_tokens(args.tags+' '+args.summary)),'repeat_count':1,'created_at':now()})
                cid=uid('TEST'); assertions=[{'id':uid('ASSERT'),'text':x} for x in split_assertions(new['expected'])]
                regs.append({'id':cid,'error_id':eid,'canonical_task_type':new['canonical_task_type'],'status':'active','assertions':assertions,'created_at':now()})
            out={'id':eid,'task_type':args.task_type,'canonical_task_type':new['canonical_task_type'],'summary':new['summary'],'expected':new['expected'],'root_cause':redact(args.root_cause),'severity':sev,'tags':new['tags'],'repeat_count':1,'created_at':now(),'last_seen':now(),'rule_id':rid,'regression_id':cid}
            errors.append(out)
        save('ERRORS.json',errors); save('RULES.json',rules); save('REGRESSIONS.json',regs)
    print(json.dumps({'error_id':out['id'],'rule_id':out.get('rule_id'),'regression_id':out.get('regression_id'),'repeat_count':out.get('repeat_count'),'similarity':round(bestscore,3),'SELF_EVOLUTION_FAILURE':repeated},ensure_ascii=False,indent=2))

def cmd_alias(args):
    init_state(); canon=re.sub(r'\s+','_',args.canonical.strip().lower())
    with Lock():
        a=load('ALIASES.json'); a[canon]=canon
        for x in args.alias: a[re.sub(r'\s+','_',x.strip().lower())]=canon
        save('ALIASES.json',a)
    print(json.dumps({'canonical':canon,'aliases':args.alias},ensure_ascii=False))

def cmd_deprecate(args):
    init_state();
    with Lock():
        rules=load('RULES.json'); r=next((x for x in rules if x.get('id')==args.rule_id),None)
        if not r: raise KeyError('RULE_NOT_FOUND')
        r['status']='deprecated'; r['deprecated_at']=now(); r['deprecated_reason']=redact(args.reason); save('RULES.json',rules)
    print(json.dumps({'rule_id':args.rule_id,'status':'deprecated'},ensure_ascii=False))

def cmd_supersede(args):
    init_state();
    with Lock():
        rules=load('RULES.json'); old=next((x for x in rules if x.get('id')==args.old_rule_id),None); new=next((x for x in rules if x.get('id')==args.new_rule_id),None)
        if not old or not new: raise KeyError('RULE_NOT_FOUND')
        old['status']='superseded'; old['superseded_by']=new['id']; old['superseded_at']=now(); old['superseded_reason']=redact(args.reason); save('RULES.json',rules)
    print(json.dumps({'old_rule_id':old['id'],'new_rule_id':new['id'],'status':'superseded'},ensure_ascii=False))

def cmd_migration(args): init_state(); print(json.dumps(load('MIGRATION.json'),ensure_ascii=False,indent=2))

def cmd_audit(args):
    init_state(); rec={'id':uid('AUDIT'),'error_id':args.error_id,'at':now(),'preflight':args.preflight,'rule_matched':args.rule_matched,'executor':args.executor,'reviewer':args.reviewer,'regression':args.regression,'gate':args.gate,'notes':redact(args.notes)}
    with Lock():
        a=load('AUDITS.json'); a.append(rec); save('AUDITS.json',a)
    print(json.dumps(rec,ensure_ascii=False,indent=2))

def ruleset_hash(rules):
    slim=[(r['id'],r.get('statement',''),r.get('status')) for r in sorted(rules,key=lambda x:x['id'])]
    return hashlib.sha256(json.dumps(slim,ensure_ascii=False).encode()).hexdigest()

def next_version(ct):
    reg=load('REGISTRY.json')
    if ct not in reg: return '1.0.0'
    v=reg[ct].get('version','1.0.0'); parts=[int(x) for x in v.split('.')]; parts[-1]+=1; return '.'.join(map(str,parts))

def cmd_candidate(args):
    init_state(); ct=normalize_type(args.task_type); rules=[r for r in load('RULES.json') if r.get('status','active')=='active' and r.get('source')=='correction' and r.get('canonical_task_type')==ct]
    if len(rules)<args.min_rules: raise ValueError(f'INSUFFICIENT_ACTIVE_RULES:{len(rules)}<{args.min_rules}')
    rh=ruleset_hash(rules); reg=load('REGISTRY.json').get(ct,{})
    if reg.get('ruleset_hash')==rh: raise ValueError('NO_RULESET_CHANGE_SINCE_LAST_PROMOTION')
    for c in load('CANDIDATES.json'):
        if c.get('canonical_task_type')==ct and c.get('ruleset_hash')==rh and c.get('status') in ('candidate','promoted'): raise ValueError('DUPLICATE_CANDIDATE_RULESET')
    errors={e['id']:e for e in load('ERRORS.json')}; rids={r['id'] for r in rules}; errids={r.get('error_id') for r in rules}; cases=[c for c in load('REGRESSIONS.json') if c.get('error_id') in errids and c.get('status','active')=='active']
    c={'id':uid('CAND'),'task_type':args.task_type,'canonical_task_type':ct,'version':next_version(ct),'ruleset_hash':rh,'rule_ids':sorted(rids),'case_ids':[x['id'] for x in cases],'results':{},'status':'candidate','created_at':now()}
    with Lock():
        cs=load('CANDIDATES.json'); cs.append(c); save('CANDIDATES.json',cs)
    print(json.dumps(c,ensure_ascii=False,indent=2))

def cmd_candidate_reg(args):
    init_state(); checks=parse_assertion_checks(args.check); case=get_reg(args.case_id)
    req={a['id'] for a in case.get('assertions',[])}
    if set(checks)!=req: raise ValueError('CANDIDATE_ASSERTION_COVERAGE_MISMATCH')
    with Lock():
        cs=load('CANDIDATES.json'); c=next((x for x in cs if x.get('id')==args.candidate_id),None)
        if not c: raise KeyError('CANDIDATE_NOT_FOUND')
        if args.case_id not in c.get('case_ids',[]): raise ValueError('CASE_NOT_REQUIRED_FOR_CANDIDATE')
        c.setdefault('results',{})[args.case_id]={'at':now(),'checks':checks,'passed':all(v['passed'] for v in checks.values())}; save('CANDIDATES.json',cs)
    print(json.dumps({'candidate_id':c['id'],'case_id':args.case_id,'passed':c['results'][args.case_id]['passed']},ensure_ascii=False))

def safe_name(s):
    s=re.sub(r'[^a-z0-9-]+','-',s.lower()).strip('-')
    return s or 'evolved-skill'

def cmd_promote(args):
    init_state();
    with Lock():
        cs=load('CANDIDATES.json'); c=next((x for x in cs if x.get('id')==args.candidate_id),None)
        if not c: raise KeyError('CANDIDATE_NOT_FOUND')
        missing=[cid for cid in c.get('case_ids',[]) if not c.get('results',{}).get(cid,{}).get('passed')]
        if missing: raise ValueError('CANDIDATE_REGRESSION_INCOMPLETE:'+','.join(missing))
        rules={r['id']:r for r in load('RULES.json')}; selected=[rules[rid] for rid in c['rule_ids'] if rid in rules and rules[rid].get('status')=='active']
        if ruleset_hash(selected)!=c['ruleset_hash']: raise ValueError('CANDIDATE_STALE_RULESET')
        name=safe_name(c['canonical_task_type'])+'-evolved'; temp=Path(tempfile.mkdtemp()); root=temp/name; root.mkdir()
        md=['---',f'name: {name}',f'description: Evolved WorkBuddy skill for {c["canonical_task_type"]} based on validated correction rules.',f'description_zh: 基于历史纠错规则进化的 {c["canonical_task_type"]} WorkBuddy 技能。',f'description_en: Evolved WorkBuddy skill for {c["canonical_task_type"]}.',f'version: {c["version"]}','author: local-user','---','',f'# {name}','', '执行该领域任务时必须遵守以下已验证规则：','']
        for r in selected: md.append(f'- [{r["id"]}] {r.get("statement","")}')
        (root/'SKILL.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
        out=state_home()/'released'/f'{name}-{c["version"]}.zip'
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
            z.write(root/'SKILL.md',arcname=f'{name}/SKILL.md')
        c['status']='promoted'; c['promoted_at']=now(); c['artifact']=str(out); save('CANDIDATES.json',cs)
        reg=load('REGISTRY.json'); reg[c['canonical_task_type']]={'version':c['version'],'ruleset_hash':c['ruleset_hash'],'candidate_id':c['id'],'artifact':str(out),'at':now()}; save('REGISTRY.json',reg)
        shutil.rmtree(temp,ignore_errors=True)
    print(json.dumps({'promoted':True,'artifact':str(out),'version':c['version']},ensure_ascii=False,indent=2))

def cmd_snapshot(args):
    init_state(); dst=state_home()/'snapshots'/args.name
    if dst.exists(): raise ValueError('SNAPSHOT_EXISTS')
    dst.mkdir(parents=True)
    for n in STATE_FILES:
        p=state_home()/n
        if p.exists(): shutil.copy2(p,dst/n)
    print(json.dumps({'snapshot':args.name,'path':str(dst)},ensure_ascii=False))

def cmd_rollback(args):
    init_state(); src=state_home()/'snapshots'/args.name
    if not src.exists(): raise ValueError('SNAPSHOT_NOT_FOUND')
    backup='pre-rollback-'+datetime.now().strftime('%Y%m%d-%H%M%S')
    cmd_snapshot(argparse.Namespace(name=backup))
    with Lock():
        for n in STATE_FILES:
            p=src/n
            if p.exists(): shutil.copy2(p,state_home()/n)
    print(json.dumps({'rolled_back_to':args.name,'safety_snapshot':backup},ensure_ascii=False))

def build_parser():
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
    sub.add_parser('doctor').set_defaults(func=cmd_doctor)
    q=sub.add_parser('begin-task'); q.add_argument('--task-type',required=True); q.add_argument('--task',required=True); q.add_argument('--review-policy',choices=['adaptive','strict'],default='adaptive'); q.add_argument('--expect-artifact',choices=['yes','no'],default='no'); q.set_defaults(func=cmd_begin)
    q=sub.add_parser('execute-task'); q.add_argument('--task-id',required=True); q.add_argument('--summary',required=True); q.add_argument('--evidence',default=''); q.add_argument('--artifact',action='append'); q.add_argument('--evidence-file',action='append'); q.set_defaults(func=cmd_execute)
    q=sub.add_parser('submit-review'); q.add_argument('--task-id',required=True); q.add_argument('--reviewer',required=True); q.add_argument('--mode',choices=['self-adversarial','independent'],required=True); q.add_argument('--rule-check',action='append'); q.add_argument('--notes',required=True); q.set_defaults(func=cmd_review)
    q=sub.add_parser('record-regression'); q.add_argument('--task-id',required=True); q.add_argument('--case-id',required=True); q.add_argument('--check',action='append',required=True); q.add_argument('--evidence-file',action='append'); q.set_defaults(func=cmd_regression)
    q=sub.add_parser('close-task'); q.add_argument('--task-id',required=True); q.set_defaults(func=cmd_close)
    q=sub.add_parser('record-correction'); q.add_argument('--task-type',required=True); q.add_argument('--summary',required=True); q.add_argument('--expected',required=True); q.add_argument('--root-cause',required=True); q.add_argument('--severity',choices=['P0','P1','P2','P3','P4'],required=True); q.add_argument('--tags',default=''); q.set_defaults(func=cmd_correction)
    q=sub.add_parser('register-alias'); q.add_argument('--canonical',required=True); q.add_argument('--alias',action='append',required=True); q.set_defaults(func=cmd_alias)
    q=sub.add_parser('deprecate-rule'); q.add_argument('--rule-id',required=True); q.add_argument('--reason',required=True); q.set_defaults(func=cmd_deprecate)
    q=sub.add_parser('supersede-rule'); q.add_argument('--old-rule-id',required=True); q.add_argument('--new-rule-id',required=True); q.add_argument('--reason',required=True); q.set_defaults(func=cmd_supersede)
    sub.add_parser('migration-status').set_defaults(func=cmd_migration)
    q=sub.add_parser('audit-failure'); q.add_argument('--error-id',required=True); [q.add_argument('--'+x,choices=['yes','no','unknown'],required=True) for x in ['preflight','rule-matched','executor','reviewer','regression','gate']]; q.add_argument('--notes',required=True); q.set_defaults(func=cmd_audit)
    q=sub.add_parser('candidate'); q.add_argument('--task-type',required=True); q.add_argument('--min-rules',type=int,default=3); q.set_defaults(func=cmd_candidate)
    q=sub.add_parser('candidate-regression'); q.add_argument('--candidate-id',required=True); q.add_argument('--case-id',required=True); q.add_argument('--check',action='append',required=True); q.set_defaults(func=cmd_candidate_reg)
    q=sub.add_parser('promote'); q.add_argument('--candidate-id',required=True); q.set_defaults(func=cmd_promote)
    q=sub.add_parser('snapshot'); q.add_argument('--name',required=True); q.set_defaults(func=cmd_snapshot)
    q=sub.add_parser('rollback'); q.add_argument('--name',required=True); q.set_defaults(func=cmd_rollback)
    return p

def main():
    try:
        parser=build_parser(); args=parser.parse_args(); args.func(args)
    except SystemExit: raise
    except Exception as e:
        print(json.dumps({'ok':False,'error':str(e)},ensure_ascii=False,indent=2)); sys.exit(1)
if __name__=='__main__': main()
