---
name: workbuddy-evolution-kernel
description: WorkBuddy persistent correction and controlled self-improvement kernel. Use for complex tasks, repeated mistakes, user corrections, preflight review, regression verification, and gated completion.
description_zh: WorkBuddy 持久化纠错与受控自我进化内核；用于复杂任务前检、用户纠错、重复错误拦截、证据复验、回归测试和交付闸门。
description_en: Persistent correction and controlled self-improvement kernel for WorkBuddy with evidence-backed review, regression checks, and gated completion.
version: 2.2.0
author: local-user
user-invocable: true
disable-model-invocation: false
allowed-tools: Bash
---

# WorkBuddy Evolution Kernel V2.2 — 深度适配版

本 Skill 在 WorkBuddy 支持的 `SKILL.md + scripts + references` 结构内运行。它不修改宿主模型，不绕过宿主权限，也不声称单个 Skill 能拦截所有会话；它通过本地持久化纠错库、证据指纹、规则生命周期、逐条 Reviewer 检查和历史回归，把“纠错”从口头承诺变成可验证流程。

## 0. 宿主边界

- WorkBuddy Skill 由模型按相关性调用；关闭 Skill 后不会参与自动调用。对关键任务可显式调用本 Skill。
- `${CODEBUDDY_SKILL_DIR}` 是当前 Skill 目录占位符；脚本只能在实际有 Python 运行时的环境执行。
- 普通 Skill 不假装拥有独立 Agent。`adaptive` 允许对抗式自审；只有宿主确有独立 Agent/专家上下文时才记录 `independent`。
- 所有宿主安全、权限、确认机制优先于本地规则。
- 本 Skill 的持久化默认是**本机用户级**，用于跨项目复用；不承诺跨设备同步。可用 `WORKBUDDY_EVOLUTION_HOME` 指定状态目录，或 `WORKBUDDY_EVOLUTION_SCOPE=project` 改为项目级。

## 1. 首次使用必须实际验收

运行：

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" doctor
python "${CODEBUDDY_SKILL_DIR}/scripts/selftest.py"
```

若环境只有 `python3`，用 `python3` 替代。只有真正出现 `ALL_TESTS_PASSED` 才能声称脚本层验收通过。

## 2. 复杂任务强制生命周期

### A. Begin / Preflight

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" begin-task \
  --task-type "<稳定任务类型>" \
  --task "<脱敏后的任务摘要>" \
  --review-policy adaptive \
  --expect-artifact yes
```

文件/代码/配置/报告等应生成产物的任务用 `--expect-artifact yes`；纯分析可用 `no`。返回的 `hard_rules` 和 `regression_cases` 是本次必须检查的清单。

### B. Execute

真正完成工作后登记实际产物：

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" execute-task \
  --task-id "<TASK-ID>" \
  --summary "<实际完成内容>" \
  --evidence "<实际验证摘要>" \
  --artifact "<实际文件或目录路径>"
```

文件会记录 SHA-256。目录会完整遍历并建立指纹；超过安全扫描上限或扫描不完整会被标记为不可放行，不能靠“大目录截断扫描”蒙混过 Gate。重执行会使旧 Review、Regression、Gate 全部失效。

### C. Reviewer 必须逐条检查 HARD Rule

普通 WorkBuddy：

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" submit-review \
  --task-id "<TASK-ID>" \
  --reviewer "self-adversarial" \
  --mode self-adversarial \
  --rule-check "<RULE-ID>=pass:具体检查证据" \
  --notes "从用户目标、历史错误、实际产物重新找错后的结论"
```

对 `begin-task` 返回的每条 HARD Rule 都必须有 `--rule-check`。缺一条、失败一条或只写空泛文字，Gate 都不通过。

如 WorkBuddy 当前确有真正独立 Agent/专家上下文，可使用 `--mode independent`；`strict` 策略只接受 independent。

### D. Regression 必须逐断言核对

每个历史案例包含 `assertions`。逐条登记：

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" record-regression \
  --task-id "<TASK-ID>" \
  --case-id "<TEST-ID>" \
  --check "<ASSERT-ID>=pass:具体如何验证" \
  --evidence-file "<可复验文件路径>"
```

不能再用一个泛化 `passed=yes` 让整条历史案例假通过。案例有几条 assertion，就必须检查几条。

### E. Gate 重新复验真实证据

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" close-task --task-id "<TASK-ID>"
```

Gate 会重新检查：
- 当前 revision 是否执行过；
- 应交付产物是否存在；
- 产物和回归证据文件是否仍存在且指纹未变化；
- 目录指纹是否完整；
- Reviewer 是否覆盖全部适用 HARD Rule；
- 所有历史 regression assertion 是否逐条通过；
- `strict` 时 Reviewer 是否真实 independent。

只有 `GATE_PASS=true` 才能宣称“完成/已修复/可交付”。

## 3. 用户纠错必须固化，而且去重

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" record-correction \
  --task-type "<task_type>" \
  --summary "<实际错误>" \
  --expected "<以后必须满足的可验证条件；多条用分号或换行分隔>" \
  --root-cause "<根因>" \
  --severity P1 \
  --tags "关键词1,关键词2,关键词3"
```

V2.2 会跨 `task_type` 名称做语义聚类，避免通过“通达信公式 / tdx_formula / 指标公式”等不同命名绕过重复错误识别。命中旧错误时：
- 不制造重复 Rule；
- 不制造重复 Regression Case；
- 合并触发词和新断言；
- `repeat_count + 1`；
- P0/P1/P2 再犯返回 `SELF_EVOLUTION_FAILURE=true`。

如长期使用多个别名，可显式登记：

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" register-alias --canonical "tongdaxin_formula" --alias "通达信公式" --alias "tdx_formula"
```

## 4. 规则支持废止和替代

错误规则不能永久堆积。确认旧规则失效时：

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" deprecate-rule --rule-id "<RULE-ID>" --reason "<原因>"
```

有新规则替代旧规则时：

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" supersede-rule --old-rule-id "<OLD>" --new-rule-id "<NEW>" --reason "<替代原因>"
```

`begin-task` 只加载 active 规则，避免“旧规则 + 新规则”长期互相打架。

## 5. 旧版经验自动迁移

首次初始化会扫描当前状态目录以及旧版常见 workspace 路径，先备份再做去重合并；不会删除旧库。查看迁移结果：

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" migration-status
```

## 6. Candidate 受控进化

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" candidate --task-type "<task_type>" --min-rules 3
```

只有 active 规则进入 Candidate。同一规则集合不会重复制造 Candidate；规则确有变化时，新 Candidate 版本自动递增。

Candidate 的每条历史案例也必须逐 assertion 回放：

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" candidate-regression \
  --candidate-id "<CAND-ID>" \
  --case-id "<TEST-ID>" \
  --check "<ASSERT-ID>=pass:实际回放证据"
```

全部通过才允许：

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" promote --candidate-id "<CAND-ID>"
```

Promote 只生成新的 WorkBuddy Skill ZIP，不静默覆盖当前稳定版。

## 7. 快照与回滚

```bash
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" snapshot --name before-change
python "${CODEBUDDY_SKILL_DIR}/scripts/evolution.py" rollback --name before-change
```

这是纠错状态库回滚，不是 WorkBuddy 应用回滚。

## 8. 强制禁止

- 禁止把计划、承诺、待办当交付。
- 禁止没运行测试就声称“已通过”。
- 禁止用旧 revision 的 Review/Regression 给新执行放行。
- 禁止 Reviewer 漏检适用 HARD Rule。
- 禁止 Regression 用单个空泛 `passed=yes` 冒充逐断言验证。
- 禁止产物/证据在 Gate 前被删除、篡改后仍宣称通过。
- 禁止大目录只扫描前若干项就当成完整证据。
- 禁止重复错误无限制造 Rule/Test 垃圾。
- 禁止废止规则继续参与 preflight。
- 禁止密钥、Token、密码进入纠错库；脚本会基础脱敏，模型仍应主动避免传入秘密。
- 禁止本地规则覆盖 WorkBuddy 宿主安全与权限。

详细兼容边界见 @references/WORKBUDDY_COMPATIBILITY.md；状态与验收协议见 @references/OPERATING_PROTOCOL.md。
