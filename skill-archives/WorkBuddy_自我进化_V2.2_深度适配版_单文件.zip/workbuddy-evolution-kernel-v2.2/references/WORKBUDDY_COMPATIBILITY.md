# WorkBuddy 兼容边界

1. 本包采用 WorkBuddy 官方 Skill 结构：根目录 SKILL.md，可选 references/ 与 scripts/。
2. 脚本通过 Bash 调用；`${CODEBUDDY_SKILL_DIR}` 由兼容的 Skill 运行时解析为当前技能目录。
3. 单 Skill 不是全局中间件，不能保证所有会话无条件自动触发。关闭 Skill 后不会自动参与模型调用。
4. 独立 Reviewer 不是普通 Skill 的必备宿主能力。默认 adaptive：无独立上下文时采用 self-adversarial，并降低保证等级。
5. 本包使用 Python 标准库，不捆绑 Python。缺运行时必须报告缺失，不能伪造执行。
6. 默认持久化到本机用户级目录，目的是同一机器跨项目学习；不承诺 WorkBuddy 账号跨设备同步。
7. Hooks / Agent / Rule 组合属于更高层插件能力；本 Skill 不假装拥有未安装的宿主级 Hook。
