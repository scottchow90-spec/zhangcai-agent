# V2.2 运行协议

优先级：宿主安全/权限 > 用户当前明确要求 > active HARD Rule > active SOFT Rule > Skill 默认策略 > 模型自行判断。

每个复杂任务至少包含：begin-task → execute-task → submit-review → record-regression(如有) → close-task。

关键不变量：
- 每次 execute-task 都创建新 revision，并使旧 review/regression/gate 失效。
- Gate 只接受当前 revision 的证据。
- Evidence 文件在 Gate 时重新哈希；变化即失败。
- 大目录指纹扫描不完整即失败。
- Reviewer 必须覆盖 begin-task 返回的全部 HARD Rule。
- Regression 必须覆盖案例的全部 assertions。
- Rule status 非 active 时不得加载。
- 相似错误聚类后复用原 rule/case，避免数据库膨胀。
