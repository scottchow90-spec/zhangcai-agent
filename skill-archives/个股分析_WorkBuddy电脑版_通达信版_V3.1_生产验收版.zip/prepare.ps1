[CmdletBinding()]
param(
    [string]$TdxRoot,
    [string]$PythonExe,
    [switch]$NoInstall
)
$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
$stateRoot = $env:WORKBUDDY_STOCK_STATE
if (-not $stateRoot) { $stateRoot = Join-Path $env:LOCALAPPDATA 'WorkBuddyIndividualAnalysis' }
$entryPath = Join-Path $PSScriptRoot 'scripts\codex_entry.py'

function Test-PythonCandidate([string]$Candidate) {
    if (-not $Candidate -or $Candidate -like '*WindowsApps*' -or -not (Test-Path -LiteralPath $Candidate -PathType Leaf)) { return $false }
    try {
        $result = & $Candidate -c "import struct,sys; print('READY' if sys.version_info >= (3,10) and struct.calcsize('P') == 8 else 'UNSUPPORTED')" 2>$null
        return $LASTEXITCODE -eq 0 -and ($result -join '') -eq 'READY'
    } catch { return $false }
}

if ($PythonExe) {
    if (-not (Test-PythonCandidate $PythonExe)) { throw 'PythonExe must point to Python 3.10 or later, 64-bit.' }
} else {
    $candidatePaths = [System.Collections.Generic.List[string]]::new()
    $installed = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($installed) { $candidatePaths.Add($installed.Source) }
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        $launched = & $launcher.Source -3 -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0) { $candidatePaths.Add(($launched -join '').Trim()) }
    }
    $bundledRoot = Join-Path $env:USERPROFILE '.workbuddy\binaries\python\versions'
    if (Test-Path -LiteralPath $bundledRoot) {
        foreach ($candidate in @(Get-ChildItem -LiteralPath $bundledRoot -Filter python.exe -File -Recurse -ErrorAction SilentlyContinue)) {
            $candidatePaths.Add($candidate.FullName)
        }
    }
    foreach ($candidate in $candidatePaths) {
        if (Test-PythonCandidate $candidate) { $PythonExe = $candidate; break }
    }
    if (-not $PythonExe) { throw 'Install Python 3.10+ 64-bit from python.org, or pass -PythonExe with its full path.' }
}

if (-not $TdxRoot) {
    $candidates = [System.Collections.Generic.List[string]]::new()
    foreach ($drive in @(Get-PSDrive -PSProvider FileSystem)) {
        foreach ($name in @('TDX', 'tdx', 'new_tdx')) {
            $candidate = Join-Path $drive.Root $name
            if ((Test-Path -LiteralPath (Join-Path $candidate 'TdxW.exe')) -and (Test-Path -LiteralPath (Join-Path $candidate 'T0002'))) {
                if (-not $candidates.Contains($candidate)) { $candidates.Add($candidate) }
            }
        }
    }
    $distinct = @($candidates | Sort-Object -Unique)
    if ($distinct.Count -eq 1) { $TdxRoot = $distinct[0] }
    else { $TdxRoot = Read-Host 'TongDaXin folder containing TdxW.exe' }
}
if (-not (Test-Path -LiteralPath (Join-Path $TdxRoot 'TdxW.exe')) -or -not (Test-Path -LiteralPath (Join-Path $TdxRoot 'T0002'))) {
    throw 'Invalid TongDaXin folder: TdxW.exe and T0002 are required.'
}

& $PythonExe $entryPath verify
if ($LASTEXITCODE -ne 0) { throw 'Package integrity check failed. Extract the original ZIP again.' }
if ($NoInstall) {
    Write-Output 'DRY_RUN_OK: package, Python and selected TongDaXin folder checked; no environment changes.'
    exit 0
}
$venvRoot = Join-Path $stateRoot '.venv'
$venvPython = Join-Path $venvRoot 'Scripts\python.exe'
if (-not (Test-Path -LiteralPath $venvPython)) {
    if (Test-Path -LiteralPath $venvRoot) { throw 'Incomplete environment exists. Choose another WORKBUDDY_STOCK_STATE folder.' }
    & $PythonExe -m venv $venvRoot
    if ($LASTEXITCODE -ne 0) { throw 'Python environment creation failed.' }
}
& $venvPython -m pip install --disable-pip-version-check -r (Join-Path $PSScriptRoot 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check the internet connection and retry.' }
& $venvPython $entryPath configure --tdx-root $TdxRoot
if ($LASTEXITCODE -ne 0) { throw 'TongDaXin configuration failed.' }
& $venvPython $entryPath selftest
if ($LASTEXITCODE -ne 0) { throw 'Offline self-test failed.' }
& $venvPython $entryPath doctor
exit $LASTEXITCODE
