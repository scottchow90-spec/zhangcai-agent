"""Existing sixteen-row analysis, with portable connection owned by technical.py."""
import json, struct, math, os, re
from datetime import datetime, timedelta, timezone
from pathlib import Path

CN_TZ = timezone(timedelta(hours=8))

def resolve_quote_fields(records: list[dict], snapshot: dict, bar_meta: dict) -> dict:
    """Use the canonical analysis bars for OHLCV; snapshot fields are ancillary only."""
    if len(records) < 2:
        raise RuntimeError('至少需要两条日线才能确定当前行情与昨收')
    current = records[-1]
    previous = records[-2]
    close_value = float(current['C'])
    open_value = float(current['O'])
    high_value = float(current['H'])
    low_value = float(current['L'])
    volume_value = int(current['V'])
    amount_raw = float(current.get('A') or 0.0)
    try:
        snapshot_now = float(snapshot.get('Now') or 0.0)
        snapshot_matches = snapshot_now > 0 and abs(snapshot_now - close_value) <= max(0.02, abs(close_value) * 1e-05)
    except (TypeError, ValueError):
        snapshot_matches = False
    amount_value = amount_raw / 10000.0 if amount_raw > 0 else float(snapshot.get('Amount') or 0.0) if snapshot_matches else 0.0
    persisted_average = amount_raw / volume_value / 100.0 if amount_raw > 0 and volume_value > 0 else close_value
    average_value = float(snapshot.get('Average') or persisted_average) if snapshot_matches else persisted_average
    inside_value = int(snapshot.get('Inside') or 0) if snapshot_matches else 0
    outside_value = int(snapshot.get('Outside') or 0) if snapshot_matches else 0
    return {'close': close_value, 'open': open_value, 'high': high_value, 'low': low_value, 'last_close': float(previous['C']), 'volume': volume_value, 'amount': amount_value, 'average': average_value, 'inside': inside_value, 'outside': outside_value, 'source': str(bar_meta.get('bar_source', 'unknown'))}

class DaniuxianAnalyzer:
    FORMULA_RUNTIME_NAME = '大牛线撑压版'
    INDEX_SYMBOLS = {'000001.SH', '999999.SH'}
    SUBSYSTEMS = [(1, '主趋势线', 'EMA(EMA(C,10),10)', '主趋势线', 'TQ'), (2, 'EMA均线分层', 'EMA5/10/20 + EMA173/193/213', 'EMA9,EMA10,EMA11', 'TQ'), (3, 'K线颜色信号', '按原公式SSX4/SSX5及白K覆盖条件判定', '内置渲染', '手动'), (4, '流通市值', 'FINANCE(40)/1e8', '流通市值', 'TQ'), (5, 'DX动量指标', '100*EMA(EMA(MTM,6),6)/EMA(EMA(ABS(MTM),6),6)', '内置', '手动'), (6, '参与与离场信号', '短线力量低位转强=参与提醒 / 高位转弱=离场提醒', '内置主图', '手动'), (7, '控盘程度', '(VAW1-REF)/REF*1000, VAW1=EMA(EMA(C,13),13)', '内置', '手动'), (8, '财神短线', '(EMA(C,8)-EMA(C,21))*50 / EMA(财,3)', '内置', '手动'), (9, '庄进/庄出', 'OUTPUT4(庄进) + OUTPUT6(庄出)', 'OUTPUT4,OUTPUT6', 'TQ'), (10, '妖股识别', 'XDF+涨幅>9.5%+FLIGA+VARAA原公式复合条件', '妖股标记', 'TQ'), (11, '龙头参与区', 'CB=VOL/REF(VOL,1)；涨幅>=9.9%=第一参与区 / >=7%=第二参与区', '内置主图', '手动'), (12, '龙回头', '13日涨停+CP跌破震仓线', 'OUTPUT5', 'TQ'), (13, '点火信号', 'CROSS(EMA3,EMA21)', 'OUTPUT9', 'TQ'), (14, '起爆/题材共振', 'KDJ三线关系+流通市值+涨停幅度+价格+两日唯一性', 'OUTPUT3+起爆1', 'TQ'), (15, 'BOLL+多重均线', 'BOLL(20,2)+MA5/10/20/30/54/60/120', '内置主图', '手动'), (16, '核心黄金分割撑压', '大牛线撑压版核心黄金分割支撑/压力', '支撑一,支撑二,压力一,压力二,OUTPUT66', 'TQ')]

    def _configure_symbol(self, stock_code: str):
        raw = str(stock_code).strip().upper()
        match = re.fullmatch('(\\d{6})(?:\\.(SH|SZ|BJ))?', raw)
        if not match:
            raise ValueError(f'invalid_stock_code:{stock_code}')
        code, market = match.groups()
        if not market:
            market = 'SH' if code.startswith(('5', '6', '9')) else 'BJ' if code.startswith(('4', '8')) else 'SZ'
        self.code = code
        self.market = market
        self.symbol = f'{code}.{market}'
        self.is_index = self.symbol in self.INDEX_SYMBOLS or (market == 'SH' and code.startswith('000')) or (market == 'SZ' and code.startswith('399'))

    def _read_day_file(self, path):
        records = []
        if not os.path.exists(path):
            return records
        with open(path, 'rb') as f:
            data = f.read()
        for i in range(0, len(data), 32):
            if i + 32 > len(data):
                break
            rec = data[i:i + 32]
            date_int = struct.unpack('I', rec[0:4])[0]
            records.append({'date': f'{date_int // 10000}-{date_int % 10000 // 100:02d}-{date_int % 100:02d}', 'O': struct.unpack('I', rec[4:8])[0] / 100, 'H': struct.unpack('I', rec[8:12])[0] / 100, 'L': struct.unpack('I', rec[12:16])[0] / 100, 'C': struct.unpack('I', rec[16:20])[0] / 100, 'A': struct.unpack('f', rec[20:24])[0], 'V': struct.unpack('I', rec[24:28])[0]})
        return records

    @staticmethod
    def _normalize_verified_trade_date(value):
        """Normalize the verified trade date to YYYY-MM-DD."""
        raw_value = str(value or '').strip()
        if not raw_value:
            return ''
        for date_format in ('%Y%m%d', '%Y-%m-%d'):
            try:
                return datetime.strptime(raw_value, date_format).strftime('%Y-%m-%d')
            except ValueError:
                continue
        raise RuntimeError('BIG_BULL_VERIFIED_TRADE_DATE must be YYYYMMDD or YYYY-MM-DD')

    @staticmethod
    def _merge_verified_snapshot_bar(records, snap, verified_trade_date):
        """Merge a current snapshot only when its trade date was independently verified."""
        if not records:
            return (records, {'bar_source': 'missing_local_history', 'local_last_date': '', 'analysis_trade_date': '', 'snapshot_fetched_at': datetime.now(CN_TZ).isoformat(timespec='seconds'), 'persisted_records': 0})
        fetched_at = datetime.now(CN_TZ)
        local_last_date = records[-1]['date']
        meta = {'bar_source': 'persisted_tdx_day_only', 'local_last_date': local_last_date, 'analysis_trade_date': local_last_date, 'snapshot_fetched_at': fetched_at.isoformat(timespec='seconds'), 'persisted_records': len(records), 'snapshot_date_verified': False}
        if not verified_trade_date:
            return (records, meta)
        verified_trade_date = DaniuxianAnalyzer._normalize_verified_trade_date(verified_trade_date)
        trade_day = datetime.strptime(verified_trade_date, '%Y-%m-%d').date()
        if trade_day > fetched_at.date():
            raise RuntimeError(f'验证交易日晚于本机日期: {trade_day} > {fetched_at.date()}')
        if verified_trade_date < local_last_date:
            raise RuntimeError(f'验证交易日早于本地最新日线: verified={verified_trade_date} local={local_last_date}')
        try:
            current_bar = {'date': verified_trade_date, 'O': float(snap['Open']), 'H': float(snap['Max']), 'L': float(snap['Min']), 'C': float(snap['Now']), 'V': int(snap['Volume']), 'synthetic': True}
            previous_close = float(snap['LastClose'])
        except (KeyError, TypeError, ValueError) as exc:
            raise RuntimeError(f'TQ快照字段不完整，不能合成当日日线: {snap}') from exc
        if current_bar['L'] <= 0 or current_bar['H'] < current_bar['L']:
            raise RuntimeError(f'TQ快照高低价非法: {current_bar}')
        if current_bar['H'] < max(current_bar['O'], current_bar['C']):
            raise RuntimeError(f'TQ快照最高价小于开盘或最新价: {current_bar}')
        if current_bar['L'] > min(current_bar['O'], current_bar['C']):
            raise RuntimeError(f'TQ快照最低价大于开盘或最新价: {current_bar}')
        if current_bar['V'] <= 0:
            raise RuntimeError(f"TQ快照成交量非法: {current_bar['V']}")
        merged = list(records)
        reference_close = records[-1]['C'] if verified_trade_date > local_last_date else records[-2]['C'] if len(records) > 1 else previous_close
        close_tolerance = max(0.02, abs(previous_close) * 1e-05)
        if abs(reference_close - previous_close) > close_tolerance:
            raise RuntimeError(f'TQ快照昨收与本地前一日收盘不一致，禁止混合数据: snapshot={previous_close:.2f} local={reference_close:.2f}')
        if verified_trade_date == local_last_date:
            merged[-1] = current_bar
            bar_source = 'verified_tq_snapshot_replace'
        else:
            merged.append(current_bar)
            bar_source = 'verified_tq_snapshot_append'
        meta.update({'bar_source': bar_source, 'analysis_trade_date': verified_trade_date, 'snapshot_date_verified': True})
        return (merged, meta)

    @staticmethod
    def EMA(data, period):
        result, k = ([data[0]], 2.0 / (period + 1))
        for i in range(1, len(data)):
            result.append(data[i] * k + result[-1] * (1 - k))
        return result

    @staticmethod
    def MA(data, period):
        result = []
        for i in range(len(data)):
            if i < period - 1:
                result.append(sum(data[:i + 1]) / (i + 1))
            else:
                result.append(sum(data[i - period + 1:i + 1]) / period)
        return result

    @staticmethod
    def SMA(data, nv, mv):
        result = [data[0]]
        for i in range(1, len(data)):
            result.append((data[i] * mv + result[-1] * (nv - mv)) / nv)
        return result

    @staticmethod
    def STD(data, period):
        result = []
        for i in range(len(data)):
            if i < period - 1:
                result.append(0)
            else:
                w = data[i - period + 1:i + 1]
                m = sum(w) / period
                result.append(math.sqrt(sum(((x - m) ** 2 for x in w)) / period))
        return result

    @staticmethod
    def LLV(data, period):
        return [min(data[max(0, i - period + 1):i + 1]) for i in range(len(data))]

    @staticmethod
    def HHV(data, period):
        return [max(data[max(0, i - period + 1):i + 1]) for i in range(len(data))]

    @staticmethod
    def CROSS(a, b):
        return [a[i] > b[i] and a[i - 1] <= b[i - 1] if i > 0 else False for i in range(len(a))]

    @staticmethod
    def COUNT(cond, period):
        return [sum((1 for j in range(max(0, i - period + 1), i + 1) if cond[j])) for i in range(len(cond))]

    @staticmethod
    def FILTER(cond, period):
        """Tongdaxin FILTER(X,N): keep a trigger and suppress the following N bars."""
        out = [False] * len(cond)
        blocked_until = -1
        for i, flag in enumerate(cond):
            if bool(flag) and i > blocked_until:
                out[i] = True
                blocked_until = i + max(int(period), 0)
        return out

    @staticmethod
    def BARSLAST(cond):
        out, last = [], None
        for i, flag in enumerate(cond):
            if bool(flag):
                last = i
            out.append(i - last if last is not None else i + 1)
        return out

    def RSI(self, data, period):
        gains = [max(data[i] - data[i - 1], 0) if i > 0 else 0 for i in range(len(data))]
        losses = [abs(min(data[i] - data[i - 1], 0)) if i > 0 else 0 for i in range(len(data))]
        ag = self.SMA(gains, period, 1)
        al = self.SMA(losses, period, 1)
        return [100 - 100 / (1 + ag[i] / al[i]) if al[i] != 0 else 100 for i in range(len(data))]

    def analyze_all(self, raw: dict) -> dict:
        """16子系统完整计算"""
        snap, info, dnx, records = (raw['snap'], raw['info'], raw['dnx'], raw['records'])
        bar_meta = raw.get('bar_meta', {})
        if len(records) < 120:
            raise RuntimeError(f'本地日线不足120条，无法执行16子系统: code={self.code} records={len(records)}')
        v = dnx.get('Value', {})
        n = len(records)
        idx = -1
        C = [r['C'] for r in records]
        O = [r['O'] for r in records]
        H = [r['H'] for r in records]
        L = [r['L'] for r in records]
        V_arr = [r['V'] for r in records]
        A_arr = [float(r.get('A') or 0.0) for r in records]
        ema5 = self.EMA(C, 5)
        ema10 = self.EMA(C, 10)
        ema20 = self.EMA(C, 20)
        ema3 = self.EMA(C, 3)
        ema21 = self.EMA(C, 21)
        ema13 = self.EMA(C, 13)
        ema173 = self.EMA(C, 173)
        ema193 = self.EMA(C, 193)
        ema213 = self.EMA(C, 213)
        main_trend_local = self.EMA(self.EMA(C, 10), 10)
        ma5 = self.MA(C, 5)
        ma10 = self.MA(C, 10)
        ma20 = self.MA(C, 20)
        ma30 = self.MA(C, 30)
        ma54 = self.MA(C, 54)
        ma60 = self.MA(C, 60)
        ma120 = self.MA(C, 120)
        boll_ma = self.MA(C, 20)
        boll_std = self.STD(C, 20)
        UB = [boll_ma[i] + 2 * boll_std[i] for i in range(n)]
        LB = [boll_ma[i] - 2 * boll_std[i] for i in range(n)]
        Nk = 9
        rsv = [(C[i] - self.LLV(L, Nk)[i]) / (self.HHV(H, Nk)[i] - self.LLV(L, Nk)[i]) * 100 if self.HHV(H, Nk)[i] != self.LLV(L, Nk)[i] else 50 for i in range(n)]
        kdj_k = self.SMA(rsv, 3, 1)
        kdj_d = self.SMA(kdj_k, 3, 1)
        kdj_j = [3 * kdj_k[i] - 2 * kdj_d[i] for i in range(n)]
        ema12 = self.EMA(C, 12)
        ema26 = self.EMA(C, 26)
        dif = [ema12[i] - ema26[i] for i in range(n)]
        dea = self.EMA(dif, 9)
        macd_bar = [2 * (dif[i] - dea[i]) for i in range(n)]
        rsi6 = self.RSI(C, 6)
        rsi14 = self.RSI(C, 14)
        mtm_arr = [C[i] - C[i - 1] if i > 0 else 0 for i in range(n)]
        dx_ema6 = self.EMA(mtm_arr, 6)
        dx_ema6b = self.EMA(dx_ema6, 6)
        dx_abs6 = self.EMA([abs(m) for m in mtm_arr], 6)
        dx_abs6b = self.EMA(dx_abs6, 6)
        dx_vals = [100 * dx_ema6b[i] / dx_abs6b[i] if dx_abs6b[i] != 0 else 0 for i in range(n)]
        wr10 = [(self.HHV(H, 10)[i] - C[i]) / (self.HHV(H, 10)[i] - self.LLV(L, 10)[i]) * 100 if self.HHV(H, 10)[i] != self.LLV(L, 10)[i] else 50 for i in range(n)]
        vaw1 = self.EMA(ema13, 13)
        kongpan = [(vaw1[i] - vaw1[i - 1]) / vaw1[i - 1] * 1000 if i > 0 and vaw1[i - 1] != 0 else 0 for i in range(n)]
        Pv = 21
        ema8 = self.EMA(C, 8)
        ema21_cai = self.EMA(C, Pv)
        cai_arr = [(ema8[i] - ema21_cai[i]) * 50 for i in range(n)]
        shen_arr = self.EMA(cai_arr, 3)
        max_diff = [max(C[i] - C[i - 1], 0) if i > 0 else 0 for i in range(n)]
        abs_diff = [abs(C[i] - C[i - 1]) if i > 0 else 0 for i in range(n)]
        sma_max = self.SMA(max_diff, 2, 1)
        sma_abs = self.SMA(abs_diff, 2, 1)
        cp_vals = [sma_max[i] / sma_abs[i] * 100 if sma_abs[i] != 0 else 0 for i in range(n)]

        def tq_seq(key: str, fallback):
            raw = v.get(key)
            if raw in (None, [], ''):
                raw = fallback
            if not isinstance(raw, list):
                raw = [raw]
            vals = []
            for item in raw:
                try:
                    vals.append(float(item))
                except Exception:
                    vals.append(0.0)
            if not vals:
                vals = [0.0]
            while len(vals) < 2:
                vals.insert(0, vals[-1])
            return vals

        def tq_text_seq(key: str, default: str='0.00'):
            raw = v.get(key)
            if raw in (None, [], ''):
                raw = [default]
            if not isinstance(raw, list):
                raw = [raw]
            return [str(x) for x in raw] or [default]

        def tq_latest_value(key: str):
            raw_value = v.get(key)
            if isinstance(raw_value, list):
                return raw_value[-1] if raw_value else None
            return raw_value

        def tq_optional_float(key: str):
            raw_value = tq_latest_value(key)
            if raw_value is None or str(raw_value).strip().upper() in {'', 'NA', 'N/A', '--'}:
                return None
            try:
                numeric_value = float(raw_value)
            except (TypeError, ValueError):
                return None
            return numeric_value if math.isfinite(numeric_value) else None

        def tq_optional_text(key: str):
            raw_value = tq_latest_value(key)
            if raw_value is None or str(raw_value).strip().upper() in {'', 'NA', 'N/A', '--'}:
                return 'NA'
            return str(raw_value).strip()
        main_trend_tq = tq_seq('主趋势线', main_trend_local)
        main_trend = main_trend_local
        ema9_tq = tq_seq('EMA9', ema5)
        ema10_tq = tq_seq('EMA10', ema10)
        ema11_tq = tq_seq('EMA11', ema20)
        o3 = tq_text_seq('OUTPUT3')
        o4 = tq_text_seq('OUTPUT4')
        o5 = tq_text_seq('OUTPUT5')
        o6 = tq_text_seq('OUTPUT6')
        o9 = tq_text_seq('OUTPUT9')
        float_cap = tq_seq('流通市值', [0.0])[-1]
        zt_price = tq_seq('涨停价', [float(snap.get('LastClose', 0) or 0) * 1.1])[-1]
        dt_price = tq_seq('跌停价', [float(snap.get('LastClose', 0) or 0) * 0.9])[-1]
        blocks = tq_text_seq('OUTPUT47', '')[-1]
        support_1 = tq_optional_float('支撑一')
        support_2 = tq_optional_float('支撑二')
        pressure_1 = tq_optional_float('压力一')
        pressure_2 = tq_optional_float('压力二')
        output66 = tq_optional_text('OUTPUT66')
        quote = resolve_quote_fields(records, snap, bar_meta)
        close_p = quote['close']
        last_close = quote['last_close']
        open_p = quote['open']
        high_p = quote['high']
        low_p = quote['low']
        volume = quote['volume']
        amount = quote['amount']
        avg_p = quote['average']
        inside = quote['inside']
        outside = quote['outside']
        valid_supports = [value for value in (support_1, support_2) if value is not None and value <= close_p]
        valid_pressures = [value for value in (pressure_1, pressure_2) if value is not None and value >= close_p]
        nearest_support = max(valid_supports) if valid_supports else None
        nearest_pressure = min(valid_pressures) if valid_pressures else None
        if nearest_support is not None and nearest_pressure is not None:
            support_pressure_status = '双向撑压有效'
        elif nearest_support is not None:
            support_pressure_status = '仅支撑有效'
        elif nearest_pressure is not None:
            support_pressure_status = '仅压力有效'
        else:
            support_pressure_status = '撑压不可判定'
        name = info.get('Name', '')
        j_zgb = float(info.get('J_zgb', '0'))
        j_jzc = float(info.get('J_jzc', '0'))
        j_mgjzc = float(info.get('J_mgjzc', '0'))
        j_mgsy = float(info.get('J_mgsy', '0'))
        change_pct = (close_p - last_close) / last_close * 100
        # 原公式 CB:=VOL/REF(VOL,1)，禁止以5日均量替代。
        prev_volume = V_arr[-2] if n >= 2 else 0
        cb_r = volume / prev_volume if prev_volume > 0 else None
        is_zt = close_p >= zt_price * 0.999
        trend_up = main_trend[-1] > main_trend[-2]
        bullish = ema5[idx] > ema10[idx] > ema20[idx]
        ssx4 = ema5[idx] > ema20[idx]
        ssx5 = ema5[idx] < ema20[idx]
        ssx6 = ema5[idx] > ema10[idx]
        ssx7 = ema5[idx] < ema10[idx]
        white_override = (ssx5 and ssx6) or (ssx4 and ssx7)
        kline_color = '白K' if white_override else '红K' if ssx4 else '绿K' if ssx5 else '原色/无覆盖'
        # 原公式“金叉”变量实际为三线相对位置，不是CROSS；保持原语义。
        jincha_kdj = kdj_k[idx] > kdj_d[idx] and kdj_j[idx] > kdj_d[idx] and kdj_j[idx] > kdj_k[idx]
        # 庄进/庄出按源码直接复刻；不再用不透明OUTPUT编号替代公式语义。
        jj_seq = []
        for i in range(n):
            if V_arr[i] > 0 and A_arr[i] > 0:
                jj_seq.append(A_arr[i] / V_arr[i] / 100.0)
            else:
                jj_seq.append(C[i])
        if avg_p and avg_p > 0:
            jj_seq[-1] = avg_p
        cross_cai_shen = self.CROSS(cai_arr, shen_arr)
        cross_shen_cai = self.CROSS(shen_arr, cai_arr)
        zhuang_raw = []
        stj1_raw, stj2_raw = [], []
        for i in range(n):
            jj = jj_seq[i]
            prev_kongpan = kongpan[i - 1] if i > 0 else kongpan[i]
            btj11 = bool(jj and (C[i] - jj) / jj < -0.03)
            btj2 = bool(kongpan[i] > prev_kongpan and kongpan[i] < -0.2)
            btj3 = bool(cross_cai_shen[i] and cai_arr[i] < -0.3)
            zhuang_raw.append(bool(btj11 and btj2 and btj3))
            stj1 = bool(jj and (C[i] - jj) / jj > 0.005)
            stj01 = bool(kongpan[i] < prev_kongpan and kongpan[i] > 0.5)
            stj31 = bool(cross_shen_cai[i])
            stj1_raw.append(bool(stj1 and stj01 and stj31))
            stj02 = bool(kongpan[i] > 0)
            stj32 = bool(cross_shen_cai[i] and cai_arr[i] > 1.618)
            stj2_raw.append(bool(stj02 and stj32))
        zhuangjin_seq = self.FILTER(zhuang_raw, 30)
        stj81_seq = self.FILTER(stj1_raw, 13)
        stj82_seq = self.FILTER(stj2_raw, 13)
        zhuangchu_seq = [bool(stj81_seq[i] and stj82_seq[i]) for i in range(n)]
        zhuangjin = bool(zhuangjin_seq[idx])
        zhuangchu = bool(zhuangchu_seq[idx])
        zhuangchu_tq = o6[-1] not in ('0.00', '0')
        zhuangjin_tq = o4[-1] not in ('0.00', '0')
        dianhuo_tq = o9[-1] not in ('0.00', '0')
        jincha_tq = o3[-1] not in ('0.00', '0')
        # “龙回头”严格沿用源码里的10%涨停定义。
        limit_up_flags = [bool(i > 0 and C[i - 1] * 1.1 - C[i] < 0.01) for i in range(n)]
        zt_13d = sum((1 for i in range(max(0, n - 13), n) if limit_up_flags[i]))
        pp_45 = [bool(i > 0 and cp_vals[i] < 45 and (cp_vals[i - 1] > 45)) for i in range(n)]
        pp_20 = [bool(i > 0 and cp_vals[i] < 20 and (cp_vals[i - 1] > 20)) for i in range(n)]
        hh_13 = [any(limit_up_flags[max(0, i - 12):i + 1]) for i in range(n)]
        lht_visible = bool(idx > 0 and L[idx] > 0 and (pp_45[idx - 1] or pp_20[idx - 1]) and hh_13[idx])
        body = abs(close_p - open_p)
        upper_shadow = high_p - max(open_p, close_p)
        lower_shadow = min(open_p, close_p) - low_p
        dx_ma2 = self.MA(dx_vals, 2)
        hhv_dx2_seq = self.HHV(dx_vals, 2)
        llv_dx2_seq = self.LLV(dx_vals, 2)
        hhv_dx7_seq = self.HHV(dx_vals, 7)
        llv_dx7_seq = self.LLV(dx_vals, 7)
        cdx0_seq = self.COUNT([d < 0 for d in dx_vals], 2)
        cdx50_seq = self.COUNT([d > 50 for d in dx_vals], 2)
        buy_raw = [math.isclose(llv_dx2_seq[i], llv_dx7_seq[i]) and bool(cdx0_seq[i]) and self.CROSS(dx_vals, dx_ma2)[i] for i in range(n)]
        sell_raw = [math.isclose(hhv_dx2_seq[i], hhv_dx7_seq[i]) and bool(cdx50_seq[i]) and self.CROSS(dx_ma2, dx_vals)[i] for i in range(n)]
        # 原图实际显示使用 FILTER(卖,1) 与 FILTER(买1,5)。
        buy_filtered = self.FILTER(buy_raw, 5)
        sell_filtered = self.FILTER(sell_raw, 1)
        buy_sig = bool(buy_filtered[idx])
        sell_sig = bool(sell_filtered[idx])
        dianhuo = self.CROSS(ema3, ema21)[idx]

        # 妖股：完整复刻源码 HJ_8..妖股 条件，避免“涨停即妖股”。
        pct1 = [((C[i] - C[i - 1]) / C[i - 1] * 100) if i > 0 and C[i - 1] else 0.0 for i in range(n)]
        hj8 = [bool(i >= 3 and C[i - 3] and (C[i - 3] - C[i]) / C[i - 3] * 100 > 5) for i in range(n)]
        hj9 = self.FILTER(hj8, 10)
        hj10 = self.BARSLAST(hj9)
        hj25 = []
        for i in range(n):
            gap = int(hj10[i])
            def href(offset):
                pos = i - offset
                return H[pos] if pos >= 0 else None
            h11, h12, h13 = href(gap + 2), href(gap + 1), href(gap)
            h15 = max(x for x in (h11, h12, h13) if x is not None) if any(x is not None for x in (h11, h12, h13)) else None
            hj16 = pct1[i] > 5
            hj17 = gap < 150
            hj18 = bool(h15 and (O[i] - h15) / h15 * 100 < 30)
            if gap <= 0:
                llv_low = min(L[:i + 1])
            else:
                llv_low = min(L[max(0, i - gap + 1):i + 1])
            hj19 = bool(llv_low and (C[i] - llv_low) / llv_low * 100 < 50)
            hj20 = bool(i >= 5 and O[i - 5] and (C[i] - O[i - 5]) / O[i - 5] * 100 < 30)
            ma_v5 = self.MA(V_arr, 5)[i]
            hj21 = bool(ma_v5 and V_arr[i] / ma_v5 < 3.5)
            hj22 = bool(i >= 89 and C[i - 89] and (C[i] - C[i - 89]) / C[i - 89] * 100 < 80)
            hj25.append(bool(hj16 and hj17 and hj18 and hj19 and hj20 and hj21 and hj22))
        baoli = self.FILTER(hj25, 15)
        pl1 = [bool(ma54[i] and (C[i] - ma54[i]) / ma54[i] < 0.1) for i in range(n)]
        pl2 = [bool(ma10[i] and (C[i] - ma10[i]) / ma10[i] < 0.3) for i in range(n)]
        deviation = [0.2 if pl1[i] and pl2[i] else 0.0 for i in range(n)]
        platform_breakout = []
        for i in range(n):
            prev10_all = i >= 10 and all(math.isclose(deviation[j], 0.2) for j in range(i - 10, i))
            platform_breakout.append(bool(i > 0 and math.isclose(deviation[i], 0.0) and math.isclose(deviation[i - 1], 0.2) and prev10_all))
        xdf = [bool(baoli[i] or platform_breakout[i]) for i in range(n)]
        vol_expand = bool(prev_volume > 0 and volume / prev_volume > 1.2)
        varaa = bool(last_close > 0 and open_p > 0 and close_p / last_close > 1.05 and close_p / open_p > 1.05)
        fliga = bool(vol_expand and ((close_p > open_p) or (low_p > H[-2] and open_p > close_p)))
        yaogu = bool(xdf[idx] and last_close > 0 and close_p / last_close > 1.095 and fliga and varaa)

        # 龙头第一/第二买点：严格使用CB=当日量/前一日量。
        first_leader_buy = bool(last_close > 0 and close_p / last_close >= 1.099 and cb_r is not None and cb_r < 1)
        second_leader_buy = bool(last_close > 0 and close_p / last_close >= 1.07 and cb_r is not None and cb_r < 1)

        # 起爆1：按源码金叉、流通市值、9.8%~10.07%、收最高、价格与两日唯一性复刻。
        abc2_seq = [bool(i > 0 and C[i - 1] and ((C[i] - C[i - 1]) / C[i - 1] * 100 > 9.8) and ((C[i] - C[i - 1]) / C[i - 1] * 100 < 10.07) and math.isclose(C[i], H[i], rel_tol=0.0, abs_tol=max(0.001, abs(C[i]) * 1e-6))) for i in range(n)]
        abc0 = n > 1  # 源码“... OR BARSCOUNT(C)>1”使有历史数据时该条件恒真。
        abc1 = bool(float_cap and 0 < float_cap < 80)
        abc2 = bool(abc2_seq[idx])
        abc3 = bool(2 < close_p < 22)
        abc4 = sum(1 for flag in abc2_seq[max(0, n - 2):n] if flag) == 1
        qibao1 = bool(jincha_kdj and abc0 and abc1 and abc2 and abc3 and abc4)
        result = {'name': name, 'code': self.code, 'is_index': raw.get('is_index', False), 'formula_runtime_name': raw.get('formula_runtime_name', ''), 'trade_date': records[-1]['date'], 'local_last_date': bar_meta.get('local_last_date', records[-1]['date']), 'bar_source': bar_meta.get('bar_source', 'unknown'), 'snapshot_fetched_at': bar_meta.get('snapshot_fetched_at', ''), 'snapshot_date_verified': bool(bar_meta.get('snapshot_date_verified', False)), 'n_persisted_records': int(bar_meta.get('persisted_records', n)), 'close': close_p, 'open': open_p, 'high': high_p, 'low': low_p, 'last_close': last_close, 'volume': volume, 'amount': amount, 'avg': avg_p, 'inside': inside, 'outside': outside, 'change_pct': change_pct, 'cb_ratio': cb_r, 'cb_basis': 'VOL/REF(VOL,1)', 'float_cap': float_cap, 'zt_price': zt_price, 'dt_price': dt_price, 'blocks': blocks, 'j_zgb': j_zgb, 'j_jzc': j_jzc, 'j_mgjzc': j_mgjzc, 'j_mgsy': j_mgsy, 'n_records': n, 'main_trend': main_trend[-1], 'main_trend_prev': main_trend[-2], 'trend_up': trend_up, 'main_trend_tq': main_trend_tq[-1], 'ema5': ema5[idx], 'ema10': ema10[idx], 'ema20': ema20[idx], 'ema173': ema173[idx], 'ema193': ema193[idx], 'ema213': ema213[idx], 'ema173_prev': ema173[idx - 1], 'ema193_prev': ema193[idx - 1], 'ema213_prev': ema213[idx - 1], 'bullish': bullish, 'kline_color': kline_color, 'ssx4': ssx4, 'ssx5': ssx5, 'ssx6': ssx6, 'ssx7': ssx7, 'ema173_tq': ema9_tq[-1], 'ema193_tq': ema10_tq[-1], 'ema213_tq': ema11_tq[-1], 'kline_type': '阳' if close_p > open_p else '阴', 'body': body, 'upper_shadow': upper_shadow, 'lower_shadow': lower_shadow, 'dx': dx_vals[idx], 'dx_prev': dx_vals[idx - 1], 'dx_dir': '增强' if dx_vals[idx] > dx_vals[idx - 1] else '减弱', 'sell_sig': sell_sig, 'buy_sig': buy_sig, 'buy_raw': bool(buy_raw[idx]), 'sell_raw': bool(sell_raw[idx]), 'kongpan': kongpan[idx], 'kongpan_prev': kongpan[idx - 1], 'cai': cai_arr[idx], 'shen': shen_arr[idx], 'o3': o3[-1], 'o4': o4[-1], 'o5': o5[-1], 'o6': o6[-1], 'o9': o9[-1], 'zhuangchu': zhuangchu, 'zhuangjin': zhuangjin, 'zhuangchu_output_hint': zhuangchu_tq, 'zhuangjin_output_hint': zhuangjin_tq, 'dianhuo': dianhuo, 'lht': lht_visible, 'jincha_tq': jincha_tq, 'is_zt': is_zt, 'zt_13d': zt_13d, 'lht_ref_pp45': pp_45[idx - 1] if idx > 0 else False, 'lht_ref_pp20': pp_20[idx - 1] if idx > 0 else False, 'lht_hh13': hh_13[idx], 'kdj_k': kdj_k[idx], 'kdj_d': kdj_d[idx], 'kdj_j': kdj_j[idx], 'jincha_kdj': jincha_kdj, 'yaogu': yaogu, 'yaogu_components': {'xdf': bool(xdf[idx]), 'baoli': bool(baoli[idx]), 'platform_breakout': bool(platform_breakout[idx]), 'fliga': fliga, 'varaa': varaa, 'pct_gt_9_5': bool(last_close > 0 and close_p / last_close > 1.095), 'vol_expand_gt_1_2': vol_expand}, 'first_leader_buy': first_leader_buy, 'second_leader_buy': second_leader_buy, 'qibao1': qibao1, 'qibao_components': {'kdj_relation': jincha_kdj, 'float_cap_lt_80': abc1, 'limitup_band_and_close_high': abc2, 'price_2_22': abc3, 'unique_in_2d': abc4}, 'dif': dif[idx], 'dea': dea[idx], 'macd_bar': macd_bar[idx], 'rsi6': rsi6[idx], 'rsi14': rsi14[idx], 'wr10': wr10[idx], 'UB': UB[idx], 'LB': LB[idx], 'boll_ma': boll_ma[idx], 'ma5': ma5[idx], 'ma10': ma10[idx], 'ma20': ma20[idx], 'ma30': ma30[idx], 'ma54': ma54[idx], 'ma60': ma60[idx], 'ma120': ma120[idx], 'cp': cp_vals[idx], 'pp': cp_vals[idx] < 45 and cp_vals[idx - 1] > 45 if idx > 0 else False, 'ema3': ema3[idx], 'ema21': ema21[idx], 'support_1': support_1, 'support_2': support_2, 'pressure_1': pressure_1, 'pressure_2': pressure_2, 'output66': output66, 'downtrend_breakout_verified': False, 'downtrend_breakout_source': '大牛线撑压版未提供独立可计算字段', 'nearest_support': nearest_support, 'nearest_pressure': nearest_pressure, 'support_pressure_status': support_pressure_status, 'main_trend_seq': main_trend_local, 'main_trend_tq_seq': main_trend_tq, 'ema9_seq': ema9_tq, 'ema10_seq': ema10_tq, 'ema11_seq': ema11_tq, 'dx_seq': dx_vals, 'cai_seq': cai_arr, 'shen_seq': shen_arr, 'kdj_k_seq': kdj_k, 'kdj_d_seq': kdj_d, 'kdj_j_seq': kdj_j, 'ema3_seq': ema3, 'ema21_seq': ema21, 'ema5_seq': ema5, 'ema10_seq': ema10, 'ema20_seq': ema20, 'records': records, 'kongpan_seq': kongpan}
        return result

def _display_number(value, digits=2):
    try:
        numeric_value = float(value)
    except (TypeError, ValueError):
        return 'NA'
    if not math.isfinite(numeric_value):
        return 'NA'
    return f'{numeric_value:.{digits}f}'

def _display_text(value):
    if value is None:
        return 'NA'
    text = str(value).strip()
    if not text or text.upper() in {'NA', 'N/A', '--'}:
        return 'NA'
    return text

def _float_or_none(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

def _subsystem_row(number, name, evidence, status, conclusion, note='适用'):
    return {'公式': DaniuxianAnalyzer.FORMULA_RUNTIME_NAME, '序号': number, '子系统/输出': name, '当前值/证据': str(evidence or '无可用证据'), '状态': str(status or '状态不可判定'), '结论': str(conclusion or '结论不可判定'), '适用性/备注': str(note or '适用性未说明')}

def build_subsystem_rows(data: dict) -> list[dict]:
    """Build the fixed 16-row external table without parsing text reports."""
    d = data or {}
    is_index = bool(d.get('is_index'))

    def index_na(number, name, reason):
        return _subsystem_row(number, name, '指数不适用', '指数不适用', f'{reason}，不纳入指数技术结论', '保留固定子系统行')
    trend_up = bool(d.get('trend_up'))
    bullish = bool(d.get('bullish'))
    close = d.get('close')
    main_trend = d.get('main_trend')
    main_trend_status = '向上' if trend_up else '向下'
    kline_color = d.get('kline_color') or '状态不可判定'
    dx = d.get('dx')
    try:
        dx_value = float(dx)
        dx_zone = '超买' if dx_value > 50 else '多头' if dx_value > 20 else '中性' if dx_value > -20 else '空头' if dx_value > -50 else '超卖'
    except (TypeError, ValueError):
        dx_zone = '状态不可判定'
    buy_sig = bool(d.get('buy_sig'))
    sell_sig = bool(d.get('sell_sig'))
    if buy_sig and sell_sig:
        trade_state = '参与与离场提醒同时触发'
    elif buy_sig:
        trade_state = '参与提醒触发'
    elif sell_sig:
        trade_state = '离场提醒触发'
    else:
        trade_state = '未触发'
    kongpan = d.get('kongpan')
    kongpan_prev = d.get('kongpan_prev')
    try:
        kongpan_status = '增强' if float(kongpan) > float(kongpan_prev) else '减弱' if float(kongpan) < float(kongpan_prev) else '持平'
    except (TypeError, ValueError):
        kongpan_status = '状态不可判定'
    cai = d.get('cai')
    shen = d.get('shen')
    try:
        caishen_status = '偏多' if float(cai) > float(shen) else '偏空' if float(cai) < float(shen) else '持平'
    except (TypeError, ValueError):
        caishen_status = '状态不可判定'
    dianhuo = bool(d.get('dianhuo'))
    qibao1 = bool(d.get('qibao1'))
    cb_ratio_value = _float_or_none(d.get('cb_ratio'))
    first_leader_buy = bool(d.get('first_leader_buy'))
    second_leader_buy = bool(d.get('second_leader_buy'))
    boll_position = '上半区' if close is not None and d.get('boll_ma') is not None and (close > d.get('boll_ma')) else '下半区'
    rows = [_subsystem_row(1, '主趋势线', f"现值={_display_number(main_trend)}，前值={_display_number(d.get('main_trend_prev'))}，收盘={_display_number(close)}", main_trend_status, f"主趋势线{main_trend_status}，方向{('偏多' if trend_up else '偏空')}"), _subsystem_row(2, 'EMA均线分层', f"EMA5/10/20={_display_number(d.get('ema5'))}/{_display_number(d.get('ema10'))}/{_display_number(d.get('ema20'))}；EMA173/193/213={_display_number(d.get('ema173'))}/{_display_number(d.get('ema193'))}/{_display_number(d.get('ema213'))}", '多头排列' if bullish else '非多头排列', '短中期均线结构偏多' if bullish else '短中期均线尚未形成多头排列'), _subsystem_row(3, 'K线颜色信号', f"{kline_color}，{d.get('kline_type', 'NA')}线，实体={_display_number(d.get('body'))}，上影={_display_number(d.get('upper_shadow'))}，下影={_display_number(d.get('lower_shadow'))}", kline_color, f'当前按大牛线着色规则判定为{kline_color}')]
    rows.append(index_na(4, '流通市值', '流通市值及每股财务指标属于个股口径') if is_index else _subsystem_row(4, '流通市值', f"流通市值={_display_number(d.get('float_cap'))}亿，总股本={_display_number((d.get('j_zgb') or 0) / 10000)}亿股", '已取得', '流通市值数据已纳入个股规模判断'))
    rows.extend([_subsystem_row(5, 'DX动量指标', f"DX={_display_number(dx)}，前值={_display_number(d.get('dx_prev'))}，方向={d.get('dx_dir', 'NA')}", dx_zone, f'DX动量处于{dx_zone}区间'), _subsystem_row(6, '参与与离场信号', f'参与提醒={buy_sig}，离场提醒={sell_sig}', trade_state, f'大牛线参与与离场信号当前为{trade_state}'), _subsystem_row(7, '控盘程度', f'当前={_display_number(kongpan, 4)}，前值={_display_number(kongpan_prev, 4)}', kongpan_status, f'控盘程度较前值{kongpan_status}'), _subsystem_row(8, '财神短线', f'财={_display_number(cai, 4)}，神={_display_number(shen, 4)}', caishen_status, f'财神短线结构{caishen_status}')])
    rows.append(index_na(9, '庄进/庄出', '庄进和庄出属于个股资金信号') if is_index else _subsystem_row(9, '庄进/庄出', f"源码复算：庄进={bool(d.get('zhuangjin'))}，庄出={bool(d.get('zhuangchu'))}；OUTPUT旁证4/6={d.get('o4', 'NA')}/{d.get('o6', 'NA')}", '庄进触发' if d.get('zhuangjin') else '庄出触发' if d.get('zhuangchu') else '未触发', '结论按源码控盘、财神、均价、CROSS与FILTER复算；OUTPUT仅作旁证'))
    rows.append(index_na(10, '妖股识别', '妖股识别属于个股复合启动模型') if is_index else _subsystem_row(10, '妖股识别', f"XDF={d.get('yaogu_components', {}).get('xdf', 'NA')}，暴利={d.get('yaogu_components', {}).get('baoli', 'NA')}，平台突破={d.get('yaogu_components', {}).get('platform_breakout', 'NA')}，FLIGA={d.get('yaogu_components', {}).get('fliga', 'NA')}，VARAA={d.get('yaogu_components', {}).get('varaa', 'NA')}，涨幅>9.5%={d.get('yaogu_components', {}).get('pct_gt_9_5', 'NA')}", '妖股条件成立' if d.get('yaogu') else '妖股条件不成立', '严格按原公式XDF、涨幅、FLIGA与VARAA复合条件判定'))
    rows.append(index_na(11, '龙头参与区', '龙头参与区属于个股涨幅与缩量模型') if is_index else _subsystem_row(11, '龙头参与区', f"涨幅={_display_number(d.get('change_pct'))}%，CB(当日量/前日量)={_display_number(d.get('cb_ratio'))}", '第一参与区触发' if first_leader_buy else '第二参与区触发' if second_leader_buy else '未触发', '第一参与区=涨幅>=9.9%且CB<1；第二参与区=涨幅>=7%且CB<1'))
    rows.append(index_na(12, '龙回头', '龙回头属于个股涨停回撤模型') if is_index else _subsystem_row(12, '龙回头', f"图示四件套共同条件，13日涨停={d.get('zt_13d', 'NA')}，前一日跌破45={bool(d.get('lht_ref_pp45'))}，前一日跌破20={bool(d.get('lht_ref_pp20'))}", '触发' if d.get('lht') else '未触发', '龙回头只按白横杠、红点、红箭头和红色买字共同条件判定'))
    rows.extend([_subsystem_row(13, '点火信号', f"EMA3={_display_number(d.get('ema3'))}，EMA21={_display_number(d.get('ema21'))}，OUTPUT9={d.get('o9', 'NA')}", '点火触发' if dianhuo else '未触发', '短线点火条件已触发' if dianhuo else '短线点火条件尚未触发'), _subsystem_row(14, '起爆/题材共振', f"KDJ关系={d.get('qibao_components', {}).get('kdj_relation', 'NA')}；流通市值<80亿={d.get('qibao_components', {}).get('float_cap_lt_80', 'NA')}；9.8%~10.07%且收最高={d.get('qibao_components', {}).get('limitup_band_and_close_high', 'NA')}；价格2~22={d.get('qibao_components', {}).get('price_2_22', 'NA')}；两日唯一={d.get('qibao_components', {}).get('unique_in_2d', 'NA')}", '题材共振触发' if qibao1 else '未触发', '严格按原公式起爆1复合条件判定', '适用'), _subsystem_row(15, 'BOLL+多重均线', f"BOLL上/中/下={_display_number(d.get('UB'))}/{_display_number(d.get('boll_ma'))}/{_display_number(d.get('LB'))}；MA5/10/20/60={_display_number(d.get('ma5'))}/{_display_number(d.get('ma10'))}/{_display_number(d.get('ma20'))}/{_display_number(d.get('ma60'))}", boll_position, f'价格处于BOLL{boll_position}，结合多重均线判断趋势强弱'), _subsystem_row(16, '核心黄金分割撑压', f"支撑一={_display_number(d.get('support_1'))}，支撑二={_display_number(d.get('support_2'))}，压力一={_display_number(d.get('pressure_1'))}，压力二={_display_number(d.get('pressure_2'))}，OUTPUT66={_display_text(d.get('output66'))}", d.get('support_pressure_status', '撑压不可判定'), f"最近有效支撑={_display_number(d.get('nearest_support'))}，最近有效压力={_display_number(d.get('nearest_pressure'))}", 'TQ核心黄金分割撑压输出')])
    return rows
