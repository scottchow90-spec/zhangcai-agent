"""Portable read-only Tongdaxin two-formula analysis."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
import re
import struct
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

FORMULAS = ('大牛线撑压版', '飞龙在天')
TZ = timezone(timedelta(hours=8))
COUNTS = {FORMULAS[0]: 16, FORMULAS[1]: 10}
COLUMNS = ('公式', '序号', '子系统/输出', '当前值/证据', '状态', '结论', '适用性/备注')
BULL_OUTPUTS = ('主趋势线', 'EMA9', 'EMA10', 'EMA11', '流通市值',
                'OUTPUT3', 'OUTPUT4', 'OUTPUT5', 'OUTPUT6', 'OUTPUT9',
                '支撑一', '支撑二', '压力一', '压力二', 'OUTPUT66')


def sha256(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest() if hasattr(hashlib, 'file_digest') else hashlib.sha256(stream.read()).hexdigest()


def _paths(config: dict) -> tuple[Path, Path, Path]:
    raw_root = str(config.get('tdx_root') or '').strip()
    if not raw_root:
        raise ValueError('请先配置通达信安装目录。')
    root = Path(raw_root).expanduser().resolve()
    module = config.get('tq_module')
    if module:
        module_path = Path(str(module)).expanduser().resolve()
    else:
        candidates = [root / 'PYPlugins/user/tqcenter.py', root / 'PYPlugins/sys/tqcenter.py']
        module_path = next((item for item in candidates if item.is_file()), candidates[0])
    # The official tqcenter module derives this location from its own parent.
    return root, module_path, module_path.parent.parent / 'TPythClient.dll'


def _dll_bits(path: Path) -> int:
    with path.open('rb') as stream:
        if stream.read(2) != b'MZ':
            raise ValueError('DLL 文件不是有效的 Windows 程序。')
        stream.seek(60)
        offset = struct.unpack('<I', stream.read(4))[0]
        stream.seek(offset)
        if stream.read(4) != b'PE\0\0':
            raise ValueError('DLL 文件头无效。')
        machine = struct.unpack('<H', stream.read(2))[0]
    if machine == 0x8664:
        return 64
    if machine == 0x14c:
        return 32
    raise ValueError(f'不支持的 DLL 架构: {machine}')


def diagnose_technical(config: dict) -> list[dict]:
    """Read files and package metadata only; never import the DLL bridge."""
    records = []

    def add(check, ok, detail):
        records.append({'check': check, 'status': 'PASS' if ok else 'BLOCKED', 'detail': detail})

    add('windows', os.name == 'nt', '需要 Windows 电脑版。')
    add('python_version', sys.version_info >= (3, 10), f'Python {sys.version_info.major}.{sys.version_info.minor}')
    for name in ('numpy', 'pandas'):
        add(name, importlib.util.find_spec(name) is not None, f'需要安装 {name}。')
    try:
        root, module, dll = _paths(config)
    except (ValueError, OSError) as exc:
        add('tdx_root', False, str(exc))
        return records
    add('tdx_root', root.is_dir(), str(root))
    add('tq_module', module.is_file(), str(module))
    add('tq_dll', dll.is_file(), str(dll))
    if dll.is_file():
        try:
            bits = _dll_bits(dll)
            python_bits = struct.calcsize('P') * 8
            add('architecture', bits == python_bits, f'Python {python_bits} 位，通达信接口 {bits} 位。')
        except (OSError, ValueError, struct.error) as exc:
            add('architecture', False, str(exc))
    add('daily_data_root', (root / 'vipdoc').is_dir(), '需要通达信已下载的日线数据。')
    if module.is_file():
        try:
            content = module.read_text(encoding='utf-8-sig')
            methods = ('initialize', 'formula_set_data_info', 'formula_zb', 'formula_process_mul_zb', 'get_market_data', 'get_stock_info', 'get_market_snapshot', 'close')
            missing = [name for name in methods if not re.search(r'\bdef\s+' + name + r'\s*\(', content)]
            add('tq_api', not missing, '接口方法齐全。' if not missing else '接口缺少方法: ' + ', '.join(missing))
        except (OSError, UnicodeError) as exc:
            add('tq_api', False, str(exc))
    return records


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'无法加载模块: {path.name}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _write_evidence(output_dir: Path, name: str, data: dict) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / name
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str) + '\n', encoding='utf-8')
    return {'path': str(path.resolve()), 'sha256': sha256(path), 'size': path.stat().st_size}


def validate_subsystem_table(rows: list[dict]) -> dict:
    from bull_analysis import DaniuxianAnalyzer
    from feilong_analysis import SUBSYSTEMS
    expected = [(FORMULAS[0], n, name) for n, name, *_ in DaniuxianAnalyzer.SUBSYSTEMS]
    expected += [(FORMULAS[1], n, name) for n, name, *_ in SUBSYSTEMS]
    if not isinstance(rows, list) or len(rows) != 26:
        raise ValueError('技术分析必须完整包含 26 项。')
    actual = []
    for row in rows:
        if not isinstance(row, dict) or set(row) != set(COLUMNS):
            raise ValueError('技术分析表格字段不符合固定结构。')
        if any(row[field] is None or not str(row[field]).strip() for field in COLUMNS):
            raise ValueError('技术分析表格存在空字段。')
        actual.append((row['公式'], row['序号'], row['子系统/输出']))
    if actual != expected:
        raise ValueError('技术分析表格项目或顺序错误。')
    text = json.dumps(rows, ensure_ascii=False)
    if re.search(r'评分|得分|打分|总分|综合分|分数|评级|排名|权重|(?<![A-Za-z])(?:score|scoring|rating|rank|ranking|weight)s?(?![A-Za-z])', text, re.I):
        raise ValueError('技术分析表格含不适用内容。')
    if rows[23]['状态'] not in {'金叉', '未形成金叉', '金叉状态不可判定'}:
        raise ValueError('飞龙在天状态不符合固定输出规则。')
    semantic_checks = [
        ('大牛线妖股语义', rows[9], ('XDF=', 'FLIGA=', 'VARAA=')),
        ('大牛线龙头量能口径', rows[10], ('CB(当日量/前日量)',)),
        ('大牛线起爆语义', rows[13], ('流通市值<80亿', '两日唯一')),
        ('飞龙金叉证据', rows[23], ('波当前/前值=', '段当前/前值=')),
    ]
    for label, row, required_fragments in semantic_checks:
        evidence = str(row.get('当前值/证据') or '')
        if any(fragment not in evidence for fragment in required_fragments):
            raise ValueError(label + '输出证据不完整。')
    return dict(COUNTS)


def _bull(tq, root: Path, symbol: str, output_dir: Path, verified_trade_date: str):
    from bull_analysis import DaniuxianAnalyzer, build_subsystem_rows
    analyzer = DaniuxianAnalyzer()
    analyzer._configure_symbol(symbol)
    snapshot = tq.get_market_snapshot(symbol)
    info = tq.get_stock_info(symbol)
    tq.formula_set_data_info(symbol, count=600, dividend_type=1)
    formula = tq.formula_zb(FORMULAS[0], formula_arg=analyzer.code)
    evidence = _write_evidence(output_dir, 'bull-formula-raw.json', {'symbol': symbol, 'formula': formula, 'snapshot': snapshot, 'info': info})
    outputs = formula.get('Value') if isinstance(formula, dict) else None
    if not isinstance(outputs, dict):
        raise RuntimeError('大牛线撑压版调用失败，请确认目标通达信已导入同名公式。')
    missing = [name for name in BULL_OUTPUTS if name not in outputs]
    for name in BULL_OUTPUTS[:10]:
        value = outputs.get(name)
        latest = value[-1] if isinstance(value, list) and value else value
        if latest is None or str(latest).strip().upper() in {'', '[]', 'NA', 'N/A', '--'}:
            missing.append(name)
        elif name in BULL_OUTPUTS[:5]:
            try:
                if not math.isfinite(float(latest)):
                    missing.append(name)
            except (TypeError, ValueError):
                missing.append(name)
    if missing:
        raise RuntimeError('大牛线撑压版输出缺失: ' + ', '.join(sorted(set(missing))))
    market = analyzer.market.lower()
    day_path = root / 'vipdoc' / market / 'lday' / f'{market}{analyzer.code}.day'
    if not day_path.is_file() or day_path.stat().st_size % 32:
        raise RuntimeError('目标股票日线文件缺失或格式错误，请先在通达信下载盘后数据。')
    records = analyzer._read_day_file(str(day_path))
    records, metadata = analyzer._merge_verified_snapshot_bar(records, snapshot, verified_trade_date)
    raw = {'snap': snapshot, 'info': info, 'dnx': formula, 'records': records,
           'formula_runtime_name': FORMULAS[0], 'is_index': False, 'bar_meta': metadata}
    bar_evidence = _write_evidence(output_dir, 'bull-analysis-input.json', raw)
    data = analyzer.analyze_all(raw)
    return build_subsystem_rows(data), {
        'status': 'PASS', 'formula': FORMULAS[0], 'subsystem_count': 16,
        'bar_date': data.get('trade_date'), 'bar_source': data.get('bar_source'),
        'scoring_executed': False, 'evidence_mode': 'installed_tq_formula_with_existing_local_bar_derivations',
        'source_evidence': [evidence, bar_evidence],
    }


def _feilong(tq, symbol: str, output_dir: Path):
    from feilong_analysis import _analyze, build_subsystem_rows
    result = _analyze(symbol, tq, persist_artifacts=False)
    summary = result['summary']
    date_context = summary.get('date_context') or {}
    source = _write_evidence(output_dir, 'feilong-analysis-input.json', summary)
    return build_subsystem_rows(summary), {
        'status': 'PASS', 'formula': FORMULAS[1], 'subsystem_count': 10,
        'analysis_as_of_date': date_context.get('analysis_as_of_date'),
        'data_mode': date_context.get('mode'), 'source_evidence': [source],
    }


def collect_technical(config: dict, symbol: str, output_dir: Path) -> dict:
    base = {
        'skill': 'technical-analysis', 'symbol': symbol, 'code': symbol,
        'target_type': '个股', 'components': 'bull-feilong',
        'required_formulas': list(FORMULAS), 'required_subsystem_counts': dict(COUNTS),
        'required_total_subsystems': 26, 'scoring_executed': False,
        'generated_at': datetime.now(TZ).isoformat(timespec='seconds'),
        'formula_results': {}, 'analysis_complete': False,
    }
    tq = None
    dll_directory = None
    prior_argv = list(sys.argv)
    prior_path = list(sys.path)
    active_formula = None
    try:
        match = re.fullmatch(r'(\d{6})\.(SH|SZ|BJ)', symbol)
        if not match:
            raise ValueError('请传入已校验的单一 A 股代码。')
        diagnostics = diagnose_technical(config)
        failed = [item['detail'] for item in diagnostics if item['status'] != 'PASS']
        if failed:
            raise RuntimeError('；'.join(failed))
        root, module_path, dll_path = _paths(config)
        base['data_source'] = str(root) + ' TQ'
        runtime_dir = Path(__file__).resolve().parent
        sys.path.insert(0, str(runtime_dir))
        sys.path.insert(0, str(module_path.parent))
        if hasattr(os, 'add_dll_directory'):
            dll_directory = os.add_dll_directory(str(dll_path.parent))
        sys.argv = ['workbuddy-individual-analysis', '--run_tdx', '0']
        module = _load('workbuddy_tqcenter', module_path)
        tq = module.tq
        tq.initialize(str(runtime_dir / 'tq_session.py'), str(dll_path))
        # 先运行飞龙，用“公式输出日期 ∩ 日K日期”形成独立交易日证据；
        # 再把该日期交给大牛线，只有昨收一致时才允许把当天快照并入本地.day。
        active_formula = FORMULAS[1]
        feilong_rows, feilong_result = _feilong(tq, symbol, output_dir)
        base['formula_results'][FORMULAS[1]] = feilong_result
        verified_trade_date = str(feilong_result.get('analysis_as_of_date') or '')
        if not re.fullmatch(r'\d{8}', verified_trade_date):
            raise RuntimeError('飞龙未形成可验证的交易日期，禁止大牛线混合实时快照。')
        active_formula = FORMULAS[0]
        bull_rows, bull_result = _bull(tq, root, symbol, output_dir, verified_trade_date)
        base['formula_results'][FORMULAS[0]] = bull_result
        rows = bull_rows + feilong_rows
        active_formula = None
        validate_subsystem_table(rows)
        dates = base['formula_results']
        bull_date = str(dates[FORMULAS[0]].get('bar_date') or '').replace('-', '')
        feilong_date = str(dates[FORMULAS[1]].get('analysis_as_of_date') or '')
        if not re.fullmatch(r'\d{8}', bull_date) or bull_date != feilong_date:
            raise RuntimeError('两套公式的数据日期不一致，请更新通达信日线数据后重试。')
        if bull_date > datetime.now(TZ).strftime('%Y%m%d'):
            raise RuntimeError('行情日期晚于当前日期。')
        return {**base, 'status': 'PASS', 'analysis_complete': True, 'technical_as_of': bull_date,
                'subsystem_counts': dict(COUNTS), 'subsystem_table': rows, 'failed_formulas': [], 'errors': []}
    except (Exception, SystemExit) as exc:
        if active_formula:
            base['formula_results'][active_formula] = {'status': 'BLOCKED', 'error': str(exc)}
        return {**base, 'status': 'BLOCKED', 'failed_formulas': [active_formula] if active_formula else list(FORMULAS),
                'errors': [f'{type(exc).__name__}: {exc}']}
    finally:
        if tq is not None:
            try:
                tq.close()
            except Exception:
                pass
        sys.argv = prior_argv
        sys.path[:] = prior_path
        if dll_directory is not None:
            dll_directory.close()
