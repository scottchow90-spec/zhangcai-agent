"""Existing ten-row current analysis without backtest or host paths."""
from __future__ import annotations
import json, math, re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List
import numpy as np
import pandas as pd
FORMULA_DISPLAY_NAME = '飞龙在天4.0'
FORMULA_CALL_NAME = '飞龙在天'
TZ = timezone(timedelta(hours=8))
REQUIRED_FORMULA_OUTPUTS = {'OUTPUT3', 'OUTPUT4', 'OUTPUT5', 'OUTPUT6', '波', '段'}
NAME_MAP = {'科净源': '301372.SZ'}
SUBSYSTEMS = [(1, '龙头战法', 'OUTPUT3'), (2, '趋势过滤/中长期均线强势条件', None), (3, '四日实体重叠箱体/波段密码底层形态', None), (4, '首板/唯一涨停确认', None), (5, '波段密码打板', 'OUTPUT4'), (6, '量价模型/暴涨启动', 'OUTPUT5'), (7, '波段随机强弱-波', '波'), (8, '波段随机强弱-段', '段'), (9, '私募秘进', 'OUTPUT6'), (10, '主升启动共振', None)]

def fnum(x):
    try:
        return float(x)
    except Exception:
        return None

def indicator_output_triggered(value: Any) -> bool:
    if value is True:
        return True
    numeric = fnum(value)
    return numeric is not None and numeric != 0

def normalize_date(value: Any) -> str | None:
    if value is None:
        return None
    if hasattr(value, 'strftime'):
        return value.strftime('%Y%m%d')
    digits = re.sub('\\D', '', str(value))
    if len(digits) < 8:
        return None
    candidate = digits[:8]
    try:
        datetime.strptime(candidate, '%Y%m%d')
    except ValueError:
        return None
    return candidate

def resolve_symbol(query: str) -> str:
    q = query.strip().upper()
    if q in NAME_MAP:
        return NAME_MAP[q]
    if query.strip() in NAME_MAP:
        return NAME_MAP[query.strip()]
    exact = re.fullmatch('(\\d{6})\\.(SH|SZ|BJ)', q)
    if exact:
        return q
    m = re.search('(\\d{6})', q)
    if not m:
        raise SystemExit(f'无法解析股票代码: {query}; 请传入6位代码或已登记名称')
    code = m.group(1)
    if code.startswith(('0', '3')):
        return f'{code}.SZ'
    if code.startswith(('6', '9')):
        return f'{code}.SH'
    if code.startswith(('4', '8')):
        return f'{code}.BJ'
    return f'{code}.SH'

def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()

def sma_tdx(s, n, m=1):
    out = []
    prev = np.nan
    for x in s:
        if np.isnan(x):
            out.append(prev)
            continue
        if np.isnan(prev):
            prev = x
        else:
            prev = (m * x + (n - m) * prev) / n
        out.append(prev)
    return pd.Series(out, index=s.index)

def ref(s, n=1):
    return s.shift(n)

def hhv(s, n):
    return s.rolling(n, min_periods=1).max()

def llv(s, n):
    return s.rolling(n, min_periods=1).min()

def last_val(series):
    if not series:
        return None
    x = series[-1]
    return fnum(x.get('Value') if isinstance(x, dict) else x)

def prev_val(series, n=1):
    if not series or len(series) <= n:
        return None
    x = series[-1 - n]
    return fnum(x.get('Value') if isinstance(x, dict) else x)

def last_date(series):
    if not series:
        return None
    x = series[-1]
    return x.get('Date') if isinstance(x, dict) else None

def tail_pairs(series, n=10):
    arr = []
    for x in (series or [])[-n:]:
        if isinstance(x, dict):
            arr.append((x.get('Date'), fnum(x.get('Value'))))
        else:
            arr.append((None, fnum(x)))
    return arr

def market_series(market_data: Any, field: str, symbol: str) -> pd.Series:
    values = market_data[field]
    if isinstance(values, pd.DataFrame):
        return values[symbol]
    if isinstance(values, pd.Series):
        return values
    raise TypeError(f'unsupported market-data field {field}: {type(values).__name__}')

def series_dates(series: pd.Series) -> List[str]:
    return [d for d in (normalize_date(value) for value in series.index) if d]

def formula_dates_by_output(node: Dict[str, Any]) -> Dict[str, List[str]]:
    result: Dict[str, List[str]] = {}
    for key in sorted(REQUIRED_FORMULA_OUTPUTS):
        dates = []
        for item in node.get(key, []) or []:
            if isinstance(item, dict):
                date = normalize_date(item.get('Date'))
                if date:
                    dates.append(date)
        result[key] = sorted(set(dates))
    return result

def build_date_context(run_calendar_date: str, requested_as_of_date: str | None, output_dates: Dict[str, List[str]], kline_dates: List[str], snapshot_available: bool) -> Dict[str, Any]:
    run_date = normalize_date(run_calendar_date)
    requested = normalize_date(requested_as_of_date)
    if run_date is None:
        raise ValueError(f'invalid run calendar date: {run_calendar_date}')
    if requested_as_of_date is not None and requested is None:
        raise ValueError(f'invalid requested as-of date: {requested_as_of_date}')
    normalized_output_dates = {key: sorted({date for value in values if (date := normalize_date(value))}) for key, values in output_dates.items()}
    formula_sets = [set(normalized_output_dates.get(key, [])) for key in sorted(REQUIRED_FORMULA_OUTPUTS)]
    common_formula_dates = set.intersection(*formula_sets) if formula_sets else set()
    normalized_kline_dates = {date for value in kline_dates if (date := normalize_date(value))}
    common_dates = sorted((date for date in common_formula_dates & normalized_kline_dates if date <= run_date))
    errors: List[str] = []
    if requested and requested > run_date:
        errors.append(f'requested_as_of_date_is_future:{requested}>{run_date}')
    if requested and requested not in common_formula_dates:
        errors.append(f'formula_outputs_missing_as_of:{requested}')
    if requested and requested not in normalized_kline_dates:
        errors.append(f'kline_missing_as_of:{requested}')
    analysis_as_of_date = requested or (common_dates[-1] if common_dates else None)
    if analysis_as_of_date is None:
        errors.append('no_common_formula_and_kline_date')
    formula_latest_by_output = {key: values[-1] if values else None for key, values in normalized_output_dates.items()}
    same_day_realtime = not errors and analysis_as_of_date == run_date and snapshot_available
    mode = 'same_day_realtime' if same_day_realtime else 'as_of_close' if not errors else 'blocked'
    return {'ok': not errors, 'mode': mode, 'run_calendar_date': run_date, 'requested_as_of_date': requested, 'analysis_as_of_date': analysis_as_of_date, 'formula_latest_date': max((date for date in formula_latest_by_output.values() if date), default=None), 'formula_latest_by_output': formula_latest_by_output, 'formula_has_as_of': bool(analysis_as_of_date and all((analysis_as_of_date in dates for dates in normalized_output_dates.values()))), 'kline_latest_date': max(normalized_kline_dates, default=None), 'kline_has_as_of': bool(analysis_as_of_date and analysis_as_of_date in normalized_kline_dates), 'snapshot_available': snapshot_available, 'errors': errors}

def formula_series_through_date(series: List[Any], as_of_date: str) -> List[Any]:
    filtered = []
    for item in series or []:
        if not isinstance(item, dict):
            continue
        item_date = normalize_date(item.get('Date'))
        if item_date and item_date <= as_of_date:
            filtered.append(item)
    return filtered

def market_series_through_date(series: pd.Series, as_of_date: str) -> pd.Series:
    mask = [bool(date and date <= as_of_date) for date in (normalize_date(value) for value in series.index)]
    return series.loc[mask]

def _analyze(query: str, tq, out: str | None=None, as_of_date: str | None=None, persist_artifacts: bool=True) -> Dict:
    symbol = resolve_symbol(query)
    code = symbol.split('.')[0]
    run_calendar_date = datetime.now(TZ).strftime('%Y%m%d')
    info = tq.get_stock_info(symbol)
    snap = tq.get_market_snapshot(symbol)
    md = tq.get_market_data(stock_list=[symbol], period='1d', count=180, dividend_type='front')
    formula = tq.formula_process_mul_zb(FORMULA_CALL_NAME, stock_list=[symbol], count=0, return_count=80, return_date=True, dividend_type=1)
    node = formula.get(symbol, {}) if isinstance(formula, dict) else {}
    populated_formula_outputs = {key for key, value in node.items() if key in REQUIRED_FORMULA_OUTPUTS and isinstance(value, list) and value}
    missing_formula_outputs = sorted(REQUIRED_FORMULA_OUTPUTS - populated_formula_outputs)
    if missing_formula_outputs:
        try:
            tq.close()
        finally:
            raise SystemExit(f"飞龙公式执行失败: display={FORMULA_DISPLAY_NAME}, call={FORMULA_CALL_NAME}, missing_outputs={missing_formula_outputs}, error_id={(formula.get('ErrorId') if isinstance(formula, dict) else None)}")
    raw_close = market_series(md, 'Close', symbol)
    date_context = build_date_context(run_calendar_date=run_calendar_date, requested_as_of_date=as_of_date, output_dates=formula_dates_by_output(node), kline_dates=series_dates(raw_close), snapshot_available=bool(snap))
    if not date_context['ok']:
        raise SystemExit('飞龙日期口径校验失败: ' + json.dumps(date_context, ensure_ascii=False, default=str))
    analysis_as_of_date = date_context['analysis_as_of_date']
    latest = {}
    for key, val in node.items():
        if isinstance(val, list):
            val = formula_series_through_date(val, analysis_as_of_date)
            latest[key] = {'latest_date': last_date(val), 'latest': last_val(val), 'prev': prev_val(val, 1), 'prev2': prev_val(val, 2), 'tail10': tail_pairs(val, 10)}
    C = market_series_through_date(raw_close.astype(float), analysis_as_of_date)
    H = market_series_through_date(market_series(md, 'High', symbol).astype(float), analysis_as_of_date)
    L = market_series_through_date(market_series(md, 'Low', symbol).astype(float), analysis_as_of_date)
    O = market_series_through_date(market_series(md, 'Open', symbol).astype(float), analysis_as_of_date)
    V = market_series_through_date(market_series(md, 'Volume', symbol).astype(float), analysis_as_of_date)
    X5 = ref(C, 1)
    X6 = ema(hhv(H, 1), 8)
    X7 = ema(C, 8)
    X8 = (X7 < ref(X7, 1)) & (C < X7)
    X9 = ((X6 < ref(X6, 1)) | X8).astype(int)
    up = (C - X5).clip(lower=0)
    abschg = (C - X5).abs()
    X10 = sma_tdx(up, 2, 1) / sma_tdx(abschg, 2, 1) * 100
    X14 = (X10 < 20) & (ref(X10, 1) > 20)
    X13 = (X10 < 45) & (ref(X10, 1) > 45)
    longtou_calc = (X9.eq(1).rolling(4, min_periods=4).sum() == 3) & (X9 == 0) & (O < C) & ((C - ref(C, 1)) / ref(C, 1) > 0.089) | ((C - ref(C, 1)) / ref(C, 1) > 0.089) & (ref(X14.astype(int), 1).astype(bool) | ref(X13.astype(int), 1).astype(bool))
    X15 = ema(C, 89)
    X16 = ema(ema(ema(H, 13), 13), 13)
    X17 = ema(ema(ema(H, 5), 5), 5)
    X18 = (C - ref(C, 1)) / ref(C, 1) * 100
    X22 = (ref(C, 1) < 89) & (ref(C, 1) > 2)
    X23 = not code.startswith('3')
    X24 = (C > X17) & (C > X16) & (C > X15)
    X25 = H / X17
    X26 = (X18 >= 9.84) & ref((X18 < 9.84).astype(int), 1).astype(bool) & ref((X18 < 9.84).astype(int), 2).astype(bool)
    X27 = X22 & X23 & X24 & (X25 < 1.16) & X26
    X28 = pd.concat([C, O], axis=1).max(axis=1)
    X29 = pd.concat([C, O], axis=1).min(axis=1)
    X30 = llv(X28, 4)
    X31 = hhv(X29, 4)
    X32 = (X28 >= X30) & (X29 <= X30) & (X28 >= X31) & (X29 <= X31)
    X33 = (ref(X28, 1) >= X30) & (ref(X29, 1) <= X30) & (ref(X28, 1) >= X31) & (ref(X29, 1) <= X31)
    X34 = (ref(X28, 2) >= X30) & (ref(X29, 2) <= X30) & (ref(X28, 2) >= X31) & (ref(X29, 2) <= X31)
    X35 = (ref(X28, 3) >= X30) & (ref(X29, 3) <= X30) & (ref(X28, 3) >= X31) & (ref(X29, 3) <= X31)
    X36 = X32 & X33 & X34 & X35
    X37 = X36.rolling(36, min_periods=1).max().astype(bool)
    X45 = (X18 > 9.85) & ~(O == C)
    X46 = X45.rolling(21, min_periods=1).sum()
    X47 = (X46 == 1) & X45
    private_basic = (C / ref(C, 1) > 1.048) & (C == H)
    if date_context['mode'] == 'same_day_realtime':
        now = fnum(snap.get('Now'))
        last_close = fnum(snap.get('LastClose'))
        avg = fnum(snap.get('Average'))
        high = fnum(snap.get('Max'))
        low = fnum(snap.get('Min'))
        openp = fnum(snap.get('Open'))
        vol = fnum(snap.get('Volume'))
        amount = fnum(snap.get('Amount'))
        inside = fnum(snap.get('Inside'))
        outside = fnum(snap.get('Outside'))
    else:
        now = fnum(C.iloc[-1])
        last_close = fnum(C.iloc[-2])
        avg = None
        high = fnum(H.iloc[-1])
        low = fnum(L.iloc[-1])
        openp = fnum(O.iloc[-1])
        vol = fnum(V.iloc[-1])
        amount = None
        inside = None
        outside = None
    realtime_calc = {'basis': date_context['mode'], 'now': now, 'last_close': last_close, 'change_pct': (now - last_close) / last_close * 100 if now and last_close else None, 'open': openp, 'high': high, 'low': low, 'avg': avg, 'volume_lot': vol, 'amount_wan': amount, 'amount_yi': amount / 10000 if amount else None, 'inside': inside, 'outside': outside, 'inside_minus_outside': inside - outside if inside is not None and outside is not None else None, 'intraday_amp_pct': (high - low) / last_close * 100 if high and low and last_close else None, 'below_avg_pct': (now - avg) / avg * 100 if now and avg else None}
    derived = {'longtou_calc': bool(longtou_calc.iloc[-1]), 'x9_last4': [int(x) for x in X9.tail(4).tolist()], 'rsi2_x10': float(X10.iloc[-1]), 'rsi2_prev': float(X10.iloc[-2]), 'trend_filter': {'ema89': float(X15.iloc[-1]), 'high_ema13x3': float(X16.iloc[-1]), 'high_ema5x3': float(X17.iloc[-1]), 'close_gt_all_three': bool(X24.iloc[-1]), 'x25_high_div_high_ema5x3': float(X25.iloc[-1]), 'x23_code_prefix_filter_pass': bool(X23), 'x22_price_range_pass': bool(X22.iloc[-1]), 'x26_first_limitup_pass': bool(X26.iloc[-1]), 'x27_all_pass': bool(X27.iloc[-1])}, 'box_shape': {'x36_today': bool(X36.iloc[-1]), 'x37_exist_36d': bool(X37.iloc[-1])}, 'limitup_unique': {'x45_today_gt985_not_doji': bool(X45.iloc[-1]), 'x46_count_21d': float(X46.iloc[-1]), 'x47_unique_limitup': bool(X47.iloc[-1])}, 'boduan_password_calc': {'x55': False, 'x47': bool(X47.iloc[-1]), 'trigger': indicator_output_triggered(latest.get('OUTPUT4', {}).get('latest'))}, 'private_entry_basic': {'pct_gt_4_8': bool((C / ref(C, 1) > 1.048).iloc[-1]), 'close_eq_high': bool((C == H).iloc[-1]), 'trigger_basic': bool(private_basic.iloc[-1])}}
    analysis_json = None
    derived_json = None
    report_path = None
    data = {'generated_at': datetime.now(TZ).isoformat(), 'symbol': symbol, 'name': info.get('Name', query), 'date_context': date_context, 'info': info, 'snapshot': snap, 'realtime_calc': realtime_calc, 'latest_outputs': latest, 'derived': derived, 'realtime_evidence': date_context, 'formula_raw': formula}
    return {'report': str(report_path) if report_path else None, 'analysis_json': str(analysis_json) if analysis_json else None, 'derived_json': str(derived_json) if derived_json else None, 'summary': data}

def golden_cross_status(wave, seg, wave_prev=None, seg_prev=None):
    """A true cross requires prior non-above and current above; current relative position alone is insufficient."""
    current_wave, current_seg = fnum(wave), fnum(seg)
    previous_wave, previous_seg = fnum(wave_prev), fnum(seg_prev)
    if None in (current_wave, current_seg, previous_wave, previous_seg):
        return '金叉状态不可判定'
    return '金叉' if current_wave > current_seg and previous_wave <= previous_seg else '未形成金叉'

def _display_value(value):
    number = fnum(value)
    return 'NA' if number is None else f'{number:.2f}'

def _triggered(value) -> bool:
    return indicator_output_triggered(value)

def _subsystem_row(number, name, evidence, status, conclusion, note='适用'):
    return {'公式': FORMULA_CALL_NAME, '序号': number, '子系统/输出': name, '当前值/证据': str(evidence or '无可用证据'), '状态': str(status or '状态不可判定'), '结论': str(conclusion or '结论不可判定'), '适用性/备注': str(note or '适用性未说明')}

def build_subsystem_rows(data: Dict, is_index: bool=False) -> List[Dict]:
    """Build the fixed 10-row Feilong table with closed external terminology."""
    d = data or {}
    lo = d.get('latest_outputs') or {}
    der = d.get('derived') or {}
    rc = d.get('realtime_calc') or {}

    def output_value(name):
        node = lo.get(name) or {}
        return node.get('latest')

    def index_na(number, name, reason):
        return _subsystem_row(number, name, '指数不适用', '指数不适用', f'{reason}，不纳入指数技术结论', '保留固定子系统行')
    output3 = output_value('OUTPUT3')
    output4 = output_value('OUTPUT4')
    output5 = output_value('OUTPUT5')
    output6 = output_value('OUTPUT6')
    wave_node = lo.get('波') or {}
    seg_node = lo.get('段') or {}
    wave = wave_node.get('latest')
    seg = seg_node.get('latest')
    wave_prev = wave_node.get('prev')
    seg_prev = seg_node.get('prev')
    wave_now = fnum(wave)
    wave_before = fnum(wave_prev)
    if wave_now is None or wave_before is None:
        wave_state = '状态不可判定'
    elif wave_now > wave_before:
        wave_state = '上行'
    elif wave_now < wave_before:
        wave_state = '下行'
    else:
        wave_state = '持平'
    trend = der.get('trend_filter') or {}
    box = der.get('box_shape') or {}
    limitup = der.get('limitup_unique') or {}
    password = der.get('boduan_password_calc') or {}
    private = der.get('private_entry_basic') or {}
    cross_state = golden_cross_status(wave_now, fnum(seg), fnum(wave_prev), fnum(seg_prev))
    resonance = (_triggered(output6) or _triggered(output5)) and (_triggered(output4) or _triggered(output3))
    rows = []
    rows.append(index_na(1, '龙头战法', '龙头战法依赖个股涨停与反转条件') if is_index else _subsystem_row(1, '龙头战法', f"OUTPUT3={_display_value(output3)}；X9近4日={der.get('x9_last4', 'NA')}；涨跌幅={_display_value(rc.get('change_pct'))}%", '触发' if _triggered(output3) else '未触发', '龙头战法信号已触发' if _triggered(output3) else '龙头战法信号尚未触发'))
    rows.append(_subsystem_row(2, '趋势过滤/中长期均线强势条件', f"EMA89={_display_value(trend.get('ema89'))}；高点13三重EMA={_display_value(trend.get('high_ema13x3'))}；高点5三重EMA={_display_value(trend.get('high_ema5x3'))}；站上三线={trend.get('close_gt_all_three', 'NA')}", '通过' if trend.get('x27_all_pass') else '未完整通过', '趋势过滤条件完整通过' if trend.get('x27_all_pass') else '趋势过滤条件尚未完整通过', '指数部分适用：仅采用趋势均线条件' if is_index else '底层复算为辅助证据；核心触发以本机公式输出为准'))
    rows.append(_subsystem_row(3, '四日实体重叠箱体/波段密码底层形态', f"今日箱体={box.get('x36_today', 'NA')}；36日内存在={box.get('x37_exist_36d', 'NA')}", '形成' if box.get('x36_today') else '未形成', '四日实体重叠箱体已形成' if box.get('x36_today') else '四日实体重叠箱体尚未形成', '底层复算为辅助证据；飞龙源码未随包提供'))
    rows.append(index_na(4, '首板/唯一涨停确认', '首板确认属于个股涨停模型') if is_index else _subsystem_row(4, '首板/唯一涨停确认', f"X45={limitup.get('x45_today_gt985_not_doji', 'NA')}；21日涨停次数={_display_value(limitup.get('x46_count_21d'))}；X47={limitup.get('x47_unique_limitup', 'NA')}", '成立' if limitup.get('x47_unique_limitup') else '不成立', '首板/唯一涨停条件成立' if limitup.get('x47_unique_limitup') else '首板/唯一涨停条件不成立'))
    rows.append(index_na(5, '波段密码打板', '打板信号属于个股涨停模型') if is_index else _subsystem_row(5, '波段密码打板', f"OUTPUT4={_display_value(output4)}；X47={password.get('x47', 'NA')}", '触发' if _triggered(output4) else '未触发', '波段密码打板信号已触发' if _triggered(output4) else '波段密码打板信号尚未触发'))
    rows.append(index_na(6, '量价模型/暴涨启动', '暴涨启动属于个股量价模型') if is_index else _subsystem_row(6, '量价模型/暴涨启动', f"OUTPUT5={_display_value(output5)}；涨跌幅={_display_value(rc.get('change_pct'))}%；成交额={_display_value(rc.get('amount_wan'))}万", '触发' if _triggered(output5) else '未触发', '暴涨启动信号已触发' if _triggered(output5) else '暴涨启动信号尚未触发'))
    rows.append(_subsystem_row(7, '波段随机强弱-波', f'当前={_display_value(wave)}；前值={_display_value(wave_prev)}', wave_state, f'波指标当前运行状态为{wave_state}'))
    rows.append(_subsystem_row(8, '波段随机强弱-段', f'波当前/前值={_display_value(wave)}/{_display_value(wave_prev)}；段当前/前值={_display_value(seg)}/{_display_value(seg_prev)}', cross_state, f'飞龙在天当前为{cross_state}；仅当前波>段不视为金叉', '金叉必须满足前一周期波<=段且当前波>段'))
    rows.append(index_na(9, '私募秘进', '私募秘进属于个股封板条件') if is_index else _subsystem_row(9, '私募秘进', f"OUTPUT6={_display_value(output6)}；涨幅条件={private.get('pct_gt_4_8', 'NA')}；收最高={private.get('close_eq_high', 'NA')}", '触发' if _triggered(output6) else '未触发', '私募秘进信号已触发' if _triggered(output6) else '私募秘进信号尚未触发'))
    rows.append(index_na(10, '主升启动共振', '主升启动共振属于个股主动信号组合') if is_index else _subsystem_row(10, '主升启动共振', f'OUTPUT3/4/5/6={_display_value(output3)}/{_display_value(output4)}/{_display_value(output5)}/{_display_value(output6)}', '触发' if resonance else '未触发', '主升启动共振已形成' if resonance else '主升启动共振尚未形成'))
    return rows
