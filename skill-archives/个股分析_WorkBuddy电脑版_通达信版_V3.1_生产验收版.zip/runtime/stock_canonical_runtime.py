"""Portable, single-skill execution and evidence authorization for WorkBuddy."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
from datetime import datetime, timedelta, timezone
import uuid

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
TZ = timezone(timedelta(hours=8))
SKILL_ID = "individual-stock-analysis"
EXPECTED_DEPENDENCIES = {"numpy": "2.2.6", "pandas": "2.2.3"}


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def binding(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return {"path": str(path), "size": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def state_dir():
    custom = os.environ.get("WORKBUDDY_STOCK_STATE")
    return Path(custom).resolve() if custom else Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "WorkBuddyIndividualAnalysis"


def load_config():
    path = state_dir() / "config.json"
    return read(path) if path.is_file() else {}


def integrity():
    errors = []
    try:
        manifest = read(ROOT / "package_manifest.json")
        entries = manifest["files"]
        declared = set()
        for item in entries:
            relative = item["path"]
            path = (ROOT / relative).resolve()
            if not path.is_relative_to(ROOT) or relative in declared:
                raise ValueError("unsafe_or_duplicate_manifest_path")
            declared.add(relative)
            actual = binding(path)
            if any(item[key] != actual[key] for key in ("size", "sha256")):
                errors.append("package_file_changed:" + relative)
        actual_files = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
        if actual_files - declared - {"package_manifest.json"}:
            errors.append("unexpected_package_files:" + ",".join(sorted(actual_files - declared - {"package_manifest.json"})))
        if manifest.get("skill_id") != SKILL_ID:
            errors.append("package_skill_identity_mismatch")
        return {"status": "CLEAN_PASS" if not errors else "BLOCKED", "checked_files": len(entries),
                "errors": errors, "manifest": binding(ROOT / "package_manifest.json")}
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return {"status": "BLOCKED", "errors": [str(exc)]}


def contract():
    catalog = read(ROOT / "references" / "stock_skill_ids.json")
    contracts = read(ROOT / "references" / "stock_execution_contracts.json")
    if len(catalog["skills"]) != 1 or catalog["skills"][0]["id"] != SKILL_ID:
        raise ValueError("single_analysis_skill_catalog_required")
    result = contracts["contracts"][SKILL_ID]
    if result["purpose"] != "individual_analysis_only" or result["formulas"] != {"大牛线撑压版": 16, "飞龙在天": 10}:
        raise ValueError("analysis_contract_changed")
    semantic_path = ROOT / str(result.get("semantic_contract") or "")
    semantic = read(semantic_path) if semantic_path.is_file() else {}
    if semantic.get("schema") != "WORKBUDDY_TECHNICAL_SEMANTIC_CONTRACT_V1" or semantic.get("version") != "3.0.0":
        raise ValueError("technical_semantic_contract_missing_or_changed")
    acceptance_contract = read(ROOT / "references" / "production-acceptance-contract.json")
    if acceptance_contract.get("schema") != "WORKBUDDY_STOCK_PRODUCTION_ACCEPTANCE_CONTRACT_V1" or acceptance_contract.get("version") != "3.1.0":
        raise ValueError("production_acceptance_contract_missing_or_changed")
    if acceptance_contract.get("technical", {}).get("formulas") != {"大牛线撑压版": 16, "飞龙在天": 10} or acceptance_contract.get("technical", {}).get("total_subsystems") != 26:
        raise ValueError("production_acceptance_contract_formula_changed")
    return result


def normalize(value):
    from research_data import normalize_symbol
    raw = value.strip().upper()
    if re.fullmatch(r"\d{6}", raw):
        exchange = "SH" if raw.startswith("6") else "BJ" if raw.startswith(("4", "8", "92")) else "SZ"
        raw += "." + exchange
    return normalize_symbol(raw)


def request_errors(request, symbol=None):
    from intent import validate_analysis_request
    errors = validate_analysis_request(request)
    codes = set(re.findall(r"(?<!\d)\d{6}(?!\d)", request))
    if len(codes) > 1:
        errors.append("single_stock_required")
    if symbol and codes and codes != {symbol.split(".")[0]}:
        errors.append("request_symbol_mismatch")
    return errors


_GENERIC_NAME_TARGETS = {"这只股票", "该股票", "该股", "这家公司", "该公司", "个股", "股票", "公司"}

def _normalize_security_name(value):
    text = re.sub(r"[\s·・•()（）]", "", str(value or ""))
    for suffix in ("股份有限公司", "有限责任公司", "集团股份有限公司", "集团有限公司", "有限公司", "集团", "股份"):
        if text.endswith(suffix) and len(text) > len(suffix) + 1:
            text = text[:-len(suffix)]
            break
    return text.replace("股票", "").replace("个股", "")

def requested_name_candidate(request):
    if not isinstance(request, str):
        return None
    compact = re.sub(r"\s+", "", request)
    pattern = re.compile(r"(?:分析|研究|看看|看下|看)([\u4e00-\u9fffA-Za-z·]{2,24}?)(?=(?:的)?(?:所属行业|所在行业|所属板块|所在板块|市场情绪|走势|支撑|压力|基本面|技术面|财务|公告)|[，,。.!！?？;；]|$)")
    match = pattern.search(compact)
    if not match:
        return None
    candidate = match.group(1).strip("的")
    if candidate in _GENERIC_NAME_TARGETS or any(term in candidate for term in ("大盘", "指数", "全市场", "股票池")):
        return None
    return candidate

def request_identity_errors(request, research):
    candidate = requested_name_candidate(request)
    if not candidate:
        return []
    identity = research.get("security_identity") if isinstance(research, dict) else None
    names = identity.get("names", []) if isinstance(identity, dict) else []
    if not names:
        return ["request_name_identity_unverified:" + candidate]
    target = _normalize_security_name(candidate)
    normalized_names = [_normalize_security_name(name) for name in names]
    if not target or not any(target in name or name in target for name in normalized_names if name):
        return ["request_name_symbol_mismatch:" + candidate + "!=" + "/".join(names)]
    return []


def doctor(config):
    from technical import diagnose_technical
    checks = []
    def check(name, passed, detail):
        checks.append({"item": name, "status": "CLEAN_PASS" if passed else "BLOCKED", "detail": detail})
    check("Python版本", sys.version_info >= (3, 10), sys.version.split()[0])
    check("Python位数", struct.calcsize("P") * 8 == 64, str(struct.calcsize("P") * 8))
    for name, expected_version in EXPECTED_DEPENDENCIES.items():
        try:
            module = __import__(name)
            actual_version = str(module.__version__)
            check(name, actual_version == expected_version, f"{actual_version}，要求锁定版本 {expected_version}")
        except Exception as exc:
            check(name, False, str(exc))
    tdx = Path(config.get("tdx_root", "__not_configured__"))
    check("通达信目录", (tdx / "TdxW.exe").is_file() and (tdx / "T0002").is_dir(), str(tdx))
    for item in diagnose_technical(config):
        check(item["check"], item["status"] == "PASS", item["detail"])
    calendar = ROOT / "references" / f"exchange-calendar-{datetime.now(TZ).year}.json"
    check("交易日历策略", True, calendar.name if calendar.is_file() else "当年日历未随包提供：启用最多12个自然日的保守新鲜度回退，不猜测节假日")
    package = integrity()
    check("安装包完整性", package["status"] == "CLEAN_PASS", package)
    return {"schema": "WORKBUDDY_ANALYSIS_DIAGNOSTIC_V1", "status": "CLEAN_PASS" if all(c["status"] == "CLEAN_PASS" for c in checks) else "BLOCKED",
            "checks": checks, "live_formula_status": "NOT_VERIFIED", "state_dir": str(state_dir()),
            "next_step": "环境检查不会连接通达信；正式分析会另行核对两项公式及当前日线。"}


def technical_day(payload):
    formulas = payload["formula_results"]
    first = datetime.strptime(str(formulas["大牛线撑压版"]["bar_date"]), "%Y-%m-%d").date()
    second = datetime.strptime(str(formulas["飞龙在天"]["analysis_as_of_date"]).replace("-", ""), "%Y%m%d").date()
    if first != second:
        raise ValueError("technical_formula_date_mismatch")
    moment = datetime.now(TZ)
    calendar_path = ROOT / "references" / f"exchange-calendar-{moment.year}.json"
    if calendar_path.is_file():
        cal = read(calendar_path)
        closures = [(datetime.fromisoformat(a).date(), datetime.fromisoformat(b).date()) for a, b in cal["closed_ranges"]]
        allowed, day = set(), moment.date()
        for _ in range(32):
            if day.weekday() < 5 and not any(a <= day <= b for a, b in closures):
                allowed.add(day)
                if day < moment.date() or moment.hour >= 17:
                    break
            day -= timedelta(days=1)
        if first not in allowed:
            raise ValueError("technical_data_stale:" + first.isoformat())
    else:
        # Future years may not have an official holiday file at packaging time.
        # Do not invent holiday dates; accept only data no older than 12 natural days.
        if first > moment.date() or (moment.date() - first).days > 12:
            raise ValueError("technical_data_stale_without_calendar:" + first.isoformat())
    return first.isoformat()


def load_technical(config, symbol, folder):
    folder.mkdir(parents=True, exist_ok=True)
    source = folder / "technical.json"
    try:
        child = subprocess.run([sys.executable, str(Path(__file__).resolve()), "_technical", "--symbol", symbol, "--outdir", str(folder)],
                               capture_output=True, timeout=330, env={**os.environ, "WORKBUDDY_CANONICAL_CHILD": "1", "PYTHONUTF8": "1"})
        (folder / "technical.stdout.txt").write_bytes(child.stdout)
        (folder / "technical.stderr.txt").write_bytes(child.stderr)
        if not source.is_file():
            raise ValueError("technical_child_failed:" + child.stderr.decode("utf-8", errors="replace")[-1500:])
        payload = read(source)
        if child.returncode or payload.get("status") not in {"PASS", "CLEAN_PASS"}:
            raise ValueError("technical_not_complete:" + json.dumps(payload.get("errors", []), ensure_ascii=False))
        day = technical_day(payload)
        return payload, {"status": "CLEAN_PASS", "authorized": True, "source": binding(source), "technical_as_of": day}
    except (OSError, ValueError, KeyError, TypeError, subprocess.TimeoutExpired) as exc:
        return {"status": "BLOCKED", "components": "bull-feilong", "symbol": symbol, "analysis_complete": False,
                "scoring_executed": False, "subsystem_table": [], "formula_results": {}, "errors": [str(exc)]}, {
                    "status": "BLOCKED", "authorized": False, "errors": [str(exc)]}


def execute(symbol, request):
    from research_data import collect_research
    from analysis_report import build_report, render_markdown, validate_report
    rule = contract()
    errors = request_errors(request, symbol)
    if errors:
        return {"status": "BLOCKED", "errors": errors}, 2
    run_dir = state_dir() / "runs" / (datetime.now(TZ).strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8])
    run_dir.mkdir(parents=True)
    config = load_config()
    diagnostics = doctor(config)
    dump(run_dir / "environment.json", diagnostics)
    status = "BLOCKED"
    if diagnostics["status"] == "CLEAN_PASS":
        research = collect_research(symbol, run_dir / "evidence" / "research")
        errors.extend(request_identity_errors(request, research))
        if not errors:
            technical, technical_binding = load_technical(config, symbol, run_dir / "evidence" / "technical")
            report = build_report(symbol, request, research, technical, technical_binding)
            errors.extend(validate_report(report))
            if errors:
                report["status"] = "BLOCKED"
            dump(run_dir / "individual_stock_analysis.json", report)
            (run_dir / "individual_stock_analysis.md").write_text(render_markdown(report), encoding="utf-8")
            status = report["status"]
        else:
            status = "BLOCKED"
    else:
        errors.append("environment_check_failed")
    receipt = {"schema": "WORKBUDDY_STOCK_RUNTIME_RECEIPT_V1", "skill_id": SKILL_ID, "purpose": rule["purpose"],
               "status": status, "symbol": symbol, "request": request, "finished_at": datetime.now(TZ).isoformat(),
               "run_dir": str(run_dir), "package_manifest": binding(ROOT / "package_manifest.json"),
               "artifacts": [binding(p) for p in sorted(run_dir.rglob("*")) if p.is_file()], "errors": errors}
    receipt_path = run_dir / "receipt.json"
    dump(receipt_path, receipt)
    return {"status": status, "receipt": str(receipt_path), "report": str(run_dir / "individual_stock_analysis.md") if (run_dir / "individual_stock_analysis.md").exists() else None,
            "errors": errors, "next_step": "使用 authorize --receipt 核验本轮回执。"}, 0 if status in {"CLEAN_PASS", "DEGRADED"} else 2


def authorize(path):
    from analysis_report import validate_report
    errors = integrity()["errors"]
    receipt_path = Path(path).resolve()
    receipt = read(receipt_path)
    run_dir = Path(receipt["run_dir"]).resolve()
    if receipt_path.parent != run_dir or receipt.get("schema") != "WORKBUDDY_STOCK_RUNTIME_RECEIPT_V1" or receipt.get("skill_id") != SKILL_ID:
        errors.append("receipt_identity_invalid")
    if receipt.get("purpose") != contract()["purpose"]:
        errors.append("receipt_purpose_invalid")
    if receipt.get("package_manifest") != binding(ROOT / "package_manifest.json"):
        errors.append("receipt_package_changed")
    seen = set()
    for item in receipt["artifacts"]:
        path = Path(item["path"]).resolve()
        if not path.is_relative_to(run_dir) or str(path) in seen:
            errors.append("receipt_artifact_path_invalid")
            continue
        seen.add(str(path))
        try:
            if binding(path) != item:
                errors.append("artifact_changed:" + path.name)
        except OSError:
            errors.append("artifact_missing:" + path.name)
    required = {str((run_dir / name).resolve()) for name in ("environment.json", "individual_stock_analysis.json", "individual_stock_analysis.md")}
    if not required <= seen:
        errors.append("required_delivery_artifact_missing")
    actual_files = {str(p.resolve()) for p in run_dir.rglob("*") if p.is_file() and p.resolve() != receipt_path}
    if actual_files != seen:
        errors.append("receipt_artifact_set_mismatch")
    report_path = run_dir / "individual_stock_analysis.json"
    report = None
    if str(report_path) not in seen:
        errors.append("report_missing_from_receipt")
    elif not errors:
        report = read(report_path)
        if report.get("symbol") != receipt.get("symbol") or report.get("request") != receipt.get("request") or report.get("status") != receipt.get("status"):
            errors.append("report_receipt_mismatch")
        errors.extend(request_errors(report.get("request", ""), receipt["symbol"]))
        referenced = [s.get("raw_path") for s in report.get("sources", []) if s.get("raw_path")]
        technical_source = report.get("technical_binding", {}).get("source", {}).get("path")
        if technical_source:
            referenced.append(technical_source)
        if any(str(Path(p).resolve()) not in seen for p in referenced):
            errors.append("report_evidence_not_receipt_bound")
        if not errors:
            errors.extend(validate_report(report))
            from analysis_report import render_markdown
            if (run_dir / "individual_stock_analysis.md").read_text(encoding="utf-8") != render_markdown(report):
                errors.append("rendered_report_differs_from_evidence")
            environment = read(run_dir / "environment.json")
            if environment.get("status") != "CLEAN_PASS" or any(c.get("status") != "CLEAN_PASS" for c in environment.get("checks", [])):
                errors.append("environment_not_clean")
            if report.get("technical_binding", {}).get("authorized"):
                try:
                    technical_day(read(technical_source))
                except (OSError, ValueError, KeyError, TypeError) as exc:
                    errors.append(str(exc))
    errors.extend(receipt.get("errors", []))
    complete = not errors and receipt.get("status") == "CLEAN_PASS"
    partial = not errors and receipt.get("status") == "DEGRADED" and report is not None
    result = {"schema": "WORKBUDDY_STOCK_DELIVERY_AUTHORIZATION_V1", "status": "CLEAN_PASS" if complete else "DEGRADED" if partial else "BLOCKED",
              "receipt": binding(receipt_path), "complete_analysis_authorized": complete, "partial_delivery_allowed": partial,
              "errors": errors, "missing_items": report.get("missing_items", []) if report else []}
    return result, 0 if (complete or partial) else 2



def production_accept(symbol, request):
    """Run a target-machine production acceptance using live Tongdaxin evidence.

    Production readiness is about runtime/evidence integrity. A report may remain DEGRADED
    when public research sources have honest gaps, but the technical chain itself must be live,
    complete, date-aligned and receipt-authorized.
    """
    from technical import validate_subsystem_table, COUNTS, FORMULAS, BULL_OUTPUTS
    from feilong_analysis import REQUIRED_FORMULA_OUTPUTS

    acceptance_dir = state_dir() / "production_acceptance"
    acceptance_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(TZ).strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8]
    acceptance_path = acceptance_dir / (stamp + "-" + symbol.replace(".", "_") + ".json")
    errors = []
    checks = []

    def add(name, passed, detail):
        checks.append({"item": name, "status": "CLEAN_PASS" if passed else "BLOCKED", "detail": detail})
        if not passed:
            errors.append(name + ":" + (detail if isinstance(detail, str) else json.dumps(detail, ensure_ascii=False, default=str)))

    package = integrity()
    add("安装包完整性", package.get("status") == "CLEAN_PASS", package)

    run_result, run_code = execute(symbol, request)
    receipt_path = Path(str(run_result.get("receipt") or "")).resolve() if run_result.get("receipt") else None
    add("正式分析入口", run_code == 0 and run_result.get("status") in {"CLEAN_PASS", "DEGRADED"}, run_result)

    authorization = None
    report = None
    technical = None
    live_evidence = {}
    if receipt_path and receipt_path.is_file():
        authorization, auth_code = authorize(receipt_path)
        add("回执授权", auth_code == 0 and authorization.get("status") in {"CLEAN_PASS", "DEGRADED"}, authorization)
        try:
            receipt = read(receipt_path)
            run_dir = Path(receipt["run_dir"]).resolve()
            environment = read(run_dir / "environment.json")
            add("目标机环境", environment.get("status") == "CLEAN_PASS" and all(c.get("status") == "CLEAN_PASS" for c in environment.get("checks", [])), environment)
            report_path = run_dir / "individual_stock_analysis.json"
            if report_path.is_file():
                report = read(report_path)
                add("股票身份绑定", report.get("symbol") == symbol and report.get("request") == request, {"symbol": report.get("symbol"), "request": report.get("request")})
                source_info = report.get("technical_binding", {}).get("source", {})
                source_path = Path(str(source_info.get("path") or "")).resolve()
                source_ok = source_path.is_file() and binding(source_path) == source_info
                add("技术证据绑定", report.get("technical_binding", {}).get("authorized") is True and source_ok, source_info)
                if source_ok:
                    technical = read(source_path)
                    rows = technical.get("subsystem_table") or []
                    try:
                        counts = validate_subsystem_table(rows)
                        table_ok = counts == dict(COUNTS) and len(rows) == 26
                        table_detail = {"counts": counts, "total": len(rows)}
                    except Exception as exc:
                        table_ok = False
                        table_detail = str(exc)
                    add("26项技术表", table_ok, table_detail)
                    formula_results = technical.get("formula_results") or {}
                    formula_ok = set(formula_results) == set(FORMULAS) and all(formula_results.get(name, {}).get("status") == "PASS" and formula_results.get(name, {}).get("subsystem_count") == COUNTS[name] for name in FORMULAS)
                    add("双公式现场执行", formula_ok and technical.get("analysis_complete") is True and not technical.get("failed_formulas"), formula_results)
                    try:
                        verified_day = technical_day(technical)
                        date_ok = report.get("technical_as_of") == verified_day
                        date_detail = {"technical_day": verified_day, "report_day": report.get("technical_as_of")}
                    except Exception as exc:
                        date_ok = False
                        date_detail = str(exc)
                    add("双公式交易日一致", date_ok, date_detail)

                    bull_raw = source_path.parent / "bull-formula-raw.json"
                    bull_input = source_path.parent / "bull-analysis-input.json"
                    dragon_input = source_path.parent / "feilong-analysis-input.json"
                    evidence_files_ok = all(x.is_file() for x in (bull_raw, bull_input, dragon_input))
                    if evidence_files_ok:
                        try:
                            br = read(bull_raw)
                            outputs = (br.get("formula") or {}).get("Value") or {}
                            bull_live = isinstance(outputs, dict) and all(name in outputs for name in BULL_OUTPUTS)
                            dr = read(dragon_input)
                            raw_formula = dr.get("formula_raw") or {}
                            node = raw_formula.get(symbol, {}) if isinstance(raw_formula, dict) else {}
                            dragon_live = isinstance(node, dict) and all(name in node and isinstance(node.get(name), list) and node.get(name) for name in REQUIRED_FORMULA_OUTPUTS)
                            live_evidence = {"bull_formula_raw": binding(bull_raw), "bull_analysis_input": binding(bull_input), "feilong_analysis_input": binding(dragon_input), "bull_outputs_present": bull_live, "feilong_outputs_present": dragon_live}
                            evidence_files_ok = bull_live and dragon_live
                        except Exception as exc:
                            evidence_files_ok = False
                            live_evidence = {"error": str(exc)}
                    add("通达信原始公式证据", evidence_files_ok, live_evidence if live_evidence else {"required": [str(bull_raw), str(bull_input), str(dragon_input)]})

                    report_rows = []
                    core = report.get("core_sections") or {}
                    for name in FORMULAS:
                        report_rows.extend((core.get(name) or {}).get("subsystem_table") or [])
                    add("报告与技术证据一致", report_rows == rows and report.get("formula_results") == technical.get("formula_results"), {"report_rows": len(report_rows), "source_rows": len(rows)})
            else:
                add("正式报告文件", False, str(report_path))
        except Exception as exc:
            add("验收证据解析", False, f"{type(exc).__name__}: {exc}")
    else:
        add("正式回执文件", False, str(receipt_path) if receipt_path else "missing")

    production_ready = not errors
    result = {
        "schema": "WORKBUDDY_STOCK_PRODUCTION_ACCEPTANCE_V1",
        "status": "CLEAN_PASS" if production_ready else "BLOCKED",
        "production_ready": production_ready,
        "symbol": symbol,
        "request": request,
        "finished_at": datetime.now(TZ).isoformat(),
        "analysis_status": run_result.get("status"),
        "authorization_status": authorization.get("status") if isinstance(authorization, dict) else None,
        "complete_analysis_authorized": authorization.get("complete_analysis_authorized") if isinstance(authorization, dict) else False,
        "partial_delivery_allowed": authorization.get("partial_delivery_allowed") if isinstance(authorization, dict) else False,
        "research_missing_items": report.get("missing_items", []) if isinstance(report, dict) else [],
        "technical_live_verified": bool(production_ready and technical is not None),
        "checks": checks,
        "receipt": binding(receipt_path) if receipt_path and receipt_path.is_file() else None,
        "live_evidence": live_evidence,
        "errors": errors,
    }
    dump(acceptance_path, result)
    return {**result, "acceptance": str(acceptance_path)}, 0 if production_ready else 2

def configure(tdx_root):
    target = Path(tdx_root).resolve()
    if not (target / "TdxW.exe").is_file() or not (target / "T0002").is_dir():
        raise ValueError("请选择包含 TdxW.exe 和 T0002 的通达信主目录")
    state_dir().mkdir(parents=True, exist_ok=True)
    path = state_dir() / "config.json"
    if path.is_file():
        backup = path.with_name("config-backup-" + uuid.uuid4().hex[:8] + ".json")
        backup.write_bytes(path.read_bytes())
        if binding(backup)["sha256"] != binding(path)["sha256"]:
            raise ValueError("config_backup_failed")
    dump(path, {"schema": "WORKBUDDY_ANALYSIS_CONFIG_V1", "tdx_root": str(target)})
    return {"status": "CONFIGURED", "config": str(path), "next_step": "运行 doctor 检查环境，正式分析另核对公式。"}


def main(argv=None):
    parser = argparse.ArgumentParser(description="个股分析 WorkBuddy 电脑版")
    sub = parser.add_subparsers(dest="action", required=True)
    p = sub.add_parser("route"); p.add_argument("--query", required=True)
    p = sub.add_parser("run"); p.add_argument("--symbol", required=True); p.add_argument("--request", required=True)
    p = sub.add_parser("authorize"); p.add_argument("--receipt", required=True)
    p = sub.add_parser("accept"); p.add_argument("--symbol", required=True); p.add_argument("--request", required=True)
    p = sub.add_parser("configure"); p.add_argument("--tdx-root", required=True)
    sub.add_parser("doctor"); sub.add_parser("verify"); sub.add_parser("selftest")
    p = sub.add_parser("_technical"); p.add_argument("--symbol", required=True); p.add_argument("--outdir", required=True)
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:2] == ["run", "--"]:
        argv.pop(1)
    args = parser.parse_args(argv)
    try:
        if args.action == "_technical":
            if os.environ.get("WORKBUDDY_CANONICAL_CHILD") != "1":
                raise ValueError("canonical_entry_required")
            from technical import collect_technical
            result = collect_technical(load_config(), normalize(args.symbol), Path(args.outdir))
            dump(Path(args.outdir) / "technical.json", result)
            return 0 if result.get("status") in {"PASS", "CLEAN_PASS"} else 2
        code = 0
        if args.action == "run":
            result, code = execute(normalize(args.symbol), args.request)
        elif args.action == "authorize":
            result, code = authorize(args.receipt)
        elif args.action == "accept":
            result, code = production_accept(normalize(args.symbol), args.request)
        elif args.action == "configure":
            result = configure(args.tdx_root)
        elif args.action == "doctor":
            result = doctor(load_config()); code = 0 if result["status"] == "CLEAN_PASS" else 2
        elif args.action == "route":
            contract()
            errors = request_errors(args.query)
            result = {"status": "BLOCKED" if errors else "MATCHED", "skill_id": None if errors else SKILL_ID, "errors": errors}
            code = 2 if errors else 0
        elif args.action == "verify":
            result = integrity(); code = 0 if result["status"] == "CLEAN_PASS" else 2
        else:
            contract()
            import analysis_report, research_data, technical
            from bull_analysis import DaniuxianAnalyzer
            from feilong_analysis import golden_cross_status
            tests = [("分析600519", True), ("分析600519，不要评分", True), ("给600519评分", False),
                     ("分析600519并打分", False), ("分析600519和000001", False), ("分析大盘指数", False),
                     ("分析600519所属行业", True), ("分析600519所在板块", True),
                     ("分析600519的市场情绪影响", True), ("分析贵州茅台所属行业", True),
                     ("分析银行板块", False)]
            failed = [request for request, allowed in tests if (not request_errors(request)) != allowed]
            semantic_failed = []
            if golden_cross_status(11, 10, 9, 10) != "金叉":
                semantic_failed.append("golden_cross_true_cross")
            if golden_cross_status(11, 10, 11, 10) != "未形成金叉":
                semantic_failed.append("golden_cross_relative_position_must_not_equal_cross")
            if DaniuxianAnalyzer.FILTER([True, True, False, True], 1) != [True, False, False, True]:
                semantic_failed.append("tdx_filter_semantics")
            if request_identity_errors("分析贵州茅台", {"security_identity": {"names": ["平安银行"]}}) == []:
                semantic_failed.append("name_symbol_mismatch_not_detected")
            if request_identity_errors("分析贵州茅台所属行业", {"security_identity": {"names": ["贵州茅台", "贵州茅台酒股份有限公司"]}}):
                semantic_failed.append("valid_name_binding_rejected")
            bull_text = (ROOT / "runtime" / "bull_analysis.py").read_text(encoding="utf-8")
            technical_text = (ROOT / "runtime" / "technical.py").read_text(encoding="utf-8")
            for forbidden in ("avg_vol_5", "'妖股条件成立' if d.get('is_zt')"):
                if forbidden in bull_text:
                    semantic_failed.append("regression_forbidden:" + forbidden)
            for required in ("cb_r = volume / prev_volume", "'yaogu': yaogu", "'qibao1': qibao1"):
                if required not in bull_text:
                    semantic_failed.append("regression_required_missing:" + required)
            if "_merge_verified_snapshot_bar(records, snapshot, verified_trade_date)" not in technical_text:
                semantic_failed.append("verified_trade_date_not_bound_to_bull")
            runtime_text = Path(__file__).read_text(encoding="utf-8")
            for required in ("def production_accept(symbol, request):", "WORKBUDDY_STOCK_PRODUCTION_ACCEPTANCE_V1", "通达信原始公式证据", "production_ready"):
                if required not in runtime_text:
                    semantic_failed.append("production_acceptance_regression:" + required)
            all_failed = failed + semantic_failed
            result = {"status": "CLEAN_PASS" if not all_failed else "BLOCKED",
                      "offline_cases": len(tests) + 15, "failed": all_failed,
                      "live_status": "NOT_VERIFIED",
                      "coverage": ["intent", "name-symbol-binding", "golden-cross", "TDX-FILTER", "bull-formula-regression", "trade-date-binding", "production-acceptance-contract"]}
            code = 2 if all_failed else 0
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return code
    except (OSError, ValueError, KeyError, TypeError, ImportError) as exc:
        print(json.dumps({"status": "BLOCKED", "errors": [str(exc)]}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
