"""Bounded, anonymous public evidence for one A-share company."""

from __future__ import annotations

import hashlib
import html
import json
import math
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta, timezone
from pathlib import Path


TZ = timezone(timedelta(hours=8))
TIMEOUT_SECONDS = 12
MAX_RESPONSE_BYTES = 8_000_000
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140.0 Safari/537.36"
DATACENTER = "https://datacenter-web.eastmoney.com/api/data/v1/get"


def now() -> str:
    return datetime.now(TZ).isoformat(timespec="seconds")


def normalize_symbol(symbol: str) -> str:
    value = str(symbol).upper()
    if not re.fullmatch(r"\d{6}\.(SH|SZ|BJ)", value):
        raise ValueError("symbol_requires_six_digits_and_exchange")
    code, exchange = value.split(".")
    valid = (exchange == "SH" and code.startswith(("600", "601", "603", "605", "688", "689"))) or (
        exchange == "SZ" and code.startswith(("000", "001", "002", "003", "300", "301"))) or (
        exchange == "BJ" and code.startswith(("43", "83", "87", "88", "92")))
    if not valid:
        raise ValueError("symbol_exchange_mismatch_or_not_a_share")
    return value


def _code(symbol: str) -> str:
    return normalize_symbol(symbol).split(".")[0]


def _prefix(symbol: str) -> str:
    code, exchange = normalize_symbol(symbol).split(".")
    return exchange.lower() + code


def _number(value):
    if value is None or str(value).strip() in ("", "-", "--", "N/A", "null"):
        return None
    number = float(str(value).replace(",", "").strip())
    if not math.isfinite(number):
        raise ValueError("non_finite_number")
    return number


def _day(value, *, allow_missing=False) -> str | None:
    if value in (None, "") and allow_missing:
        return None
    text = str(value).strip()
    if re.fullmatch(r"\d{8}", text):
        text = f"{text[:4]}-{text[4:6]}-{text[6:]}"
    parsed = date.fromisoformat(text[:10])
    if parsed > datetime.now(TZ).date():
        raise ValueError("future_source_date")
    return parsed.isoformat()


def _identity(row: dict, symbol: str, *, required=False) -> str:
    found = False
    for key in ("SECUCODE", "SECURITY_CODE", "stockCode", "secCode", "paperCode", "code"):
        value = row.get(key)
        if value in (None, ""):
            continue
        found = True
        text = str(value).strip().upper()
        expected = {symbol, _code(symbol), _prefix(symbol).upper()}
        if text not in expected:
            raise ValueError(f"response_symbol_mismatch:{key}")
    if required and not found:
        raise ValueError("response_security_identity_missing")
    return "RESPONSE_MATCH" if found else "REQUEST_BOUND_NO_ECHO"


def _text(value) -> str:
    return html.unescape(re.sub(r"<[^>]*>", "", str(value or ""))).strip()


def parse_tencent(payload: bytes, symbol: str) -> dict:
    text = payload.decode("gb18030")
    match = re.search(r'v_([a-z]{2}\d{6})="([^"]*)"', text, re.I)
    if not match or match.group(1).lower() != _prefix(symbol):
        raise ValueError("response_symbol_mismatch:tencent")
    fields = match.group(2).split("~")
    if len(fields) < 53 or fields[2] != _code(symbol) or not fields[1]:
        raise ValueError("incomplete_or_mismatched_tencent_quote")
    timestamp = datetime.strptime(fields[30], "%Y%m%d%H%M%S").replace(tzinfo=TZ)
    if timestamp > datetime.now(TZ) + timedelta(minutes=5):
        raise ValueError("future_quote_timestamp")
    price = _number(fields[3])
    if price is None or price <= 0:
        raise ValueError("invalid_quote_price")
    specs = {"price": (3, "元/股", "公开快照"), "previous_close": (4, "元/股", "上一交易日收盘"),
             "pe_ttm": (39, "倍", "滚动十二个月"), "pb": (46, "倍", "源端市净率"),
             "float_market_cap": (44, "亿元", "流通市值"), "market_cap": (45, "亿元", "总市值")}
    return {"name": fields[1], "symbol": symbol, "source_date": timestamp.isoformat(),
            "identity_validation": "RESPONSE_MATCH",
            "metrics": {key: {"value": _number(fields[index]), "unit": unit, "basis": basis,
                              "period": timestamp.date().isoformat()}
                        for key, (index, unit, basis) in specs.items()}}


def parse_sina_financial(payload: dict, symbol: str) -> dict:
    result = payload.get("result") or {}
    data = result.get("data") or {}
    identity = _identity(data, symbol)
    report_list = data.get("report_list")
    if not isinstance(report_list, dict) or not report_list:
        raise ValueError("financial_report_list_missing")
    periods = []
    for raw_period in sorted(report_list, reverse=True)[:8]:
        period = _day(raw_period)
        record = report_list[raw_period]
        _identity(record, symbol)
        declared_unit = record.get("unit") or data.get("unit")
        items = []
        for item in record.get("data") or []:
            title = _text(item.get("item_title"))
            value = item.get("item_value")
            if not title or value in (None, "", "--"):
                continue
            unit = item.get("item_unit") or item.get("unit") or declared_unit
            embedded = re.search(r"[（(](元|万元|亿元|%|百分比|元/股)[）)]$", title)
            if not unit and embedded:
                unit = embedded.group(1)
            items.append({"label": title, "raw_value": value, "unit": unit,
                          "unit_status": "EXPLICIT" if unit else "NOT_PROVIDED",
                          "period": period, "year_over_year_raw": item.get("item_tongbi")})
        if items:
            periods.append({"period": period, "items": items})
    if not periods:
        raise ValueError("financial_statement_has_no_items")
    return {"symbol": symbol, "source_date": periods[0]["period"],
            "identity_validation": identity, "periods": periods}


def parse_reports(payload: dict, symbol: str) -> dict:
    rows = payload.get("data")
    if not isinstance(rows, list):
        raise ValueError("research_list_missing")
    result = []
    for row in rows[:30]:
        _identity(row, symbol, required=True)
        published = _day(row.get("publishDate"))
        title = _text(row.get("title"))
        if not title:
            continue
        info_code = str(row.get("infoCode") or "")
        url = f"https://pdf.dfcfw.com/pdf/H3_{info_code}_1.pdf" if re.fullmatch(r"[A-Za-z0-9_-]+", info_code) else None
        forecasts = []
        for field, label in (("predictThisYearEps", "源字段当年每股收益预测"),
                             ("predictNextYearEps", "源字段次年每股收益预测"),
                             ("predictNextTwoYearEps", "源字段后年每股收益预测")):
            value = _number(row.get(field))
            if value is not None:
                forecasts.append({"label": label, "value": value, "unit": "元/股", "fiscal_year": None,
                                  "period_note": "接口未明确预测年份，未自行推算"})
        result.append({"title": title, "institution": row.get("orgSName"), "published_at": published,
                       "url": url, "forecasts": forecasts, "classification": "机构观点，非公司承诺"})
    return {"symbol": symbol, "identity_validation": "RESPONSE_MATCH" if result else "REQUEST_BOUND_NO_ECHO",
            "source_date": max((r["published_at"] for r in result), default=None), "items": result,
            "window": "按源端顺序最多30份，不能代表全部机构覆盖"}


def parse_cninfo_map(payload: dict, symbol: str) -> dict:
    matches = [row for row in payload.get("stockList", []) if row.get("code") == _code(symbol)]
    if len(matches) != 1 or not matches[0].get("orgId"):
        raise ValueError("cninfo_target_orgid_unavailable")
    return {"symbol": symbol, "org_id": matches[0]["orgId"], "name": matches[0].get("zwjc"),
            "source_date": None, "identity_validation": "RESPONSE_MATCH"}


def parse_announcements(payload: dict, symbol: str) -> dict:
    rows = payload.get("announcements")
    if rows is None and payload.get("totalAnnouncement") == 0:
        rows = []
    if not isinstance(rows, list):
        raise ValueError("announcement_list_missing")
    result = []
    for row in rows[:30]:
        _identity(row, symbol, required=True)
        raw_time = row.get("announcementTime")
        published = _day(datetime.fromtimestamp(raw_time / 1000, TZ).date().isoformat()) if isinstance(raw_time, (float, int)) else _day(raw_time)
        identifier = str(row.get("announcementId") or "")
        title = _text(row.get("announcementTitle"))
        if not title or not re.fullmatch(r"[A-Za-z0-9_-]+", identifier):
            raise ValueError("announcement_identity_or_title_missing")
        result.append({"title": title, "published_at": published,
                       "url": f"https://www.cninfo.com.cn/new/disclosure/detail?annoId={identifier}",
                       "document_path": row.get("adjunctUrl"), "classification": "公司公告索引，正文未自动解读"})
    return {"symbol": symbol, "source_date": max((r["published_at"] for r in result), default=None),
            "identity_validation": "RESPONSE_MATCH" if result else "REQUEST_BOUND_NO_ECHO", "items": result,
            "total_returned_by_source": payload.get("totalAnnouncement"), "document_text_verified": False}


def parse_company(payload: dict, symbol: str) -> dict:
    rows = payload.get("jbzl")
    if not isinstance(rows, list) or not rows:
        raise ValueError("company_profile_missing")
    row = rows[0]
    _identity(row, symbol, required=True)
    mappings = {"ORG_NAME": "公司名称", "ORG_PROFILE": "公司简介", "BUSINESS_SCOPE": "经营范围",
                "MAIN_BUSINESS": "主营业务", "INDUSTRYCSRC1": "所属行业", "CHAIRMAN": "董事长",
                "LEGAL_PERSON": "法定代表人", "SECRETARY": "董事会秘书", "ACTUAL_CONTROLLER": "实际控制人"}
    facts = [{"label": label, "value": _text(row[key]), "unit": None}
             for key, label in mappings.items() if row.get(key) not in (None, "")]
    if not facts:
        raise ValueError("company_profile_has_no_usable_fields")
    return {"symbol": symbol, "source_date": _day(row.get("UPDATE_DATE"), allow_missing=True),
            "identity_validation": "RESPONSE_MATCH", "items": facts}


def parse_business(payload: dict, symbol: str) -> dict:
    rows = payload.get("zygcfx")
    if not isinstance(rows, list) or not rows:
        raise ValueError("business_segments_missing")
    result = []
    for row in rows[:80]:
        _identity(row, symbol, required=True)
        period = _day(row.get("REPORT_DATE"))
        result.append({"label": _text(row.get("ITEM_NAME")), "category": str(row.get("MAINOP_TYPE", "")),
                       "period": period, "revenue": {"value": _number(row.get("MAIN_BUSINESS_INCOME")), "unit": "元"},
                       "revenue_share": {"raw_value": row.get("MBI_RATIO"), "unit": None,
                                         "unit_status": "接口未明确比例单位，保留原值"}})
    return {"symbol": symbol, "source_date": max(r["period"] for r in result),
            "identity_validation": "RESPONSE_MATCH", "items": result}


def parse_holders(payload: dict, symbol: str) -> dict:
    rows = (payload.get("result") or {}).get("data")
    if not isinstance(rows, list):
        raise ValueError("holder_rows_missing")
    result = []
    for row in rows[:30]:
        _identity(row, symbol, required=True)
        period = _day(row.get("END_DATE"))
        result.append({"holder": _text(row.get("HOLDER_NAME")), "holder_type": row.get("HOLDER_TYPE"),
                       "period": period, "shares": {"value": _number(row.get("HOLD_NUM")), "unit": "股"},
                       "change_in_shares": {"raw_value": row.get("HOLD_NUM_CHANGE"), "unit": "股"},
                       "change_description": row.get("HOLD_CHANGE"),
                       "classification": "源端股东披露；未由名称推断机构身份"})
    return {"symbol": symbol, "source_date": max((r["period"] for r in result), default=None),
            "identity_validation": "RESPONSE_MATCH" if result else "REQUEST_BOUND_NO_ECHO", "items": result}


class _Collector:
    def __init__(self, symbol: str, output_dir: Path):
        self.symbol = normalize_symbol(symbol)
        self.raw_dir = Path(output_dir).resolve() / "research_raw"
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        self.sources = []
        self._last_eastmoney = 0.0

    def fetch(self, source_id: str, provider: str, url: str, parser, *, params=None, form=None, stale_days=None):
        if params:
            url += "?" + urllib.parse.urlencode(params)
        source = {"id": source_id, "provider": provider, "symbol": self.symbol, "url": url,
                  "retrieved_at": now(), "source_date": None, "status": "BLOCKED", "errors": [],
                  "raw_path": None, "sha256": None, "identity_validation": "NOT_VERIFIED"}
        self.sources.append(source)
        try:
            body = urllib.parse.urlencode(form).encode("utf-8") if form else None
            headers = {"User-Agent": UA, "Referer": url.split("?", 1)[0]}
            if body is not None:
                headers["Content-Type"] = "application/x-www-form-urlencoded"
                source["request_form"] = form
            request = urllib.request.Request(url, data=body, headers=headers)
            raw = None
            for attempt in range(2):
                source["attempts"] = attempt + 1
                if provider == "eastmoney":
                    delay = 1.1 - (time.monotonic() - self._last_eastmoney)
                    if delay > 0:
                        time.sleep(delay)
                    self._last_eastmoney = time.monotonic()
                try:
                    with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
                        raw = response.read(MAX_RESPONSE_BYTES + 1)
                        source["http_status"] = response.status
                    break
                except urllib.error.HTTPError as exc:
                    raw = exc.read(MAX_RESPONSE_BYTES + 1)
                    source["http_status"] = exc.code
                    if attempt == 0 and exc.code in {408, 425, 429, 500, 502, 503, 504}:
                        time.sleep(1.0)
                        continue
                    self._persist(source, raw)
                    raise ValueError(f"http_status:{exc.code}") from exc
                except (urllib.error.URLError, TimeoutError, OSError):
                    if attempt == 0:
                        time.sleep(1.0)
                        continue
                    raise
            if raw is None:
                raise ValueError("empty_network_response")
            self._persist(source, raw)
            if len(raw) > MAX_RESPONSE_BYTES:
                source["truncated"] = True
                raise ValueError("response_exceeds_size_limit")
            payload = raw if parser is parse_tencent else json.loads(raw.decode("utf-8-sig"))
            parsed = parser(payload, self.symbol)
            source["source_date"] = parsed.get("source_date")
            source["identity_validation"] = parsed.get("identity_validation", "REQUEST_BOUND_NO_ECHO")
            source["status"] = "CLEAN_PASS"
            if stale_days is not None and source["source_date"]:
                age = (datetime.now(TZ).date() - date.fromisoformat(source["source_date"][:10])).days
                if age > stale_days:
                    source["status"] = "DEGRADED"
                    source["errors"].append(f"source_older_than_{stale_days}_days:{age}")
            return parsed
        except (ValueError, TypeError, KeyError, IndexError, OverflowError, OSError, UnicodeError) as exc:
            source["errors"].append(f"{type(exc).__name__}: {exc}")
            return None

    def _persist(self, source: dict, raw: bytes):
        path = self.raw_dir / f"{source['id']}.response"
        with path.open("xb") as handle:
            handle.write(raw)
        source.update(raw_path=str(path), sha256=hashlib.sha256(raw).hexdigest(), byte_count=len(raw))


def _section(title: str, data: dict, source_ids: list[str], missing=None) -> dict:
    missing = list(missing or [])
    present = {key: value for key, value in data.items() if value is not None}
    if len(present) != len(data):
        missing.extend(key for key, value in data.items() if value is None)
    return {"title": title, "status": "DEGRADED" if present and missing else "CLEAN_PASS" if present else "BLOCKED",
            "source_ids": source_ids, "facts": present, "missing_items": missing,
            "inferences": [], "assumptions": [], "risks": []}


def collect_research(symbol: str, output_dir: Path) -> dict:
    symbol = normalize_symbol(symbol)
    collector = _Collector(symbol, output_dir)
    code, exchange = symbol.split(".")
    quote = collector.fetch("tencent_quote", "tencent", f"https://qt.gtimg.cn/q={_prefix(symbol)}", parse_tencent, stale_days=10)
    statements = {}
    for kind in ("lrb", "fzb", "llb"):
        statements[kind] = collector.fetch(f"sina_{kind}", "sina",
            "https://quotes.sina.cn/cn/api/openapi.php/CompanyFinanceService.getFinanceReport2022", parse_sina_financial,
            params={"paperCode": _prefix(symbol), "source": kind, "type": "0", "page": "1", "num": "8"}, stale_days=190)
    company = collector.fetch("eastmoney_company", "eastmoney", "https://emweb.securities.eastmoney.com/PC_HSF10/CompanySurvey/PageAjax",
                              parse_company, params={"code": exchange + code})
    business = collector.fetch("eastmoney_business", "eastmoney", "https://emweb.securities.eastmoney.com/PC_HSF10/BusinessAnalysis/PageAjax",
                               parse_business, params={"code": exchange + code}, stale_days=370)
    reports = collector.fetch("eastmoney_reports", "eastmoney", "https://reportapi.eastmoney.com/report/list", parse_reports,
                              params={"industryCode": "*", "pageSize": "30", "industry": "*", "beginTime": "2000-01-01",
                                      "endTime": datetime.now(TZ).date().isoformat(), "pageNo": "1", "qType": "0", "code": code}, stale_days=30)
    holders = collector.fetch("eastmoney_holders", "eastmoney", DATACENTER, parse_holders,
                              params={"reportName": "RPT_F10_EH_HOLDERS", "columns": "ALL", "filter": f'(SECURITY_CODE="{code}")',
                                      "pageNumber": "1", "pageSize": "30", "sortColumns": "END_DATE", "sortTypes": "-1",
                                      "source": "WEB", "client": "WEB"}, stale_days=190)
    mapping = collector.fetch("cninfo_identity", "cninfo", "https://www.cninfo.com.cn/new/data/szse_stock.json", parse_cninfo_map)
    announcements = None
    if mapping:
        announcements = collector.fetch("cninfo_announcements", "cninfo", "https://www.cninfo.com.cn/new/hisAnnouncement/query", parse_announcements,
                                         form={"stock": f"{code},{mapping['org_id']}", "tabName": "fulltext", "pageSize": "30", "pageNum": "1",
                                               "column": "", "category": "", "plate": "", "seDate": "", "searchkey": "", "secid": "", "isHLtitle": "false"})
    sections = {
        "company_business": _section("公司经营", {"profile": company, "business_segments": business}, ["eastmoney_company", "eastmoney_business"]),
        "governance": _section("治理与管理层", {"profile": company, "disclosed_holders": holders}, ["eastmoney_company", "eastmoney_holders"],
                               ["历史战略兑现、激励与资本配置需结合公告正文核实"]),
        "financials": _section("财务三表", statements, ["sina_lrb", "sina_fzb", "sina_llb"]),
        "announcements_events": _section("公告与事件", {"announcements": announcements}, ["cninfo_identity", "cninfo_announcements"],
                                         ["公告正文尚未逐份核实；标题不能替代事件结论"]),
        "institutional_research": _section("机构研究与盈利预测", {"reports": reports}, ["eastmoney_reports"],
                                           ["未获得全市场机构覆盖总数、明确年度的一致预期与目标价分布"]),
        "institutional_activity": _section("披露持股与变动", {"holders": holders}, ["eastmoney_holders"],
                                           ["未披露持仓不能视为没有持仓；未按名称推断持有人类型"]),
        "valuation": _section("估值事实", {"quote": quote}, ["tencent_quote"], ["历史估值区间与同业比较未采集"]),
    }
    for kind, statement in statements.items():
        if statement and any(item.get("unit_status") == "NOT_PROVIDED" for period in statement["periods"] for item in period["items"]):
            sections["financials"]["missing_items"].append(f"{kind}部分科目单位未由来源明确提供，保留原值")
    for key, payload in (("institutional_research", reports), ("institutional_activity", holders)):
        if payload is not None and not payload.get("items"):
            sections[key]["missing_items"].append("来源返回空列表，未据此认定没有覆盖或持仓")
    if company and not company.get("source_date"):
        sections["company_business"]["missing_items"].append("公司资料源端未提供更新日期")
    if quote and any(metric["value"] is None for metric in quote["metrics"].values()):
        sections["valuation"]["missing_items"].append("部分估值指标源端未提供")
    identity_names = []
    if isinstance(quote, dict) and quote.get("name"):
        identity_names.append(_text(quote.get("name")))
    if isinstance(company, dict):
        for item in company.get("items", []):
            if item.get("label") == "公司名称" and item.get("value"):
                identity_names.append(_text(item.get("value")))
    identity_names = list(dict.fromkeys(name for name in identity_names if name))
    security_identity = {"symbol": symbol, "primary_name": identity_names[0] if identity_names else None,
                         "names": identity_names, "verified": bool(identity_names)}

    missing = []
    source_by_id = {s["id"]: s for s in collector.sources}
    for section_id, section in sections.items():
        for source_id in section["source_ids"]:
            source = source_by_id.get(source_id)
            if not source or source["status"] != "CLEAN_PASS":
                section["missing_items"].append(f"来源未完整通过:{source_id}")
        if section["missing_items"] and section["status"] == "CLEAN_PASS":
            section["status"] = "DEGRADED"
        missing.extend({"section": section_id, "reason": reason} for reason in section["missing_items"])
    complete = all(section["status"] == "CLEAN_PASS" for section in sections.values()) and not missing
    usable = any(section["status"] != "BLOCKED" for section in sections.values())
    return {"schema": "INDIVIDUAL_STOCK_RESEARCH_V1", "symbol": symbol, "as_of": now(),
            "status": "CLEAN_PASS" if complete else "DEGRADED" if usable else "BLOCKED",
            "security_identity": security_identity,
            "sources": collector.sources, "sections": sections, "missing_items": missing,
            "scope": "仅指定证券的公开事实；数据源未提供的内容保留缺项"}
