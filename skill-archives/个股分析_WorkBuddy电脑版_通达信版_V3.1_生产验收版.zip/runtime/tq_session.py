"""Read-only analysis session identity passed to the Tongdaxin interface."""
