"""Analysis-only intent gate; no scoring implementation."""
import re

_CLAUSE_BOUNDARY = re.compile(r"[，,。.!！?？;；\n]|但是|但|而是|不过|然后|并且|并(?=分析|评分)|(?:只|仅)(?:做|要|需|进行)?")

_NEGATIVE = re.compile(r"(?:不(?:要|用|必|需(?:要)?|能|应(?:该)?|许)?|无需|禁止|别|拒绝|取消|停止|暂停|暂缓|放弃|撤销|而非|\b(?:no|not|never|without)\b|\bdon['’]t\b)", re.IGNORECASE)

_CONCEPT = re.compile(r"解释|介绍|科普|含义|概念|原理|定义|规则|标准|细则|机制|方法|是什么|什么意思|怎么(?:算|做)|如何(?:计算|使用)|有哪些|几套|多少套")

_NON_STOCK = re.compile(r"天气|气温|作文|作业|考试|成绩|数学|语文|电影|游戏|饭店|餐厅|酒店|软件|算法|代码|面试|员工|学生|课程")

_BROAD_SCOPE = re.compile(r"大盘|指数|行业$|板块$|选股|全市场|全部股票|所有股票|股票池|成分股|市场情绪")

_GENERIC_TARGETS = {"大盘", "指数", "市场", "全市场", "行业", "板块", "股票", "个股", "股票池", "成分股"}

def _has_single_stock_anchor(request: str) -> bool:
    if re.search(r"(?<!\d)\d{6}(?!\d)", request):
        return True
    compact = re.sub(r"[，,。.!！?？;；\s]", "", request)
    # Name-only requests may ask for the target stock's industry/sector/sentiment context.
    # Recognize the target before the relational phrase without treating a bare sector request as a stock.
    match = re.search(r"(?:分析|研究|看看|看下|看)([\u4e00-\u9fffA-Za-z]{2,20}?)(?:的)?(?:所属行业|所在行业|所属板块|所在板块|市场情绪|走势|支撑|压力)", compact)
    if not match:
        return False
    candidate = match.group(1)
    return candidate not in _GENERIC_TARGETS and not any(term in candidate for term in ("大盘", "指数", "全市场", "股票池", "成分股"))

_SCORING_TERMS = (
    "评分", "打分", "综合分", "总分", "得分", "分值", "分数", "评级", "排名", "等级",
    "score", "scores", "scoring", "rating", "ratings", "rank", "ranks", "ranking",
)

_SCORING_OPERATION_PATTERN = "(?:" + "|".join(re.escape(term) for term in _SCORING_TERMS) + ")"

def _term_state(request: str, term: str) -> tuple[bool, bool]:
    positive = False
    negative = False
    pattern = re.escape(term)
    if term.isascii():
        pattern = r"(?<![a-z])" + pattern + r"(?![a-z])"
    elif term.endswith("分"):
        pattern += r"(?!析)"
    for clause in _CLAUSE_BOUNDARY.split(request):
        for occurrence in re.finditer(pattern, clause, re.IGNORECASE):
            before = clause[max(0, occurrence.start() - 32):occurrence.start()]
            after = clause[occurrence.end():occurrence.end() + 24]
            other_operation = "分析" if term != "分析" else _SCORING_OPERATION_PATTERN
            if re.match(_NEGATIVE.pattern + r"(?:做|进行)?" + other_operation, after.lstrip()):
                after = ""
            # Scope negation to the requested operation, excluding unrelated clauses.
            negated = bool(_NEGATIVE.search(before) or _NEGATIVE.match(after.lstrip()))
            negated = negated or bool(re.match(r"(?:先|暂时|这次|目前|现在|就|都|也|可以|还是|暂且|暂){0,3}" + _NEGATIVE.pattern, after.lstrip()))
            if negated:
                negative = True
                continue
            if _CONCEPT.search(before + term + after):
                continue
            positive = True
    return positive, negative

def validate_analysis_request(request):
    if not isinstance(request, str) or not request.strip():
        return ["original_user_request_required"]
    for term in _SCORING_TERMS:
        pattern = re.escape(term)
        if term.isascii():
            pattern = r"(?<![a-z])" + pattern + r"(?![a-z])"
        elif term.endswith("分"):
            pattern += r"(?!析)"
        for clause in _CLAUSE_BOUNDARY.split(request):
            for occurrence in re.finditer(pattern, clause, re.I):
                before = clause[:occurrence.start()].strip()
                after = clause[occurrence.end():].strip()
                prefix = r"(?:不要|不用|无需|禁止|不能|拒绝|不需要|不允许|别|不)(?:进行|做|任何|给我|再|计算|输出|提供|附加|生成|的|\s)*$"
                suffix = r"^(?:不要|不用|无需|禁止|不能|不需要|不允许)(?:了)?$"
                negated = bool(re.search(prefix, before) or re.fullmatch(suffix, after))
                if re.search(r"不能不|不要不|不是不|不得不|不许不|不可以不", before[-20:]):
                    negated = False
                if not negated:
                    return ["analysis_and_scoring_must_be_separate"]
    if any(_BROAD_SCOPE.search(clause.strip()) for clause in _CLAUSE_BOUNDARY.split(request)) and not _has_single_stock_anchor(request):
        return ["single_stock_analysis_required"]
    if _NON_STOCK.search(request) and not re.search(r"股票|个股|(?<!\d)\d{6}(?!\d)", request):
        return ["individual_stock_scope_required"]
    if not _term_state(request, "分析")[0] and not re.search("研究|走势|支撑|压力", request):
        return ["analysis_request_required"]
    return []
