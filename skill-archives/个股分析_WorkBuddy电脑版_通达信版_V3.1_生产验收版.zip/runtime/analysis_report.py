"""Four-part evidence report with a strict analysis-only contract."""

from __future__ import annotations

import json
import re
import hashlib
import math
from collections import Counter
from copy import deepcopy
from datetime import datetime
from pathlib import Path

from research_data import TZ, normalize_symbol, now


FORMULAS = {"大牛线撑压版": 16, "飞龙在天": 10}
CORE_NAMES = ("个股研究引擎", "高级股票研究", "大牛线撑压版", "飞龙在天")
_FORBIDDEN = {"score", "scores", "scoring", "rank", "ranks", "ranking", "grade", "grades", "rating", "ratings",
              "评分", "分数", "总分", "排名", "排序", "等级", "评级", "百分制"}
_SAMPLE_KEYS = {"audit_fixture", "fixture", "fixtures", "fixture_boundary", "is_sample", "sample", "simulated", "simulation"}


def validate_analysis_only(value, path="root"):
    if isinstance(value, dict):
        for key, item in value.items():
            folded = str(key).lower()
            location = f"{path}.{key}"
            if folded == "scoring_executed":
                if item is not False:
                    raise ValueError(f"prohibited_scoring_execution:{location}")
                continue
            tokens = set(re.split(r"[_\s\-]+", folded))
            if folded in _FORBIDDEN or tokens.intersection(_FORBIDDEN) or any(word in folded for word in ("评分", "排名", "等级", "评级", "百分制")):
                raise ValueError(f"prohibited_analysis_field:{location}")
            if folded in _SAMPLE_KEYS or "fixture" in folded:
                raise ValueError(f"sample_evidence_rejected:{location}")
            if folded in {"mode", "data_mode", "data_origin", "source_type"} and str(item).lower() in {"sample", "fixture", "test", "audit", "simulated", "synthetic", "mock"}:
                raise ValueError(f"sample_evidence_rejected:{location}")
            validate_analysis_only(item, location)
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            validate_analysis_only(item, f"{path}[{index}]")
    elif isinstance(value, float) and not math.isfinite(value):
        raise ValueError(f"non_finite_report_value:{path}")


def _check_symbol(value: dict, symbol: str, label: str):
    for key in ("symbol", "code", "security_code"):
        found = value.get(key)
        if found and str(found).upper() != symbol:
            raise ValueError(f"report_symbol_mismatch:{label}.{key}")


def _research_part(title: str, keys: list[str], research: dict) -> dict:
    available = research.get("sections", {})
    sections = {}
    missing = []
    for key in keys:
        section = available.get(key)
        if not isinstance(section, dict):
            missing.append(f"研究章节缺失:{key}")
            continue
        sections[key] = deepcopy(section)
        missing.extend(str(reason) for reason in section.get("missing_items", []))
        if not section.get("facts"):
            missing.append(f"研究章节无事实:{key}")
        if section.get("status") != "CLEAN_PASS" and not section.get("missing_items"):
            missing.append(f"研究章节未完整通过:{key}")
    has_facts = any(bool(section.get("facts")) for section in sections.values())
    return {"title": title, "status": "BLOCKED" if not has_facts else "DEGRADED" if missing else "CLEAN_PASS",
            "sections": sections, "missing_items": missing}


def _technical_binding_check(binding, symbol):
    errors, contents = [], {}
    if not isinstance(binding, dict) or binding.get("authorized") is not True or binding.get("status") != "CLEAN_PASS":
        return ["technical_authorization_not_clean"], None
    for key in ("source",):
        item = binding.get(key)
        if not isinstance(item, dict):
            errors.append(f"technical_file_binding_missing:{key}")
            continue
        try:
            raw = Path(item["path"]).read_bytes()
            if len(raw) != item.get("size") or hashlib.sha256(raw).hexdigest() != item.get("sha256"):
                errors.append(f"technical_file_hash_or_size_mismatch:{key}")
                continue
            contents[key] = raw.decode("utf-8-sig")
        except (OSError, KeyError, TypeError, UnicodeError) as exc:
            errors.append(f"technical_file_unreadable:{key}:{type(exc).__name__}")
    if errors:
        return errors, None
    try:
        source = json.loads(contents["source"])
        if not isinstance(source, dict):
            return ["technical_source_must_be_object"], None
        validate_analysis_only(source, "technical_source")
        _check_symbol(source, symbol, "technical_source")
        if source.get("symbol", source.get("code")) != symbol:
            errors.append("technical_source_target_missing")
        if source.get("components") != "bull-feilong" or source.get("scoring_executed") is not False:
            errors.append("technical_source_mode_invalid")
        if source.get("status") not in {"PASS", "CLEAN_PASS"} or source.get("analysis_complete") is not True:
            errors.append("technical_source_not_complete")
        rows = source.get("subsystem_table")
        columns = {"公式", "序号", "子系统/输出", "当前值/证据", "状态", "结论", "适用性/备注"}
        if not isinstance(rows, list) or any(not isinstance(row, dict) or set(row) != columns for row in rows):
            errors.append("technical_source_table_invalid")
        else:
            if Counter(row.get("公式") for row in rows) != Counter(FORMULAS):
                errors.append("technical_source_row_counts_mismatch")
            for formula, count in FORMULAS.items():
                numbers = {str(row.get("序号")) for row in rows if row.get("公式") == formula}
                if numbers != {str(i) for i in range(1, count + 1)}:
                    errors.append(f"technical_source_sequence_invalid:{formula}")
        if source.get("required_subsystem_counts") != FORMULAS:
            errors.append("technical_source_required_counts_mismatch")
        formulas = source.get("formula_results", {})
        if set(formulas) != set(FORMULAS):
            errors.append("technical_source_formula_set_mismatch")
        else:
            bull_date = datetime.strptime(str(formulas["大牛线撑压版"].get("bar_date")), "%Y-%m-%d").date().isoformat()
            dragon_date = datetime.strptime(str(formulas["飞龙在天"].get("analysis_as_of_date")), "%Y%m%d").date().isoformat()
            if bull_date != dragon_date or binding.get("technical_as_of") != bull_date:
                errors.append("technical_source_dates_mismatch")
            if bull_date > datetime.now(TZ).date().isoformat():
                errors.append("technical_source_date_in_future")
        return errors, source
    except (OSError, ValueError, KeyError, TypeError, IndexError, AttributeError) as exc:
        return errors + [f"technical_binding_parse_invalid:{type(exc).__name__}:{exc}"], None


def _executive_summary(research: dict, technical: dict) -> dict:
    identity = research.get("security_identity") or {}
    rows = technical.get("subsystem_table") or []
    triggered = []
    structure = []
    structure_names = {"主趋势线", "EMA均线分层", "DX动量指标", "控盘程度", "财神短线",
                       "BOLL+多重均线", "核心黄金分割撑压", "趋势过滤/中长期均线强势条件",
                       "波段随机强弱-波", "波段随机强弱-段"}
    for row in rows:
        status = str(row.get("状态") or "")
        name = str(row.get("子系统/输出") or "")
        formula = str(row.get("公式") or "")
        positive_trigger = (("触发" in status and "未触发" not in status) or
                            ("成立" in status and "不成立" not in status) or status == "金叉")
        if positive_trigger:
            triggered.append(f"{formula}-{name}：{status}")
        if name in structure_names:
            structure.append(f"{formula}-{name}：{row.get('结论')}")
    section_status = {}
    for key, section in (research.get("sections") or {}).items():
        if isinstance(section, dict):
            section_status[key] = section.get("status")
    return {
        "security": {"symbol": research.get("symbol"), "name": identity.get("primary_name"),
                     "identity_verified": bool(identity.get("verified"))},
        "triggered_signals": triggered,
        "technical_structure": structure,
        "research_section_status": section_status,
        "known_data_gaps": len(research.get("missing_items") or []),
        "note": "仅汇总本轮已绑定证据，不产生评分、排名或未由来源支持的预测。",
    }


def build_report(symbol, request, research, technical, technical_binding) -> dict:
    symbol = normalize_symbol(symbol)
    if not isinstance(request, (str, dict)):
        raise ValueError("report_request_must_be_text_or_object")
    if isinstance(request, dict):
        validate_analysis_only(request, "request")
        _check_symbol(request, symbol, "request")
    else:
        requested_codes = set(re.findall(r"(?<!\d)\d{6}(?!\d)", request))
        if requested_codes and requested_codes != {symbol.split(".")[0]}:
            raise ValueError("report_request_security_mismatch")
    for label, payload in (("research", research), ("technical", technical), ("technical_binding", technical_binding)):
        if not isinstance(payload, dict):
            raise ValueError(f"report_input_must_be_object:{label}")
        validate_analysis_only(payload, label)
        _check_symbol(payload, symbol, label)
    if research.get("symbol") != symbol:
        raise ValueError("research_target_binding_missing")
    identity = research.get("security_identity")
    if not isinstance(identity, dict) or identity.get("symbol") != symbol:
        raise ValueError("research_security_identity_missing_or_mismatched")
    sources = research.get("sources")
    if not isinstance(sources, list):
        raise ValueError("research_sources_must_be_list")
    source_ids = set()
    for source in sources:
        if not isinstance(source, dict):
            raise ValueError("source_must_be_object")
        if source.get("symbol") != symbol:
            raise ValueError("source_security_binding_mismatch")
        identifier = source.get("id")
        if not identifier or identifier in source_ids:
            raise ValueError("source_id_missing_or_duplicated")
        source_ids.add(identifier)
        if source.get("status") == "CLEAN_PASS" and not all(source.get(key) for key in ("retrieved_at", "raw_path", "sha256")):
            raise ValueError("successful_source_missing_raw_evidence_binding")
    core = {
        "个股研究引擎": _research_part("个股研究引擎", ["company_business", "governance", "financials", "announcements_events", "valuation"], research),
        "高级股票研究": _research_part("高级股票研究", ["institutional_research", "institutional_activity"], research),
    }
    table = technical.get("subsystem_table", [])
    if not isinstance(table, list):
        raise ValueError("technical_table_must_be_list")
    if any(not isinstance(row, dict) for row in table):
        raise ValueError("technical_table_row_must_be_object")
    counts = Counter(row.get("公式") for row in table)
    if any(formula not in FORMULAS for formula in counts):
        raise ValueError("technical_formula_not_allowlisted")
    declared = technical.get("required_subsystem_counts")
    if declared is not None and declared != FORMULAS:
        raise ValueError("technical_required_counts_mismatch")
    required_columns = {"公式", "序号", "子系统/输出", "当前值/证据", "状态", "结论", "适用性/备注"}
    complete_rows = all(required_columns <= row.keys() for row in table)
    for formula in FORMULAS:
        numbers = [row.get("序号") for row in table if row.get("公式") == formula]
        if len(numbers) != len(set(map(str, numbers))):
            raise ValueError("technical_subsystem_sequence_duplicated")
    valid_technical = (technical.get("status") in {"PASS", "CLEAN_PASS"}
                       and technical.get("analysis_complete") is True
                       and technical.get("scoring_executed") is False
                       and counts == Counter(FORMULAS) and complete_rows)
    binding_errors, bound_source = _technical_binding_check(technical_binding, symbol)
    if bound_source is not None and bound_source != technical:
        binding_errors.append("technical_input_differs_from_bound_source")
    binding_ok = not binding_errors
    for formula, expected in FORMULAS.items():
        rows = [deepcopy(row) for row in table if row.get("公式") == formula]
        missing = []
        if len(rows) != expected:
            missing.append(f"原始子系统证据为{len(rows)}项，要求{expected}项")
        if not valid_technical:
            missing.append("技术来源未完整通过")
        if not binding_ok:
            missing.extend(binding_errors)
        core[formula] = {"title": formula, "status": "CLEAN_PASS" if not missing else "DEGRADED" if rows else "BLOCKED",
                         "expected_count": expected, "observed_count": len(rows),
                         "subsystem_table": rows, "missing_items": missing}
    missing = [{"part": title, "reason": reason} for title in CORE_NAMES for reason in core[title]["missing_items"]]
    if research.get("status") not in {"CLEAN_PASS", "DEGRADED", "BLOCKED"}:
        raise ValueError("invalid_research_status")
    if research.get("status") != "CLEAN_PASS" and not any(item["part"] in CORE_NAMES[:2] for item in missing):
        missing.append({"part": "个股研究引擎", "reason": "研究来源整体未完整通过"})
    all_complete = all(part["status"] == "CLEAN_PASS" for part in core.values()) and research["status"] == "CLEAN_PASS"
    usable = any(part["status"] != "BLOCKED" for part in core.values())
    report = {"schema": "INDIVIDUAL_STOCK_ANALYSIS_REPORT_V1", "purpose": "individual_analysis_only", "symbol": symbol,
              "security_identity": deepcopy(identity), "executive_summary": _executive_summary(research, technical),
              "created_at": now(), "as_of": research.get("as_of"), "request": deepcopy(request),
              "technical_as_of": technical_binding.get("technical_as_of"),
              "status": "CLEAN_PASS" if all_complete and not missing else "DEGRADED" if usable else "BLOCKED",
              "core_sections": core, "sources": deepcopy(sources), "missing_items": missing,
              "technical_binding": deepcopy(technical_binding),
              "formula_results": deepcopy(technical.get("formula_results", {})),
              "scope": "单只证券公开事实、公司研究及两项指定技术公式"}
    validate_analysis_only(report)
    return report


def validate_report(report) -> list[str]:
    """Validate stored evidence; an honest partial report is structurally valid."""
    errors = []
    try:
        validate_analysis_only(report)
    except ValueError as exc:
        errors.append(str(exc))
    if not isinstance(report, dict):
        return errors + ["report_must_be_object"]
    try:
        symbol = normalize_symbol(report.get("symbol", ""))
    except ValueError as exc:
        return errors + [str(exc)]
    if report.get("schema") != "INDIVIDUAL_STOCK_ANALYSIS_REPORT_V1":
        errors.append("report_schema_mismatch")
    if report.get("purpose") != "individual_analysis_only":
        errors.append("report_purpose_mismatch")
    identity = report.get("security_identity")
    if not isinstance(identity, dict) or identity.get("symbol") != symbol:
        errors.append("report_security_identity_invalid")
    if report.get("status") not in {"CLEAN_PASS", "DEGRADED", "BLOCKED"}:
        errors.append("report_status_invalid")
    core = report.get("core_sections")
    if not isinstance(core, dict) or set(core) != set(CORE_NAMES):
        return errors + ["required_four_core_sections_missing_or_extra"]
    for title in CORE_NAMES:
        part = core[title]
        if not isinstance(part, dict):
            errors.append(f"core_section_not_object:{title}")
            continue
        if part.get("status") not in {"CLEAN_PASS", "DEGRADED", "BLOCKED"}:
            errors.append(f"core_section_status_invalid:{title}")
        if title in FORMULAS:
            rows = part.get("subsystem_table")
            if not isinstance(rows, list):
                errors.append(f"subsystem_table_missing:{title}")
                continue
            if any(not isinstance(row, dict) or row.get("公式") != title for row in rows):
                errors.append(f"subsystem_formula_mismatch:{title}")
            if part.get("status") == "CLEAN_PASS":
                numbers = {str(row.get("序号")) for row in rows if isinstance(row, dict)}
                if len(rows) != FORMULAS[title] or numbers != {str(i) for i in range(1, FORMULAS[title] + 1)}:
                    errors.append(f"complete_subsystem_evidence_count_mismatch:{title}")
                if report.get("technical_binding", {}).get("authorized") is not True:
                    errors.append("complete_technical_section_missing_authorization")
        if part.get("status") == "CLEAN_PASS" and part.get("missing_items"):
            errors.append(f"complete_section_has_missing_items:{title}")
    if report.get("status") == "CLEAN_PASS":
        if report.get("missing_items") or any(part.get("status") != "CLEAN_PASS" for part in core.values() if isinstance(part, dict)):
            errors.append("complete_report_contains_incomplete_sections")
    sources = report.get("sources")
    if not isinstance(sources, list):
        return errors + ["sources_must_be_list"]
    seen = set()
    for source in sources:
        if not isinstance(source, dict):
            errors.append("source_not_object")
            continue
        source_id = source.get("id")
        if not source_id or source_id in seen:
            errors.append("source_id_missing_or_duplicate")
        seen.add(source_id)
        if source.get("symbol") != symbol:
            errors.append(f"source_symbol_mismatch:{source_id}")
        raw_path, expected_hash = source.get("raw_path"), source.get("sha256")
        if raw_path or expected_hash:
            try:
                actual = hashlib.sha256(Path(raw_path).read_bytes()).hexdigest()
                if actual != expected_hash:
                    errors.append(f"source_sha256_mismatch:{source_id}")
            except (OSError, TypeError, ValueError) as exc:
                errors.append(f"source_raw_unreadable:{source_id}:{type(exc).__name__}")
        elif source.get("status") == "CLEAN_PASS":
            errors.append(f"successful_source_raw_missing:{source_id}")
        if source.get("status") == "CLEAN_PASS" and not source.get("retrieved_at"):
            errors.append(f"successful_source_retrieval_time_missing:{source_id}")
    expected_research = {"个股研究引擎": {"company_business", "governance", "financials", "announcements_events", "valuation"},
                         "高级股票研究": {"institutional_research", "institutional_activity"}}
    source_states = {source.get("id"): source.get("status") for source in sources if isinstance(source, dict)}
    for title in CORE_NAMES[:2]:
        research_sections = core.get(title, {}).get("sections", {})
        if not isinstance(research_sections, dict):
            errors.append(f"research_sections_must_be_object:{title}")
            continue
        if core.get(title, {}).get("status") == "CLEAN_PASS" and set(research_sections) != expected_research[title]:
            errors.append(f"complete_research_part_sections_missing_or_extra:{title}")
        for section_id, section in research_sections.items():
            if not isinstance(section, dict):
                errors.append(f"research_section_not_object:{section_id}")
                continue
            facts = section.get("facts", {})
            if section.get("status") == "CLEAN_PASS" and not facts:
                errors.append(f"complete_research_section_has_no_facts:{section_id}")
            if section.get("status") == "CLEAN_PASS" and any(source_states.get(ref) != "CLEAN_PASS" for ref in section.get("source_ids", [])):
                errors.append(f"complete_research_section_source_not_clean:{section_id}")
            if facts:
                inherited = section.get("source_ids", [])
                if not inherited:
                    errors.append(f"research_fact_source_binding_missing:{section_id}")
                errors.extend(_fact_reference_errors(facts, seen, inherited, section_id))
            for field in ("inferences", "assumptions", "risks"):
                if section.get(field):
                    errors.extend(_fact_reference_errors(section[field], seen, section.get("source_ids", []), f"{section_id}.{field}"))
    technical_binding = report.get("technical_binding", {})
    if technical_binding.get("authorized") is True or any(core.get(name, {}).get("status") == "CLEAN_PASS" for name in FORMULAS):
        binding_errors, source_payload = _technical_binding_check(technical_binding, symbol)
        errors.extend(binding_errors)
        if source_payload:
            rows = [row for name in FORMULAS for row in core.get(name, {}).get("subsystem_table", [])]
            if rows != source_payload.get("subsystem_table"):
                errors.append("report_technical_rows_differ_from_source")
            if report.get("formula_results") != source_payload.get("formula_results"):
                errors.append("report_formula_results_differ_from_source")
        if report.get("technical_as_of") != technical_binding.get("technical_as_of"):
            errors.append("report_technical_as_of_binding_mismatch")
    formula_results = report.get("formula_results")
    if isinstance(formula_results, dict) and any(name not in FORMULAS for name in formula_results):
        errors.append("formula_results_outside_allowlist")
    return errors


def _fact_reference_errors(value, known, inherited, path):
    errors = []
    references = value.get("source_ids", inherited) if isinstance(value, dict) else inherited
    if not isinstance(references, list) or any(not isinstance(item, str) or item not in known for item in references):
        errors.append(f"fact_source_reference_unknown:{path}")
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, (dict, list)) and key != "source_ids":
                errors.extend(_fact_reference_errors(item, known, references, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            if isinstance(item, (dict, list)):
                errors.extend(_fact_reference_errors(item, known, references, f"{path}[{index}]"))
    return errors


def _cell(value):
    if value is None:
        return "未提供"
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False, allow_nan=False)
    return str(value).replace("|", "\\|").replace("\r", " ").replace("\n", " ")


_DISPLAY = {"profile": "公司资料", "business_segments": "主营构成", "disclosed_holders": "披露持有人", "lrb": "利润表",
            "fzb": "资产负债表", "llb": "现金流量表", "announcements": "公告索引", "reports": "机构研报", "holders": "持股披露",
            "quote": "公开估值快照", "symbol": "证券", "name": "名称", "source_date": "源内日期", "items": "条目",
            "metrics": "指标", "periods": "报告期", "period": "报告期", "label": "项目", "value": "数值", "raw_value": "源端原值",
            "unit": "单位", "basis": "口径", "title": "标题", "institution": "机构", "published_at": "发布日期",
            "url": "原文地址", "forecasts": "盈利预测", "fiscal_year": "明确预测年份", "period_note": "年份说明",
            "classification": "内容性质", "holder": "持有人", "holder_type": "源端持有人类型", "shares": "披露持股",
            "change_in_shares": "持股变化", "change_description": "变化说明", "revenue": "收入", "revenue_share": "收入占比",
            "category": "分类", "unit_status": "单位核实", "year_over_year_raw": "源端同比", "identity_validation": "证券校验",
            "price": "公开价格", "previous_close": "上一交易日收盘", "pe_ttm": "滚动市盈率", "pb": "市净率",
            "market_cap": "总市值", "float_market_cap": "流通市值", "window": "采集范围",
            "document_path": "源端文件地址", "document_text_verified": "全文已核实", "total_returned_by_source": "源端公告总条数"}


def _display(value):
    mapping = {"RESPONSE_MATCH": "返回证券与请求一致", "REQUEST_BOUND_NO_ECHO": "请求绑定，源端未回显证券", "EXPLICIT": "源端明确提供", "NOT_PROVIDED": "源端未提供"}
    if isinstance(value, str):
        return mapping.get(value, _cell(value))
    if isinstance(value, bool):
        return "是" if value else "否"
    return _cell(value)


def _render_facts(value, lines, depth=0):
    if isinstance(value, dict):
        simple = {key: item for key, item in value.items() if not isinstance(item, (dict, list))}
        if simple:
            lines.append("；".join(f"{_DISPLAY.get(key, key)}：{_display(item)}" for key, item in simple.items()))
            lines.append("")
        for key, item in value.items():
            if isinstance(item, (dict, list)) and item:
                lines.append(f"**{_DISPLAY.get(key, key)}**")
                lines.append("")
                _render_facts(item, lines, depth + 1)
    elif isinstance(value, list):
        for item in value[:12]:
            _render_facts(item, lines, depth + 1)
        if len(value) > 12:
            lines.extend([f"本节展示前12条，另有{len(value) - 12}条保留在结构化报告和原始证据中。", ""])
    else:
        lines.extend([_cell(value), ""])


def render_markdown(report) -> str:
    validate_analysis_only(report)
    labels = {"CLEAN_PASS": "完整通过", "DEGRADED": "部分内容缺失", "BLOCKED": "未取得有效证据"}
    identity = report.get("security_identity") or {}
    summary = report.get("executive_summary") or {}
    title_name = identity.get("primary_name") or ""
    lines = [f"# {report['symbol']} {title_name} 个股分析".strip(), "", f"基准时间：{_cell(report.get('as_of'))}", "",
             f"技术基准交易日：{_cell(report.get('technical_as_of'))}", "",
             f"状态：{labels.get(report['status'], report['status'])}", "", "## 核心摘要", "",
             f"证券身份：{_cell(title_name)}（{report['symbol']}），身份核验：{'已核验' if identity.get('verified') else '未核验'}", "",
             f"研究缺项数量：{_cell(summary.get('known_data_gaps'))}", ""]
    triggered = summary.get("triggered_signals") or []
    lines.append("已触发/成立的技术信号：" + ("；".join(triggered) if triggered else "本轮未发现明确触发项"))
    lines.append("")
    structure = summary.get("technical_structure") or []
    if structure:
        lines.extend(["技术结构摘要：", ""] + [f"- {_cell(item)}" for item in structure] + [""])
    for title in CORE_NAMES:
        part = report["core_sections"][title]
        lines.extend([f"## {title}", "", f"状态：{labels.get(part['status'], part['status'])}", ""])
        if "subsystem_table" in part:
            columns = ("序号", "子系统/输出", "当前值/证据", "状态", "结论", "适用性/备注")
            lines.append("| " + " | ".join(columns) + " |")
            lines.append("| " + " | ".join("---" for _ in columns) + " |")
            for row in part["subsystem_table"]:
                lines.append("| " + " | ".join(_cell(row.get(col)) for col in columns) + " |")
            lines.append("")
        for section in part.get("sections", {}).values():
            lines.extend([f"### {section.get('title', '')}", "", "来源编号：" + "、".join(section.get("source_ids", [])), ""])
            _render_facts(section.get("facts", {}), lines)
        if part.get("missing_items"):
            lines.extend(["待核实与缺项：", ""])
            lines.extend(f"- {_cell(reason)}" for reason in part["missing_items"])
            lines.append("")
    lines.extend(["## 来源与时间", "", "| 编号 | 来源 | 源内日期 | 读取时间 | 状态 | 原始证据 |", "| --- | --- | --- | --- | --- | --- |"])
    for source in report.get("sources", []):
        lines.append("| " + " | ".join(_cell(source.get(key)) for key in ("id", "provider", "source_date", "retrieved_at", "status", "raw_path")) + " |")
        if source.get("errors"):
            lines.extend(["", f"{source['id']}：" + "；".join(source["errors"]), ""])
    lines.extend(["", "## 核实边界", "", "事实按来源和报告期保留；缺失数据不推算，不将公告标题等同公告全文，不将机构预测等同公司承诺。", ""])
    return "\n".join(lines)
