@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0prepare.ps1"
if errorlevel 1 (
  echo 检查未完整通过，请保留上方缺项并查看“安装与调试.md”。
) else (
  echo 环境检查通过。正式分析仍会核对公式及数据日期。
)
pause
