[CmdletBinding()]
param([Parameter(ValueFromRemainingArguments=$true)][string[]]$EntryArguments)
$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
$stateRoot = $env:WORKBUDDY_STOCK_STATE
if (-not $stateRoot) { $stateRoot = Join-Path $env:LOCALAPPDATA 'WorkBuddyIndividualAnalysis' }
$pythonPath = Join-Path $stateRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $pythonPath)) {
    throw 'Run prepare.ps1 first to create the Python environment.'
}
& $pythonPath (Join-Path $PSScriptRoot 'codex_entry.py') @EntryArguments
exit $LASTEXITCODE
