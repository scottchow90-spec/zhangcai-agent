"""Synthetic regressions for native-date alignment, without SDK or network access."""

from __future__ import annotations

import copy
import importlib.util
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock


PACKAGE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("desktop_date_alignment_runtime", PACKAGE / "scripts/stock_canonical_runtime.py")
runtime = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = runtime
SPEC.loader.exec_module(runtime)
SYMBOL = "600519.SH"
TARGET = "2026-09-04"


def synthetic_scan():
    dates = ["2026-09-03", "2026-09-04", "2026-09-07"]
    items = []
    for name in ("大牛线4.0", "飞龙在天4.0"):
        fields = {"date": dates[:], "line": [13.0, 14.0, 99.0], "signal": [0, 100, 0]}
        raw = {SYMBOL: {key: [{"Date": day, "Value": value} for day, value in zip(dates, values)]
                        for key, values in fields.items() if key != "date"}, "ErrorId": "0"}
        items.append({"formula": name, "ok": True, "symbol": SYMBOL, "result": {SYMBOL: fields}, "raw_result": raw})
    return {"ok": True, "status": "FORMULA_QUERY_PASS", "symbol": SYMBOL, "items": items, "errors": []}


class DateAlignmentTests(unittest.TestCase):
    def test_intraday_values_are_trimmed_to_last_completed_daily_date(self):
        aligned = runtime.align_formula_scan_to_trade_date(synthetic_scan(), SYMBOL, TARGET)
        self.assertTrue(aligned["ok"])
        for item in aligned["items"]:
            self.assertEqual(item["result"][SYMBOL], {"date": ["2026-09-03", TARGET], "line": [13.0, 14.0], "signal": [0, 100]})
            self.assertEqual(item["date_alignment"]["retained_source_indices"], [0, 1])
            self.assertEqual(item["date_alignment"]["source_last_date"], "2026-09-07")
            self.assertEqual(item["date_alignment"]["removed_after_target_count"], 1)

    def test_target_day_missing_is_not_replaced_with_another_date(self):
        scan = synthetic_scan()
        scan["items"][0]["result"][SYMBOL]["date"] = ["2026-09-02", "2026-09-03", "2026-09-07"]
        original = copy.deepcopy(scan["items"][0]["result"])
        aligned = runtime.align_formula_scan_to_trade_date(scan, SYMBOL, TARGET)
        self.assertFalse(aligned["ok"])
        self.assertFalse(aligned["items"][0]["ok"])
        self.assertEqual(aligned["items"][0]["result"], original)
        self.assertIn("formula_alignment_target_date_missing", aligned["items"][0]["error"])

    def test_unordered_or_duplicate_native_dates_are_rejected(self):
        for dates in ([TARGET, "2026-09-03", "2026-09-07"], ["2026-09-03", TARGET, TARGET]):
            with self.subTest(dates=dates):
                scan = synthetic_scan()
                scan["items"][0]["result"][SYMBOL]["date"] = dates
                aligned = runtime.align_formula_scan_to_trade_date(scan, SYMBOL, TARGET)
                self.assertFalse(aligned["ok"])
                self.assertIn("formula_alignment_native_dates_not_increasing", aligned["items"][0]["error"])

    def test_series_length_conflict_does_not_partial_trim_fields(self):
        scan = synthetic_scan()
        scan["items"][0]["result"][SYMBOL]["signal"] = [100]
        original = copy.deepcopy(scan["items"][0]["result"])
        aligned = runtime.align_formula_scan_to_trade_date(scan, SYMBOL, TARGET)
        self.assertFalse(aligned["ok"])
        self.assertEqual(aligned["items"][0]["result"], original)
        self.assertIn("formula_alignment_series_length_mismatch:signal", aligned["items"][0]["error"])

    def test_original_scan_raw_result_and_archived_response_remain_unchanged(self):
        scan = synthetic_scan()
        before = copy.deepcopy(scan)
        with tempfile.TemporaryDirectory() as directory:
            response = Path(directory) / "formula-response.json"
            runtime.write_json(response, scan)
            response_bytes = response.read_bytes()
            aligned = runtime.align_formula_scan_to_trade_date(scan, SYMBOL, TARGET)
            self.assertEqual(response.read_bytes(), response_bytes)
        self.assertEqual(scan, before)
        for original, result in zip(scan["items"], aligned["items"]):
            self.assertEqual(original["raw_result"], result["raw_result"])
            self.assertEqual(len(result["raw_result"][SYMBOL]["line"]), 3)

    def test_already_aligned_result_values_remain_unchanged(self):
        scan = synthetic_scan()
        for item in scan["items"]:
            for key in item["result"][SYMBOL]:
                item["result"][SYMBOL][key] = item["result"][SYMBOL][key][:-1]
        aligned = runtime.align_formula_scan_to_trade_date(scan, SYMBOL, TARGET)
        self.assertTrue(aligned["ok"])
        for original, result in zip(scan["items"], aligned["items"]):
            self.assertEqual(result["result"], original["result"])
            self.assertEqual(result["date_alignment"]["status"], "ALREADY_ALIGNED")
            self.assertEqual(result["date_alignment"]["removed_after_target_count"], 0)

    def test_original_failure_cannot_be_upgraded_by_alignment(self):
        scan = synthetic_scan()
        scan["ok"] = False
        scan["errors"] = ["original_source_failure"]
        aligned = runtime.align_formula_scan_to_trade_date(scan, SYMBOL, TARGET)
        self.assertFalse(aligned["ok"])
        self.assertIn("original_source_failure", aligned["errors"])

    def test_failed_scan_without_error_text_still_produces_a_blocking_error(self):
        scan = synthetic_scan()
        scan["ok"] = False
        aligned = runtime.align_formula_scan_to_trade_date(scan, SYMBOL, TARGET)
        self.assertFalse(aligned["ok"])
        self.assertEqual(aligned["errors"], ["formula_alignment_original_scan_failed"])

    def test_missing_required_formula_remains_blocked(self):
        scan = synthetic_scan()
        scan["items"].pop()
        aligned = runtime.align_formula_scan_to_trade_date(scan, SYMBOL, TARGET)
        self.assertFalse(aligned["ok"])
        self.assertEqual(aligned["failed_formulas"], ["飞龙在天4.0"])

    def test_native_entry_applies_alignment_without_changing_clock(self):
        observation = {"trade_date": TARGET, "formula_scan": synthetic_scan(),
                       "evidence": {"fund_flow": {"test_only": True}, "evaluation_clock": {"as_of": "unchanged-clock"}}}
        original_clock = copy.deepcopy(observation["evidence"]["evaluation_clock"])
        native = types.SimpleNamespace(load_native_observation=mock.Mock(return_value=(observation, {}, [])))
        args = types.SimpleNamespace(evidence=None)
        with tempfile.TemporaryDirectory() as directory, mock.patch.dict(runtime.os.environ), \
             mock.patch.object(runtime, "entry", return_value=native), \
             mock.patch.object(runtime, "datetime", side_effect=AssertionError("clock must not change")):
            result, _, errors = runtime.native_observation(SYMBOL, {"tdx_root": directory}, args, Path(directory))
        self.assertEqual(errors, [])
        self.assertEqual(result["formula_scan"]["items"][0]["result"][SYMBOL]["date"][-1], TARGET)
        self.assertEqual(result["evidence"]["evaluation_clock"], original_clock)


if __name__ == "__main__":
    unittest.main()
