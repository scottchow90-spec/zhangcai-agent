from __future__ import annotations

import copy
import importlib.util
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest import mock


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import desktop_environment as env


class EnvironmentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "alternative-drive" / "证券行情终端"
        (self.root / "vipdoc").mkdir(parents=True)
        (self.root / "T0002").mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def write_days(self, symbol, dates):
        code, market = symbol.lower().split(".")
        path = self.root / "vipdoc" / market / "lday" / (market + code + ".day")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"".join(env.DAY_RECORD.pack(date, 1000, 1200, 900, 1100, 100000.0, 10000, 0) for date in dates))
        return path

    def formula_response(self, formula="大牛线4.0", with_dates=True):
        names = ("主趋势线", "EMA9", "EMA10", "EMA11") if formula == "大牛线4.0" else ("波", "段")
        values = [{"Date": "20260903", "Value": "10.25"}, {"Date": "20260904", "Value": "11.50"}]
        return {"ErrorId": "0", "600519.SH": {
            name: copy.deepcopy(values) if with_dates else [point["Value"] for point in values]
            for name in names
        }}

    def scan_responses(self, big, fly=None):
        tq = mock.Mock(_initialized=True, _reInitialized=False)
        tq.formula_process_mul_zb.side_effect = [big, fly if fly is not None else self.formula_response("飞龙在天4.0")]
        with mock.patch.object(env, "_existing_handle", return_value=tq), \
             mock.patch.object(env, "_initialize_explicit_sdk", side_effect=AssertionError("SDK initialization forbidden")):
            return env.collect_formula_scan(self.root, "600519.SH", {}, self.temp.name)

    def test_explicit_path_and_vipdoc_are_supported(self):
        self.assertEqual(env.discover_tdx_roots(self.root), [self.root.resolve()])
        self.assertEqual(env.discover_tdx_roots(self.root / "vipdoc"), [self.root.resolve()])
        self.assertEqual(env.discover_tdx_roots(self.root / "missing"), [])

    def test_discovery_preserves_multiple_installations(self):
        other = Path(self.temp.name) / "second"
        (other / "vipdoc").mkdir(parents=True)
        (other / "T0002").mkdir()
        with mock.patch.dict(env.os.environ, {"TDX_ROOT": str(self.root)}), \
             mock.patch.object(env, "_registry_candidates", return_value=[other]), \
             mock.patch.object(env, "_shortcut_candidates", return_value=[]), \
             mock.patch.object(env, "_common_candidates", return_value=[self.root]):
            self.assertEqual(env.discover_tdx_roots(), [self.root.resolve(), other.resolve()])

    def test_static_inspection_does_not_initialize_or_write(self):
        self.write_days("600519.SH", [20260903, 20260904])
        self.write_days("000001.SH", [20260903, 20260904])
        before = {str(path.relative_to(self.root)): path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        with mock.patch.object(env, "_initialize_explicit_sdk", side_effect=AssertionError("SDK import forbidden")), \
             mock.patch.object(env, "_load_normalizer", side_effect=AssertionError("SDK import forbidden")):
            result = env.inspect_environment(self.root)
        after = {str(path.relative_to(self.root)): path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        self.assertEqual(before, after)
        self.assertFalse(result["formula_execution_verified"])
        self.assertEqual(result["checks"]["stock_day"]["last_date"], "2026-09-04")
        self.assertIn("insufficient_native_history", [item["code"] for item in result["issues"]])

    def test_malformed_and_misaligned_history_is_rejected(self):
        path = self.write_days("600519.SH", [20260904])
        self.write_days("000001.SH", [20260903])
        result = env.inspect_environment(self.root)
        self.assertIn("stock_benchmark_date_mismatch", [item["code"] for item in result["issues"]])
        path.write_bytes(path.read_bytes() + b"x")
        self.assertEqual(env._day_summary(path)["error"], "day_file_invalid_length")
        self.write_days("600519.SH", [20260904, 20260903])
        self.assertEqual(env._day_summary(path)["error"], "day_dates_not_increasing")

    def test_invalid_ohlc_is_rejected(self):
        path = self.write_days("600519.SH", [20260904])
        path.write_bytes(env.DAY_RECORD.pack(20260904, 1000, 900, 800, 1100, 10.0, 100, 0))
        self.assertEqual(env._day_summary(path)["error"], "day_file_invalid_price")

    def test_alternate_daily_directory_cannot_pass_standard_layout_check(self):
        canonical = self.write_days("600519.SH", [20260904])
        alternate = self.root / "vipdoc" / "xinzeng" / "sh" / "lday" / canonical.name
        alternate.parent.mkdir(parents=True)
        canonical.replace(alternate)
        self.write_days("000001.SH", [20260904])
        result = env.inspect_environment(self.root)
        self.assertEqual(env._day_path(self.root, "600519.SH"), canonical)
        self.assertFalse(result["checks"]["stock_day"]["ok"])
        self.assertFalse(result["ok"])
        issue = next(item for item in result["issues"] if item["code"] == "stock_day_invalid")
        self.assertIn("标准本地日线尚未下载", issue["message"])
        self.assertFalse(result["checks"]["daily_layout"]["alternate_layouts_accepted"])

    def test_config_cannot_redirect_original_normalizer_outside_package(self):
        external = Path(self.temp.name) / "external-vendor" / "skills" / "tdx-local-hub" / "scripts" / "tdx_hub.py"
        external.parent.mkdir(parents=True)
        external.write_text("raise AssertionError('external normalizer must never load')\n", encoding="utf-8")
        normalizer = env._load_normalizer({"vendor_root": str(external.parents[3])})
        expected = env.PACKAGE_ROOT / "vendor" / "skills" / "tdx-local-hub" / "scripts" / "tdx_hub.py"
        self.assertEqual(Path(normalizer.__code__.co_filename).resolve(), expected.resolve())

    def test_no_session_blocks_without_creating_state_or_loading_sdk(self):
        state = Path(self.temp.name) / "state"
        with mock.patch.object(env, "_load_normalizer", return_value=lambda result, symbol: result), \
             mock.patch.object(env, "_existing_handle", return_value=None):
            result = env.collect_formula_scan(self.root, "600519.SH", {}, state)
        self.assertFalse(result["ok"])
        self.assertIn("sdk_initialize_not_authorized", result["errors"][0])
        self.assertFalse(state.exists())

    def test_formula_calls_keep_original_names_counts_and_adjustment(self):
        tq = mock.Mock(_initialized=True, _reInitialized=False)
        tq.formula_process_mul_zb.side_effect = [self.formula_response(), self.formula_response("飞龙在天4.0")]
        with mock.patch.object(env, "_existing_handle", return_value=tq):
            result = env.collect_formula_scan(self.root, "sh600519", {}, self.temp.name)
        self.assertTrue(result["ok"])
        self.assertEqual(tq.formula_process_mul_zb.call_args_list, [
            mock.call("大牛线撑压版", stock_list=["600519.SH"], count=20, return_date=True, return_count=300, dividend_type=0),
            mock.call("飞龙在天", stock_list=["600519.SH"], count=0, return_date=True, return_count=300, dividend_type=0),
        ])
        tq.initialize.assert_not_called()
        tq.close.assert_not_called()
        tq.formula_get_info.assert_not_called()
        tq.formula_get_all.assert_not_called()
        self.assertEqual(len(result["items"]), 2)

    def test_formula_errors_do_not_become_success(self):
        tq = mock.Mock(_initialized=True, _reInitialized=False)
        tq.formula_process_mul_zb.return_value = {"ErrorId": "404"}
        with mock.patch.object(env, "_existing_handle", return_value=tq), \
             mock.patch.object(env, "_load_normalizer", return_value=lambda value, symbol: value):
            result = env.collect_formula_scan(self.root, "600519.SH", {}, self.temp.name)
        self.assertFalse(result["ok"])
        self.assertEqual(len(result["errors"]), 2)

    def test_original_normalizer_rejects_formula_values_without_native_dates(self):
        tq = mock.Mock(_initialized=True, _reInitialized=False)
        raw_results = [self.formula_response(with_dates=False), self.formula_response("飞龙在天4.0", with_dates=False)]
        tq.formula_process_mul_zb.side_effect = raw_results
        with mock.patch.object(env, "_existing_handle", return_value=tq):
            result = env.collect_formula_scan(self.root, "600519.SH", {}, self.temp.name)
        self.assertFalse(result["ok"])
        self.assertEqual(len(result["failed_formulas"]), 2)
        self.assertTrue(all("native_formula_output_dates_missing" in error for error in result["errors"]))
        for item, raw in zip(result["items"], raw_results):
            self.assertEqual(item["raw_result"], raw)
            self.assertFalse(item["ok"])

    def test_explicit_initialization_releases_only_owned_connection(self):
        tq = mock.Mock(_initialized=True, _reInitialized=False)
        tq.formula_process_mul_zb.side_effect = [self.formula_response(), self.formula_response("飞龙在天4.0")]
        with mock.patch.object(env, "_existing_handle", return_value=None), \
             mock.patch.object(env, "_initialize_explicit_sdk", return_value=tq) as initialize:
            result = env.collect_formula_scan(self.root, "600519.SH", {"allow_sdk_initialize": True}, self.temp.name)
        self.assertTrue(result["ok"])
        self.assertEqual(result["connection_mode"], "explicit_sdk_initialize")
        initialize.assert_called_once()
        tq._release.assert_called_once()

    def test_big_line_chart_text_does_not_block_named_scoring_fields(self):
        raw = self.formula_response()
        raw["600519.SH"].update({
            "OUTPUT30": ["抄底", {"Date": "20260904", "Value": "0.00"}],
            "OUTPUT46": ["概念板块："],
            "OUTPUT66": ["核心黄金分割: 有效可见"],
            "压力一": [{"Date": "20260903", "Value": None}],
        })
        before = copy.deepcopy(raw)
        with self.assertRaisesRegex(ValueError, "native_formula_output_dates_missing:OUTPUT30"):
            env._load_normalizer({})(raw, "600519.SH")
        result = self.scan_responses(raw)
        self.assertTrue(result["ok"], result["errors"])
        item = result["items"][0]
        self.assertEqual(item["raw_result"], before)
        self.assertEqual(raw, before)
        self.assertEqual(set(item["result"]["600519.SH"]), {"主趋势线", "EMA9", "EMA10", "EMA11", "date"})
        self.assertEqual(item["result"]["600519.SH"]["date"], ["2026-09-03", "2026-09-04"])
        self.assertEqual(item["result"]["600519.SH"]["主趋势线"], ["10.25", "11.50"])
        self.assertEqual(set(item["omitted_fields"]), {"OUTPUT30", "OUTPUT46", "OUTPUT66", "压力一"})
        self.assertFalse(item["projection"]["anonymous_output_mapping"])

    def test_each_required_big_line_field_must_be_present(self):
        for name in ("主趋势线", "EMA9", "EMA10", "EMA11"):
            with self.subTest(name=name):
                raw = self.formula_response()
                del raw["600519.SH"][name]
                result = self.scan_responses(raw)
                self.assertFalse(result["ok"])
                self.assertIn("native_formula_required_fields_missing:" + name, result["items"][0]["error"])
                self.assertEqual(result["items"][0]["raw_result"], raw)

    def test_big_line_required_dates_cannot_conflict_or_be_absent(self):
        for problem in ("conflicting", "missing", "nonincreasing"):
            with self.subTest(problem=problem):
                raw = self.formula_response()
                values = raw["600519.SH"]["EMA9"]
                if problem == "conflicting":
                    values[-1]["Date"] = "20260907"
                elif problem == "missing":
                    del values[-1]["Date"]
                else:
                    values[-1]["Date"] = values[0]["Date"]
                result = self.scan_responses(raw)
                self.assertFalse(result["ok"])
                self.assertIn("native_formula_", result["items"][0]["error"])
                self.assertNotIn("result", result["items"][0])

    def test_big_line_numeric_fields_reject_nonfinite_empty_and_nonnumeric_values(self):
        for value in (None, "", " ", "NaN", "Infinity", float("nan"), float("inf"), "not-a-number", {}, True):
            with self.subTest(value=value):
                raw = self.formula_response()
                raw["600519.SH"]["EMA10"][-1]["Value"] = value
                result = self.scan_responses(raw)
                self.assertFalse(result["ok"])
                self.assertIn("native_formula_numeric_value_invalid:EMA10", result["items"][0]["error"])
                self.assertNotIn("result", result["items"][0])

    def test_big_line_empty_numeric_series_is_rejected(self):
        raw = self.formula_response()
        raw["600519.SH"]["EMA11"] = []
        result = self.scan_responses(raw)
        self.assertFalse(result["ok"])
        self.assertIn("native_formula_output_not_series:EMA11", result["items"][0]["error"])

    def test_optional_named_risk_series_is_preserved_and_validated(self):
        for name in ("庄出", "STJ83"):
            with self.subTest(name=name):
                raw = self.formula_response()
                raw["600519.SH"][name] = [{"Date": "20260903", "Value": "0.00"}, {"Date": "20260904", "Value": "1.00"}]
                result = self.scan_responses(raw)
                self.assertTrue(result["ok"], result["errors"])
                self.assertEqual(result["items"][0]["result"]["600519.SH"][name], ["0.00", "1.00"])
                raw["600519.SH"][name][-1]["Value"] = "signal text"
                failed = self.scan_responses(raw)
                self.assertFalse(failed["ok"])
                self.assertIn("native_formula_numeric_value_invalid:" + name, failed["items"][0]["error"])

    def test_anonymous_outputs_never_supply_absent_dealer_risk(self):
        raw = self.formula_response()
        raw["600519.SH"].update({name: [{"Date": "20260903", "Value": "1.00"}, {"Date": "20260904", "Value": "1.00"}]
                                for name in ("OUTPUT32", "OUTPUT33", "庄家出货")})
        result = self.scan_responses(raw)
        self.assertTrue(result["ok"], result["errors"])
        item = result["items"][0]
        self.assertNotIn("庄出", item["result"]["600519.SH"])
        self.assertNotIn("STJ83", item["result"]["600519.SH"])
        self.assertIn("OUTPUT32", item["omitted_fields"])
        self.assertEqual(item["raw_result"], raw)

    def test_other_formula_still_uses_unfiltered_original_normalizer(self):
        fly = self.formula_response("飞龙在天4.0")
        fly["600519.SH"]["OUTPUT30"] = ["unexpected text"]
        result = self.scan_responses(self.formula_response(), fly)
        self.assertFalse(result["ok"])
        self.assertTrue(result["items"][0]["ok"])
        item = result["items"][1]
        self.assertIn("native_formula_output_dates_missing:OUTPUT30", item["error"])
        self.assertNotIn("projection", item)
        self.assertEqual(item["raw_result"], fly)

    def test_formula_identity_read_is_explicit_and_uses_exact_sdk_arguments(self):
        tq = mock.Mock(_initialized=True, _reInitialized=False)
        tq.formula_process_mul_zb.side_effect = [self.formula_response(), self.formula_response("飞龙在天4.0")]
        identities = [{"ErrorId": "0", "Value": "synthetic big formula source"}, {"ErrorId": "0", "Value": "synthetic fly formula source"}]
        tq.formula_get_info.side_effect = identities
        with mock.patch.object(env, "_existing_handle", return_value=tq), \
             mock.patch.object(env, "_initialize_explicit_sdk", side_effect=AssertionError("SDK initialization forbidden")):
            result = env.collect_formula_scan(self.root, "600519.SH", {"read_formula_info": True}, self.temp.name)
        self.assertTrue(result["ok"], result["errors"])
        self.assertEqual(tq.formula_get_info.call_args_list, [
            mock.call(formula_type=0, formula_code="大牛线撑压版"),
            mock.call(formula_type=0, formula_code="飞龙在天"),
        ])
        self.assertEqual([item["native_formula_info"] for item in result["items"]], identities)
        tq.formula_get_all.assert_not_called()
        tq.initialize.assert_not_called()
        tq.close.assert_not_called()

    def test_formula_identity_failure_is_recorded_without_inventing_source(self):
        tq = mock.Mock(_initialized=True, _reInitialized=False)
        tq.formula_process_mul_zb.side_effect = [self.formula_response(), self.formula_response("飞龙在天4.0")]
        tq.formula_get_info.side_effect = RuntimeError("identity unavailable")
        with mock.patch.object(env, "_existing_handle", return_value=tq):
            result = env.collect_formula_scan(self.root, "600519.SH", {"read_formula_info": True}, self.temp.name)
        self.assertTrue(result["ok"], result["errors"])
        for item in result["items"]:
            self.assertEqual(item["identity_error"], "identity unavailable")
            self.assertNotIn("native_formula_info", item)
        tq.formula_get_all.assert_not_called()

    def test_string_false_does_not_authorize_initialization(self):
        with mock.patch.object(env, "_existing_handle", return_value=None), \
             mock.patch.object(env, "_load_normalizer", return_value=lambda value, symbol: value), \
             mock.patch.object(env, "_initialize_explicit_sdk") as initialize:
            result = env.collect_formula_scan(self.root, "600519.SH", {"allow_sdk_initialize": "false"}, self.temp.name)
        self.assertFalse(result["ok"])
        initialize.assert_not_called()

    def test_sdk_state_cannot_write_inside_tdx(self):
        with self.assertRaisesRegex(ValueError, "sdk_state_must_be_outside_tdx"):
            env._initialize_explicit_sdk(self.root, self.root / "user-state")

    def test_fake_sdk_initialization_uses_only_credential_free_external_state(self):
        sdk = self.root / "PYPlugins" / "user" / "tqcenter.py"
        sdk.parent.mkdir(parents=True)
        sdk.write_text(
            "class tq:\n"
            "    _initialized = False\n"
            "    run_id = -1\n"
            "    @classmethod\n"
            "    def initialize(cls, path):\n"
            "        cls._connection_path = path\n"
            "        cls._initialized = True\n"
            "        cls.run_id = 1\n",
            encoding="utf-8",
        )
        secret = sdk.parent / "tdxdata_test.py"
        secret.write_text("raise AssertionError('user initialization must not execute')\n", encoding="utf-8")
        before = {str(path.relative_to(self.root)): path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        previous_cwd, previous_argv, previous_path = Path.cwd(), sys.argv[:], sys.path[:]
        state = Path(self.temp.name) / "separate-state"
        tq = env._initialize_explicit_sdk(self.root, state)
        after = {str(path.relative_to(self.root)): path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        self.assertEqual(before, after)
        self.assertEqual(Path.cwd(), previous_cwd)
        self.assertEqual(sys.argv, previous_argv)
        self.assertEqual(sys.path, previous_path)
        init = Path(tq._connection_path)
        self.assertEqual(init.parent, state.resolve())
        self.assertEqual(init.read_text(encoding="utf-8"), "# Credential-free connection identity for the read-only formula worker.\n")
        self.assertFalse((sdk.parent / "__pycache__").exists())

    def test_removed_capital_formulas_cannot_be_reintroduced(self):
        for name in ("游资资金监控", "庄家资金监控", "机构资金监控"):
            with self.assertRaisesRegex(ValueError, "excluded_capital_formula"):
                env._configured_formulas({"formula_names": {"大牛线4.0": name}})

    def test_capital_formula_whitespace_cannot_bypass_exclusion(self):
        for name in ("游资资金监控", "庄家资金监控", "机构资金监控"):
            for prefix, suffix in (("", " "), (" ", ""), ("\t", "\t"), ("\u3000", "\u3000")):
                for technical_name in ("大牛线4.0", "飞龙在天4.0"):
                    with self.subTest(name=name, prefix=prefix, suffix=suffix, technical_name=technical_name):
                        with self.assertRaisesRegex(ValueError, "excluded_capital_formula"):
                            env._configured_formulas({"formula_names": {technical_name: prefix + name + suffix}})

    def test_technical_formula_names_remain_normalized(self):
        formulas = env._configured_formulas({"formula_names": {"大牛线4.0": " 大牛线撑压版 ", "飞龙在天4.0": "\t飞龙在天\t"}})
        self.assertEqual([item["call_name"] for item in formulas], ["大牛线撑压版", "飞龙在天"])

    def test_pe_architecture_is_checked_without_loading_dll(self):
        path = Path(self.temp.name) / "client.dll"
        header = bytearray(64)
        header[:2] = b"MZ"
        struct.pack_into("<I", header, 60, 64)
        path.write_bytes(bytes(header) + b"PE\0\0" + struct.pack("<H", 0x8664))
        self.assertEqual(env._pe_machine(path), "x64")

    def test_symbols_are_not_silently_truncated(self):
        self.assertEqual(env.normalize_symbol("920001"), "920001.BJ")
        self.assertEqual(env.normalize_symbol("sh600519"), "600519.SH")
        with self.assertRaises(ValueError):
            env.normalize_symbol("junk600519")


if __name__ == "__main__":
    unittest.main()
