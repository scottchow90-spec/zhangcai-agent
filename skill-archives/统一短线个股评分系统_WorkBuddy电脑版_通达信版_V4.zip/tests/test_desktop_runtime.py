"""Offline wrapper regressions using synthetic input, never live market evidence."""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import importlib.util
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock


sys.dont_write_bytecode = True
PACKAGE = Path(__file__).resolve().parents[1]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


runtime = load(PACKAGE / "scripts/stock_canonical_runtime.py", "desktop_runtime_tests")
fixtures = load(PACKAGE / "vendor/skills/stock-unified/tests/test_unified_stock_scoring.py", "desktop_runtime_fixtures")


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for target in ("socket.create_connection", "urllib.request.urlopen"):
            patcher = mock.patch(target, side_effect=AssertionError("network forbidden"))
            patcher.start()
            self.addCleanup(patcher.stop)

    def synthetic(self):
        observation = copy.deepcopy(fixtures.complete_observation())
        observation["bars_dividend_type"] = 0
        for item in observation["formula_scan"]["items"]:
            item["dividend_type"] = 0
        return observation

    def score(self, observation):
        supplied = self.root / "synthetic-only.json"
        runtime.write_json(supplied, observation)
        args = runtime.parser().parse_args(["run", "--input", str(supplied), "--output", str(self.root / "results")])
        with mock.patch.object(runtime, "environment", side_effect=AssertionError("environment access forbidden")), \
             mock.patch.object(runtime, "native_observation", side_effect=AssertionError("native collection forbidden")):
            result = runtime.run_score(args)
        receipt = Path(result["receipt"])
        return result, receipt, runtime.read_json(receipt.parent / "report.json")

    def doctor(self, ok, probe=False):
        args = runtime.parser().parse_args(["doctor"] + (["--probe-formulas"] if probe else []))
        fake_environment = types.SimpleNamespace(inspect_environment=mock.Mock(return_value={
            "ok": ok, "status": "STATIC_CHECK_PASS" if ok else "BLOCKED",
            "issues": [] if ok else [{"code": "missing_day"}],
        }))
        config = {"tdx_root": str(self.root), "allow_sdk_initialize": False}
        with mock.patch.object(runtime, "ROOT", self.root), \
             mock.patch.object(runtime, "CONFIG", self.root / ".local/config.json"), \
             mock.patch.object(runtime, "verify_package", return_value={"model_sha256": "synthetic"}), \
             mock.patch.object(runtime, "configuration", return_value=config), \
             mock.patch.object(runtime, "entry", return_value=types.SimpleNamespace(normalize_symbol=lambda symbol: symbol)), \
             mock.patch.object(runtime, "environment", return_value=fake_environment), \
             mock.patch.object(runtime, "formula_scan", return_value={"ok": True, "items": []}) as scan:
            result = runtime.dispatch(args)
        return result, scan

    def test_static_doctor_success_matches_first_check_protocol(self):
        result, scan = self.doctor(True)
        self.assertEqual(result["status"], "READY")
        self.assertEqual(result["environment_status"], "STATIC_CHECK_PASS")
        scan.assert_not_called()

    def test_static_doctor_failure_is_setup_required(self):
        result, scan = self.doctor(False)
        self.assertEqual(result["status"], "SETUP_REQUIRED")
        self.assertFalse(result["ok"])
        scan.assert_not_called()

    def test_formula_probe_cannot_hide_static_failure(self):
        result, scan = self.doctor(False, probe=True)
        self.assertEqual(result["status"], "SETUP_REQUIRED")
        scan.assert_not_called()

    def test_complete_synthetic_input_is_authorized_as_non_live(self):
        result, receipt, report = self.score(self.synthetic())
        self.assertEqual(result["status"], "COMPLETE_SCORE")
        self.assertTrue(report["non_live"])
        self.assertFalse(report["realtime_verified"])
        authorized = runtime.authorize(receipt)
        self.assertEqual(authorized["status"], "AUTHORIZED")
        self.assertEqual(authorized["final_score"], report["final_score"])
        self.assertIn("NOT_CURRENT_MARKET_FRESHNESS", authorized["authorization_scope"])

    def test_complete_hard_exclusion_is_not_misreported_as_missing_data(self):
        observation = self.synthetic()
        fixtures.formula(observation, "\u98de\u9f99\u5728\u59294.0")["\u6bb5"][-1] = 90
        result, receipt, report = self.score(observation)
        self.assertEqual(result["status"], "COMPLETE_SCORE")
        self.assertFalse(report["decision_eligible"])
        self.assertEqual(runtime.authorize(receipt)["status"], "AUTHORIZED")

    def test_missing_funds_never_publishes_a_complete_score(self):
        observation = self.synthetic()
        del observation["evidence"]["fund_flow"]
        result, receipt, report = self.score(observation)
        self.assertEqual(result["status"], "BLOCKED_NO_SCORE")
        self.assertEqual(result["score_status"], "DATA_REQUIRED")
        self.assertIsNone(report["final_score"])
        self.assertIsNone(report["unified_score"])
        self.assertFalse(report["decision_eligible"])
        with self.assertRaisesRegex(ValueError, "incomplete_receipt"):
            runtime.authorize(receipt)

    def test_mixed_actual_adjustment_basis_blocks_complete_score(self):
        observation = self.synthetic()
        observation["formula_scan"]["items"][0]["dividend_type"] = 1
        result, _, report = self.score(observation)
        self.assertEqual(result["status"], "BLOCKED_NO_SCORE")
        self.assertIsNone(report["final_score"])

    def test_report_tampering_is_rejected_even_after_hash_update(self):
        _, receipt_path, report = self.score(self.synthetic())
        report_path = receipt_path.parent / "report.json"
        report["final_score"] += 1
        runtime.write_json(report_path, report)
        receipt = runtime.read_json(receipt_path)
        receipt["report"]["sha256"] = runtime.sha(report_path)
        runtime.write_json(receipt_path, receipt)
        with self.assertRaisesRegex(ValueError, "score_recomputation_mismatch"):
            runtime.authorize(receipt_path)

    def test_markdown_tampering_is_rejected_even_after_hash_update(self):
        _, receipt_path, _ = self.score(self.synthetic())
        receipt = runtime.read_json(receipt_path)
        markdown = receipt_path.parent / receipt["markdown"]["path"]
        markdown.write_text(markdown.read_text(encoding="utf-8") + "tampered\n", encoding="utf-8")
        receipt["markdown"]["sha256"] = runtime.sha(markdown)
        runtime.write_json(receipt_path, receipt)
        with self.assertRaisesRegex(ValueError, "markdown_recomputation_mismatch"):
            runtime.authorize(receipt_path)

    def test_receipt_cannot_reference_artifacts_outside_its_directory(self):
        _, receipt_path, _ = self.score(self.synthetic())
        receipt = runtime.read_json(receipt_path)
        external = receipt_path.parent.parent / "outside-observation.json"
        external.write_bytes((receipt_path.parent / "observation.json").read_bytes())
        receipt["observation"] = {"path": "../outside-observation.json", "sha256": runtime.sha(external)}
        runtime.write_json(receipt_path, receipt)
        with self.assertRaisesRegex(ValueError, "path_outside_root"):
            runtime.authorize(receipt_path)

    def test_sdk_permission_requires_a_boolean(self):
        path = self.root / "config.json"
        runtime.write_json(path, {"schema": "WORKBUDDY_DESKTOP_CONFIG_V1", "tdx_root": str(self.root),
                                  "allow_sdk_initialize": "false"})
        args = runtime.parser().parse_args(["configure", "--config", str(path)])
        with self.assertRaisesRegex(ValueError, "allow_sdk_initialize_must_be_boolean"):
            runtime.configuration(args)

    def test_duplicate_and_nonfinite_json_are_rejected(self):
        path = self.root / "invalid.json"
        for text in ('{"symbol": 1, "symbol": 2}', '{"value": NaN}', '{"value": 1e999}'):
            with self.subTest(text=text):
                path.write_text(text, encoding="utf-8")
                with self.assertRaises(ValueError):
                    runtime.read_json(path)

    def check_native_fund_completion_clock(self, explicit_clock):
        observation = self.synthetic()
        fund_flow = observation["evidence"].pop("fund_flow")
        original_clock = copy.deepcopy(observation["evidence"]["evaluation_clock"])
        supplement_evidence = {"announcements": observation["evidence"]["announcements"]}
        if explicit_clock:
            supplement_evidence["evaluation_clock"] = copy.deepcopy(original_clock)
        supplement = self.root / "synthetic-supplement.json"
        runtime.write_json(supplement, {"stocks": {observation["symbol"]: {"evidence": supplement_evidence}}})
        args = runtime.parser().parse_args(["run"] + (["--evidence", str(supplement)] if explicit_clock else []))
        config = {"tdx_root": str(self.root / "synthetic-tdx"), "allow_sdk_initialize": False}
        if not explicit_clock:
            config["evidence_file"] = str(supplement)
        native = types.SimpleNamespace(
            load_native_observation=mock.Mock(return_value=(observation, {}, [])),
            fetch_fund_flow=mock.Mock(),
        )
        now = datetime(2026, 9, 7, 10, 30, tzinfo=timezone.utc)
        with mock.patch.dict(runtime.os.environ), \
             mock.patch.object(runtime, "entry", return_value=native), \
             mock.patch.object(runtime, "formula_scan", side_effect=AssertionError("SDK forbidden")), \
             mock.patch.object(runtime, "datetime") as clock:
            clock.now.return_value = now

            def fetch(symbol, trade_date):
                self.assertEqual(observation["evidence"]["evaluation_clock"], original_clock)
                clock.now.assert_not_called()
                return fund_flow

            native.fetch_fund_flow.side_effect = fetch
            actual, _, errors = runtime.native_observation(observation["symbol"], config, args, self.root / "output")
            if explicit_clock:
                clock.now.assert_not_called()
            else:
                clock.now.assert_called_once_with(timezone.utc)
        native.load_native_observation.assert_called_once_with(observation["symbol"])
        native.fetch_fund_flow.assert_called_once_with(observation["symbol"], observation["trade_date"])
        self.assertEqual(actual["evidence"]["fund_flow"], fund_flow)
        self.assertEqual(errors, [])
        expected_clock = copy.deepcopy(original_clock)
        if not explicit_clock:
            expected_clock["as_of"] = now.isoformat()
        self.assertEqual(actual["evidence"]["evaluation_clock"], expected_clock)

    def test_native_fund_completion_refreshes_only_automatic_clock_after_fetch(self):
        self.check_native_fund_completion_clock(explicit_clock=False)

    def test_native_fund_completion_preserves_explicit_historical_clock(self):
        self.check_native_fund_completion_clock(explicit_clock=True)


if __name__ == "__main__":
    unittest.main()
