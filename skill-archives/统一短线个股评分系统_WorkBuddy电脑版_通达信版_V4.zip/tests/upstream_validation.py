"""Offline upstream regressions and complete-result equivalence verification."""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import io
import json
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
PACKAGE = Path(__file__).resolve().parents[1]
ENGINE_RELATIVE = Path("stock-unified/scripts/unified_stock_scoring.py")
FIXTURE_RELATIVE = Path("stock-unified/tests/test_unified_stock_scoring.py")


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(value) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def synthetic_cases(fixtures):
    """Original fixture and explicit counterexamples; never market evidence."""
    baseline = fixtures.complete_observation()
    yield "complete_original_fixture", copy.deepcopy(baseline)
    for key in ("fund_flow", "announcements", "lhb", "price_basis", "evaluation_clock"):
        item = copy.deepcopy(baseline)
        item["evidence"].pop(key)
        yield "missing_" + key, item
    item = copy.deepcopy(baseline)
    item["evidence"]["hard_checks"].pop("H02")
    yield "missing_investigation_check", item
    item = copy.deepcopy(baseline)
    item.pop("mainline_context")
    yield "missing_mainline", item
    item = copy.deepcopy(baseline)
    item["formula_scan"]["items"].pop()
    yield "missing_technical_formula", item
    item = copy.deepcopy(baseline)
    fixtures.formula(item, "飞龙在天4.0")["段"][-1] = 90
    yield "hard_excluded_high_segment", item
    item = copy.deepcopy(baseline)
    item["name"] = "ST测试"
    yield "hard_excluded_risk_warning", item
    item = copy.deepcopy(baseline)
    item["evidence"]["fund_flow"] = fixtures.fund_flow_record(item, nets=[-100000000] * 5, latest_pct=-10)
    yield "negative_fund_flow", item
    item = copy.deepcopy(baseline)
    item["bars_dividend_type"] = 0
    for formula in item["formula_scan"]["items"]:
        formula["dividend_type"] = 1
    yield "conflicting_price_basis", item
    yield "empty_observation", {}


def validate(source_skills: Path | None = None, observation_paths=()) -> dict:
    manifest = json.loads((PACKAGE / "vendor-source-manifest.json").read_text(encoding="utf-8"))
    errors, source_files_checked = [], 0
    for row in manifest["files"]:
        path = (PACKAGE / row["path"]).resolve()
        if PACKAGE.resolve() not in path.parents:
            raise ValueError("vendor_manifest_path_escaped_package")
        raw = path.read_bytes()
        if len(raw) != row["bytes"] or hashlib.sha256(raw).hexdigest() != row["sha256"]:
            errors.append("vendor_hash_mismatch:" + row["path"])
        if source_skills is not None:
            source = (source_skills / row["source_relative"]).resolve()
            if source_skills.resolve() not in source.parents:
                raise ValueError("source_relative_escaped_supplied_root")
            if source.read_bytes() != raw:
                errors.append("upstream_bytes_differ:" + row["path"])
            source_files_checked += 1
    vendor_skills = PACKAGE / "vendor/skills"
    engine = load(vendor_skills / ENGINE_RELATIVE, "desktop_export_v4_validation")
    fixtures = load(vendor_skills / FIXTURE_RELATIVE, "desktop_export_v4_fixtures")
    original = load(source_skills / ENGINE_RELATIVE, "desktop_original_v4_comparison") if source_skills else None
    expected = json.loads((PACKAGE / "tests/upstream_expected.json").read_text(encoding="utf-8"))
    if engine.MODEL_SHA256 != expected["model_sha256"] or engine.MODEL_SHA256 != manifest["model_sha256"]:
        errors.append("model_fingerprint_mismatch")
    expected_cases = {row["case"]: row for row in expected["cases"]}
    comparisons = []
    for name, observation in synthetic_cases(fixtures):
        actual = engine.score_stock(copy.deepcopy(observation))
        baseline = expected_cases[name]
        matches = (digest(observation) == baseline["input_sha256"]
                   and digest(actual) == baseline["complete_result_sha256"])
        direct_match = actual == original.score_stock(copy.deepcopy(observation)) if original else None
        if not matches or direct_match is False:
            errors.append("result_mismatch:" + name)
        comparisons.append({"case": name, "evidence_kind": "SYNTHETIC_TEST_ONLY", "matches_all_fields": matches,
                            "direct_original_match": direct_match, "result_sha256": digest(actual)})
    replays = []
    for supplied_path in observation_paths:
        raw = supplied_path.read_bytes()
        payload = json.loads(raw.decode("utf-8-sig"))
        observation = payload.get("observation", payload)
        actual = engine.score_stock(copy.deepcopy(observation))
        direct_match = actual == original.score_stock(copy.deepcopy(observation)) if original else None
        if direct_match is False:
            errors.append("recorded_result_mismatch:" + supplied_path.name)
        replays.append({"source_name": supplied_path.name, "source_sha256": hashlib.sha256(raw).hexdigest(),
                       "evidence_kind": "SUPPLIED_RECORDED_OBSERVATION_REPLAY", "live_run": False,
                       "source_authenticity_independently_verified": False, "direct_original_match": direct_match,
                       "result_sha256": digest(actual), "symbol": actual["symbol"], "trade_date": actual["trade_date"],
                       "final_score": actual["final_score"], "evidence_complete": actual["evidence_complete"],
                       "decision_eligible": actual["decision_eligible"], "missing_evidence": actual["missing_evidence"]})
    suite = unittest.defaultTestLoader.discover(str(vendor_skills / "stock-unified/tests"), pattern="test_*.py")
    stream = io.StringIO()
    test_result = unittest.TextTestRunner(stream=stream, verbosity=1).run(suite)
    if not test_result.wasSuccessful():
        errors.append("upstream_unittest_failed")
    return {"schema": "WORKBUDDY_DESKTOP_UPSTREAM_VALIDATION_V1", "status": "PASS" if not errors else "FAILED",
            "model_version": engine.MODEL_VERSION, "model_sha256": engine.MODEL_SHA256,
            "vendor_file_count": len(manifest["files"]), "source_files_compared": source_files_checked,
            "scoring_core_files": manifest["scoring_core_count"], "comparison_scope": "all_result_fields_without_exclusions",
            "synthetic_comparisons": comparisons, "recorded_replays": replays,
            "upstream_unittest": {"tests_run": test_result.testsRun, "failures": len(test_result.failures),
                                  "errors": len(test_result.errors), "skipped": len(test_result.skipped),
                                  "output": stream.getvalue()},
            "other_pc_live_verified": False, "errors": errors}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-skills", type=Path)
    parser.add_argument("--observation", type=Path, action="append", default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = validate(args.source_skills, args.observation)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "vendor_file_count": result["vendor_file_count"],
                      "synthetic_cases": len(result["synthetic_comparisons"]),
                      "recorded_replays": len(result["recorded_replays"]),
                      "upstream_unittest": {key: value for key, value in result["upstream_unittest"].items() if key != "output"},
                      "errors": result["errors"]}, ensure_ascii=False))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
