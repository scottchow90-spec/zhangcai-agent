"""Portable, read-only Tongdaxin discovery and explicit formula collection."""

from __future__ import annotations

import contextlib
import datetime as dt
import hashlib
import importlib.util
import io
import math
import os
from pathlib import Path
import re
import struct
import sys
import threading
import uuid


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DAY_RECORD = struct.Struct("<IIIIIfII")
FORMULAS = (
    {"formula": "大牛线4.0", "call_name": "大牛线撑压版", "count": 20, "dividend_type": 0},
    {"formula": "飞龙在天4.0", "call_name": "飞龙在天", "count": 0, "dividend_type": 0},
)
BIG_LINE_NUMERIC_FIELDS = ("主趋势线", "EMA9", "EMA10", "EMA11", "庄出", "STJ83")
BIG_LINE_REQUIRED_FIELDS = BIG_LINE_NUMERIC_FIELDS[:4]
_FORMULA_LOCK = threading.Lock()


def normalize_symbol(symbol: str) -> str:
    value = str(symbol).strip().upper()
    suffix = re.fullmatch(r"(\d{6})[.]?(SH|SZ|BJ)", value)
    prefix = re.fullmatch(r"(SH|SZ|BJ)[.]?(\d{6})", value)
    if suffix:
        code, market = suffix.groups()
    elif prefix:
        market, code = prefix.groups()
    elif re.fullmatch(r"\d{6}", value):
        code = value
        market = "BJ" if code.startswith(("4", "8", "92")) else "SH" if code.startswith(("5", "6", "9")) else "SZ"
    else:
        raise ValueError("invalid_stock_symbol")
    return code + "." + market


def _root_candidate(value) -> Path | None:
    if not value:
        return None
    try:
        path = Path(os.path.expandvars(str(value).strip().strip('"'))).expanduser()
        if path.suffix.lower() == ".exe":
            path = path.parent
        if path.name.lower() == "vipdoc":
            path = path.parent
        return path.resolve()
    except (OSError, ValueError):
        return None


def _is_tdx_root(path: Path) -> bool:
    return path.is_dir() and (path / "vipdoc").is_dir() and (
        (path / "TdxW.exe").is_file() or (path / "T0002").is_dir()
    )


def _registry_candidates() -> list[Path]:
    if os.name != "nt":
        return []
    import winreg

    result = []
    key_name = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
            try:
                with winreg.OpenKey(hive, key_name, 0, winreg.KEY_READ | view) as base:
                    for index in range(min(winreg.QueryInfoKey(base)[0], 4096)):
                        try:
                            with winreg.OpenKey(base, winreg.EnumKey(base, index)) as key:
                                name = str(winreg.QueryValueEx(key, "DisplayName")[0])
                                if not re.search(r"通达信|tongdaxin|\btdx\b", name, re.I):
                                    continue
                                for field in ("InstallLocation", "DisplayIcon"):
                                    try:
                                        raw = str(winreg.QueryValueEx(key, field)[0])
                                        if field == "DisplayIcon":
                                            raw = re.sub(r",\s*-?\d+$", "", raw).strip('"')
                                        candidate = _root_candidate(raw)
                                        if candidate:
                                            result.append(candidate)
                                    except OSError:
                                        pass
                        except OSError:
                            continue
            except OSError:
                continue
    return result


def _shortcut_target(path: Path) -> Path | None:
    """Read only the local LinkInfo target of a bounded Windows .lnk file."""
    try:
        if path.stat().st_size > 1024 * 1024:
            return None
        data = path.read_bytes()
        if len(data) < 80 or struct.unpack_from("<I", data)[0] != 76:
            return None
        flags = struct.unpack_from("<I", data, 20)[0]
        offset = 76
        if flags & 1:
            offset += 2 + struct.unpack_from("<H", data, offset)[0]
        if not flags & 2 or offset + 28 > len(data):
            return None
        size, header = struct.unpack_from("<II", data, offset)
        if size < header or header < 28 or offset + size > len(data):
            return None
        local = struct.unpack_from("<I", data, offset + 16)[0]
        unicode_local = struct.unpack_from("<I", data, offset + 28)[0] if header >= 36 else 0
        relative = unicode_local or local
        if not relative or relative < header or relative >= size:
            return None
        raw = data[offset + relative:offset + size]
        if unicode_local:
            end = next((i for i in range(0, len(raw) - 1, 2) if raw[i:i + 2] == b"\0\0"), len(raw))
            target = raw[:end].decode("utf-16-le")
        else:
            target = raw.split(b"\0", 1)[0].decode("mbcs" if os.name == "nt" else "utf-8")
        return _root_candidate(target)
    except (OSError, ValueError, struct.error, UnicodeError):
        return None


def _shortcut_candidates() -> list[Path]:
    result = []
    bases = []
    if os.environ.get("PUBLIC"):
        bases.append(Path(os.environ["PUBLIC"]) / "Desktop")
    if os.environ.get("PROGRAMDATA"):
        bases.append(Path(os.environ["PROGRAMDATA"]) / "Microsoft" / "Windows" / "Start Menu" / "Programs")
    for base in bases:
        if not base.is_dir():
            continue
        count = 0
        for pattern in ("*.lnk", "*/*.lnk", "*/*/*.lnk"):
            for path in base.glob(pattern):
                count += 1
                if count > 1500:
                    break
                candidate = _shortcut_target(path)
                if candidate:
                    result.append(candidate)
            if count > 1500:
                break
    return result


def _common_candidates() -> list[Path]:
    candidates = []
    names = ("TDX", "tdx", "new_tdx", "通达信", "通达信金融终端")
    if os.name == "nt":
        for drive in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            base = Path(drive + ":/")
            if base.exists():
                candidates.extend(base / name for name in names)
    for key in ("ProgramFiles", "ProgramFiles(x86)"):
        if os.environ.get(key):
            base = Path(os.environ[key])
            candidates.extend(base / name for name in names)
    return candidates


def discover_tdx_roots(explicit=None) -> list[Path]:
    """Return all valid candidates; callers must resolve multiple installations."""
    if explicit:
        candidate = _root_candidate(explicit)
        return [candidate] if candidate and _is_tdx_root(candidate) else []
    candidates = [_root_candidate(os.environ.get("TDX_ROOT"))]
    candidates += _registry_candidates() + _shortcut_candidates() + _common_candidates()
    unique = {}
    for path in candidates:
        if path is not None and _is_tdx_root(path):
            unique.setdefault(os.path.normcase(str(path)), path)
    return list(unique.values())


def _day_path(root: Path, symbol: str) -> Path:
    code, market = normalize_symbol(symbol).lower().split(".")
    filename = market + code + ".day"
    return root / "vipdoc" / market / "lday" / filename


def _day_summary(path: Path) -> dict:
    result = {"path": str(path), "exists": path.is_file(), "ok": False}
    if not path.is_file():
        result["error"] = "day_file_missing"
        return result
    try:
        size = path.stat().st_size
        result.update(size=size, record_count=size // DAY_RECORD.size)
        if size == 0 or size % DAY_RECORD.size:
            raise ValueError("day_file_invalid_length")
        count = min(300, size // DAY_RECORD.size)
        with path.open("rb") as handle:
            handle.seek(size - count * DAY_RECORD.size)
            raw = handle.read(count * DAY_RECORD.size)
        if len(raw) != count * DAY_RECORD.size:
            raise ValueError("day_file_changed_during_read")
        dates = []
        for row in DAY_RECORD.iter_unpack(raw):
            date_i, open_i, high_i, low_i, close_i, amount, volume, unused = row
            dates.append(dt.datetime.strptime(str(date_i), "%Y%m%d").date().isoformat())
            if min(open_i, high_i, low_i, close_i) <= 0 or high_i < max(open_i, close_i, low_i) or low_i > min(open_i, close_i, high_i):
                raise ValueError("day_file_invalid_price")
            if not math.isfinite(amount) or amount < 0 or volume < 0:
                raise ValueError("day_file_invalid_amount_volume")
        if any(left >= right for left, right in zip(dates, dates[1:])):
            raise ValueError("day_dates_not_increasing")
        result.update(ok=True, first_inspected_date=dates[0], last_date=dates[-1], inspected_count=count,
                      inspected_tail_sha256=hashlib.sha256(raw).hexdigest())
    except (OSError, ValueError, struct.error) as exc:
        result["error"] = str(exc)
    return result


def _pe_machine(path: Path) -> str | None:
    try:
        with path.open("rb") as handle:
            header = handle.read(64)
            if len(header) < 64 or header[:2] != b"MZ":
                return None
            offset = struct.unpack_from("<I", header, 60)[0]
            if offset > 1024 * 1024:
                return None
            handle.seek(offset)
            signature = handle.read(6)
        if len(signature) != 6 or signature[:4] != b"PE\0\0":
            return None
        return {0x014C: "x86", 0x8664: "x64", 0xAA64: "arm64"}.get(struct.unpack_from("<H", signature, 4)[0])
    except (OSError, struct.error):
        return None


def inspect_environment(tdx_root, symbol: str = "600519.SH") -> dict:
    """Static checks only: do not import TQ, connect DLLs, or write TDX files."""
    root = _root_candidate(tdx_root)
    issues = []
    checks = {}
    result = {"ok": False, "status": "BLOCKED", "tdx_root": str(root) if root else None,
              "symbol": normalize_symbol(symbol), "checks": checks, "issues": issues,
              "inspection_mode": "STATIC_READ_ONLY", "formula_execution_verified": False}
    if root is None or not _is_tdx_root(root):
        issues.append({"code": "tdx_root_invalid", "message": "指定目录不是有效的通达信安装目录。"})
        return result
    checks["daily_layout"] = {"required": "vipdoc/{market}/lday/{market}{code}.day",
                              "alternate_layouts_accepted": False}
    for key, target in (("stock_day", symbol), ("benchmark_day", "000001.SH")):
        checks[key] = _day_summary(_day_path(root, target))
        if not checks[key]["ok"]:
            error = checks[key].get("error", "invalid")
            message = ("标准本地日线尚未下载到正式评分目录：" + checks[key]["path"]
                       if error == "day_file_missing" else error)
            issues.append({"code": key + "_invalid", "message": message})
    if checks["stock_day"].get("ok") and checks["benchmark_day"].get("ok"):
        if checks["stock_day"]["last_date"] != checks["benchmark_day"]["last_date"]:
            issues.append({"code": "stock_benchmark_date_mismatch", "message": "个股与上证指数日线日期不一致。"})
        if checks["stock_day"]["record_count"] < 240:
            issues.append({"code": "insufficient_native_history", "message": "个股原生日线不足240条，无法满足长周期公式历史要求。"})
    market = result["symbol"].split(".")[1].lower()
    components = {
        "stock_names": root / "T0002" / "hq_cache" / (market + "s.tnf"),
        "tq_sdk": root / "PYPlugins" / "user" / "tqcenter.py",
        "tq_client_dll": root / "PYPlugins" / "TPythClient.dll",
        "tq_rpc_dll": root / "PYPlugins" / "tdxrpcx64.dll",
    }
    for name, path in components.items():
        exists = path.is_file() and path.stat().st_size > 0
        checks[name] = {"path": str(path), "exists": exists}
        if not exists:
            issues.append({"code": name + "_missing", "message": "必要组件不存在或为空：" + name})
    if checks["tq_client_dll"]["exists"]:
        machine = _pe_machine(components["tq_client_dll"])
        runtime = "x64" if struct.calcsize("P") == 8 else "x86"
        checks["tq_client_dll"].update(machine=machine, python_machine=runtime)
        if machine != runtime:
            issues.append({"code": "tq_python_architecture_mismatch", "message": "Python与通达信数据接口的位数不匹配或无法识别。"})
    for name in ("numpy", "pandas"):
        exists = importlib.util.find_spec(name) is not None
        checks[name] = {"available": exists}
        if not exists:
            issues.append({"code": name + "_missing", "message": "Python缺少必要数据组件：" + name})
    checks["formula_contracts"] = [{**item, "return_count": 300, "return_date": True, "installation_verified": False} for item in FORMULAS]
    result.update(ok=not issues, status="STATIC_CHECK_PASS" if not issues else "BLOCKED")
    return result


def _load_normalizer(config: dict):
    path = PACKAGE_ROOT / "vendor" / "skills" / "tdx-local-hub" / "scripts" / "tdx_hub.py"
    if not path.is_file():
        raise FileNotFoundError("packaged_original_tdx_hub_missing")
    spec = importlib.util.spec_from_file_location("_workbuddy_original_tdx_hub", path)
    if spec is None or spec.loader is None:
        raise ImportError("packaged_original_tdx_hub_unloadable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.normalize_dated_formula_result


def _existing_handle(root: Path):
    expected = (root / "PYPlugins" / "user" / "tqcenter.py").resolve()
    for module in tuple(sys.modules.values()):
        module_file = getattr(module, "__file__", None)
        if not module_file:
            continue
        try:
            if Path(module_file).resolve() != expected:
                continue
        except (OSError, ValueError):
            continue
        handle = getattr(module, "tq", None)
        if handle is not None and getattr(handle, "_initialized", False) and not getattr(handle, "_reInitialized", False):
            return handle
    return None


def _initialize_explicit_sdk(root: Path, state_dir: Path):
    state = state_dir.resolve()
    if state == root or state.is_relative_to(root):
        raise ValueError("sdk_state_must_be_outside_tdx_installation")
    sdk_path = root / "PYPlugins" / "user" / "tqcenter.py"
    if not sdk_path.is_file():
        raise FileNotFoundError("target_machine_tq_sdk_missing")
    state.mkdir(parents=True, exist_ok=True)
    init_path = state / ("workbuddy_tq_init_" + uuid.uuid4().hex + ".py")
    init_path.write_text("# Credential-free connection identity for the read-only formula worker.\n", encoding="utf-8")
    name = "_workbuddy_target_tqcenter_" + uuid.uuid4().hex
    spec = importlib.util.spec_from_file_location(name, sdk_path)
    if spec is None or spec.loader is None:
        raise ImportError("target_machine_tq_sdk_unloadable")
    module = importlib.util.module_from_spec(spec)
    previous_cwd = Path.cwd()
    previous_path = sys.path[:]
    previous_argv = sys.argv[:]
    previous_bytecode = sys.dont_write_bytecode
    handle = None
    try:
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(sdk_path.parent))
        sys.argv = [str(init_path)]
        os.chdir(root)
        sys.modules[name] = module
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            spec.loader.exec_module(module)
            handle = module.tq
            handle.initialize(str(init_path))
        if not getattr(handle, "_initialized", False) or getattr(handle, "run_id", -1) < 0:
            raise RuntimeError("target_machine_tq_initialization_failed")
        return handle
    except Exception:
        if handle is not None and getattr(handle, "_initialized", False):
            with contextlib.suppress(Exception), contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                handle._release() if hasattr(handle, "_release") else handle.close()
        raise
    finally:
        os.chdir(previous_cwd)
        sys.path[:] = previous_path
        sys.argv[:] = previous_argv
        sys.dont_write_bytecode = previous_bytecode


def _configured_formulas(config: dict) -> list[dict]:
    names = config.get("formula_names", {})
    if not isinstance(names, dict):
        raise ValueError("formula_names_must_be_an_object")
    formulas = []
    for item in FORMULAS:
        name = names.get(item["formula"], item["call_name"])
        if not isinstance(name, str) or not name.strip() or len(name) > 80 or any(char in name for char in "\r\n\0"):
            raise ValueError("invalid_formula_call_name")
        name = name.strip()
        if name in ("游资资金监控", "庄家资金监控", "机构资金监控"):
            raise ValueError("excluded_capital_formula")
        formulas.append({**item, "call_name": name})
    return formulas


def _project_big_line_fields(raw: dict, symbol: str) -> tuple[dict, dict, list[str]]:
    fields = raw.get(symbol)
    if not isinstance(fields, dict) or not fields:
        raise ValueError("native_formula_fields_missing")
    selected = {name: fields[name] for name in BIG_LINE_NUMERIC_FIELDS if name in fields}
    projection = {"mode": "V4_NAMED_NUMERIC_FIELDS_ONLY", "fields": list(selected),
                  "required_fields": list(BIG_LINE_REQUIRED_FIELDS),
                  "missing_required_fields": [name for name in BIG_LINE_REQUIRED_FIELDS if name not in fields],
                  "anonymous_output_mapping": False}
    return {**raw, symbol: selected}, projection, [name for name in fields if name not in selected]


def _validate_numeric_series(result: dict, symbol: str, names: list[str]) -> None:
    fields = result.get(symbol)
    if not isinstance(fields, dict):
        raise ValueError("native_formula_fields_missing")
    dates = fields.get("date")
    if not isinstance(dates, list) or not dates:
        raise ValueError("native_formula_dates_missing")
    for name in names:
        values = fields.get(name)
        if not isinstance(values, list) or not values:
            raise ValueError("native_formula_output_not_series:" + name)
        if len(values) != len(dates):
            raise ValueError("native_formula_output_dates_mismatch:" + name)
        for value in values:
            try:
                valid = not isinstance(value, bool) and isinstance(value, (str, int, float)) and math.isfinite(float(value))
            except (TypeError, ValueError, OverflowError):
                valid = False
            if not valid:
                raise ValueError("native_formula_numeric_value_invalid:" + name)


def collect_formula_scan(tdx_root, symbol, config, state_dir) -> dict:
    """Query only the two original formulas; never initialize a desktop service implicitly."""
    root = _root_candidate(tdx_root)
    normalized = normalize_symbol(symbol)
    config = config or {}
    payload = {"ok": False, "status": "BLOCKED", "symbol": normalized, "items": [], "errors": [],
               "formula_count": 2, "with_dates": True, "connection_mode": "existing_initialized",
               "required_formulas": [item["formula"] for item in FORMULAS],
               "failed_formulas": [item["formula"] for item in FORMULAS],
               "desktop_process_launch_requested": False, "tdx_configuration_write_requested": False}
    if root is None or not _is_tdx_root(root):
        payload["errors"].append("tdx_root_invalid")
        return payload
    with _FORMULA_LOCK:
        owned_connection = False
        tq = None
        try:
            formulas = _configured_formulas(config)
            normalize = _load_normalizer(config)
            tq = _existing_handle(root)
            if tq is None:
                if config.get("allow_sdk_initialize") is not True:
                    raise RuntimeError("sdk_initialize_not_authorized: existing_initialized_TQ_session_required")
                tq = _initialize_explicit_sdk(root, Path(state_dir))
                owned_connection = True
                payload["connection_mode"] = "explicit_sdk_initialize"
                payload["sdk_native_connection_side_effects"] = "vendor_DLL_behavior_not_guaranteed_attach_only"
            for formula in formulas:
                item = {"ok": False, "formula": formula["formula"], "tq_formula": formula["call_name"],
                        "kind": "zb", "symbol": normalized, "count": formula["count"],
                        "required": True, "reserved": False,
                        "dividend_type": formula["dividend_type"], "with_dates": True,
                        "date_source": "TQ.formula_process_mul.return_date"}
                try:
                    if not getattr(tq, "_initialized", False) or getattr(tq, "_reInitialized", False):
                        raise RuntimeError("existing_tq_connection_no_longer_initialized")
                    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                        raw = tq.formula_process_mul_zb(formula["call_name"], stock_list=[normalized],
                            count=formula["count"], return_date=True, return_count=300,
                            dividend_type=formula["dividend_type"])
                    if not isinstance(raw, dict) or str(raw.get("ErrorId", "0")) != "0":
                        raise RuntimeError("native_formula_query_failed:" + str(raw.get("ErrorId") if isinstance(raw, dict) else "invalid_response"))
                    item["raw_result"] = raw
                    if config.get("read_formula_info") is True:
                        try:
                            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                                item["native_formula_info"] = tq.formula_get_info(
                                    formula_type=0, formula_code=formula["call_name"])
                        except Exception as exc:
                            item["identity_error"] = str(exc)
                    projected = raw
                    if formula["formula"] == "大牛线4.0":
                        # Chart text and anonymous outputs have no V4 numeric-field identity.
                        projected, item["projection"], item["omitted_fields"] = _project_big_line_fields(raw, normalized)
                        if item["projection"]["missing_required_fields"]:
                            raise ValueError("native_formula_required_fields_missing:" + ",".join(item["projection"]["missing_required_fields"]))
                    result = normalize(projected, normalized)
                    if formula["formula"] == "大牛线4.0":
                        _validate_numeric_series(result, normalized, item["projection"]["fields"])
                    item.update(result=result, ok=True, installation_verified=True)
                except Exception as exc:
                    item["error"] = str(exc)
                    payload["errors"].append(formula["formula"] + ":" + str(exc))
                payload["items"].append(item)
        except Exception as exc:
            payload["errors"].append(str(exc))
        finally:
            if owned_connection and tq is not None:
                try:
                    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                        tq._release() if hasattr(tq, "_release") else tq.close()
                except Exception as exc:
                    payload["errors"].append("own_tq_connection_release_failed:" + str(exc))
    payload["ok"] = len(payload["items"]) == 2 and all(item["ok"] for item in payload["items"]) and not payload["errors"]
    passed = {item["formula"] for item in payload["items"] if item["ok"]}
    payload["failed_formulas"] = [item["formula"] for item in FORMULAS if item["formula"] not in passed]
    payload["status"] = "FORMULA_QUERY_PASS" if payload["ok"] else "BLOCKED"
    return payload
