"""Portable WorkBuddy dispatcher; the vendored V4 calculation stays unchanged."""
from __future__ import annotations

import argparse
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import date, datetime, timedelta, timezone
import uuid

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / "vendor/skills"
CONFIG = ROOT / ".local/config.json"
BEIJING = timezone(timedelta(hours=8))
OWNER = "stock-analysis"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def reject_constant(value):
    raise ValueError("nonfinite_json_number:" + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate_json_key:" + key)
        result[key] = value
    return result


def read_json(path):
    def number(value):
        result = float(value)
        if not math.isfinite(result):
            reject_constant(value)
        return result
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), parse_constant=reject_constant,
                      parse_float=number, object_pairs_hook=unique_object)


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def within(root, value):
    path = (root / value).resolve()
    if root.resolve() not in path.parents:
        raise ValueError("path_outside_root:" + str(value))
    return path


def verify_package():
    manifest = read_json(ROOT / "vendor-source-manifest.json")
    for row in manifest["files"]:
        path = within(ROOT, row["path"])
        if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("original_model_file_changed:" + row["path"])
    package_manifest = ROOT / "package-manifest.json"
    if package_manifest.is_file():
        for row in read_json(package_manifest)["files"]:
            path = within(ROOT, row["path"])
            if path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
                raise ValueError("package_file_changed:" + row["path"])
    catalog = read_json(ROOT / "references/stock_skill_ids.json")
    contract = read_json(ROOT / "references/stock_execution_contracts.json")
    if catalog["skills"][0]["id"] != OWNER or len(catalog["skills"]) != 1:
        raise ValueError("export_catalog_invalid")
    if contract["contracts"][OWNER]["model_sha256"] != manifest["model_sha256"]:
        raise ValueError("export_contract_model_mismatch")
    return manifest


def engine():
    return load(VENDOR / "stock-unified/scripts/unified_stock_scoring.py", "desktop_v4_engine")


def entry():
    return load(VENDOR / "stock-analysis/scripts/entry_stock_analysis.py", "desktop_v4_native_entry")


def environment():
    return load(ROOT / "scripts/desktop_environment.py", "desktop_tdx_environment")


def config_path(args):
    return Path(args.config).expanduser().resolve() if args.config else CONFIG


def configuration(args):
    path = config_path(args)
    result = read_json(path) if path.is_file() else {"schema": "WORKBUDDY_DESKTOP_CONFIG_V1"}
    if result.get("schema") != "WORKBUDDY_DESKTOP_CONFIG_V1":
        raise ValueError("config_schema_invalid")
    if getattr(args, "tdx_root", None):
        result["tdx_root"] = str(Path(args.tdx_root).expanduser().resolve())
    result.setdefault("allow_sdk_initialize", False)
    result.setdefault("formula_names", {"大牛线4.0": "大牛线撑压版", "飞龙在天4.0": "飞龙在天"})
    if type(result["allow_sdk_initialize"]) is not bool:
        raise ValueError("allow_sdk_initialize_must_be_boolean")
    if not result.get("tdx_root"):
        roots = environment().discover_tdx_roots()
        if len(roots) != 1:
            raise ValueError("tdx_root_requires_explicit_selection:" + json.dumps([str(p) for p in roots], ensure_ascii=False))
        result["tdx_root"] = str(roots[0].resolve())
    root = Path(result["tdx_root"]).expanduser()
    if not root.is_absolute() or not root.is_dir():
        raise ValueError("tdx_root_must_be_existing_absolute_directory")
    result["tdx_root"] = str(root.resolve())
    for key in ("evidence_file", "mainline_file", "duanxianxia_file", "lianban_file", "lianban_history_file"):
        if result.get(key):
            p = Path(result[key]).expanduser()
            result[key] = str((p if p.is_absolute() else path.parent / p).resolve())
    return result


def completed_date(moment):
    current = moment.astimezone(BEIJING)
    calendar = read_json(VENDOR / "core-mainline-scoring-system/references/exchange-calendar-2026.json")
    if current.year != calendar["year"]:
        raise ValueError("exchange_calendar_year_not_covered")
    day = current.date() - timedelta(days=current.hour < 17)
    closures = [(date.fromisoformat(a), date.fromisoformat(b)) for a, b in calendar["closed_ranges"]]
    while day.weekday() >= 5 or any(a <= day <= b for a, b in closures):
        day -= timedelta(days=1)
    return day.isoformat()


def file_binding(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}


def formula_scan(root, symbol, config, output):
    request = output / "formula-request.json"
    response = output / "formula-response.json"
    write_json(request, {"tdx_root": str(root), "symbol": symbol, "config": config})
    try:
        child = subprocess.run([sys.executable, "-B", str(Path(__file__).resolve()), "_formula-worker",
                                "--request", str(request), "--response", str(response)],
                               cwd=str(ROOT), capture_output=True, timeout=100,
                               env={**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"})
        if child.returncode or not response.is_file():
            raise RuntimeError("formula_worker_failed:" + str(child.returncode))
        return read_json(response)
    except subprocess.TimeoutExpired:
        return {"ok": False, "symbol": symbol, "items": [], "error": "formula_query_timeout_100s"}


def align_formula_scan_to_trade_date(scan, symbol, trade_date):
    if not isinstance(trade_date, str) or date.fromisoformat(trade_date).isoformat() != trade_date:
        raise ValueError("formula_alignment_trade_date_invalid")
    if not isinstance(scan, dict) or not isinstance(scan.get("items"), list):
        raise ValueError("formula_alignment_scan_invalid")
    aligned = copy.deepcopy(scan)
    required = ("大牛线4.0", "飞龙在天4.0")
    errors = list(aligned.get("errors", []))
    if aligned.get("error"):
        errors.append(str(aligned["error"]))
    if scan.get("ok") is not True and not errors:
        errors.append("formula_alignment_original_scan_failed")
    passed = set()
    for name in required:
        items = [item for item in aligned["items"] if isinstance(item, dict) and item.get("formula") == name]
        if len(items) != 1:
            errors.append(name + ":formula_alignment_required_item_count_invalid")
            continue
        item = items[0]
        metadata = {"target_trade_date": trade_date, "policy": "retain_original_dates_at_or_before_daily_trade_date",
                    "raw_result_preserved": True, "status": "FAILED"}
        try:
            if item.get("ok") is not True:
                raise ValueError("formula_alignment_original_query_failed")
            fields = item.get("result", {}).get(symbol)
            if not isinstance(fields, dict) or not fields:
                raise ValueError("formula_alignment_normalized_fields_missing")
            dates = fields.get("date")
            if not isinstance(dates, list) or not dates:
                raise ValueError("formula_alignment_native_dates_missing")
            if any(not isinstance(value, str) or date.fromisoformat(value).isoformat() != value for value in dates):
                raise ValueError("formula_alignment_native_date_invalid")
            if any(left >= right for left, right in zip(dates, dates[1:])):
                raise ValueError("formula_alignment_native_dates_not_increasing")
            if trade_date not in dates:
                raise ValueError("formula_alignment_target_date_missing")
            for key, values in fields.items():
                if not isinstance(values, list) or len(values) != len(dates):
                    raise ValueError("formula_alignment_series_length_mismatch:" + key)
            indices = [index for index, value in enumerate(dates) if value <= trade_date]
            # Keep each value at its original native date; never relabel an intraday value.
            item["result"][symbol] = {key: [values[index] for index in indices] for key, values in fields.items()}
            metadata.update(status="ALIGNED" if len(indices) < len(dates) else "ALREADY_ALIGNED",
                            source_first_date=dates[0], source_last_date=dates[-1],
                            source_count=len(dates), retained_count=len(indices),
                            removed_after_target_count=len(dates) - len(indices), retained_source_indices=indices)
            passed.add(name)
        except (TypeError, ValueError, AttributeError) as exc:
            item["ok"] = False
            item.setdefault("error", str(exc))
            metadata["error"] = str(exc)
            errors.append(name + ":" + str(exc))
        item["date_alignment"] = metadata
    aligned["failed_formulas"] = [name for name in required if name not in passed]
    aligned["ok"] = scan.get("ok") is True and not aligned["failed_formulas"] and not errors
    aligned["errors"] = list(dict.fromkeys(errors))
    if not aligned["ok"]:
        aligned["status"] = "BLOCKED"
    aligned["date_alignment"] = {"target_trade_date": trade_date, "status": "PASS" if aligned["ok"] else "FAILED",
                                 "original_scan_ok": scan.get("ok") is True, "raw_results_preserved": True}
    return aligned


def native_observation(symbol, config, args, output):
    root = Path(config["tdx_root"])
    paths = {"TDX_VIPDOC": root / "vipdoc", "TDX_HQ_CACHE": root / "T0002/hq_cache",
             "TDX_INFOHARBOR_BLOCK": root / "T0002/hq_cache/infoharbor_block.dat",
             "TDX_ZS_CONFIG": root / "T0002/hq_cache/tdxzs.cfg", "TDX_HY_CONFIG": root / "T0002/hq_cache/tdxhy.cfg",
             "TDX_BASE_DBF": root / "T0002/hq_cache/base.dbf", "TDX_CW_DIR": root / "vipdoc/cw"}
    os.environ.update({key: str(value) for key, value in paths.items()})
    env_paths = {"CODEX_DUANXIANXIA_PATH": "duanxianxia_file", "CODEX_LIANBAN_SNAPSHOT": "lianban_file",
                 "CODEX_LIANBAN_HISTORY_PATH": "lianban_history_file"}
    for env, key in env_paths.items():
        os.environ[env] = config.get(key, "")
    os.environ["CODEX_UNIFIED_STOCK_EVIDENCE_FILE"] = str(Path(args.evidence).resolve()) if args.evidence else config.get("evidence_file", "")
    supplied_clock = False
    if os.environ["CODEX_UNIFIED_STOCK_EVIDENCE_FILE"]:
        bundle = read_json(os.environ["CODEX_UNIFIED_STOCK_EVIDENCE_FILE"])
        supplied_clock = "evaluation_clock" in bundle.get("stocks", {}).get(symbol, {}).get("evidence", {})
    module = entry()
    module.TDX_ROOT = root
    module.expected_completed_trade_date = completed_date
    module.load_formula_scan = lambda requested: formula_scan(root, requested, config, output)
    observation, sources, errors = module.load_native_observation(symbol)
    observation["formula_scan"] = align_formula_scan_to_trade_date(observation["formula_scan"], symbol, observation["trade_date"])
    if config.get("mainline_file"):
        path = Path(config["mainline_file"])
        sources["mainline_file"] = file_binding(path)
        observation["mainline_context"] = read_json(path)
    for key in env_paths.values():
        if config.get(key):
            sources[key] = file_binding(config[key])
    # A supplement for other evidence must not suppress the genuine fund-flow request.
    if "fund_flow" not in observation.get("evidence", {}):
        observation.setdefault("evidence", {})["fund_flow"] = module.fetch_fund_flow(symbol, observation["trade_date"])
        if not supplied_clock:
            observation["evidence"]["evaluation_clock"]["as_of"] = datetime.now(timezone.utc).isoformat()
    return observation, sources, errors


def assess(observation, errors, mode):
    score = engine().score_stock(copy.deepcopy(observation))
    complete = score["evidence_complete"] is True and score["score_confidence"] == "VERIFIED" and not errors
    return {"schema": "WORKBUDDY_DESKTOP_SCORE_V1", "skill_id": OWNER,
            "model_version": score["score_contract"]["version"], "model_sha256": score["score_contract"]["model_sha256"],
            "status": "COMPLETE_SCORE" if complete else "BLOCKED_NO_SCORE",
            "score_status": "COMPLETE_SCORE" if complete else "DATA_REQUIRED",
            "data_source": mode, "non_live": True, "realtime_verified": False,
            "evidence_authenticity": "INPUT_VALIDATED_NOT_INDEPENDENTLY_ATTESTED",
            "symbol": score["symbol"], "name": score["name"], "trade_date": score["trade_date"],
            "final_score": score["final_score"] if complete else None,
            "decision_eligible": score["decision_eligible"] if complete else False,
            "unified_score": score if complete else None,
            "missing_evidence": score["missing_evidence"], "validation_errors": errors,
            "predictive_claim_allowed": False, "score_is_probability": False}


def report_markdown(report):
    lines = ["# 统一短线个股评分系统", "", f"证券：{report.get('symbol', '')} {report.get('name', '')}",
             f"资料日期：{report.get('trade_date', '')}", ""]
    if report["status"] != "COMPLETE_SCORE":
        lines += ["本次资料不足，未发布完整总分。", "", "待补齐项目："]
        lines += ["- " + str(x) for x in report["missing_evidence"] + report["validation_errors"]]
    else:
        score = report["unified_score"]
        lines += [f"最终评分：{score['final_score']} / 100；候选资格：{'合格' if score['decision_eligible'] else '不合格'}。",
                  "", "| 评分项目 | 得分 |", "|---|---:|"]
        lines += [f"| {x['id']} {x['name']} | {x['score']} |" for x in score["positive_dimensions"]]
        lines += ["", f"正向分：{score['positive_score']}；风险扣分：{score['risk_deduction']}。", "", "## 风险检查", ""]
        lines += [f"- {x['id']} {x['name']}：{'触发' if x['triggered'] else '未触发'}；实际扣分 {x['applied_deduction']}" for x in score["risks"]]
        lines += ["", "## 硬性排除", ""]
        lines += [f"- {x['id']} {x['name']}：{'通过' if x['passed'] else '未通过'}" for x in score["hard_exclusions"]]
        lines += ["", "## 资金与信号", ""]
        lines += [f"- {key}：{value}" for key, value in score["signals"].items()]
    lines += ["", "本结果来自日线资料或提供的证据；不是实时行情认证，也不是上涨概率。完整分数须由本包回执核验通过后引用。", ""]
    return "\n".join(lines)


def run_score(args):
    output = Path(args.output).resolve() if args.output else ROOT / "results"
    output = output / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8])
    output.mkdir(parents=True, exist_ok=False)
    observation = None
    sources = {}
    mode = "supplied_evidence" if args.input else "tdx_local_daily"
    try:
        verify_package()
        module = entry()
        symbol = module.normalize_symbol(args.symbol or "600519.SH")
        if args.input:
            path = Path(args.input).resolve()
            sources["supplied_input"] = file_binding(path)
            read_json(path)
            observation = module.load_supplied_observation(path, symbol if args.symbol else None)
            if file_binding(path) != sources["supplied_input"]:
                raise ValueError("supplied_input_changed")
            errors = []
        else:
            config = configuration(args)
            inspection = environment().inspect_environment(Path(config["tdx_root"]), symbol)
            if inspection.get("ok") is not True:
                raise ValueError("target_environment_requires_setup:" + json.dumps(inspection.get("issues", []), ensure_ascii=False))
            if not config["allow_sdk_initialize"]:
                raise ValueError("sdk_connection_not_enabled: 请在目标电脑允许连接后执行 configure --enable-sdk")
            observation, sources, errors = native_observation(symbol, config, args, output)
            if observation.get("formula_scan", {}).get("ok") is not True:
                errors.extend(observation.get("formula_scan", {}).get("errors", ["technical_formula_collection_failed"]))
        report = assess(observation, errors, mode)
    except Exception as exc:
        report = {"schema": "WORKBUDDY_DESKTOP_SCORE_V1", "skill_id": OWNER, "status": "BLOCKED_NO_SCORE",
                  "score_status": "DATA_REQUIRED", "data_source": mode, "non_live": True,
                  "realtime_verified": False, "final_score": None, "unified_score": None,
                  "decision_eligible": False, "missing_evidence": [], "validation_errors": [f"{type(exc).__name__}:{exc}"],
                  "predictive_claim_allowed": False, "score_is_probability": False}
    write_json(output / "observation.json", observation)
    write_json(output / "report.json", report)
    (output / "评分报告.md").write_text(report_markdown(report), encoding="utf-8")
    receipt = {"schema": "WORKBUDDY_DESKTOP_RECEIPT_V1", "skill_id": OWNER, "status": report["status"],
               "score_status": report["score_status"], "created_at": datetime.now(timezone.utc).isoformat(),
               "observation": {"path": "observation.json", "sha256": sha(output / "observation.json")},
               "report": {"path": "report.json", "sha256": sha(output / "report.json")},
               "markdown": {"path": "评分报告.md", "sha256": sha(output / "评分报告.md")},
               "model_sha256": verify_package()["model_sha256"], "source_bindings": sources,
               "package_manifest_sha256": sha(ROOT / "package-manifest.json") if (ROOT / "package-manifest.json").is_file() else None}
    write_json(output / "receipt.json", receipt)
    return {"status": report["status"], "score_status": report["score_status"], "receipt": str(output / "receipt.json"),
            "report": str(output / "评分报告.md"), "missing_evidence": report["missing_evidence"],
            "errors": report["validation_errors"]}


def authorize(path):
    manifest = verify_package()
    path = Path(path).resolve()
    receipt = read_json(path)
    if receipt.get("schema") != "WORKBUDDY_DESKTOP_RECEIPT_V1" or receipt.get("skill_id") != OWNER:
        raise ValueError("receipt_identity_invalid")
    if receipt.get("model_sha256") != manifest["model_sha256"]:
        raise ValueError("receipt_model_mismatch")
    if receipt.get("package_manifest_sha256") != (sha(ROOT / "package-manifest.json") if (ROOT / "package-manifest.json").is_file() else None):
        raise ValueError("receipt_package_mismatch")
    paths = {}
    for key in ("observation", "report", "markdown"):
        paths[key] = within(path.parent, receipt[key]["path"])
        if sha(paths[key]) != receipt[key]["sha256"]:
            raise ValueError("receipt_artifact_changed:" + key)
    report = read_json(paths["report"])
    if receipt.get("status") != "COMPLETE_SCORE" or receipt.get("score_status") != "COMPLETE_SCORE":
        raise ValueError("incomplete_receipt_cannot_publish_score")
    if report.get("data_source") not in ("tdx_local_daily", "supplied_evidence"):
        raise ValueError("report_data_source_invalid")
    observation = read_json(paths["observation"])
    recomputed = assess(observation, [], report["data_source"])
    if recomputed != report or report["status"] != "COMPLETE_SCORE":
        raise ValueError("score_recomputation_mismatch")
    if paths["markdown"].read_text(encoding="utf-8") != report_markdown(report):
        raise ValueError("markdown_recomputation_mismatch")
    return {"status": "AUTHORIZED", "skill_id": OWNER, "receipt": str(path),
            "symbol": report["symbol"], "trade_date": report["trade_date"], "final_score": report["final_score"],
            "decision_eligible": report["decision_eligible"], "non_live": True,
            "authorization_scope": "ARCHIVED_INPUT_AND_SCORE_INTEGRITY_NOT_CURRENT_MARKET_FRESHNESS",
            "predictive_claim_allowed": False}


def parser():
    root = argparse.ArgumentParser(description="统一短线个股评分系统 WorkBuddy电脑版 V4")
    sub = root.add_subparsers(dest="command", required=True)
    for name in ("configure", "doctor", "selftest", "run", "authorize", "route"):
        p = sub.add_parser(name)
        p.add_argument("--config")
        if name in ("configure", "doctor", "run"):
            p.add_argument("--tdx-root")
        if name in ("doctor", "run"):
            p.add_argument("--symbol")
        if name == "configure":
            p.add_argument("--enable-sdk", action="store_true", help="Explicitly permit SDK connection on this computer")
        if name == "doctor":
            p.add_argument("--probe-formulas", "--probe-tq", action="store_true")
        if name == "run":
            source = p.add_mutually_exclusive_group()
            source.add_argument("--input")
            source.add_argument("--evidence")
            p.add_argument("--output", "--outdir")
        if name == "authorize":
            p.add_argument("--receipt", required=True)
        if name == "route":
            p.add_argument("--query", default="统一短线个股评分系统")
    worker = sub.add_parser("_formula-worker")
    worker.add_argument("--request", required=True)
    worker.add_argument("--response", required=True)
    return root


def dispatch(args):
    verify_package()
    if args.command == "_formula-worker":
        request = read_json(args.request)
        with contextlib.redirect_stdout(io.StringIO()):
            result = environment().collect_formula_scan(Path(request["tdx_root"]), request["symbol"],
                                                       request["config"], Path(args.response).parent)
        write_json(args.response, result)
        return {"status": "WORKER_FINISHED"}
    if args.command == "route":
        skills = read_json(ROOT / "references/stock_skill_ids.json")["skills"]
        matches = [s for s in skills if args.query in [s["id"], s["name"], *s["aliases"]]]
        if len(matches) != 1:
            raise ValueError("stock_skill_exact_match_required")
        return {"status": "ROUTED", "skill_id": matches[0]["id"], "entry": str(Path(__file__).resolve())}
    if args.command == "configure":
        config = configuration(args)
        if args.enable_sdk:
            config["allow_sdk_initialize"] = True
        path = config_path(args)
        if path.exists():
            backup = path.with_name(path.name + ".backup-" + uuid.uuid4().hex[:8])
            shutil.copy2(path, backup)
        write_json(path, config)
        return {"status": "CONFIGURED", "config": str(path), "tdx_root": config["tdx_root"],
                "allow_sdk_initialize": config["allow_sdk_initialize"]}
    if args.command == "doctor":
        config = configuration(args)
        symbol = entry().normalize_symbol(args.symbol or "600519.SH")
        result = environment().inspect_environment(Path(config["tdx_root"]), symbol)
        result["environment_status"] = result["status"]
        result["status"] = "READY" if result.get("ok") is True else "SETUP_REQUIRED"
        result["config"] = str(config_path(args))
        result["model_sha256"] = verify_package()["model_sha256"]
        if args.probe_formulas and result.get("ok") is True:
            output = ROOT / ".local" / ("probe-" + uuid.uuid4().hex[:8])
            output.mkdir(parents=True)
            scan = formula_scan(Path(config["tdx_root"]), symbol, config, output)
            result["formula_scan"] = scan
            result["status"] = "FORMULAS_VERIFIED" if scan.get("ok") is True else "FORMULA_CHECK_FAILED"
        write_json(ROOT / ".local/doctor.json", result)
        return result
    if args.command == "selftest":
        validator = load(ROOT / "tests/upstream_validation.py", "desktop_upstream_validator")
        result = validator.validate()
        import unittest
        suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), pattern="test_*.py")
        stream = io.StringIO()
        tests = unittest.TextTestRunner(stream=stream).run(suite)
        result["adapter_tests"] = {"count": tests.testsRun, "failures": len(tests.failures), "errors": len(tests.errors), "output": stream.getvalue()}
        result["status"] = "SELFTEST_PASSED" if result["status"] == "PASS" and tests.wasSuccessful() else "SELFTEST_FAILED"
        write_json(ROOT / ".local/selftest.json", result)
        return {"status": result["status"], "upstream_tests": result["upstream_unittest"]["tests_run"],
                "adapter_tests": tests.testsRun, "evidence": str(ROOT / ".local/selftest.json")}
    if args.command == "run":
        return run_score(args)
    return authorize(args.receipt)


def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    args = parser().parse_args()
    try:
        result = dispatch(args)
    except Exception as exc:
        result = {"status": "REJECTED" if args.command == "authorize" else "SETUP_REQUIRED",
                  "errors": [f"{type(exc).__name__}:{exc}"], "final_score": None}
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return 0 if result["status"] in ("CONFIGURED", "READY", "SELFTEST_PASSED", "FORMULAS_VERIFIED", "COMPLETE_SCORE", "AUTHORIZED", "ROUTED", "WORKER_FINISHED") else 2


if __name__ == "__main__":
    raise SystemExit(main())
