---
name: unified-shortterm-stock-score-desktop
description: 在Windows版WorkBuddy本地任务中调用统一短线个股评分系统电脑版V4。使用目标电脑的通达信TQ、两项指定公式及完整研究证据，执行原14项100分评分、风险检查和回执核验。首次调用先配置路径与检查环境，不启动或修改通达信，不采用手机版评分口径。
---

# 统一短线个股评分系统

WorkBuddy电脑版独立导出包。评分核心的7个文件保持原V4内容；本包只适配路径配置、
资料收集与运行回执，不替换原系统，不使用手机公开数据版的替代规则。

只在目标电脑的本地任务中执行，以本文件所在目录为包根目录。不得寻找原导出电脑的
盘符、Codex目录或手机版文件。用户需要的是股票评分，不是安装、升级或重写通达信。

## 首次调用

读取 `references/安装与调试.md`。需要Python 3.10及以上64位解释器；TQ还可能要求
与目标电脑所装组件匹配的Python版本，必须以检查结果为准。

从包根目录依次运行：

```powershell
python scripts/stock_canonical_runtime.py configure
python scripts/stock_canonical_runtime.py doctor --symbol 600519.SH
python scripts/stock_canonical_runtime.py selftest
```

自动识别不出唯一通达信目录时，依据实际安装目录重新执行：

```powershell
python scripts/stock_canonical_runtime.py configure --tdx-root "D:\通达信"
```

上面的路径仅为示例，不得直接假定目标电脑存在该目录。`首次检查.ps1` 可以完成解释器
查找和前三项检查，不安装软件、不修改注册表、不启动或关闭通达信。

`doctor` 默认只做静态检查，配置中的 `allow_sdk_initialize` 默认为 `false`。
用户在目标电脑的本地任务中明确允许连接TQ后，才执行以下命令开启本包连接许可：

```powershell
python scripts/stock_canonical_runtime.py configure --enable-sdk
```

不得在首次配置或探测时自行启用。用户自行准备好通达信及TQ服务后，再执行实际只读公式验证：

用户在当前任务中已经明确允许本包连接TQ时，执行上述开启步骤，不重复索要同一许可。
这是本包的连接许可，不是通达信主程序开关；通达信已经运行也不能跳过本包配置。

```powershell
python scripts/stock_canonical_runtime.py doctor --symbol 600519.SH --probe-formulas
```

证券代码应替换为用户实际指定的对象。必须同时核实TQ与下列两项公式实际可调用，
不能仅根据“已安装通达信”或进程存在作出结论：

- 大牛线4.0，对应默认公式名“大牛线撑压版”。
- 飞龙在天4.0，对应默认公式名“飞龙在天”。

如目标电脑公式名称不同，只按真实对应关系配置 `formula_names`，不能把相似公式当作同一公式。
导出层对这两项公式统一使用 `dividend_type=0`，与本机未复权日线口径一致，不能混用复权输入。
不得擅自导入、重写、启动或关闭通达信。检测缺少组件、版本不兼容或资料不足时，
准确展示检查结果与下一项必要条件，不反复重试。

大牛线绘图文字不参与数值评分；适配层只向原模型传递实际使用的命名数值字段，
完整原回包另存。`庄出`或`STJ83`未以可确认的命名字段返回时，卖出预警仍为缺证，
不能按匿名输出编号猜测。盘中公式数据按本地完整日线的实际日期对齐，不补造日期。

## 执行评分

所有操作都经本包统一入口，不直接调用内部评分脚本拼装结论。

```powershell
python scripts/stock_canonical_runtime.py run --symbol 600519.SH --output ./results
```

可按实际工作流提供 `--evidence` 或 `--input` 文件；格式与资料要求以入口检查为准，
不把手工填补、空字段、来源不明资料作为完整输入。各子命令均可通过 `--config` 指定本包配置。
补充资料的字段与来源要求见 [补充资料格式](references/补充资料格式.md)。
安装通达信、公式可调用仍不保证研究证据及主线资料齐全，必须由入口核实全部必需资料。
生成回执后，用回执中的实际路径核验：

```powershell
python scripts/stock_canonical_runtime.py authorize --receipt "实际运行回执路径"
```

只有运行回执 `status=COMPLETE_SCORE`、`score_status=COMPLETE_SCORE` 且
`authorize` 返回 `AUTHORIZED`，才能展示完整总分和最终结论。
缺资料时外层为 `status=BLOCKED_NO_SCORE`、评分状态为 `score_status=DATA_REQUIRED`，不能展示完整总分。
`SETUP_REQUIRED`、`FORMULA_CHECK_FAILED` 同样不是评分完成；
不得缺项补零、填中性分、删除评分项目或重分权重。

完整评分可以得出“合格”或“不合格”，不能把不合格改写成取数失败。
输出证券名称、资料截止时间、14项得分、风险与硬剔除、最终分数、候选资格及来源。
评分并不等于上涨概率或收益保证。

结果说明必须从本次保存的JSON实际读取。字段名称、记录数量、缺项名称和解释器版本
不得凭印象填写，不得加入原14项模型以外的研究清单；自然语言总结不替代程序回执。

## 验证边界

`CONFIGURED` 只证明本包配置已写入；`READY` 只证明结构检查通过；
`SELFTEST_PASSED` 只证明自检通过；`FORMULAS_VERIFIED` 只证明本次实际公式调用通过。
它们都不能代替完整评分和回执授权。迁移电脑上尚无实际运行回执时，不得声称另一电脑已实测通过。
