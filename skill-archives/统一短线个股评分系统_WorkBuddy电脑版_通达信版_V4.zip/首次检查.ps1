﻿[CmdletBinding()]
param(
    [string]$TdxRoot = '',
    [string]$PythonPath = '',
    [string]$ConfigPath = '',
    [string]$Symbol = '600519.SH',
    [switch]$ProbeFormulas
)

$ErrorActionPreference = 'Stop'
$packageRoot = $PSScriptRoot
$entryPath = Join-Path $packageRoot 'scripts\stock_canonical_runtime.py'
$pythonCandidates = New-Object 'System.Collections.Generic.List[object]'
$seenPythonCandidates = @{}

function Add-PythonCandidate {
    param([string]$Executable, [string[]]$Prefix = @())
    if ([string]::IsNullOrWhiteSpace($Executable)) { return }
    $expanded = [Environment]::ExpandEnvironmentVariables($Executable)
    if ($expanded -match '\\Microsoft\\WindowsApps\\') { return }
    if (-not (Test-Path -LiteralPath $expanded -PathType Leaf)) { return }
    $resolved = (Resolve-Path -LiteralPath $expanded).ProviderPath
    $key = $resolved + '|' + ($Prefix -join '|')
    if ($seenPythonCandidates.ContainsKey($key)) { return }
    $seenPythonCandidates[$key] = $true
    $pythonCandidates.Add([pscustomobject]@{ Executable = $resolved; Prefix = $Prefix })
}

function Find-UsablePython {
    if ($PythonPath) {
        Add-PythonCandidate -Executable $PythonPath
    }
    else {
        foreach ($commandName in @('py.exe', 'python.exe', 'python3.exe')) {
            $commands = @(Get-Command $commandName -CommandType Application -All -ErrorAction SilentlyContinue)
            foreach ($command in $commands) {
                if ($commandName -eq 'py.exe') {
                    Add-PythonCandidate -Executable $command.Source -Prefix @('-3')
                }
                else { Add-PythonCandidate -Executable $command.Source }
            }
        }
        foreach ($registryRoot in @(
            'Registry::HKEY_CURRENT_USER\Software\Python\PythonCore',
            'Registry::HKEY_LOCAL_MACHINE\Software\Python\PythonCore',
            'Registry::HKEY_CURRENT_USER\Software\WOW6432Node\Python\PythonCore',
            'Registry::HKEY_LOCAL_MACHINE\Software\WOW6432Node\Python\PythonCore'
        )) {
            foreach ($versionKey in @(Get-ChildItem -LiteralPath $registryRoot -ErrorAction SilentlyContinue)) {
                $installKey = Get-Item -LiteralPath (Join-Path $versionKey.PSPath 'InstallPath') -ErrorAction SilentlyContinue
                if ($null -eq $installKey) { continue }
                $registeredExecutable = [string]$installKey.GetValue('ExecutablePath', '')
                if ($registeredExecutable) { Add-PythonCandidate -Executable $registeredExecutable }
                $registeredDirectory = [string]$installKey.GetValue('', '')
                if ($registeredDirectory) { Add-PythonCandidate -Executable (Join-Path $registeredDirectory 'python.exe') }
            }
        }
    }
    $probeCode = "import json,struct,sys; print(json.dumps({'version':list(sys.version_info[:3]),'bits':struct.calcsize('P')*8,'executable':sys.executable}))"
    foreach ($candidate in $pythonCandidates) {
        try {
            $arguments = @($candidate.Prefix) + @('-c', $probeCode)
            $probeOutput = @(& $candidate.Executable @arguments 2>&1)
            $probeExit = $LASTEXITCODE
            if ($probeExit -ne 0) { continue }
            $details = ($probeOutput -join [Environment]::NewLine) | ConvertFrom-Json
            $major = [int]$details.version[0]
            $minor = [int]$details.version[1]
            if (($major -eq 3 -and $minor -ge 10) -and [int]$details.bits -eq 64) {
                return [pscustomobject]@{
                    Executable = [string]$details.executable
                    Version = ($details.version -join '.')
                    Bits = [int]$details.bits
                }
            }
        }
        catch { continue }
    }
    throw '未找到可运行的Python 3.10及以上64位解释器。请在目标电脑准备兼容解释器，或用-PythonPath指定；本脚本没有安装或升级软件。'
}

function Invoke-PackageCheck {
    param([string]$Label, [string]$Command, [string[]]$Arguments = @(), [string]$ExpectedStatus)
    Write-Host ''
    Write-Host ('正在' + $Label + '...')
    $cliArguments = @($entryPath, $Command) + $Arguments
    if ($ConfigPath) { $cliArguments += @('--config', $ConfigPath) }
    $lines = @(& $script:selectedPython.Executable @cliArguments 2>&1)
    $commandExit = $LASTEXITCODE
    $outputText = ($lines | ForEach-Object { [string]$_ }) -join [Environment]::NewLine
    if ($outputText) { Write-Host $outputText }
    if ($commandExit -ne 0) {
        throw ($Label + '未通过，退出码' + $commandExit + '。请依据上方实际检查结果处理；尚未完成评分。')
    }
    try { $result = $outputText | ConvertFrom-Json }
    catch { throw ($Label + '未返回可核验的JSON状态。请检查上方输出，不能仅凭退出码认定通过。') }
    if ([string]$result.status -ne $ExpectedStatus) {
        throw ($Label + '状态不是' + $ExpectedStatus + '，实际为' + [string]$result.status + '。尚未完成本项验证。')
    }
}

$originalPythonEncoding = $env:PYTHONIOENCODING
$originalPythonUtf8 = $env:PYTHONUTF8
$originalConsoleEncoding = [Console]::OutputEncoding
$locationPushed = $false
$resultExit = 2
try {
    $env:PYTHONIOENCODING = 'utf-8'
    $env:PYTHONUTF8 = '1'
    [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
    if (-not (Test-Path -LiteralPath $entryPath -PathType Leaf)) {
        throw '本包统一入口缺失。请重新取得完整ZIP，不要从原系统或手机版目录临时拼接文件。'
    }
    if ($ConfigPath) { $ConfigPath = [IO.Path]::GetFullPath($ConfigPath) }
    if ($TdxRoot) {
        $TdxRoot = [IO.Path]::GetFullPath($TdxRoot)
        if (-not (Test-Path -LiteralPath $TdxRoot -PathType Container)) {
            throw ('指定的通达信目录不存在：' + $TdxRoot)
        }
    }
    $script:selectedPython = Find-UsablePython
    Write-Host ('已检测到Python ' + $selectedPython.Version + '，' + $selectedPython.Bits + '位：' + $selectedPython.Executable)
    Write-Host '本次只检查本包，不安装软件、不改注册表或系统设置、不启动或关闭通达信。'
    Push-Location -LiteralPath $packageRoot
    $locationPushed = $true
    $configureArguments = @()
    if ($TdxRoot) { $configureArguments += @('--tdx-root', $TdxRoot) }
    Invoke-PackageCheck -Label '配置本包路径' -Command 'configure' -Arguments $configureArguments -ExpectedStatus 'CONFIGURED'
    Invoke-PackageCheck -Label '检查环境结构' -Command 'doctor' -Arguments @('--symbol', $Symbol) -ExpectedStatus 'READY'
    Invoke-PackageCheck -Label '运行本包自检' -Command 'selftest' -ExpectedStatus 'SELFTEST_PASSED'
    if ($ProbeFormulas) {
        Write-Host '实际连接还要求用户已在本包配置中明确启用allow_sdk_initialize；本脚本不会替用户开启。'
        Invoke-PackageCheck -Label '实际验证TQ和两项公式' -Command 'doctor' -Arguments @('--symbol', $Symbol, '--probe-formulas') -ExpectedStatus 'FORMULAS_VERIFIED'
        Write-Host ''
        Write-Host '基础检查和本次公式实际调用已通过。尚未执行完整个股评分，不能据此展示总分。'
    }
    else {
        Write-Host ''
        Write-Host '基础检查已通过；尚未验证TQ和两项公式，尚未进行个股评分。'
        Write-Host '请由用户自行准备好通达信及TQ服务，再执行本脚本并添加-ProbeFormulas。'
        Write-Host '连接前还需用户明确允许并在本包配置中启用allow_sdk_initialize，默认保持关闭。'
    }
    $resultExit = 0
}
catch {
    Write-Host ''
    Write-Host ('首次检查未完成：' + $_.Exception.Message) -ForegroundColor Red
    $resultExit = 2
}
finally {
    if ($locationPushed) { Pop-Location }
    $env:PYTHONIOENCODING = $originalPythonEncoding
    $env:PYTHONUTF8 = $originalPythonUtf8
    [Console]::OutputEncoding = $originalConsoleEncoding
}
exit $resultExit
