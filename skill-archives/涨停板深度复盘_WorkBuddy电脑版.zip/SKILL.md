---
name: limit-up-review
description: 在 Windows 电脑版 WorkBuddy 中完成最新交易日涨停板深度复盘。用户提到“涨停板深度复盘”“涨停复盘”“涨停池复盘”时调用，覆盖完整涨停池、20/60日基线、题材催化、资金机构、技术结构、个股角色和次日情景，并以回执硬闸校验。
agent_created: true
entry: scripts/workbuddy_entry.py
display_name: 涨停板深度复盘（电脑版）
---

# 涨停板深度复盘（电脑版）

中文备注：面向 WorkBuddy 电脑版的 A 股收盘后涨停板全景复盘与次日条件观察工具。

## 调用

统一入口：`python scripts/workbuddy_entry.py`。不得绕过入口直接执行内部脚本或拼装结论。

首次导入：

```powershell
python scripts/workbuddy_entry.py configure
python scripts/workbuddy_entry.py selftest
python scripts/workbuddy_entry.py sources --output .local/source-check
```

若自动识别到多个或零个通达信目录，指定目标电脑真实路径：

```powershell
python scripts/workbuddy_entry.py configure --tdx-root "D:\TDX"
```

实战运行与授权：

```powershell
python scripts/workbuddy_entry.py run --output .local/runs/current
python scripts/workbuddy_entry.py authorize --receipt .local/runs/current/receipt.json
```

## 数据源

- 东方财富：正式涨停池、核心题材、全市场宽度、个股资金流、龙虎榜明细。
- 新浪财经：东方财富资金流受连接风控时的独立日度备用源；逐股保留目标日原始记录与哈希，不使用成交额替代净流入。
- 同花顺：此前 60 个交易日同口径涨停揭秘基线。
- 连板网：目标交易日页面与开放 JSON，交叉核验连板、题材和事件线索。
- AkShare：交易日历及东方财富/新浪公开接口的稳定适配，包括涨停、炸板、跌停、强势股、龙虎榜与机构买卖。
- 本地通达信：只读 `vipdoc` 日线完成目标日逐股收盘价和技术覆盖；`ZTC.blk` 仅作诊断，不能新增股票。

详细接口、主机和字段用途见 `references/数据源与接口.md`。连接器只能补充交叉核对，不能替代固定来源或把“连接器存在”当成数据已经取得。

## 完成规则

- 官方涨停池是唯一候选全集，最终 CSV 必须与其代码集合完全一致。
- 20/60 日基线、催化、技术、资金和机构数据均按完整口径校验。
- 所有判断必须有证据、反证、失效条件和置信依据。
- 个股角色只来自固定七类，题材选择必须保留同股证据链。
- 业务语义硬闸通过后才生成 Word、Markdown、CSV 与观察清单。
- 最终必须执行 `authorize --receipt`；只有返回 `AUTHORIZED` 才可展示结论。

## 环境与安全

- 适配 WorkBuddy 5.5.3 及 Windows 电脑版技能 ZIP 根目录导入方式。
- Python 3.10 以上，依赖见 `requirements.txt`。
- 只读使用通达信，不启动、关闭、注入或修改其进程和文件。
- 网络仅访问公开 HTTPS 数据接口；不需要账号、Cookie 或交易密钥。
- 不自动交易、不下单、不承诺收益；结果仅作研究参考。

执行细节见 `references/workflow.md`，业务口径见 `references/business_spec.md`，首次安装见 `安装说明.md`。
