import importlib.util
import struct
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "prepare_analysis_inputs.py"


class AnalysisInputTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location("prepare_analysis_inputs", SCRIPT)
        cls.module = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(cls.module)

    def test_catalyst_bundle_keeps_only_official_codes(self):
        snapshot = {
            "target_date": "2026-09-07",
            "sources": {"page": {"url": "https://example.test/day", "sha256": "abc", "status_code": 200}},
            "page_details": {"stock_items": [
                {"code": "002403", "name": "爱仕达", "theme": "机器人概念", "reason": "同日公开理由"},
                {"code": "999999", "name": "池外股票", "theme": "其他", "reason": "不得进入"},
            ]},
        }
        bundle = self.module.build_catalyst_bundle(snapshot, {"002403"}, "2026-09-07")
        self.assertEqual([item["code"] for item in bundle["items"]], ["002403"])
        self.assertEqual(bundle["status"], "VERIFIED")

    def test_baseline_requires_sixty_complete_records(self):
        records = [{"date": f"2026-01-{index:02d}"} for index in range(1, 60)]
        result = self.module.validate_baseline_records(records, required_count=60)
        self.assertEqual(result["status"], "BLOCKED")

    def test_local_technical_snapshot_uses_target_date_and_full_history(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "sz000001.day"
            day = struct.Struct("<IIIIIfII")
            raw = b"".join(
                day.pack(20260000 + index, 1000, 1100, 900, 1000 + index, 1.0, 100, 0)
                for index in range(1, 66)
            )
            path.write_bytes(raw)
            result = self.module.read_technical_snapshot(path, "20260065")
            self.assertEqual(result["status"], "VERIFIED")
            self.assertEqual(result["history_count"], 65)

    def test_complete_web_capture_builds_verified_baseline_record(self):
        capture = {
            "status": "COMPLETE",
            "complete": True,
            "final_url": "https://lianban.net/days/2026-07-17.html",
            "content": {
                "title": "2026年7月17日A股复盘：涨停32家 最高4板 主线电力_连板网",
                "text": "2026-07-17 当日主线 智能电网 涨停9家 业绩增长 涨停6家",
                "structured_data": [{
                    "@type": "Dataset",
                    "name": "连板网 2026-07-17",
                    "variableMeasured": [
                        {"name": "涨停家数", "value": 32},
                        {"name": "连板家数", "value": 8},
                        {"name": "最高板", "value": 4},
                    ],
                }],
            },
            "evidence": {
                "http_status": 200,
                "sha256": "e1aa08b78dbae76c7a63a2b5a3de6ab125ed8666c8e401bb7763e7626c309752",
                "truncated": False,
            },
        }

        result = self.module.baseline_record_from_capture(capture, "2026-07-17")

        self.assertEqual(result["limitup_count"], 32)
        self.assertEqual(result["continuation_count"], 8)
        self.assertEqual(result["max_board"], 4)
        self.assertEqual(result["largest_direction_share"], 0.28125)
        self.assertEqual(result["sha256"], capture["evidence"]["sha256"])

    def test_web_capture_rejects_wrong_trade_date(self):
        capture = {
            "status": "COMPLETE",
            "complete": True,
            "final_url": "https://lianban.net/days/2026-07-16.html",
            "content": {
                "title": "2026年7月16日A股复盘：涨停40家 最高5板_连板网",
                "text": "2026-07-16 当日主线 电力 涨停8家",
                "structured_data": [{
                    "@type": "Dataset",
                    "name": "连板网 2026-07-16",
                    "variableMeasured": [
                        {"name": "涨停家数", "value": 40},
                        {"name": "连板家数", "value": 9},
                        {"name": "最高板", "value": 5},
                    ],
                }],
            },
            "evidence": {"http_status": 200, "sha256": "abc", "truncated": False},
        }

        with self.assertRaisesRegex(ValueError, "target date mismatch"):
            self.module.baseline_record_from_capture(capture, "2026-07-17")

    def test_rate_limited_capture_retries_until_complete(self):
        limited = {
            "status": "DEGRADED",
            "complete": False,
            "content": {"text": "请求过快, 请稍后再试"},
            "evidence": {"http_status": 429},
        }
        complete = {"status": "COMPLETE", "complete": True, "evidence": {"http_status": 200}}

        with patch.object(self.module.time, "sleep") as sleeper:
            result = self.module.acquire_complete_page(
                lambda: limited if sleeper.call_count == 0 else complete,
                attempts=2,
                backoff_seconds=1,
            )

        self.assertIs(result, complete)
        sleeper.assert_called_once_with(1)

    def test_ths_pool_builds_consistent_baseline_record(self):
        rows = [
            {"code": "000001", "high_days": "3连板", "reason_type": "机器人概念+中报增长"},
            {"code": "000002", "high_days": "2连板", "reason_type": "机器人概念"},
            {"code": "000003", "high_days": "3天2板", "reason_type": "医药+中报增长"},
            {"code": "000004", "high_days": "首板", "reason_type": "机器人概念"},
        ]

        result = self.module.baseline_record_from_ths_pool(
            rows,
            "2026-08-10",
            "https://data.10jqka.com.cn/example?date=20260810",
            "a" * 64,
        )

        self.assertEqual(result["limitup_count"], 4)
        self.assertEqual(result["continuation_count"], 2)
        self.assertEqual(result["max_board"], 3)
        self.assertEqual(result["largest_direction_share"], 0.75)

    def test_selects_latest_verified_same_date_snapshot(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            wrong = root / "wrong.json"
            valid = root / "valid.json"
            wrong.write_text('{"target_date":"2026-09-06","sources":{"page":{"status_code":200,"sha256":"x"}}}', encoding="utf-8")
            valid.write_text('{"target_date":"2026-09-07","sources":{"page":{"status_code":200,"sha256":"y"}}}', encoding="utf-8")

            selected = self.module.select_verified_lianban_snapshot([wrong, valid], "2026-09-07")

            self.assertEqual(selected, valid)


if __name__ == "__main__":
    unittest.main()
