import importlib.util
import unittest
from pathlib import Path

import pandas as pd


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "generate_limit_up_review_strict.py"
SPEC = importlib.util.spec_from_file_location("generate_limit_up_review_strict", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(MODULE)


class InstitutionInputTests(unittest.TestCase):
    def test_institution_rows_are_limited_to_same_day_official_pool(self):
        raw = pd.DataFrame([
            {"代码": "002403", "名称": "爱仕达", "机构买入净额": 100.0, "上榜日期": "2026-09-07"},
            {"代码": "999999", "名称": "池外", "机构买入净额": 200.0, "上榜日期": "2026-09-07"},
            {"代码": "002403", "名称": "旧日", "机构买入净额": 300.0, "上榜日期": "2026-09-06"},
        ])
        context = pd.DataFrame([{"代码": "002403", "名称": "爱仕达", "投资板块": "机器人概念"}])

        result = MODULE.prepare_institution_rows(raw, context, "2026-09-07")

        self.assertEqual(result["代码"].tolist(), ["002403"])
        self.assertEqual(result["_net"].tolist(), [100.0])
        self.assertEqual(result["投资板块"].tolist(), ["机器人概念"])


if __name__ == "__main__":
    unittest.main()
