import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "collect_limitup_data_strict.py"
sys.path.insert(0, str(SCRIPT.parent))
SPEC = importlib.util.spec_from_file_location("collect_limitup_data_strict", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(MODULE)

CONTRACT_SCRIPT = SCRIPT.parent / "limit_up_review_workflow_contract.py"
CONTRACT_SPEC = importlib.util.spec_from_file_location("limit_up_review_workflow_contract", CONTRACT_SCRIPT)
CONTRACT = importlib.util.module_from_spec(CONTRACT_SPEC)
assert CONTRACT_SPEC and CONTRACT_SPEC.loader
CONTRACT_SPEC.loader.exec_module(CONTRACT)


class TopicSelectionTests(unittest.TestCase):
    def test_same_stock_event_theme_breaks_global_popularity_tie(self):
        topics = [
            {"name": "机器人概念", "rank": 8, "precise": True},
            {"name": "土地流转", "rank": 6, "precise": True},
        ]
        stats = {
            "机器人概念": {"support": 10, "connected": 1, "max_board": 3},
            "土地流转": {"support": 14, "connected": 3, "max_board": 4},
        }

        selected = MODULE.select_investment_topic(topics, stats, "机器人概念")

        self.assertEqual(selected["name"], "机器人概念")

    def test_supplemental_theme_cannot_introduce_unconfirmed_topic(self):
        topics = [
            {"name": "小家电", "rank": 5, "precise": True},
            {"name": "跨境电商", "rank": 7, "precise": True},
        ]
        stats = {
            "小家电": {"support": 4, "connected": 1, "max_board": 3},
            "跨境电商": {"support": 7, "connected": 2, "max_board": 4},
        }

        selected = MODULE.select_investment_topic(topics, stats, "机器人概念")

        self.assertEqual(selected["name"], "跨境电商")

    def test_contract_rejects_nonstandard_watchlist_role(self):
        payload = CONTRACT.build_positive_contract_canary()
        payload["watchlist"][0]["role"] = "ladder_observer"

        blocks = CONTRACT.validate_business_result_payload(payload)

        self.assertIn("watchlist[0].role is not an allowed standard role: 'ladder_observer'", blocks)

    def test_same_date_verified_snapshot_is_selected_when_current_path_is_missing(self):
        with tempfile.TemporaryDirectory() as temp:
            valid = Path(temp) / "lianban-daily.json"
            valid.write_text(
                '{"status":"CLEAN_PASS","target_date":"2026-09-07","sources":{"page":{"status_code":200,"sha256":"abc"}}}',
                encoding="utf-8",
            )

            selected = MODULE.select_lianban_snapshot([Path(temp) / "missing.json", valid], "20260907")

            self.assertEqual(selected["target_date"], "2026-09-07")

    def test_contract_rejects_nonverified_domain_or_metric(self):
        payload = CONTRACT.build_positive_contract_canary()
        payload["domains"]["direction"]["status"] = "PARTIAL"
        payload["metrics"]["official_limit_up_count"]["verification_status"] = "UNAVAILABLE"

        blocks = CONTRACT.validate_business_result_payload(payload)

        self.assertIn("domains.direction.status must be VERIFIED", blocks)
        self.assertIn("metrics.official_limit_up_count.verification_status must be VERIFIED", blocks)

    def test_contract_rejects_watchlist_direction_not_reflected_in_rationale(self):
        payload = CONTRACT.build_positive_contract_canary()
        payload["watchlist"][0]["direction"] = "机器人概念"

        blocks = CONTRACT.validate_business_result_payload(payload)

        self.assertIn("watchlist[0].rationale does not match direction", blocks)


if __name__ == "__main__":
    unittest.main()
