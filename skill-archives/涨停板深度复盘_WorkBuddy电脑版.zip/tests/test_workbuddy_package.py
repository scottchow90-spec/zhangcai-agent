import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("workbuddy_entry", ROOT / "scripts" / "workbuddy_entry.py")
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(MODULE)


class WorkBuddyPackageTests(unittest.TestCase):
    def test_required_files_exist(self):
        self.assertTrue((ROOT / "SKILL.md").is_file())
        for name in MODULE.REQUIRED_FILES:
            self.assertTrue((ROOT / "scripts" / name).is_file(), name)

    def test_paths_are_package_local(self):
        text = (ROOT / "scripts" / "workbuddy_entry.py").read_text(encoding="utf-8")
        self.assertNotIn("F:\\Codex", text)
        self.assertNotIn("C:\\Users\\25296", text)

    def test_tdx_discovery_accepts_explicit_valid_root(self):
        self.assertTrue(MODULE.valid_tdx_root(Path(r"D:\TDX")))

    def test_metadata_names_entry(self):
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("entry: scripts/workbuddy_entry.py", text)
        self.assertIn("display_name: 涨停板深度复盘（电脑版）", text)

    def test_ths_probe_creates_cache_on_first_run(self):
        spec = importlib.util.spec_from_file_location("prepare_inputs_first_run", ROOT / "scripts" / "prepare_analysis_inputs.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader
        spec.loader.exec_module(module)

        class Response:
            url = "https://data.10jqka.com.cn/dataapi/limit_up/limit_up_pool?date=20260907"
            content = json.dumps({"status_code": 0, "data": {"page": {"total": 1}, "info": [{"code": "600000", "high_days": "1连板", "reason_type": "银行"}]}}).encode()
            def raise_for_status(self):
                return None
            def json(self):
                return json.loads(self.content)

        with tempfile.TemporaryDirectory() as temp:
            module.THS_CACHE_DIR = Path(temp) / "new-cache"
            with patch.object(module.requests, "get", return_value=Response()):
                result = module.fetch_ths_baseline("2026-09-07")
            self.assertEqual(result["date"], "2026-09-07")
            self.assertTrue((module.THS_CACHE_DIR / "2026-09-07.raw.json").is_file())

    def test_sina_fund_flow_backup_preserves_exact_day_proof(self):
        spec = importlib.util.spec_from_file_location("fund_flow", ROOT / "scripts" / "fetch_push2_fund_flow_strict.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader
        spec.loader.exec_module(module)
        raw = {
            "opendate": "2026-09-07", "trade": "3.9100", "changeratio": "0.101408",
            "netamount": "794712236.7700", "ratioamount": "0.423858",
            "r0_net": "615171729.5700", "r0_ratio": "0.32810051",
        }
        result = module.parse_sina_day([raw], "https://vip.stock.finance.sina.com.cn/test", "2026-09-07")
        self.assertTrue(result["ok"])
        self.assertEqual(result["source"], "sina_moneyflow_daily")
        self.assertEqual(result["主力净流入"], 794712236.77)
        self.assertEqual(result["超大单净流入"], 615171729.57)
        self.assertAlmostEqual(result["主力净占比"], 42.3858)
        self.assertTrue(result["raw_sha256"])

    def test_generator_accepts_verified_sina_fund_evidence(self):
        spec = importlib.util.spec_from_file_location("generator", ROOT / "scripts" / "generate_limit_up_review_strict.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader
        spec.loader.exec_module(module)
        source = {
            "opendate": "2026-09-07", "trade": "3.9100", "changeratio": "0.101408",
            "netamount": "794712236.7700", "ratioamount": "0.423858",
            "r0_net": "615171729.5700", "r0_ratio": "0.32810051",
        }
        proof = module.parse_sina_fund_day([source], "https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/MoneyFlow.ssl_qsfx_zjlrqs", "2026-09-07")
        checked = module.validate_historical_fund_frame(pd.DataFrame([proof]), "2026-09-07")
        self.assertTrue(bool(checked.iloc[0]["ok"]))


if __name__ == "__main__":
    unittest.main()
