# 涨停板深度复盘 WorkBuddy 电脑版工作流

WORKBUDDY_DESKTOP_ENTRY

NO_REDISCOVERY: true

NO_CROSS_JUMP: true

LOCKED_ENTRY: scripts/workbuddy_entry.py
LOCKED_EXECUTION: scripts/workbuddy_entry.py run

## 唯一入口

正式业务执行只允许：

```powershell
python scripts/workbuddy_entry.py run --output .local/runs/current
```

首次导入先执行 `configure`、`selftest` 和 `sources`。正式结论生成后必须使用同一运行目录中的 `receipt.json` 执行 `authorize`。其他脚本均是入口锁定的内部实现。

## 固定流程

1. 按上海时区锁定最近一个已完整收盘交易日。
2. 从东方财富正式涨停池取得唯一候选全集，并使用 AkShare 同口径结果、连板网及本地通达信日线完成日期和集合交叉验证。
3. 逐只取得东方财富核心题材、资金流、龙虎榜和机构买卖数据。
4. 从同花顺涨停揭秘接口建立此前 60 个交易日同口径基线，保存原始响应与哈希。
5. 对候选全集逐只读取本地通达信日线，完成技术覆盖。
6. 生成市场结构、方向论证、七类个股角色、证据反证、四分支次日情景和冻结预测账本。
7. 先通过业务语义硬闸，再生成 Markdown、CSV、观察清单与 Word。
8. 最终闸校验股票集合、覆盖率、状态、可见内容和产物哈希。
9. `authorize` 重新读取回执及全部文件哈希后才允许展示结论。

## 完整性要求

- 官方涨停池、最终表格和所有逐股分析使用同一代码全集。
- 60 日历史基线必须覆盖 60 个唯一交易日；20 日窗口必须覆盖 20 日。
- 催化、技术和资金覆盖必须等于官方池数量。
- 所有数据域及带校验状态的指标必须通过验证。
- 个股角色只允许：高度锚、方向核心、容量承接、首板确认、补涨跟随、孤立涨停、脆弱样本。
- 任一硬闸失败时不生成授权结果。

## 安全边界

- 只读通达信文件，不启动、关闭、注入或修改通达信。
- 不执行交易、下单、转账或自动发布。
- 不读取或打包账号、密钥、会话、Cookie 和历史数据库。
- 网络仅访问 `references/数据源与接口.md` 列出的公开 HTTPS 来源。
