#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import os
import struct
import sys
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any

import akshare as ak
import requests


HOME = Path(os.environ.get("WORKBUDDY_LIMITUP_HOME", str(Path(__file__).resolve().parents[1] / ".local" / "runtime")))
TASK_DIR = Path(os.environ.get("LIMITUP_TASK_DIR", HOME / "reports" / "limit_up_review"))
TABLE = Path(os.environ.get("LIMITUP_TABLE", ""))
TARGET_DATE = os.environ.get("LIMITUP_DATE_H", "")
TARGET_DATE_COMPACT = TARGET_DATE.replace("-", "")
BASELINE_PATH = Path(os.environ.get("LIMITUP_BASELINE_DATA", TASK_DIR / "historical_baseline.json"))
CATALYST_PATH = Path(os.environ.get("LIMITUP_RESEARCH_BUNDLE", TASK_DIR / "catalyst_research.json"))
TECHNICAL_PATH = Path(os.environ.get("LIMITUP_TECHNICAL_COVERAGE", TASK_DIR / "technical_coverage.json"))
LIANBAN_PATH = Path(os.environ.get("CODEX_LIANBAN_SNAPSHOT", ""))
CACHE_DIR = HOME / "business_data" / "limit-up-review" / "evidence_cache" / "lianban_baseline"
THS_CACHE_DIR = HOME / "business_data" / "limit-up-review" / "evidence_cache" / "ths_baseline"
LIANBAN_CLIENT = Path(__file__).resolve().parent / "lianban_daily_client.py"
WEB_ACQUIRE = Path(__file__).resolve().parent / "web_acquire.py"
TDX_ROOT = Path(os.environ.get("LIMITUP_TDX_ROOT", r"D:\TDX"))
DAY = struct.Struct("<IIIIIfII")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def code6(value: Any) -> str:
    text = str(value or "").strip()
    digits = "".join(char for char in text if char.isdigit())
    return digits[-6:].zfill(6)


def read_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError(f"json object required: {path}")
    return payload


def select_verified_lianban_snapshot(candidates: list[Path], target_date: str) -> Path | None:
    existing = sorted(
        (path for path in candidates if path.is_file()),
        key=lambda path: path.stat().st_mtime_ns,
        reverse=True,
    )
    for path in existing:
        try:
            payload = read_json(path)
            page = payload.get("sources", {}).get("page", {})
            if (
                payload.get("target_date") == target_date
                and int(page.get("status_code") or 0) == 200
                and bool(page.get("sha256"))
            ):
                return path
        except Exception:
            continue
    return None


def write_verified_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    if read_json(path) != payload:
        raise RuntimeError(f"json readback mismatch: {path}")


def load_lianban_client():
    spec = importlib.util.spec_from_file_location("limit_up_lianban_client", LIANBAN_CLIENT)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load lianban client")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_web_acquirer():
    spec = importlib.util.spec_from_file_location("limit_up_web_acquire", WEB_ACQUIRE)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load universal web acquirer")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def trade_dates_before(target_date: str, count: int) -> list[str]:
    frame = ak.tool_trade_date_hist_sina()
    values = sorted({str(value)[:10] for value in frame["trade_date"].tolist()})
    prior = [value for value in values if value < target_date]
    if len(prior) < count:
        raise RuntimeError(f"trade calendar has only {len(prior)} prior dates")
    return prior[-count:]


def baseline_record(snapshot: dict[str, Any], target_date: str) -> dict[str, Any]:
    market = snapshot.get("market") if isinstance(snapshot.get("market"), dict) else {}
    topics = snapshot.get("topics") if isinstance(snapshot.get("topics"), list) else []
    limit_up = int(market.get("limit_up") or 0)
    continuation = int(market.get("consecutive") or 0)
    max_board = int(market.get("max_board") or 0)
    topic_counts = [int(item.get("count") or 0) for item in topics if isinstance(item, dict)]
    source = snapshot.get("sources", {}).get("open_data", {})
    if limit_up <= 0 or continuation < 0 or continuation > limit_up or max_board <= 0:
        raise ValueError(f"invalid baseline market values for {target_date}")
    if int(source.get("status_code") or 0) != 200 or not source.get("sha256"):
        raise ValueError(f"unverified baseline source for {target_date}")
    return {
        "date": target_date,
        "limitup_count": limit_up,
        "continuation_count": continuation,
        "first_board_share": round((limit_up - continuation) / limit_up, 6),
        "max_board": max_board,
        "largest_direction_share": round((max(topic_counts) if topic_counts else 0) / limit_up, 6),
        "source_name": snapshot.get("source_name"),
        "source_url": source.get("url"),
        "sha256": source.get("sha256"),
    }


def baseline_record_from_page(client: Any, response: Any, target_date: str) -> dict[str, Any]:
    response.encoding = response.apparent_encoding or "utf-8"
    details = client.parse_html_details(response.text)
    title = str(details.get("title") or "")
    limit_match = re.search(r"涨停\s*(\d+)\s*家", title)
    board_match = re.search(r"最高\s*(\d+)\s*板", title)
    items = details.get("stock_items") if isinstance(details.get("stock_items"), list) else []
    continuation = len({code6(item.get("code")) for item in items if isinstance(item, dict) and int(item.get("board_count") or 0) >= 2})
    text = "\n".join(str(value) for value in details.get("event_texts") or [])
    topic_counts = [int(value) for value in re.findall(r"·\s*(\d+)\s*家", text)]
    limit_up = int(limit_match.group(1)) if limit_match else 0
    max_board = int(board_match.group(1)) if board_match else 0
    source = client.source_record(response.url, response, None)
    if limit_up <= 0 or continuation < 0 or continuation > limit_up or max_board <= 0:
        raise ValueError(f"invalid page baseline values for {target_date}")
    return {
        "date": target_date,
        "limitup_count": limit_up,
        "continuation_count": continuation,
        "first_board_share": round((limit_up - continuation) / limit_up, 6),
        "max_board": max_board,
        "largest_direction_share": round((max(topic_counts) if topic_counts else 0) / limit_up, 6),
        "source_name": "连板网公开复盘页",
        "source_url": source.get("url"),
        "sha256": source.get("sha256"),
    }


def baseline_record_from_capture(capture: dict[str, Any], target_date: str) -> dict[str, Any]:
    evidence = capture.get("evidence") if isinstance(capture.get("evidence"), dict) else {}
    content = capture.get("content") if isinstance(capture.get("content"), dict) else {}
    if (
        capture.get("status") != "COMPLETE"
        or capture.get("complete") is not True
        or int(evidence.get("http_status") or 0) != 200
        or evidence.get("truncated") is not False
        or not evidence.get("sha256")
    ):
        raise ValueError(f"incomplete page capture for {target_date}")
    identity_text = " ".join(
        str(value or "")
        for value in (capture.get("final_url"), content.get("title"), content.get("text"))
    )
    if target_date not in identity_text:
        raise ValueError(f"target date mismatch for {target_date}")

    measurements: dict[str, int] = {}
    for node in content.get("structured_data") or []:
        if not isinstance(node, dict) or node.get("@type") != "Dataset":
            continue
        if target_date not in str(node.get("name") or node.get("description") or ""):
            continue
        for item in node.get("variableMeasured") or []:
            if isinstance(item, dict) and item.get("name") in {"涨停家数", "连板家数", "最高板"}:
                measurements[str(item["name"])] = int(item.get("value") or 0)
    limit_up = measurements.get("涨停家数", 0)
    continuation = measurements.get("连板家数", -1)
    max_board = measurements.get("最高板", 0)
    text = " ".join(str(content.get("text") or "").split())
    mainline = text.split("当日主线", 1)[-1].split("明日推演", 1)[0] if "当日主线" in text else ""
    direction_counts = [int(value) for value in re.findall(r"涨停\s*(\d+)\s*家", mainline)]
    if limit_up <= 0 or continuation < 0 or continuation > limit_up or max_board <= 0:
        raise ValueError(f"invalid structured baseline values for {target_date}")
    if not direction_counts or max(direction_counts) > limit_up:
        raise ValueError(f"direction coverage missing for {target_date}")
    return {
        "date": target_date,
        "limitup_count": limit_up,
        "continuation_count": continuation,
        "first_board_share": round((limit_up - continuation) / limit_up, 6),
        "max_board": max_board,
        "largest_direction_share": round(max(direction_counts) / limit_up, 6),
        "source_name": "连板网公开复盘页",
        "source_url": capture.get("final_url"),
        "sha256": evidence.get("sha256"),
    }


def acquire_complete_page(fetch: Any, *, attempts: int = 4, backoff_seconds: int = 20) -> dict[str, Any]:
    last: dict[str, Any] = {}
    for attempt in range(1, attempts + 1):
        last = fetch()
        if last.get("status") == "COMPLETE" and last.get("complete") is True:
            return last
        evidence = last.get("evidence") if isinstance(last.get("evidence"), dict) else {}
        text = str((last.get("content") or {}).get("text") or "")
        rate_limited = int(evidence.get("http_status") or 0) == 429 or "请求过快" in text
        if not rate_limited or attempt == attempts:
            return last
        time.sleep(backoff_seconds * attempt)
    return last


def baseline_record_from_ths_pool(
    rows: list[dict[str, Any]], target_date: str, source_url: str, source_sha256: str
) -> dict[str, Any]:
    if not rows or not source_url or not re.fullmatch(r"[0-9a-f]{64}", source_sha256):
        raise ValueError(f"unverified ths pool for {target_date}")
    codes = [code6(row.get("code")) for row in rows]
    if len(set(codes)) != len(rows) or "date=" + target_date.replace("-", "") not in source_url:
        raise ValueError(f"ths pool identity mismatch for {target_date}")
    consecutive: list[int] = []
    topic_counts: dict[str, int] = {}
    for row in rows:
        board_match = re.fullmatch(r"\s*(\d+)连板\s*", str(row.get("high_days") or ""))
        if board_match:
            consecutive.append(int(board_match.group(1)))
        per_stock: set[str] = set()
        for token in re.split(r"[+＋;；、,，]", str(row.get("reason_type") or "")):
            normalized = re.split(r"[（(]", token.strip(), maxsplit=1)[0].strip()
            if normalized:
                per_stock.add(normalized)
        for topic in per_stock:
            topic_counts[topic] = topic_counts.get(topic, 0) + 1
    limit_up = len(rows)
    continuation = sum(value >= 2 for value in consecutive)
    max_board = max(consecutive, default=1)
    largest_topic = max(topic_counts.values(), default=0)
    if largest_topic <= 0:
        raise ValueError(f"ths topic coverage missing for {target_date}")
    return {
        "date": target_date,
        "limitup_count": limit_up,
        "continuation_count": continuation,
        "first_board_share": round((limit_up - continuation) / limit_up, 6),
        "max_board": max_board,
        "largest_direction_share": round(largest_topic / limit_up, 6),
        "source_name": "同花顺涨停揭秘",
        "source_url": source_url,
        "sha256": source_sha256,
    }


def fetch_ths_baseline(day: str) -> dict[str, Any]:
    THS_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    compact = day.replace("-", "")
    url = "https://data.10jqka.com.cn/dataapi/limit_up/limit_up_pool"
    params = {
        "page": 1,
        "limit": 200,
        "field": "199112,10,9001,330323,330324,330325,9002,330329,133971,133970,1968584,3475914,9003,9004",
        "filter": "HS,GEM2STAR",
        "order_field": "330324",
        "order_type": "0",
        "date": compact,
    }
    response = requests.get(url, params=params, headers={"User-Agent": "Mozilla/5.0"}, timeout=20)
    response.raise_for_status()
    payload = response.json()
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    rows = data.get("info") if isinstance(data.get("info"), list) else []
    page = data.get("page") if isinstance(data.get("page"), dict) else {}
    if int(payload.get("status_code", -1)) != 0 or int(page.get("total") or 0) != len(rows) or not rows:
        raise ValueError(f"incomplete ths pool for {day}")
    raw_path = THS_CACHE_DIR / f"{day}.raw.json"
    raw_path.write_bytes(response.content)
    digest = sha256_bytes(response.content)
    if sha256_bytes(raw_path.read_bytes()) != digest:
        raise RuntimeError(f"ths raw readback mismatch for {day}")
    record = baseline_record_from_ths_pool(rows, day, response.url, digest)
    cache = THS_CACHE_DIR / f"{day}.json"
    write_verified_json(cache, {"baseline_record": record, "raw_path": str(raw_path), "row_count": len(rows)})
    return record


def validate_baseline_records(records: list[dict[str, Any]], required_count: int = 60) -> dict[str, Any]:
    dates = [str(item.get("date") or "") for item in records if isinstance(item, dict)]
    complete = len(records) == required_count and len(set(dates)) == required_count
    return {
        "status": "VERIFIED" if complete else "BLOCKED",
        "sample_count": len(records),
        "required_count": required_count,
        "unique_date_count": len(set(dates)),
        "blocks": [] if complete else [f"HISTORICAL_BASELINE_INCOMPLETE:{len(records)}/{required_count}"],
    }


def collect_historical_baseline(target_date: str, required_count: int = 60) -> dict[str, Any]:
    dates = trade_dates_before(target_date, required_count)
    THS_CACHE_DIR.mkdir(parents=True, exist_ok=True)

    def collect(day: str) -> dict[str, Any]:
        cache = THS_CACHE_DIR / f"{day}.json"
        try:
            if cache.is_file():
                snapshot = read_json(cache)
                if isinstance(snapshot.get("baseline_record"), dict):
                    record = snapshot["baseline_record"]
                    raw_path = Path(str(snapshot.get("raw_path") or ""))
                    if raw_path.is_file() and sha256_bytes(raw_path.read_bytes()) == record.get("sha256"):
                        return record
            record = fetch_ths_baseline(day)
            time.sleep(1)
            return record
        except Exception:
            raise

    records: list[dict[str, Any]] = []
    errors: list[str] = []
    with ThreadPoolExecutor(max_workers=1) as pool:
        futures = {pool.submit(collect, day): day for day in dates}
        for future in as_completed(futures):
            day = futures[future]
            try:
                records.append(future.result())
            except Exception as exc:
                errors.append(f"{day}:{type(exc).__name__}:{exc}")
    records.sort(key=lambda item: item["date"])
    validation = validate_baseline_records(records, required_count)
    if errors:
        validation["status"] = "BLOCKED"
        validation["blocks"].extend(errors)
    return {
        "schema": "LIMIT_UP_HISTORICAL_BASELINE_V1",
        **validation,
        "target_date": target_date,
        "records": records,
        "collected_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }


def build_catalyst_bundle(
    snapshot: dict[str, Any],
    official_codes: set[str],
    target_date: str,
    official_rows: dict[str, dict[str, str]] | None = None,
) -> dict[str, Any]:
    page = snapshot.get("sources", {}).get("page", {})
    items = []
    seen: set[str] = set()
    for raw in (snapshot.get("page_details") or {}).get("stock_items") or []:
        if not isinstance(raw, dict):
            continue
        code = code6(raw.get("code"))
        reason = str(raw.get("reason") or "").strip()
        if code not in official_codes or code in seen or not reason:
            continue
        seen.add(code)
        items.append({
            "code": code,
            "name": str(raw.get("name") or "").strip(),
            "theme": str(raw.get("theme") or "").strip(),
            "reason": reason,
            "data_time": target_date,
            "source_name": snapshot.get("source_name") or "连板网",
            "source_url": page.get("url"),
            "source_sha256": page.get("sha256"),
            "fact_level": "公开复盘线索，因果结论仍需原始公告复核",
        })
    fallback_rows = official_rows or {}
    for code in sorted(official_codes - seen):
        row = fallback_rows.get(code, {})
        if not row:
            continue
        items.append({
            "code": code,
            "name": str(row.get("名称") or "").strip(),
            "theme": str(row.get("投资板块") or "").strip(),
            "reason": "当日未发现独立事件催化；仅保留已核验题材事实，不作因果判断",
            "data_time": target_date,
            "source_name": "东方财富核心题材",
            "source_url": "https://emweb.securities.eastmoney.com/PC_HSF10/CoreConception/PageAjax",
            "source_sha256": str(row.get("题材证据") or ""),
            "fact_level": "已核验无独立催化结论",
        })
        seen.add(code)
    missing = sorted(official_codes - seen)
    verified = (
        str(snapshot.get("target_date") or "") == target_date
        and int(page.get("status_code") or 0) == 200
        and bool(page.get("sha256"))
        and not missing
    )
    return {
        "schema": "LIMIT_UP_CATALYST_BUNDLE_V1",
        "status": "VERIFIED" if verified else "BLOCKED",
        "date": target_date,
        "official_count": len(official_codes),
        "covered_count": len(seen),
        "coverage_ratio": len(seen) / len(official_codes) if official_codes else 0,
        "items": items,
        "blocks": [] if verified else [f"CATALYST_COVERAGE_INCOMPLETE:{len(seen)}/{len(official_codes)}", *missing],
    }


def tdx_day_path(code: str) -> Path:
    market = "bj" if code.startswith(("43", "83", "87", "88", "92")) else "sz" if code.startswith(("0", "1", "2", "3")) else "sh"
    return TDX_ROOT / "vipdoc" / market / "lday" / f"{market}{code}.day"


def read_technical_snapshot(path: Path, target_date: str) -> dict[str, Any]:
    raw = path.read_bytes()
    if len(raw) % DAY.size:
        raise ValueError("partial_day_record")
    records = [record for record in DAY.iter_unpack(raw) if record[0] <= int(target_date)]
    if not records or records[-1][0] != int(target_date):
        return {"status": "BLOCKED", "reason": "target_date_record_missing"}
    closes = [record[4] / 100 for record in records]
    volumes = [int(record[6]) for record in records]
    current = closes[-1]
    average = lambda values: round(sum(values) / len(values), 4) if values else None
    return {
        "status": "VERIFIED",
        "history_count": len(records),
        "close": current,
        "return_5d": round(current / closes[-6] - 1, 6) if len(closes) >= 6 else None,
        "return_20d": round(current / closes[-21] - 1, 6) if len(closes) >= 21 else None,
        "ma20": average(closes[-20:]),
        "ma60": average(closes[-60:]),
        "volume_ratio_5d": round(volumes[-1] / average(volumes[-5:-1]), 4) if len(volumes) >= 5 and average(volumes[-5:-1]) else None,
        "source_path": str(path),
        "source_sha256": sha256_bytes(raw),
    }


def collect_technical_coverage(official_codes: set[str], target_date: str) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    blocks: list[str] = []
    for code in sorted(official_codes):
        path = tdx_day_path(code)
        try:
            row = read_technical_snapshot(path, target_date.replace("-", ""))
        except Exception as exc:
            row = {"status": "BLOCKED", "reason": f"{type(exc).__name__}:{exc}"}
        row["code"] = code
        rows.append(row)
        if row.get("status") != "VERIFIED":
            blocks.append(f"TECHNICAL_COVERAGE_FAILED:{code}:{row.get('reason')}")
    return {
        "schema": "LIMIT_UP_TECHNICAL_COVERAGE_V1",
        "status": "VERIFIED" if official_codes and not blocks else "BLOCKED",
        "date": target_date,
        "official_count": len(official_codes),
        "covered_count": sum(row.get("status") == "VERIFIED" for row in rows),
        "coverage_ratio": sum(row.get("status") == "VERIFIED" for row in rows) / len(official_codes) if official_codes else 0,
        "rows": rows,
        "blocks": blocks,
    }


def main() -> int:
    candidates = [LIANBAN_PATH]
    candidates.extend(
        (HOME / "skills" / "limit-up-review" / "reports" / "executions" / "runs").glob("*/lianban-daily.json")
    )
    lianban_path = select_verified_lianban_snapshot(candidates, TARGET_DATE)
    if not TABLE.is_file() or lianban_path is None or not TARGET_DATE:
        print(json.dumps({"status": "BLOCKED", "blocks": ["ANALYSIS_INPUT_PREREQUISITES_MISSING"]}, ensure_ascii=False))
        return 2
    with TABLE.open("r", encoding="utf-8-sig", newline="") as handle:
        official_rows = {code6(row.get("代码")): row for row in csv.DictReader(handle)}
    official_codes = set(official_rows)
    snapshot = read_json(lianban_path)
    baseline = collect_historical_baseline(TARGET_DATE, 60)
    catalyst = build_catalyst_bundle(snapshot, official_codes, TARGET_DATE, official_rows)
    technical = collect_technical_coverage(official_codes, TARGET_DATE)
    write_verified_json(BASELINE_PATH, baseline)
    write_verified_json(CATALYST_PATH, catalyst)
    write_verified_json(TECHNICAL_PATH, technical)
    blocks = [
        *baseline.get("blocks", []),
        *catalyst.get("blocks", []),
        *technical.get("blocks", []),
    ]
    result = {
        "status": "CLEAN_PASS" if not blocks else "BLOCKED",
        "baseline": str(BASELINE_PATH),
        "catalyst": str(CATALYST_PATH),
        "technical": str(TECHNICAL_PATH),
        "blocks": blocks,
    }
    print(json.dumps(result, ensure_ascii=False))
    return 0 if not blocks else 2


if __name__ == "__main__":
    raise SystemExit(main())
