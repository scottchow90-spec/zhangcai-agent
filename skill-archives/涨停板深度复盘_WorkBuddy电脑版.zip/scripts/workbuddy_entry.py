#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
LOCAL = ROOT / ".local"
CONFIG = LOCAL / "config.json"
REQUIRED_FILES = (
    "entry_limit_up_review.py", "collect_limitup_data_strict.py",
    "prepare_analysis_inputs.py", "fetch_push2_fund_flow_strict.py",
    "generate_limit_up_review_strict.py", "limit_up_review_workflow_contract.py",
    "limit_up_review_final_gate.py", "lianban_daily_client.py",
)


def emit(payload: dict[str, Any]) -> int:
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload.get("status") in {"PASS", "READY", "CONFIGURED", "CLEAN_PASS", "AUTHORIZED"} else 2


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_module(filename: str, name: str):
    path = SCRIPTS / filename
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"module_load_failed:{filename}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def valid_tdx_root(path: Path) -> bool:
    return path.is_dir() and (path / "vipdoc" / "sh" / "lday" / "sh000001.day").is_file()


def discover_tdx(explicit: str | None = None) -> list[Path]:
    values: list[Path] = []
    if explicit:
        values.append(Path(os.path.expandvars(explicit)).expanduser())
    if os.environ.get("TDX_ROOT"):
        values.append(Path(os.path.expandvars(os.environ["TDX_ROOT"])).expanduser())
    for drive in "CDEFGHIJKLMNOPQRSTUVWXYZ":
        values.extend(Path(f"{drive}:/{name}") for name in ("TDX", "通达信", "通达信金融终端"))
    unique: dict[str, Path] = {}
    for value in values:
        try:
            resolved = value.resolve()
        except OSError:
            continue
        if valid_tdx_root(resolved):
            unique.setdefault(os.path.normcase(str(resolved)), resolved)
    return list(unique.values())


def read_config(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    return value if isinstance(value, dict) else {}


def resolve_tdx(explicit: str | None, config_path: Path) -> Path:
    configured = read_config(config_path).get("tdx_root")
    candidates = discover_tdx(explicit or configured)
    if len(candidates) != 1:
        raise RuntimeError(f"tdx_root_not_unique:{len(candidates)}")
    return candidates[0]


def runtime_env(tdx: Path, lianban: Path | None = None) -> dict[str, str]:
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    env["WORKBUDDY_LIMITUP_HOME"] = str(LOCAL / "runtime")
    env["WORKBUDDY_LIMITUP_DELIVERY"] = str(LOCAL / "delivery")
    env["LIMITUP_TDX_ROOT"] = str(tdx)
    env["TDX_ROOT"] = str(tdx)
    if lianban is not None:
        env["CODEX_LIANBAN_SNAPSHOT"] = str(lianban)
    return env


def command_info() -> int:
    return emit({
        "schema": "WORKBUDDY_LIMIT_UP_REVIEW_INFO_V1", "status": "PASS",
        "skill_id": "limit-up-review", "display_name": "涨停板深度复盘（电脑版）",
        "entry": str(Path(__file__).resolve()),
        "sources": ["东方财富公开接口", "新浪日度资金流备用源", "同花顺涨停揭秘", "连板网公开页和开放数据", "AkShare公开数据适配", "本地通达信日线"],
    })


def command_configure(tdx_root: str | None, config_path: Path) -> int:
    candidates = discover_tdx(tdx_root)
    if len(candidates) != 1:
        return emit({"status": "BLOCKED", "errors": [f"tdx_root_not_unique:{len(candidates)}"], "candidates": [str(x) for x in candidates]})
    config_path.parent.mkdir(parents=True, exist_ok=True)
    data = {"schema": "WORKBUDDY_LIMIT_UP_REVIEW_CONFIG_V1", "tdx_root": str(candidates[0]), "read_only": True}
    config_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return emit({"status": "CONFIGURED", "config": str(config_path), "tdx_root": str(candidates[0])})


def command_selftest(config_path: Path) -> int:
    errors: list[str] = []
    for name in REQUIRED_FILES:
        if not (SCRIPTS / name).is_file():
            errors.append(f"missing:{name}")
    parsed = 0
    for path in ROOT.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        try:
            ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
            parsed += 1
        except Exception as exc:
            errors.append(f"syntax:{path.relative_to(ROOT)}:{exc}")
    for package in ("akshare", "pandas", "requests", "docx"):
        try:
            __import__(package)
        except ImportError:
            errors.append(f"dependency_missing:{package}")
    try:
        tdx = resolve_tdx(None, config_path)
    except Exception as exc:
        errors.append(str(exc))
        tdx = None
    try:
        contract = load_module("limit_up_review_workflow_contract.py", "wb_limitup_contract").validate(ROOT)
        if contract.get("status") != "CLEAN_PASS":
            errors.extend(f"contract:{x}" for x in contract.get("blocks", []))
    except Exception as exc:
        errors.append(f"contract:{type(exc).__name__}:{exc}")
    return emit({"schema": "WORKBUDDY_LIMIT_UP_REVIEW_SELFTEST_V1", "status": "READY" if not errors else "BLOCKED", "python": sys.version.split()[0], "python_files_parsed": parsed, "tdx_root": str(tdx) if tdx else None, "errors": errors})


def collect_lianban(target_date: str, output: Path, env: dict[str, str]) -> Path:
    output.parent.mkdir(parents=True, exist_ok=True)
    child = subprocess.run([sys.executable, str(SCRIPTS / "lianban_daily_client.py"), "--date", target_date, "--output", str(output)], cwd=ROOT, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
    if child.returncode or not output.is_file():
        raise RuntimeError(f"lianban_collection_failed:{child.returncode}:{child.stderr[-500:]}")
    payload = json.loads(output.read_text(encoding="utf-8-sig"))
    page = payload.get("sources", {}).get("page", {})
    if payload.get("target_date") != target_date or int(page.get("status_code") or 0) != 200 or not page.get("sha256"):
        raise RuntimeError("lianban_snapshot_not_verified")
    return output


def target_date() -> str:
    gate = load_module("entry_limit_up_review.py", "wb_limitup_date_gate").evaluate_date_gate("", "latest")
    if gate.get("status") != "CLEAN_PASS":
        raise RuntimeError("date_gate_failed:" + json.dumps(gate.get("blocks", []), ensure_ascii=False))
    return str(gate["target_date"])


def command_sources(output: Path, config_path: Path, tdx_root: str | None) -> int:
    try:
        tdx = resolve_tdx(tdx_root, config_path)
        date = target_date()
        env = runtime_env(tdx)
        snapshot = collect_lianban(date, output.resolve() / "lianban-daily.json", env)
        os.environ.update(env)
        os.environ["LIMITUP_DATE"] = date.replace("-", "")
        os.environ["LIMITUP_DATE_H"] = date
        collector = load_module("collect_limitup_data_strict.py", "wb_limitup_source_probe")
        baseline = load_module("prepare_analysis_inputs.py", "wb_limitup_baseline_probe").fetch_ths_baseline(date)
        official, codes = collector.fetch_official_source_snapshot()
        status = "CLEAN_PASS" if codes and official.get("request_date") == date.replace("-", "") and baseline.get("date") == date else "BLOCKED"
        return emit({"schema": "WORKBUDDY_LIMIT_UP_REVIEW_SOURCES_V1", "status": status, "trading_date": date, "official_pool_rows": len(codes), "official_pool_sha256": official.get("response_body_sha256"), "lianban_snapshot": str(snapshot), "ths_baseline_sha256": baseline.get("sha256"), "tdx_root": str(tdx)})
    except Exception as exc:
        return emit({"schema": "WORKBUDDY_LIMIT_UP_REVIEW_SOURCES_V1", "status": "BLOCKED", "errors": [f"{type(exc).__name__}:{exc}"]})


def command_run(output: Path, config_path: Path, tdx_root: str | None) -> int:
    try:
        tdx = resolve_tdx(tdx_root, config_path)
        run_dir = output.resolve()
        date = target_date()
        env = runtime_env(tdx)
        lianban = collect_lianban(date, run_dir / "source" / "lianban-daily.json", env)
        os.environ.update(runtime_env(tdx, lianban))
        engine = load_module("entry_limit_up_review.py", "wb_limitup_engine")
        result = engine.full_run("", tdx, out_dir=run_dir, delivery_root=str(run_dir / "delivery"), mode="latest")
        result_path = run_dir / "workbuddy-result.json"
        result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        if result.get("status") != "CLEAN_PASS":
            return emit({"schema": "WORKBUDDY_LIMIT_UP_REVIEW_RUN_V1", "status": "BLOCKED", "result": str(result_path), "errors": result.get("blocks", [])})
        files = [path for path in run_dir.rglob("*") if path.is_file() and path.name != "receipt.json"]
        receipt = {"schema": "WORKBUDDY_LIMIT_UP_REVIEW_RECEIPT_V1", "status": "CLEAN_PASS", "created_at": datetime.now().astimezone().isoformat(timespec="seconds"), "trading_date": date, "tdx_root": str(tdx), "result": str(result_path), "files": [{"path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)} for path in sorted(files)]}
        receipt_path = run_dir / "receipt.json"
        receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return emit({"schema": "WORKBUDDY_LIMIT_UP_REVIEW_RUN_V1", "status": "CLEAN_PASS", "trading_date": date, "result": str(result_path), "receipt": str(receipt_path), "report": result.get("report"), "docx": result.get("docx"), "table": result.get("table")})
    except Exception as exc:
        return emit({"schema": "WORKBUDDY_LIMIT_UP_REVIEW_RUN_V1", "status": "BLOCKED", "errors": [f"{type(exc).__name__}:{exc}"]})


def command_authorize(receipt_path: Path) -> int:
    errors: list[str] = []
    try:
        receipt = json.loads(receipt_path.resolve().read_text(encoding="utf-8-sig"))
        if receipt.get("schema") != "WORKBUDDY_LIMIT_UP_REVIEW_RECEIPT_V1" or receipt.get("status") != "CLEAN_PASS":
            errors.append("receipt_status_invalid")
        for item in receipt.get("files", []):
            path = Path(item["path"]).resolve()
            if not path.is_file() or path.stat().st_size != item["bytes"] or sha256(path) != item["sha256"]:
                errors.append(f"artifact_changed:{path.name}")
        result = json.loads(Path(receipt["result"]).read_text(encoding="utf-8-sig"))
        if result.get("status") != "CLEAN_PASS" or result.get("blocks"):
            errors.append("business_result_not_complete")
    except Exception as exc:
        errors.append(f"{type(exc).__name__}:{exc}")
    return emit({"schema": "WORKBUDDY_LIMIT_UP_REVIEW_AUTHORIZATION_V1", "status": "AUTHORIZED" if not errors else "BLOCKED", "receipt": str(receipt_path.resolve()), "errors": errors})


def main() -> int:
    parser = argparse.ArgumentParser(description="涨停板深度复盘 WorkBuddy 电脑版入口")
    parser.add_argument("--config", type=Path, default=CONFIG)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("info")
    configure = sub.add_parser("configure"); configure.add_argument("--tdx-root")
    sub.add_parser("selftest")
    sources = sub.add_parser("sources"); sources.add_argument("--output", type=Path, default=LOCAL / "source-check"); sources.add_argument("--tdx-root")
    run = sub.add_parser("run"); run.add_argument("--output", type=Path, default=LOCAL / "runs" / datetime.now().strftime("%Y%m%d-%H%M%S")); run.add_argument("--tdx-root")
    authorize = sub.add_parser("authorize"); authorize.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "info": return command_info()
    if args.command == "configure": return command_configure(args.tdx_root, args.config)
    if args.command == "selftest": return command_selftest(args.config)
    if args.command == "sources": return command_sources(args.output, args.config, args.tdx_root)
    if args.command == "run": return command_run(args.output, args.config, args.tdx_root)
    return command_authorize(args.receipt)


if __name__ == "__main__":
    raise SystemExit(main())
