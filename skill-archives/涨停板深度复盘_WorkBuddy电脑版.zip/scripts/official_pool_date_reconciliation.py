#!/usr/bin/env python3
from __future__ import annotations
# ONESTOCK_EMBEDDED_LOCAL_IMPORT_BOOTSTRAP
import sys as _onestock_embedded_sys
from pathlib import Path as _OneStockEmbeddedPath
_onestock_embedded_dir = str(_OneStockEmbeddedPath(__file__).resolve().parent)
if _onestock_embedded_dir not in _onestock_embedded_sys.path:
    _onestock_embedded_sys.path.insert(0, _onestock_embedded_dir)

import hashlib
import struct
from pathlib import Path
from typing import Any


MIN_INDEPENDENT_OVERLAP = 0.95
DAY = struct.Struct("<IIIIIfII")


def normalize_date(value: Any) -> str:
    return str(value or "").replace("-", "")


def _day_path(root: Path, code: str) -> Path:
    market = "bj" if code.startswith(("43", "83", "87", "88", "92")) else "sz" if code.startswith(("0", "1", "2", "3")) else "sh"
    return root / "vipdoc" / market / "lday" / f"{market}{code}.day"


def build_tdx_daily_price_proof(
    tdx_root: Path, expected_date: str, official_prices_cents: dict[str, int]
) -> dict[str, Any]:
    target = int(normalize_date(expected_date))
    rows: list[dict[str, Any]] = []
    for code, official_close in sorted(official_prices_cents.items()):
        path = _day_path(tdx_root, code)
        row: dict[str, Any] = {"code": code, "path": str(path), "official_close_cents": official_close, "matched": False}
        try:
            raw = path.read_bytes()
            if len(raw) % DAY.size:
                raise ValueError("partial_day_record")
            matches = [record for record in DAY.iter_unpack(raw) if record[0] == target]
            row.update(file_sha256=hashlib.sha256(raw).hexdigest(), target_record_count=len(matches))
            if len(matches) == 1:
                row.update(record_date=matches[0][0], local_close_cents=matches[0][4])
                row["matched"] = official_close > 0 and matches[0][4] == official_close
        except (OSError, ValueError, struct.error) as exc:
            row["error"] = f"{type(exc).__name__}:{exc}"
        rows.append(row)
    return {
        "status": "CLEAN_PASS" if rows and all(row["matched"] for row in rows) else "BLOCKED",
        "basis": "exact_dated_local_day_close_for_every_official_code",
        "tdx_root": str(tdx_root),
        "target_date": normalize_date(expected_date),
        "source_count": len(official_prices_cents),
        "matched_count": sum(row["matched"] for row in rows),
        "rows": rows,
    }


def is_verified_tdx_daily_price_proof(payload: dict[str, Any], expected_date: str) -> bool:
    verification = payload.get("date_verification") or {}
    proof = verification.get("tdx_daily_price_proof") or {}
    prices = payload.get("source_prices_cents")
    source_codes = set(payload.get("source_codes") or [])
    if (
        not isinstance(prices, dict)
        or not source_codes
        or set(prices) != source_codes
        or proof.get("status") != "CLEAN_PASS"
        or normalize_date(proof.get("target_date")) != normalize_date(expected_date)
        or not proof.get("tdx_root")
    ):
        return False
    try:
        rebuilt = build_tdx_daily_price_proof(Path(proof["tdx_root"]), expected_date, prices)
    except (TypeError, ValueError):
        return False
    return rebuilt == proof and rebuilt["status"] == "CLEAN_PASS"


def is_cross_validated_official_pool_date(
    payload: dict[str, Any],
    expected_date: str,
) -> bool:
    if not isinstance(payload, dict):
        return False
    expected = normalize_date(expected_date)
    requested = normalize_date(payload.get("request_date"))
    reported = normalize_date(payload.get("qdate"))
    verification = payload.get("date_verification")
    if not isinstance(verification, dict):
        return False
    try:
        declared_minimum = float(
            verification.get("minimum_independent_overlap")
        )
        tdx_overlap = float(verification.get("tdx_overlap_ratio"))
        lianban_overlap = float(verification.get("lianban_overlap_ratio"))
    except (TypeError, ValueError):
        return False
    minimum = max(MIN_INDEPENDENT_OVERLAP, declared_minimum)
    drift_warning = f"OFFICIAL_SOURCE_QDATE_METADATA_DRIFT:{reported}!={requested}"
    tdx_verified = (
        verification.get("tdx_same_date") is True and tdx_overlap >= minimum
    ) or is_verified_tdx_daily_price_proof(payload, expected)
    return all(
        (
            payload.get("status") == "CLEAN_PASS",
            payload.get("date_metadata_status") == "CROSS_VALIDATED_DEGRADED",
            not payload.get("blocks"),
            bool(expected),
            requested == expected,
            bool(reported),
            reported != expected,
            normalize_date(verification.get("requested_date")) == expected,
            normalize_date(verification.get("reported_qdate")) == reported,
            verification.get("akshare_exact_set_match") is True,
            tdx_verified,
            verification.get("lianban_same_date") is True,
            verification.get("lianban_count_matches") is True,
            lianban_overlap >= minimum,
            drift_warning in list(payload.get("warnings") or []),
        )
    )
