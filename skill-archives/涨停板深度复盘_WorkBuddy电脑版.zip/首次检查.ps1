[CmdletBinding()]
param(
    [string]$PythonPath = '',
    [string]$TdxRoot = ''
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$entry = Join-Path $root 'scripts\workbuddy_entry.py'
$python = if ($PythonPath) { $PythonPath } else { (Get-Command python.exe -ErrorAction Stop).Source }
$configArgs = @('configure')
if ($TdxRoot) { $configArgs += @('--tdx-root', $TdxRoot) }

Push-Location -LiteralPath $root
try {
    & $python $entry @configArgs
    if ($LASTEXITCODE -ne 0) { throw '通达信路径配置未通过。' }
    & $python $entry 'selftest'
    if ($LASTEXITCODE -ne 0) { throw '技能自检未通过。' }
    & $python $entry 'sources' '--output' '.local/source-check'
    if ($LASTEXITCODE -ne 0) { throw '数据源与接口检查未通过。' }
    Write-Host '首次检查通过。'
}
finally {
    Pop-Location
}
