---
name: a-share-morning-intelligence-plan
agent_created: true
entry: scripts/workbuddy_entry.py
description: 在WorkBuddy电脑版生成A股交易日早盘资讯与盘前计划，强制完成跨日数据推导、行业结构分析和开盘验证框架；禁止股票推荐、买卖点和交易指令。
metadata:
  short-description: A股早盘资讯与盘前计划
  entry: scripts/workbuddy_entry.py
  display_name: A股早盘资讯与盘前计划（电脑版）
---

# A股早盘资讯与盘前计划（电脑版）

中文备注：每天盘前生成有结论、有对比、有支持条件和推翻条件的A股研究报告。

## 执行要求

1. 先运行 `python scripts/workbuddy_entry.py doctor` 检查电脑版环境和可用连接器，再运行 `verify` 校验技能包完整性。
2. 通过WorkBuddy已绑定连接器获取最近两个已闭市交易日的同口径数据。首选通达信；东方财富妙想、腾讯WeStock和大智慧用于补充或交叉核对。连接器不可用时可用WorkBuddy网页搜索/抓取公开来源，但必须保留时间与来源，禁止用模型记忆补数。
3. 最少取得指数涨跌、上涨/下跌家数、成交额、涨停/跌停、连板、最高连板、封板率、炸板、最强题材涨停数和达到3家涨停的题材数。
4. 正文必须复算并解释上涨占比、涨停增幅、封板率变化、炸板降幅、题材扩散和量价关系。六项共同形成一个市场性质结论，说明支持条件和推翻条件。
5. 行业部分必须包含 `主导方向：`、`扩散结构：`、`持续条件：`、`转弱条件：`，禁止逐行业复制套话。
6. 盘中计划按09:30-09:45、09:45-10:00、10:00-10:30观察市场宽度、成交同比、行业覆盖、炸板与跌停；至少三项同向才形成阶段判断。
7. 报告生成后运行 `python scripts/workbuddy_entry.py validate --report <报告.md> --snapshot <快照.json>`。检查未通过不得交付。

## 禁止内容

- 不出现具体股票、证券代码、推荐名单、买卖点、价格、仓位或下单指令。
- 不把数据表、新闻列表或重复模板当作结论。
- 正式报告不出现内部过程词、技术状态词和原始接口清单。
- 缺少必需数据时明确停止，不使用占位词伪装完整报告。

数据源适配见 [references/workbuddy-data-sources.md](references/workbuddy-data-sources.md)，报告结构见 [references/report-standard.md](references/report-standard.md)。
