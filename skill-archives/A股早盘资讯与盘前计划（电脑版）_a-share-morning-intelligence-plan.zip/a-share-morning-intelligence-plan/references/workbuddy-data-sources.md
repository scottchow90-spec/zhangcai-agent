# WorkBuddy电脑版数据源适配

本机调查基线：WorkBuddy 5.5.3，Windows x64，技能目录 `%USERPROFILE%\\.workbuddy\\skills`，内置Python 3.13可用。

## 主备顺序

1. `tdx-connector`：优先取得上证等指数行情、日线、板块行情及通达信结构化资料。常用工具为 `tdx_quotes`、`tdx_kline`、`tdx_api_data`、`wenda_news_query`、`wenda_macro_query`。
2. `mx-ds-mcp`：东方财富妙想接口。使用 `mx_index_block_finance_data` 查询指数和板块，用 `mx_finance_search_news` 查询早间新闻，用 `mx_macro_data` 查询宏观事件。所有工具只传自然语言 `query`。
3. `westock-mcp`：腾讯股票连接器，适合市场行情和资讯的第二来源核对。
4. `dzh-mcp`：大智慧连接器，适合行情、新闻和板块数据补充核对。
5. WorkBuddy `WebSearch`/`WebFetch`：仅在连接器字段不足时补充公开新闻与市场数据。优先交易所、官方部门、财联社、东方财富、同花顺、新浪等可标注时间的来源。

## 数据一致性

- 两日数据必须采用同一字段口径、同一计量单位和完整交易日。
- 不把盘中实时值与收盘值比较，不把自然日当交易日。
- 多源冲突时，指数和K线优先通达信；新闻以原始发布机构和发布时间为准；涨停生态优先能同时返回涨停、跌停、炸板和封板率的完整来源。
- 单一来源缺字段时允许拼接，但必须在工作底稿记录字段来源；正式报告不展示内部接口清单。
- 连接器“已绑定”只代表可调用资格，每次仍须检查返回日期、字段和非空结果。

## 安全边界

技能包不包含OAuth令牌、Cookie、账户、MCP地址或请求头。连接器授权由目标电脑WorkBuddy管理。技能不启动、关闭或接管通达信，不访问证券账户，不执行交易。
