#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from typing import Any

PLACEHOLDERS = ("未提供", "待补", "暂无数据", "数据缺失")
INTERNAL_TERMS = ("返工", "纠错", "验收", "证据审计", "自动任务", "代码门禁", "回执", "CLEAN_PASS", "BLOCKED")
SOURCE_AUDIT_TERMS = ("来源冲突", "数据来源：", "原始数据源：")
REQUIRED_PREVIOUS = ("trading_date", "index_change_pct", "total_amount_billion", "advancers", "decliners", "limit_up", "limit_down", "consecutive", "max_board", "seal_rate", "broken_board", "topic_top_count", "topic_count_ge3")
REQUIRED_ROWS = ("上证日线", "成交额", "上涨/下跌", "涨停/跌停", "连板", "最高连板", "封板率", "炸板", "最强题材涨停数", "至少3家涨停的题材")
INDUSTRY_MARKERS = ("主导方向：", "扩散结构：", "持续条件：", "转弱条件：")

def derived(snapshot: dict[str, Any]) -> tuple[str, ...]:
    cur = snapshot.get("market", {}); prev = snapshot.get("comparisons", {}).get("previous_trading_day", {})
    needed = ("advancers", "decliners", "total_amount_billion", "limit_up", "seal_rate", "broken_board", "topic_count_ge3")
    if any(cur.get(k) is None for k in needed) or any(prev.get(k) is None for k in REQUIRED_PREVIOUS): return ()
    ct = cur["advancers"] + cur["decliners"]; pt = prev["advancers"] + prev["decliners"]
    if not all((ct, pt, prev["limit_up"], prev["broken_board"], prev["total_amount_billion"])): return ()
    cb = cur["advancers"] / ct * 100; pb = prev["advancers"] / pt * 100
    lu = (cur["limit_up"] / prev["limit_up"] - 1) * 100
    br = (1 - cur["broken_board"] / prev["broken_board"]) * 100
    amount = (cur["total_amount_billion"] / prev["total_amount_billion"] - 1) * 100
    direction = "下降" if amount < 0 else "上升"
    return (f"上涨占比：{pb:.1f}%升至{cb:.1f}%，增加{cb-pb:.1f}个百分点", f"涨停：{prev['limit_up']}家升至{cur['limit_up']}家，增加{lu:.1f}%", f"封板率：{prev['seal_rate']:.1f}%升至{cur['seal_rate']:.1f}%，增加{cur['seal_rate']-prev['seal_rate']:.1f}个百分点", f"炸板：{prev['broken_board']}家降至{cur['broken_board']}家，减少{br:.1f}%", f"题材扩散：达到3家涨停的题材由{prev['topic_count_ge3']}个增至{cur['topic_count_ge3']}个", f"量价关系：成交额{direction}{abs(amount):.2f}%")

def validate_report(report: str, snapshot: dict[str, Any]) -> dict[str, Any]:
    errors = []
    for token in PLACEHOLDERS:
        if token in report: errors.append("placeholder_forbidden:" + token)
    for token in INTERNAL_TERMS:
        if token in report: errors.append("internal_language_forbidden:" + token)
    for token in SOURCE_AUDIT_TERMS:
        if token in report: errors.append("source_audit_forbidden:" + token)
    if "| 含义 |" in report or "|含义|" in report: errors.append("low_information_column_forbidden")
    prev = snapshot.get("comparisons", {}).get("previous_trading_day", {})
    missing = [k for k in REQUIRED_PREVIOUS if prev.get(k) is None]
    if missing: errors.append("previous_data_missing:" + ",".join(missing))
    rows = [x for x in REQUIRED_ROWS if f"| {x} |" not in report]
    if rows: errors.append("comparison_rows_missing:" + ",".join(rows))
    required = derived(snapshot)
    if not required: errors.append("derived_analysis_uncomputable")
    elif any(x not in report for x in required): errors.append("derived_analysis_missing")
    industry = [x for x in INDUSTRY_MARKERS if x not in report]
    if industry: errors.append("industry_reasoning_missing:" + ",".join(industry))
    return {"status": "BLOCKED" if errors else "CLEAN_PASS", "errors": errors}

def main() -> int:
    p=argparse.ArgumentParser(); p.add_argument("--report",required=True,type=Path); p.add_argument("--snapshot",required=True,type=Path); a=p.parse_args()
    result=validate_report(a.report.read_text(encoding="utf-8-sig"),json.loads(a.snapshot.read_text(encoding="utf-8-sig")))
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0 if result["status"]=="CLEAN_PASS" else 2
if __name__=="__main__": raise SystemExit(main())
