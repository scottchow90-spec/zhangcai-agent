#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, platform, sys
from pathlib import Path
from morning_report_gate import validate_report

ROOT=Path(__file__).resolve().parents[1]
CONNECTORS=("tdx-connector","westock-mcp","mx-ds-mcp","dzh-mcp")

def digest(path: Path)->str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""): h.update(block)
    return h.hexdigest()

def verify()->int:
    manifest=json.loads((ROOT/"package-manifest.json").read_text(encoding="utf-8-sig")); errors=[]
    for row in manifest["files"]:
        path=ROOT/Path(*row["path"].split("/"))
        if not path.is_file(): errors.append("missing:"+row["path"])
        elif path.stat().st_size!=row["bytes"] or digest(path)!=row["sha256"]: errors.append("mismatch:"+row["path"])
    print(json.dumps({"status":"CLEAN_PASS" if not errors else "BLOCKED","checked":len(manifest["files"]),"errors":errors},ensure_ascii=False,indent=2)); return 0 if not errors else 2

def connector_states()->dict:
    base=Path(os.environ.get("USERPROFILE",str(Path.home())))/".workbuddy"/"connectors"
    states={name:"not_detected" for name in CONNECTORS}
    for path in base.glob("*/connector-states.json"):
        try: payload=json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception: continue
        for name in CONNECTORS:
            row=payload.get("connectors",{}).get(name,{})
            if row.get("bound") and row.get("enabled"): states[name]="bound_enabled"
    return states

def doctor()->int:
    states=connector_states(); usable=any(v=="bound_enabled" for v in states.values())
    result={"status":"READY" if usable else "DATA_CONNECTOR_REQUIRED","python":sys.version.split()[0],"platform":platform.platform(),"skill_root":str(ROOT),"connectors":states,"web_fallback":"WorkBuddy WebSearch/WebFetch","credentials_exported":False}
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0 if usable else 2

def validate(report:Path,snapshot:Path)->int:
    result=validate_report(report.read_text(encoding="utf-8-sig"),json.loads(snapshot.read_text(encoding="utf-8-sig")))
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0 if result["status"]=="CLEAN_PASS" else 2

def main()->int:
    p=argparse.ArgumentParser(); p.add_argument("action",choices=("doctor","verify","validate","info")); p.add_argument("--report",type=Path); p.add_argument("--snapshot",type=Path); a=p.parse_args()
    if a.action=="doctor": return doctor()
    if a.action=="verify": return verify()
    if a.action=="info": print(json.dumps({"name":"a-share-morning-intelligence-plan","display_name":"A股早盘资讯与盘前计划（电脑版）","entry":"scripts/workbuddy_entry.py"},ensure_ascii=False,indent=2)); return 0
    if not a.report or not a.snapshot: p.error("validate requires --report and --snapshot")
    return validate(a.report,a.snapshot)
if __name__=="__main__": raise SystemExit(main())
