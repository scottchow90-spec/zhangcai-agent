# Python依赖

- 快照分析、校验、报告：Python标准库。
- 原始盘后数据标准化/PIT特征/席位成熟研究：`pandas>=2.0`、`numpy>=1.24`。
- 只有真实Tushare下载时才需要：`tushare>=1.4.0` 与环境变量 `TUSHARE_TOKEN`。
- 技能不会调用集合竞价或分钟接口。
