# WorkBuddy 使用 V4.3

技能目录根部为 `SKILL.md`，代码、参考资料和模板分别位于 `scripts/`、`references/`、`templates/`。

```bash
python scripts/workbuddy_entry.py verify
python scripts/workbuddy_entry.py doctor
python scripts/workbuddy_entry.py selftest
python scripts/workbuddy_entry.py audit-data --data-root data_raw --require-end 2026-09-10
python scripts/workbuddy_entry.py prepare-snapshot --data-root data_raw --trade-date 2026-09-10 --as-of 2026-09-10T21:00:00+08:00 --output snapshot.json
python scripts/workbuddy_entry.py analyze --input snapshot.json --format markdown
```

注意：`prepare-snapshot` 会再次强制执行原始数据审计，不能因为已经运行过 `audit-data` 就省略内部检查。若目录中出现盘中/竞价数据目录、缺关键日线数据或截止日期不足，快照生成失败。

Markdown默认是**完整版**，包含工作流执行审计、数据覆盖、市场总闸门、全候选排序和逐股证据链。只有调用者明确要求简版时，才可以在展示层另行压缩；底层步骤不能因此跳过。

日常 `analyze` 仅依赖Python标准库；原始数据管线需要 pandas/numpy；Tushare下载器额外需要 tushare 和 `TUSHARE_TOKEN`。下载器仅提供盘后接口白名单。
