# WorkBuddy兼容性 V4.3

技能目录根部为 `SKILL.md`，其他资源位于 `references/`、`scripts/`、`templates/`。Python包、测试和数据适配器全部放在 `scripts/` 子目录。

日常 `analyze` 只依赖Python标准库；`prepare-snapshot` 的原始数据管线需要 pandas/numpy；真实Tushare下载器是可选能力。

V4.3额外保证：

- `prepare-snapshot` 不能绕过原始数据审计；
- 禁止盘中/竞价目录会直接拒绝；
- 手工快照缺 `coverage/workflow_trace` 时按降级输入处理；
- Markdown默认输出完整工作流执行痕迹和逐股证据链；
- 历史生产模型只能使用滚动样本外自动验收结果。
