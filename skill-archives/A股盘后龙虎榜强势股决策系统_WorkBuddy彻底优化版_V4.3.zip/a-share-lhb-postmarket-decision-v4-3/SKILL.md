---
name: a-share-lhb-postmarket-decision
display_name: A股盘后龙虎榜强势股决策系统
display_name_en: A-share Post-market Dragon-Tiger List Decision System
description: A股短线强势股纯盘后龙虎榜分析、历史回放、数据审计与滚动样本外研究技能。仅使用T日收盘后已公开信息；强制执行原始数据审计、物理时间截断、历史时点行业/ST/退市、120日因果市场闸门、强势阶段、行业/题材持续性、全板块地位、价格透支、龙虎榜双窗口与成熟席位、盘后事件、历史样本外验证和风险否决。禁止集合竞价、分钟线、盘中信号、未来数据、主观总分和少跑步骤后的伪完整输出。
description_zh: A股纯盘后龙虎榜强势股决策技能；默认输出完整工作流执行痕迹、数据覆盖、证据链和降级原因。
description_en: Post-market-only A-share Dragon-Tiger List decision skill with full workflow tracing, point-in-time features, mature seat history, leakage controls and walk-forward out-of-sample validation.
version: 4.3.0
author: OpenAI
---

# A股盘后龙虎榜强势股决策系统 V4.3 完整工作流锁定版

## 不可绕过的硬边界

1. **时间冻结**：只处理T日收盘后且 `<= as_of` 的已公开数据。集合竞价、分钟线、盘中确认、T+1价格/收益和未来标签一律禁止进入日常决策。
2. **完整工作流不可少跑**：固定顺序为：**原始数据审计 → 物理时间截断 → 历史时点状态 → 市场总闸门 → 硬过滤 → 强势阶段 → 行业/题材持续性 → 市场/板块地位 → 价格透支 → 龙虎榜双窗口/席位/生命周期 → 盘后事件 → 历史样本外统计 → 风险否决 → 最终证据排序**。
3. **龙虎榜只作证据**：禁止“大额净买=最高优先级”；禁止“机构专用+股通专用+营业部=聪明资金共振”；禁止知名席位名字直接加分。
4. **阶段与地位优先**：首板、2板、3板以上、趋势强势分层处理；板块核心地位从全板块股票计算，不允许人工 `market_position` 控制排序。
5. **板块必须量化确认**：行业层必跑；只有提供历史时点题材成员表时才运行题材层。题材缺失必须明确标记，禁止凭新闻标题猜“主线”。
6. **价格透支必须完整跑**：3/5/10/20日涨幅、换手、20日成交额倍数、相对前20日高点扩张、收盘位置、炸板弱收均参与风险判断。
7. **龙虎榜窗口不能混算**：单日榜与三日榜分别保留；三日金额必须匹配三日成交额；同股同日重复原因不重复累计。
8. **席位质量必须成熟**：只有已完整走完后续10个交易日且历史样本数不少于20的席位统计，才允许参与同层级细排；不能越过阶段/地位/板块。
9. **盘后事件不得成为故事加分器**：正面催化只做事实说明；中高风险事件必须实际降级；重大风险/概念证伪可硬否决。
10. **历史模型不能手工放行**：必须使用动态滚动样本外验证；最近观察区不参与验收；生产资格由程序按样本量、基准覆盖、Bootstrap超额下界和年度稳定性自动计算。
11. **缺数据必须降级**：缺120日市场因果特征、历史行业、盘后事件、题材或覆盖元数据时，必须在结果中显式显示，并限制候选等级；禁止静默少跑。
12. **默认完整输出**：除非用户明确要求精简，Markdown必须显示工作流执行表、数据覆盖、市场闸门、全候选表和逐股完整证据链，不得用“简化输出”掩盖未执行步骤。

详细数据纪律见 @references/data-contract.md；历史验证见 @references/research-validation.md；V4.3防回归/防偷工减料审计见 @references/deep-audit-merge-report.md。

## 标准生产命令

### 从原始盘后数据生成快照

`prepare-snapshot` **内部会先强制运行数据审计**，不能通过少跑 `audit-data` 绕过。单独的 `audit-data` 只用于提前检查。

`build_snapshot()` 被程序直接调用时只生成 **unverified** 快照；只有 `prepare-snapshot` 完成全量审计后才标记为 **audited**。未审计快照即使字段齐全，也会被强制降级，不能冒充完整生产结果。

```bash
python scripts/workbuddy_entry.py audit-data --data-root data_raw --require-end 2026-09-10
python scripts/workbuddy_entry.py prepare-snapshot \
  --data-root data_raw \
  --trade-date 2026-09-10 \
  --as-of 2026-09-10T21:00:00+08:00 \
  --output snapshot.json
python scripts/workbuddy_entry.py analyze --input snapshot.json --format markdown
```

### 已有快照

```bash
python scripts/workbuddy_entry.py analyze --input snapshot.json --format markdown
```

没有完整 `coverage/workflow_trace` 的手工快照会被识别为降级输入，候选等级受到限制，不允许伪装成完整生产链路。

## 历史研究

```bash
python scripts/build_history_model.py \
  --events labeled_events.csv \
  --cutoff 2026-09-10 \
  --output history_model.json
```

模型采用动态滚动样本外验证：最早阶段仅开发，之后逐年向前验证；`cutoff` 前最近90天为独立观察区，不进入生产验收和概率桶。生产资格没有手工开关。

## 安装/验收

```bash
python scripts/workbuddy_entry.py verify
python scripts/workbuddy_entry.py doctor
python scripts/workbuddy_entry.py selftest
```

`selftest` 同时覆盖早期错误回归、工作流完整性、盘后工程模块与样本外研究约束。测试通过只证明代码约束按设计运行，不代表未来收益已被证明。
