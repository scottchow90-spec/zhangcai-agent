from __future__ import annotations
from pathlib import Path
import os, time
import pandas as pd

class TushareUnavailable(RuntimeError): pass

class TusharePostMarketAdapter:
    """仅下载盘后数据。严禁集合竞价和分钟线端点。"""
    INDEX_CODES=('000001.SH','399001.SZ','000300.SH','000905.SH','000852.SH','932000.CSI','399006.SZ','000688.SH')
    CORE_APIS=('daily','daily_basic','adj_factor','bak_basic','stock_st','stk_limit','top_list','top_inst')

    def __init__(self, token=None, out_dir='data_raw', sleep=.13, retries=3):
        self.token = token or os.getenv('TUSHARE_TOKEN')
        if not self.token: raise TushareUnavailable('缺少TUSHARE_TOKEN；禁止伪造真实历史数据')
        try: import tushare as ts
        except Exception as e: raise TushareUnavailable('未安装tushare；原始数据下载功能不可用') from e
        self.ts=ts; ts.set_token(self.token); self.pro=ts.pro_api(); self.out=Path(out_dir); self.out.mkdir(parents=True,exist_ok=True)
        self.sleep=float(sleep); self.retries=max(1,int(retries))

    def _call(self, fn, **kw):
        last=None
        for n in range(self.retries):
            try: return fn(**kw)
            except Exception as ex:
                last=ex
                if n+1<self.retries: time.sleep(self.sleep*(2**n))
        raise last

    def _atomic_csv(self,p,df):
        p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); tmp=p.with_suffix(p.suffix+'.tmp')
        pd.DataFrame() if df is None else df
        (pd.DataFrame() if df is None else df).to_csv(tmp,index=False,encoding='utf-8-sig'); tmp.replace(p); return p

    def _save(self,name,df): return self._atomic_csv(self.out/f'{name}.csv',df)

    def trade_calendar(self,start='20180101',end='20261231'):
        return self._save('trade_cal', self._call(self.pro.trade_cal,exchange='',start_date=start,end_date=end,is_open='1'))

    def stock_basic_all(self):
        fs=[]
        for status in ['L','D','P']:
            z=self._call(self.pro.stock_basic,exchange='',list_status=status,fields='ts_code,symbol,name,area,industry,market,exchange,list_status,list_date,delist_date')
            if z is not None and len(z): fs.append(z)
        if not fs: raise TushareUnavailable('stock_basic无法获取')
        return self._save('stock_basic',pd.concat(fs,ignore_index=True).drop_duplicates('ts_code'))

    def industry_members(self):
        classes=[]
        for src in ['SW2014','SW2021']:
            z=self._call(self.pro.index_classify,level='L1',src=src)
            if z is not None and len(z):
                z=z.copy(); z['classification_version']=src; classes.append(z)
        if not classes: raise TushareUnavailable('申万一级行业分类无法获取')
        cls=pd.concat(classes,ignore_index=True).drop_duplicates(); self._save('sw_classify',cls)
        fs=[]
        for code in sorted(cls['index_code'].dropna().astype(str).unique()):
            for flag in ['Y','N']:
                z=self._call(self.pro.index_member_all,l1_code=code,is_new=flag); z=pd.DataFrame() if z is None else z
                if len(z)>=2000: raise TushareUnavailable(f'申万成分分片疑似截断:{code}:{flag}')
                if len(z): fs.append(z)
                time.sleep(self.sleep)
        if not fs: raise TushareUnavailable('申万历史成分无法获取')
        return self._save('sw_members',pd.concat(fs,ignore_index=True).drop_duplicates())

    def by_trade_date(self,api_name,dates):
        if api_name not in self.CORE_APIS: raise ValueError(f'非盘后白名单API: {api_name}')
        out=self.out/api_name; out.mkdir(exist_ok=True); api=getattr(self.pro,api_name)
        for dt in dates:
            p=out/f'{dt}.csv'
            if p.exists() and p.stat().st_size>0: continue
            df=self._call(api,trade_date=dt); self._atomic_csv(p,pd.DataFrame() if df is None else df); time.sleep(self.sleep)
        return out

    def index_daily(self,start,end):
        out=self.out/'index_daily'; out.mkdir(exist_ok=True)
        for code in self.INDEX_CODES:
            p=out/f"{code.replace('.','_')}.csv"
            if not (p.exists() and p.stat().st_size>0): self._atomic_csv(p,self._call(self.pro.index_daily,ts_code=code,start_date=start,end_date=end))
            time.sleep(self.sleep)
        return out

    def download_core(self,start='20180101',end='20261231'):
        cal=self._call(self.pro.trade_cal,exchange='',start_date=start,end_date=end,is_open='1')
        dates=sorted(cal['cal_date'].astype(str).tolist())
        self._save('trade_cal',cal); self.stock_basic_all(); self.industry_members(); self.index_daily(start,end)
        for api in self.CORE_APIS: self.by_trade_date(api,dates)
        return self.out
