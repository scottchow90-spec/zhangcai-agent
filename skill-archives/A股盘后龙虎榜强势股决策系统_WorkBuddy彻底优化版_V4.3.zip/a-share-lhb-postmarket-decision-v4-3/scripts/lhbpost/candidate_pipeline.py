from __future__ import annotations
import numpy as np
import pandas as pd
from .features import build_stock_daily_features,map_industry_point_in_time,build_sector_daily_features,aggregate_lhb,assign_lifecycle
from .market_features import build_market_features
from .schema import CandidateFeatures
from .seat_quality import build_mature_seat_quality, attach_event_seat_quality


def _event_core_rank(d:pd.DataFrame, limits:pd.DataFrame|None=None)->pd.Series:
    """与最终决策一致的短线行业核心：连板高度→是否涨停→当日强度→5日强度→成交额。

    该字段主要供工程层/兼容接口使用；最终快照仍会从全市场重新计算一次，避免候选子集污染。
    """
    cols=[c for c in ['trade_date','l1_code','ts_code','ret5','amount','pct_chg','ret1','close'] if c in d]
    x=d[cols].copy();x['_orig_index']=d.index.to_numpy();x['trade_date']=pd.to_datetime(x['trade_date']).dt.normalize()
    pct_src=x['pct_chg'] if 'pct_chg' in x else (x['ret1'] if 'ret1' in x else pd.Series(0.0,index=x.index))
    ret5_src=x['ret5'] if 'ret5' in x else pd.Series(-999.0,index=x.index)
    amount_src=x['amount'] if 'amount' in x else pd.Series(0.0,index=x.index)
    x['_pct']=pd.to_numeric(pct_src,errors='coerce').fillna(0)
    x['_ret5']=pd.to_numeric(ret5_src,errors='coerce').fillna(-999)
    x['_amount']=pd.to_numeric(amount_src,errors='coerce').fillna(0)
    x['_is_lu']=False;x['_streak']=0
    if limits is not None and len(limits) and 'close' in x:
        l=limits[['trade_date','ts_code','up_limit']].copy();l['trade_date']=pd.to_datetime(l['trade_date']).dt.normalize()
        x=x.merge(l,on=['trade_date','ts_code'],how='left')
        x['_is_lu']=x['up_limit'].notna()&(pd.to_numeric(x['close'],errors='coerce')>=pd.to_numeric(x['up_limit'],errors='coerce')-1e-8)
        x=x.sort_values(['ts_code','trade_date'])
        vals=[]
        for _,g in x.groupby('ts_code',sort=False):
            cur=0
            for idx,row in g.iterrows():
                cur=cur+1 if bool(row['_is_lu']) else 0;vals.append((idx,cur))
        x['_streak']=pd.Series(dict(vals))
    x=x.sort_values(['trade_date','l1_code','_streak','_is_lu','_pct','_ret5','_amount','ts_code'],
                    ascending=[True,True,False,False,False,False,False,True])
    x['_rank']=x.groupby(['trade_date','l1_code']).cumcount()+1
    out=pd.Series(x['_rank'].to_numpy(),index=x['_orig_index'].to_numpy(),dtype=float)
    return out.reindex(d.index)


def build_candidate_feature_table(*,daily:pd.DataFrame,daily_basic:pd.DataFrame,top_list:pd.DataFrame,top_inst:pd.DataFrame,
                                  sw_members:pd.DataFrame,stock_basic:pd.DataFrame,st_status:pd.DataFrame,limits:pd.DataFrame,
                                  index_daily:pd.DataFrame|None=None,adj_factor:pd.DataFrame|None=None,
                                  historical_basic:pd.DataFrame|None=None,event_features:pd.DataFrame|None=None,
                                  recovery_confirm_days:int=2)->pd.DataFrame:
    sf=build_stock_daily_features(daily,daily_basic,adj_factor=adj_factor)
    sf=map_industry_point_in_time(sf,sw_members)
    sf['sector_core_rank']=_event_core_rank(sf,limits)
    sec=build_sector_daily_features(sf)
    trade_dates=sorted(pd.to_datetime(sf['trade_date']).dropna().unique())
    lhb=assign_lifecycle(aggregate_lhb(top_list,top_inst,daily), trade_dates=trade_dates)
    if top_inst is not None and len(top_inst):
        # 席位标签使用与个股技术特征相同的连续价格尺度，避免除权送转把3/5/10日结果污染。
        sq=build_mature_seat_quality(top_inst,sf,trade_dates=trade_dates)
        lhb=attach_event_seat_quality(lhb,top_inst,sq)
    market=build_market_features(sf,limits,index_daily,recovery_confirm_days=recovery_confirm_days)
    e=lhb.merge(sf,on=['trade_date','ts_code'],how='left',suffixes=('','_stock'))
    sec_cols=['trade_date','l1_code','sector_ret1','sector_ret5','sector_rs_5d_pctile','sector_ret1_pctile','sector_activity_pctile']
    e=e.merge(sec[sec_cols],on=['trade_date','l1_code'],how='left')
    market_cols=['trade_date','market_state','market_permission','raw_market_permission','market_data_quality','index_extreme_up','turnover_extreme']
    e=e.merge(market[market_cols],on='trade_date',how='left')

    sb=stock_basic.copy(); sb['list_date']=pd.to_datetime(sb['list_date'],errors='coerce'); sb['delist_date']=pd.to_datetime(sb.get('delist_date'),errors='coerce') if 'delist_date' in sb else pd.NaT
    e=e.merge(sb[[c for c in ['ts_code','name','exchange','market','list_date','delist_date'] if c in sb]],on='ts_code',how='left')
    # 历史名称用于输出和辅助识别退市整理/ST，避免拿今天的名称回写过去。
    if historical_basic is not None and len(historical_basic):
        hb=historical_basic.copy();hb['trade_date']=pd.to_datetime(hb['trade_date'])
        keep=[c for c in ['trade_date','ts_code','name','industry'] if c in hb]
        hb=hb[keep].drop_duplicates(['trade_date','ts_code'])
        rename={'name':'hist_name','industry':'hist_industry'};hb=hb.rename(columns=rename)
        e=e.merge(hb,on=['trade_date','ts_code'],how='left')
        if 'hist_name' in e:e['name']=e['hist_name'].fillna(e.get('name',''))

    cal=pd.DatetimeIndex(trade_dates).normalize().sort_values()
    def _list_sessions(r):
        ld=pd.Timestamp(r['list_date']).normalize() if pd.notna(r['list_date']) else pd.NaT
        td=pd.Timestamp(r['trade_date']).normalize()
        if pd.isna(ld): return 0
        if len(cal) and ld<cal[0]: return 20+int(cal.searchsorted(td,side='right'))
        return int(cal.searchsorted(td,side='right')-cal.searchsorted(ld,side='left'))
    e['list_days']=e.apply(_list_sessions,axis=1)

    st=st_status.copy(); st['trade_date']=pd.to_datetime(st['trade_date']) if len(st) else pd.to_datetime([])
    stkey=set(zip(st['trade_date'],st['ts_code'])) if len(st) else set()
    hist_names=e.get('hist_name',e.get('name',pd.Series('',index=e.index))).astype(str)
    name_st=hist_names.str.match(r'^(\*?ST|S\*ST)',na=False)
    e['is_st']=[(d,c) in stkey for d,c in zip(e['trade_date'],e['ts_code'])]
    e['is_st']=e['is_st']|name_st
    if len(st) and 'type_name' in st:
        delistkey=set(zip(st.loc[st['type_name'].astype(str).str.contains('退市',na=False),'trade_date'],st.loc[st['type_name'].astype(str).str.contains('退市',na=False),'ts_code']))
    else: delistkey=set()
    name_delist=hist_names.str.contains('退市',na=False)|hist_names.str.startswith('退')
    e['is_delisting_arrangement']=[(d,c) in delistkey for d,c in zip(e['trade_date'],e['ts_code'])]
    e['is_delisting_arrangement']=e['is_delisting_arrangement']|name_delist

    if 'reason' in top_list:
        rs=top_list.copy(); rs['trade_date']=pd.to_datetime(rs['trade_date']); reason=rs.groupby(['trade_date','ts_code'])['reason'].apply(lambda x:'|'.join(map(str,x))).rename('reason_text').reset_index(); e=e.merge(reason,on=['trade_date','ts_code'],how='left')
    else: e['reason_text']=''
    sf2=sf.sort_values(['ts_code','trade_date']).copy(); sf2['ret3']=sf2.groupby('ts_code')['signal_close' if 'signal_close' in sf2 else 'close'].pct_change(3); sf2['amount_ratio']=sf2['amount']/sf2.groupby('ts_code')['amount'].transform(lambda x:x.shift(1).rolling(20,min_periods=10).median())
    sf2['ret3p']=sf2.groupby('trade_date')['ret3'].rank(pct=True); sf2['amountp']=sf2.groupby('trade_date')['amount_ratio'].rank(pct=True)
    e=e.merge(sf2[['trade_date','ts_code','ret3p','amountp']],on=['trade_date','ts_code'],how='left')
    e['three_day_surge_high_climax']=(e['ret3p']>=.95)&(e['amountp']>=.95)&(e['close_location_day']>=.8)
    e['extreme_volume_inst_sell_weak_relay']=(e['amountp']>=.95)&(e['inst_net_buy_ratio']<0)&(e['lhb_net_buy_ratio']<=0)
    e['downward_anomaly_without_reversal']=e['reason_text'].astype(str).str.contains('跌幅|下跌',na=False)&(~e['close_above_ma20'])
    # 风险/事件模块只接受可审计、带公开时间戳的外部特征。没有数据时保持中性，绝不由语言模型临场补分。
    e['risk_penalty']=0.0; e['severe_negative_event']=False
    e['independent_catalyst']=False; e['catalyst_quality']=np.nan; e['catalyst_public_before_cutoff']=False
    e['theme_code']='__UNKNOWN_THEME__'; e['theme_verified']=False
    if event_features is not None and len(event_features):
        ev=event_features.copy()
        need={'trade_date','ts_code','public_time'}
        miss=need-set(ev.columns)
        if miss: raise ValueError('event_features缺字段:'+','.join(sorted(miss)))
        ev['trade_date']=pd.to_datetime(ev['trade_date'],errors='coerce').dt.normalize()
        ev['public_time']=pd.to_datetime(ev['public_time'],errors='coerce',utc=True)
        if ev['trade_date'].isna().any() or ev['public_time'].isna().any():
            raise ValueError('event_features存在无法解析的trade_date/public_time')
        # 兼容直接调用工程层：事件发布时间的上海交易日不得晚于其标注trade_date。
        local_day=ev['public_time'].dt.tz_convert('Asia/Shanghai').dt.tz_localize(None).dt.normalize()
        ev=ev[local_day<=ev['trade_date']].copy()
        if len(ev):
            def _agg(g):
                q=pd.to_numeric(g.get('catalyst_quality'),errors='coerce') if 'catalyst_quality' in g else pd.Series(dtype=float)
                rp=pd.to_numeric(g.get('risk_penalty'),errors='coerce') if 'risk_penalty' in g else pd.Series(dtype=float)
                return pd.Series({
                    'ev_independent':bool(g.get('independent_catalyst',pd.Series(False,index=g.index)).fillna(False).astype(bool).any()),
                    'ev_quality':float(q.max()) if len(q.dropna()) else np.nan,
                    'ev_severe':bool(g.get('severe_negative_event',pd.Series(False,index=g.index)).fillna(False).astype(bool).any()),
                    'ev_risk':float(rp.max()) if len(rp.dropna()) else 0.0,
                    'ev_public':True,
                })
            ea=ev.groupby(['trade_date','ts_code'],as_index=False).apply(_agg,include_groups=False).reset_index()
            keep=[c for c in ['trade_date','ts_code','ev_independent','ev_quality','ev_severe','ev_risk','ev_public'] if c in ea]
            if {'trade_date','ts_code'}<=set(keep):
                e=e.merge(ea[keep],on=['trade_date','ts_code'],how='left')
                e['independent_catalyst']=e.get('ev_independent',False).fillna(False).astype(bool)
                e['catalyst_quality']=pd.to_numeric(e.get('ev_quality'),errors='coerce')
                e['severe_negative_event']=e.get('ev_severe',False).fillna(False).astype(bool)
                e['risk_penalty']=pd.to_numeric(e.get('ev_risk'),errors='coerce').fillna(0).clip(0,1)
                e['catalyst_public_before_cutoff']=e.get('ev_public',False).fillna(False).astype(bool)
    # 题材只接受独立的历史时点theme_members管线；事件文本/事件表不得暗中生成题材加分。
    if 'seat_quality_pctile' not in e: e['seat_quality_pctile']=np.nan
    if 'seat_quality_samples' not in e: e['seat_quality_samples']=0

    # 盘后板块退潮：与延迟分支使用同一可复现口径，修复此前字段从未生成导致否决失效的问题。
    e['sector_is_ebb']=(pd.to_numeric(e['sector_rs_5d_pctile'],errors='coerce')<.30)&(pd.to_numeric(e['sector_ret5'],errors='coerce')<0)
    # 高潮风险必须同时属于“指数单日极端上涨+成交极端+本板块单日集体强+个股加速”，不再用全市场情绪替代个股加速。
    e['market_climax']=(e['index_extreme_up'].fillna(False)&e['turnover_extreme'].fillna(False)&
                        (pd.to_numeric(e['sector_ret1_pctile'],errors='coerce')>=.90)&
                        (pd.to_numeric(e['ret3p'],errors='coerce')>=.95)&(pd.to_numeric(e['close_location_day'],errors='coerce')>=.80))

    required=['close','amount','l1_code','sector_rs_5d_pctile','market_permission']
    missing=e[required].isna().any(axis=1)
    if adj_factor is not None and len(adj_factor):missing=missing|e['adj_factor'].isna()
    # 席位结构是必审证据；明细缺失不能被误当成“净买0”。
    if 'seat_detail_available' in e:missing=missing|(~e['seat_detail_available'].fillna(False))
    missing=missing|(e['market_data_quality'].fillna('insufficient')=='insufficient')
    e['data_quality']=np.where(missing,'insufficient','normal')
    return e


def to_candidate_features(row)->CandidateFeatures:
    def g(k,default=None):
        v=row[k] if k in row.index else default
        return default if pd.isna(v) else v
    return CandidateFeatures(
        trade_date=pd.Timestamp(g('trade_date')).strftime('%Y-%m-%d'), ts_code=str(g('ts_code')), name=str(g('name','')),
        exchange=str(g('exchange','')),board=str(g('market','')),list_days=int(g('list_days',0)),is_st=bool(g('is_st',False)),is_delisting_arrangement=bool(g('is_delisting_arrangement',False)),data_quality=str(g('data_quality','insufficient')),
        market_state=str(g('market_state','震荡可做')),market_permission=str(g('market_permission','暂停')),market_climax=bool(g('market_climax',False)),
        sector_code=str(g('l1_code','')),theme_code=str(g('theme_code','__UNKNOWN_THEME__')),theme_verified=bool(g('theme_verified',False)),sector_rs_5d_pctile=float(g('sector_rs_5d_pctile',0)),sector_activity_pctile=float(g('sector_activity_pctile',0)),sector_core_rank=int(g('sector_core_rank',99)),sector_is_ebb=bool(g('sector_is_ebb',False)),
        independent_catalyst=bool(g('independent_catalyst',False)),catalyst_quality=g('catalyst_quality',None),catalyst_public_before_cutoff=bool(g('catalyst_public_before_cutoff',False)),
        rs_20d_pctile=float(g('rs_20d_pctile',0)),ma20_slope_pctile=float(g('ma20_slope_pctile',0)),close_above_ma20=bool(g('close_above_ma20',False)),ma5_gt_ma10_gt_ma20=bool(g('ma5_gt_ma10_gt_ma20',False)),ma20_gt_ma60=bool(g('ma20_gt_ma60',False)),
        breakout_20d_strength=float(g('breakout_20d_strength',0)),close_location_day=float(g('close_location_day',.5)),volume_health=float(g('volume_health',0)),startup_location_health=float(g('startup_location_health',0)),
        lhb_net_buy_ratio=float(g('lhb_net_buy_ratio',0)),lhb_net_impact_pctile=float(g('lhb_net_impact_pctile',0)),lhb_participation_pctile=float(g('lhb_participation_pctile',0)),
        inst_net_buy_ratio=float(g('inst_net_buy_ratio',0)),inst_net_impact_pctile=float(g('inst_net_impact_pctile',0)),broker_net_buy_ratio=float(g('broker_net_buy_ratio',0)),broker_net_impact_pctile=float(g('broker_net_impact_pctile',0)),buy_sell_balance=float(g('buy_sell_balance',0)),
        lifecycle_event_no=int(g('lifecycle_event_no',1)),lifecycle_net_improving=bool(g('lifecycle_net_improving',False)),seat_quality_pctile=g('seat_quality_pctile',None),seat_quality_samples=int(g('seat_quality_samples',0)),risk_penalty=float(g('risk_penalty',0)),
        downward_anomaly_without_reversal=bool(g('downward_anomaly_without_reversal',False)),three_day_surge_high_climax=bool(g('three_day_surge_high_climax',False)),extreme_volume_inst_sell_weak_relay=bool(g('extreme_volume_inst_sell_weak_relay',False)),severe_negative_event=bool(g('severe_negative_event',False)),
        extra={'amount':float(g('amount',0)),'t_close':float(g('close',0)),'lhb_low':float(g('low',0)),'atr14':float(g('atr14',0)),
               'theme_code':str(g('theme_code','__UNKNOWN_THEME__')),'theme_verified':bool(g('theme_verified',False))}
    )
