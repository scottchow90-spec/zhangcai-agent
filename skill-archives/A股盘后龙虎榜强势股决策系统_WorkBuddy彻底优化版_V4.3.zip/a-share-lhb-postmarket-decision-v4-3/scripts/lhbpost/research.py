from __future__ import annotations
import csv, hashlib, json, math, random
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path
from statistics import mean, median

LABEL_COLS=('return_t1','return_t3','return_t5','max_return_t5','max_drawdown_t5')
BENCH_COLS=('benchmark_return_t1','benchmark_return_t5','benchmark_max_return_t5','benchmark_max_drawdown_t5')

def _f(x):
    try:
        y=float(x);return y if math.isfinite(y) else None
    except Exception:return None

def load_labeled(path:str|Path, cutoff:date):
    rows=[]
    with open(path,'r',encoding='utf-8-sig',newline='') as fh:
        rd=csv.DictReader(fh)
        required={'event_date','model_bucket',*LABEL_COLS}
        miss=required-set(rd.fieldnames or [])
        if miss:raise ValueError('历史标签CSV缺字段:'+','.join(sorted(miss)))
        for r in rd:
            try:d=date.fromisoformat(str(r['event_date'])[:10])
            except Exception:continue
            if d>=cutoff:continue
            vals={k:_f(r.get(k)) for k in (*LABEL_COLS,*BENCH_COLS)}
            if any(vals[k] is None for k in LABEL_COLS):continue
            r.update(vals);r['_date']=d;rows.append(r)
    return sorted(rows,key=lambda r:r['_date'])

def assign_walk_forward(rows, cutoff:date, min_train_years:int=2, observation_days:int=90):
    """动态滚动样本外切分。

    - 最近 observation_days 天永久作为观察区，不进入验收/桶统计；
    - 最早 min_train_years 个自然年仅作开发；
    - 之后每一个完整/截至观察区前的自然年作为一个样本外折叠，训练期仅使用该年之前数据。
    规则完全由数据时间与cutoff派生，不写死2022/2024/2026等日期。
    """
    if not rows:return [],[]
    obs_start=cutoff-timedelta(days=max(30,int(observation_days)))
    eligible=[r for r in rows if r['_date']<obs_start]
    years=sorted({r['_date'].year for r in eligible})
    train_years=set(years[:max(1,int(min_train_years))])
    oos_years=years[max(1,int(min_train_years)):]
    folds=[]
    for y in oos_years:
        test=[r for r in eligible if r['_date'].year==y]
        train=[r for r in eligible if r['_date'].year<y]
        if not test or not train:continue
        folds.append({'fold':f'year_{y}','train_start':min(r['_date'] for r in train).isoformat(),
                      'train_end':max(r['_date'] for r in train).isoformat(),
                      'test_start':min(r['_date'] for r in test).isoformat(),
                      'test_end':max(r['_date'] for r in test).isoformat(),
                      'train_n':len(train),'test_n':len(test),'test_year':y})
    oos_year_set={f['test_year'] for f in folds}
    for r in rows:
        if r['_date']>=obs_start:r['_split']='observation';r['_fold']='observation'
        elif r['_date'].year in train_years:r['_split']='development';r['_fold']='development'
        elif r['_date'].year in oos_year_set:r['_split']='oos';r['_fold']=f"year_{r['_date'].year}"
        else:r['_split']='development';r['_fold']='development'
    return rows,folds

def _metrics(rows):
    if not rows:return {'sample_n':0}
    t1=[r['return_t1'] for r in rows];t3=[r['return_t3'] for r in rows];t5=[r['return_t5'] for r in rows]
    mfe=[r['max_return_t5'] for r in rows];mae=[r['max_drawdown_t5'] for r in rows]
    out={'sample_n':len(rows),'t1_positive_rate':sum(x>0 for x in t1)/len(t1),'t3_positive_rate':sum(x>0 for x in t3)/len(t3),
         't5_ge5_rate':sum(x>=.05 for x in mfe)/len(mfe),'avg_return_t5':mean(t5),'median_return_t5':median(t5),'avg_mae_5d':mean(mae)}
    b=[r for r in rows if r.get('benchmark_return_t5') is not None]
    out['benchmark_excess_t5']=mean(r['return_t5']-r['benchmark_return_t5'] for r in b) if b else None
    return out

def _bootstrap_lower_diff(rows, metric, bench_metric, reps=1000, seed=20260911):
    pairs=[(_f(r.get(metric)),_f(r.get(bench_metric))) for r in rows]
    pairs=[p for p in pairs if p[0] is not None and p[1] is not None]
    if len(pairs)<100:return None
    rng=random.Random(seed);n=len(pairs);vals=[]
    for _ in range(reps):
        samp=[pairs[rng.randrange(n)] for _ in range(n)]
        vals.append(mean(a-b for a,b in samp))
    vals.sort();return vals[int(.05*(len(vals)-1))]

def acceptance(rows):
    oos=[r for r in rows if r.get('_split')=='oos']
    years=defaultdict(list)
    for r in oos:years[r['_date'].year].append(r)
    complete_bench=[r for r in oos if all(r.get(k) is not None for k in BENCH_COLS)]
    t1_lb=_bootstrap_lower_diff(complete_bench,'return_t1','benchmark_return_t1') if complete_bench else None
    t5_lb=_bootstrap_lower_diff(complete_bench,'return_t5','benchmark_return_t5') if complete_bench else None
    checks={
        'oos_sample_n_ge_300':len(oos)>=300,
        'benchmark_coverage_ge_90pct':bool(oos) and len(complete_bench)/len(oos)>=.90,
        't1_excess_bootstrap_5pct_gt_0':t1_lb is not None and t1_lb>0,
        't5_excess_bootstrap_5pct_gt_0':t5_lb is not None and t5_lb>0,
        'at_least_3_oos_years':len(years)>=3,
    }
    year_ex=[]
    for y,rs in sorted(years.items()):
        q=[r['return_t5']-r['benchmark_return_t5'] for r in rs if r.get('benchmark_return_t5') is not None]
        if q:year_ex.append((y,mean(q),sum(max(x,0) for x in q)))
    checks['positive_excess_year_ratio_ge_60pct']=bool(year_ex) and sum(v>0 for _,v,_ in year_ex)/len(year_ex)>=.60
    pos=sum(z for _,_,z in year_ex)
    checks['single_year_positive_excess_le_60pct']=bool(year_ex) and (pos<=0 or max(z for _,_,z in year_ex)/pos<=.60)
    return {'passed':all(checks.values()),'checks':checks,'oos_sample_n':len(oos),'benchmark_complete_n':len(complete_bench),
            'bootstrap_lower_excess_t1':t1_lb,'bootstrap_lower_excess_t5':t5_lb,
            'year_stats':[{'year':y,'avg_excess_t5':v,'positive_excess_sum':z} for y,v,z in year_ex]}

def build_model(events_path:str|Path, cutoff:str, output:str|Path):
    cut=date.fromisoformat(cutoff);rows=load_labeled(events_path,cut);rows,folds=assign_walk_forward(rows,cut)
    groups=defaultdict(list);split_counts=defaultdict(int)
    for r in rows:
        split_counts[r['_split']]+=1
        if r['_split']=='oos':groups[r['model_bucket']].append(r)
    raw=Path(events_path).read_bytes();prov=hashlib.sha256(raw+b'|'+cutoff.encode()+b'|v4.3-walk-forward-oos').hexdigest()
    acc=acceptance(rows)
    model={'model_cutoff':cutoff,'validation_scheme':'walk_forward_oos','production_qualified':bool(acc['passed']),
           'acceptance':acc,'provenance_hash':prov,'split_counts':dict(split_counts),'walk_forward_folds':folds,
           'buckets':{k:_metrics(v) for k,v in sorted(groups.items())},
           'notes':'动态滚动样本外：最早2个自然年仅开发，后续逐年向前验证；cutoff前最近90天永久观察，不参与验收/桶统计。生产资格由样本量、基准覆盖、bootstrap超额及年度稳定性自动决定。'}
    Path(output).write_text(json.dumps(model,ensure_ascii=False,indent=2),encoding='utf-8');return model
