from __future__ import annotations
import math, hashlib, json
from pathlib import Path
from typing import Any


def clip(x: float, lo: float=0.0, hi: float=1.0) -> float:
    try:
        if x is None or math.isnan(float(x)):
            return lo
    except Exception:
        return lo
    return min(hi, max(lo, float(x)))


def pct_rank(values):
    import pandas as pd
    s = pd.Series(values, dtype='float64')
    return s.rank(method='average', pct=True)


def stable_hash(obj: Any) -> str:
    b = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(b).hexdigest()


def file_sha256(path: str|Path) -> str:
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def parse_date_series(s):
    """可靠解析YYYYMMDD整数/字符串或普通日期字符串，避免pandas把20250101整数当纳秒。"""
    import pandas as pd
    x=pd.Series(s,index=getattr(s,'index',None))
    st=x.astype('string').str.replace(r'\.0$','',regex=True).str.strip()
    out=pd.to_datetime(st,errors='coerce')
    mask=st.str.fullmatch(r'\d{8}',na=False)
    if mask.any():out.loc[mask]=pd.to_datetime(st.loc[mask],format='%Y%m%d',errors='coerce')
    return out
