#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A股盘后龙虎榜证据决策引擎 v4.3。

只处理 T 日收盘后已知信息；拒绝盘中、集合竞价、T+1 及之后字段。
不输出未经历史样本外验证的预测概率，也不使用主观总分。
"""
from __future__ import annotations

import json
import math
import re
import hashlib
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG = ROOT / "templates" / "default-config.json"

FORBIDDEN_KEYS = {
    "next_day_return", "t_plus_1", "t_plus_3", "t_plus_5", "future_return",
    "next_open", "next_close", "next_high", "next_low", "next_auction",
    "next_day_high", "next_day_low", "future_price", "future_label",
    "auction_gap", "auction_price", "call_auction", "竞价涨幅", "竞价成交额",
    "minute_bars", "intraday_signal", "five_minute_confirm", "分时信号", "盘中确认"
}
FORBIDDEN_KEY_PATTERNS = [
    re.compile(r"(^|_)(next|future|t\+?1|t\+?2|t\+?3|t\+?4|t\+?5)(_|$)", re.I),
    re.compile(r"auction|竞价|minute|intraday|分时|盘中", re.I),
]
TIME_FIELDS = {"source_time","public_time","published_at","evidence_time","as_of_time"}
DATE_FIELDS = {"trade_date","event_date","reference_date","asof_date","mature_date"}


POSITION_RANK = {
    "主线核心": 7,
    "板块最高板": 7,
    "板块前排": 6,
    "容量核心": 5,
    "独立强势": 4,
    "弱板块孤立强股": 3,
    "后排跟风": 1,
    "板块退潮": 0,
    "未知": 0,
}
STAGE_RANK = {"2板": 5, "3板及以上": 4, "首板": 3, "趋势强势": 2, "普通": 1, "特殊观察": 0}
SECTOR_RANK = {"强势持续": 3, "中性/轮动": 2, "弱势": 1, "退潮": 0, "未知": 0}
LHB_RANK = {"确认": 2, "弱确认": 1, "中性": 0, "集中风险": -1, "负面": -2, "无龙虎榜": -3}
OVERHEAT_RISK = {"低位/未见明显透支": 0, "正常加速": 1, "高位拥挤": 2, "末端透支": 3}
CONCLUSION_RANK = {
    "核心候选": 7,
    "重点候选A": 6,
    "重点候选B": 5,
    "重点观察": 4,
    "次级观察": 3,
    "风险观察": 2,
    "特殊观察池": 1,
    "剔除": 0,
}
MARKET_CAP = {
    "强进攻": "核心候选",
    "正常轮动": "核心候选",
    "强分歧": "重点候选A",
    "退潮": "重点观察",
    "极端风险": "风险观察",
}
CAUSAL_MARKET_MAP = {
    "全面主升": "强进攻",
    "结构性主升": "正常轮动",
    "震荡可做": "正常轮动",
    "修复": "强分歧",
    "结构严重分化": "强分歧",
    "退潮": "退潮",
    "恐慌": "极端风险",
}
PERMISSION_CAP = {"正常":"核心候选","精选":"重点候选A","小仓试错":"重点观察","暂停":"风险观察"}
STATE_SEVERITY = {"强进攻":0,"正常轮动":1,"强分歧":2,"退潮":3,"极端风险":4}

REQUIRED_PREANALYSIS_STEPS = [
    "原始数据审计", "时间截断", "历史时点状态", "市场环境", "强势阶段",
    "板块与题材", "市场/板块地位", "价格透支", "龙虎榜", "盘后事件", "历史样本",
]
REQUIRED_COVERAGE_KEYS = {"market_full_features","index_daily","industry_pit","theme_pit","event_feed","seat_detail","history_model"}


def load_config(path: str | Path | None = None) -> Dict[str, Any]:
    p = Path(path) if path else DEFAULT_CONFIG
    return json.loads(p.read_text(encoding="utf-8-sig"))


def parse_dt(value: str) -> datetime:
    dt = datetime.fromisoformat(str(value))
    if dt.tzinfo is None:
        raise ValueError(f"时间必须带时区: {value}")
    return dt


def iter_keys(obj: Any) -> Iterable[str]:
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield str(k)
            yield from iter_keys(v)
    elif isinstance(obj, list):
        for x in obj:
            yield from iter_keys(x)


def _f(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def _forbidden_key(k: str) -> bool:
    if k in FORBIDDEN_KEYS:
        return True
    return any(p.search(k) for p in FORBIDDEN_KEY_PATTERNS)

def _walk(obj: Any, path: str = ""):
    if isinstance(obj, dict):
        for k,v in obj.items():
            pp=f"{path}.{k}" if path else str(k)
            yield pp,str(k),v
            yield from _walk(v,pp)
    elif isinstance(obj,list):
        for i,v in enumerate(obj):
            yield from _walk(v,f"{path}[{i}]")


def _validate_production_workflow(data: Dict[str, Any]) -> List[str]:
    errors: List[str] = []
    pipeline=str(data.get("pipeline") or "")
    if pipeline != "raw-postmarket-v4.3-audited":
        return errors
    audit=data.get("raw_data_audit")
    if not isinstance(audit,dict) or audit.get("passed") is not True:
        errors.append("生产管线缺少通过的raw_data_audit，禁止把未审计快照冒充完整生产结果")
    cov=data.get("coverage")
    if not isinstance(cov,dict):
        errors.append("生产管线缺少coverage元数据")
    else:
        miss=sorted(REQUIRED_COVERAGE_KEYS-set(cov))
        if miss: errors.append("生产管线coverage缺键:"+",".join(miss))
    wf=data.get("workflow_trace")
    if not isinstance(wf,list):
        errors.append("生产管线缺少workflow_trace")
        return errors
    steps=[str(x.get("step")) for x in wf if isinstance(x,dict)]
    pos=-1
    for req in REQUIRED_PREANALYSIS_STEPS:
        try:i=steps.index(req,pos+1)
        except ValueError:
            errors.append(f"完整工作流缺少步骤:{req}")
            continue
        pos=i
    return errors

def validate_snapshot(data: Dict[str, Any]) -> List[str]:
    errors: List[str] = []
    for field in ("trade_date", "as_of", "market", "stocks"):
        if field not in data: errors.append(f"缺少顶层字段: {field}")
    bad=[]
    for path,k,v in _walk(data):
        if _forbidden_key(k): bad.append(path)
    if bad: errors.append("检测到禁用字段（未来/盘中/集合竞价）: " + ", ".join(sorted(set(bad))[:20]))
    as_of=None
    if "as_of" in data:
        try: as_of=parse_dt(data["as_of"])
        except Exception as ex: errors.append(str(ex))
    trade_date=str(data.get("trade_date", ""))
    if as_of and trade_date and as_of.date().isoformat()!=trade_date:
        errors.append("as_of 日期与 trade_date 不一致")
    if as_of:
        td=date.fromisoformat(trade_date) if trade_date else as_of.date()
        for path,k,v in _walk(data):
            if k in TIME_FIELDS and v:
                try:
                    if parse_dt(v)>as_of: errors.append(f"证据时间晚于 as_of: {path}={v}")
                except Exception as ex: errors.append(f"证据时间错误 {path}: {ex}")
            elif k in DATE_FIELDS and v and path != "trade_date":
                # 日常快照不允许把T+1/T+N日期藏在普通日期字段中。
                try:
                    dv=date.fromisoformat(str(v)[:10])
                    if dv>td: errors.append(f"日期字段晚于分析交易日: {path}={v}")
                except Exception as ex:
                    errors.append(f"日期字段错误 {path}: {ex}")
    stocks=data.get("stocks")
    if not isinstance(stocks,list): errors.append("stocks 必须为数组"); return errors
    seen=set()
    for i,s in enumerate(stocks):
        if not isinstance(s,dict): errors.append(f"stocks[{i}] 不是对象"); continue
        for field in ("code","name"):
            if not s.get(field): errors.append(f"stocks[{i}] 缺少 {field}")
        key=(s.get("code"),trade_date)
        if key in seen: errors.append(f"重复候选事件: {key[0]} {trade_date}")
        seen.add(key)
        if s.get("data_quality") == "insufficient": errors.append(f"{s.get('code','?')} 数据质量不足")
    errors.extend(_validate_production_workflow(data))
    return errors

def market_state(m: Dict[str, Any], cfg: Dict[str, Any]) -> Tuple[str, List[str]]:
    c = cfg["market_gate"]
    up, down = _f(m.get("up_count")), _f(m.get("down_count"))
    flat = _f(m.get("flat_count"))
    lu, ld = _f(m.get("limit_up_count")), _f(m.get("limit_down_count"))
    total = max(up + down + flat, 1.0)
    up_ratio = up / total
    limit_ratio = lu / max(ld, 1.0)
    idx_vals = [_f(v) for v in (m.get("index_changes") or {}).values() if isinstance(v, (int, float))]
    idx_avg = sum(idx_vals) / len(idx_vals) if idx_vals else 0.0
    turnover_change = _f(m.get("turnover_change_pct"))
    broken = _f(m.get("broken_limit_up_count"), -1)
    seal_rate = lu / max(lu + broken, 1.0) if broken >= 0 else None
    prev_lu_ret = m.get("prev_limit_up_avg_return")

    reasons = [
        f"上涨家数比例 {up_ratio:.1%}", f"涨停/跌停比 {limit_ratio:.2f}",
        f"主要指数平均涨跌 {idx_avg:.2f}%", f"成交额变化 {turnover_change:.2f}%"
    ]
    if seal_rate is not None:
        reasons.append(f"封板率 {seal_rate:.1%}")
    if prev_lu_ret is not None:
        reasons.append(f"昨日涨停股今日平均表现 {_f(prev_lu_ret):.2f}%")

    if up_ratio >= c["attack_up_ratio"] and limit_ratio >= c["attack_limit_ratio"] and idx_avg >= 0:
        return "强进攻", reasons
    if up_ratio >= c["normal_up_ratio"] and limit_ratio >= c["normal_limit_ratio"] and idx_avg >= -0.5:
        return "正常轮动", reasons
    if up_ratio < c["extreme_up_ratio"] or (ld >= lu and idx_avg <= c["extreme_index_avg_pct"]):
        return "极端风险", reasons
    if up_ratio < c["retreat_up_ratio"]:
        # 宽度极差但涨停/跌停比仍明显偏多，视为强分歧而不是直接把逆势股奖励为“强”。
        if limit_ratio >= c["normal_limit_ratio"]:
            return "强分歧", reasons
        return "退潮", reasons
    if idx_avg <= c["retreat_index_avg_pct"] and turnover_change < 0:
        return "退潮", reasons
    return "强分歧", reasons


def _more_conservative_state(a: str, b: str) -> str:
    return a if STATE_SEVERITY.get(a,9) >= STATE_SEVERITY.get(b,9) else b


def _cap_more_conservative(a: str, b: str) -> str:
    return a if CONCLUSION_RANK.get(a,-9) <= CONCLUSION_RANK.get(b,-9) else b


def resolve_market_gate(m: Dict[str, Any], cfg: Dict[str, Any], coverage: Dict[str, Any] | None = None) -> Tuple[str, str, List[str], str]:
    """双轨市场总闸门：原始宽度/涨跌停口径 + 120日因果百分位口径，取更保守结果。

    这样既不退回V3/V4.1的简化市场判断，也不让旧技能中的手工加权市场综合分单独支配结果。
    """
    raw_state, reasons = market_state(m, cfg)
    state=raw_state
    method="原始宽度闸门"
    cap=MARKET_CAP[raw_state]
    cm=m.get("causal_market") or {}
    if cm and str(cm.get("data_quality"))=="normal":
        causal_state=CAUSAL_MARKET_MAP.get(str(cm.get("state")), "强分歧")
        state=_more_conservative_state(raw_state, causal_state)
        perm=str(cm.get("permission") or "暂停")
        cap=_cap_more_conservative(MARKET_CAP[state], PERMISSION_CAP.get(perm,"风险观察"))
        reasons=reasons+[
            f"因果市场状态 {cm.get('state')}→{causal_state}",
            f"市场权限 {perm}",
            f"120日宽度分位 {cm.get('breadth_pctile')}",
            f"120日情绪分位 {cm.get('sentiment_pctile')}",
            f"120日风险分位 {cm.get('risk_pctile')}",
        ]
        method="双轨保守融合"
    else:
        # 缺完整市场因果特征时，不允许静默按简化模型给出高等级候选。
        cap=_cap_more_conservative(cap,"重点观察")
        reasons.append("完整120日因果市场特征缺失：按降级模式限制候选等级")
        method="降级：仅原始宽度闸门"
    cov=coverage or {}
    if not cov:
        cap=_cap_more_conservative(cap,"重点观察")
        reasons.append("工作流覆盖元数据缺失：视为手工/降级快照，候选等级限制为重点观察")
    if cov:
        if not cov.get("market_full_features",False):
            cap=_cap_more_conservative(cap,"重点观察")
            reasons.append("完整市场因果层/指数日线覆盖不足：降级")
        if not cov.get("industry_pit",False):
            cap=_cap_more_conservative(cap,"重点观察")
            reasons.append("历史时点行业映射缺失：降级")
        if not cov.get("event_feed",False):
            cap=_cap_more_conservative(cap,"重点候选B")
            reasons.append("盘后事件数据源缺失：禁止升级为A/核心")
    return state, cap, reasons, method

def classify_stage(s: Dict[str, Any]) -> str:
    if s.get("new_unlimited"):
        return "特殊观察"
    streak = int(_f(s.get("board_streak")))
    if streak >= 3:
        return "3板及以上"
    if streak == 2:
        return "2板"
    if streak == 1:
        return "首板"
    r20 = _f((s.get("days_return") or {}).get("20"))
    if _f(s.get("change_pct")) > 3 and r20 > 12:
        return "趋势强势"
    return "普通"


def sector_state(s: Dict[str, Any], cfg: Dict[str, Any], metrics: Dict[str, Any] | None = None) -> Tuple[str, List[str]]:
    sm = metrics if metrics is not None else (s.get("sector_metrics") or {})
    c = cfg["sector"]
    day = _f(sm.get("day_change_pct"))
    up_ratio = _f(sm.get("up_ratio"))
    lu = int(_f(sm.get("limit_up_count")))
    two = int(_f(sm.get("two_plus_board_count")))
    r3, r5 = _f(sm.get("rel_strength_3d")), _f(sm.get("rel_strength_5d"))
    advanced = bool(sm.get("leader_advanced"))
    reasons = [f"板块当日 {day:.2f}%", f"上涨占比 {up_ratio:.1%}", f"板块涨停 {lu} 家", f"2板及以上 {two} 家", f"3日相对强度 {r3:.2f}", f"5日相对强度 {r5:.2f}"]

    if day > c["strong_day_change_pct"] and up_ratio >= c["strong_up_ratio"] and lu >= c["strong_limit_up_count"] and (r3 > 0 or r5 > 0 or two > 0 or advanced):
        return "强势持续", reasons
    if day < c["weak_day_change_pct"] and up_ratio < c["weak_up_ratio"] and r3 <= 0 and r5 <= 0:
        return "弱势", reasons
    if day < 0 and up_ratio < 0.30 and lu == 0:
        return "退潮", reasons
    return "中性/轮动", reasons


def resolve_context(s: Dict[str, Any], cfg: Dict[str, Any]) -> Dict[str, Any]:
    """行业层必跑；历史时点题材存在时，只有题材状态客观强于行业时才采用题材上下文。"""
    im=s.get("industry_metrics") or s.get("sector_metrics") or {}
    tm=s.get("theme_metrics") or {}
    ist,ir=sector_state(s,cfg,im)
    tst,tr=("未知",[]) if not tm or not s.get("theme_verified") else sector_state(s,cfg,tm)
    use_theme=False
    if tm and s.get("theme_verified"):
        if tst=="强势持续" and ist!="强势持续": use_theme=True
        elif SECTOR_RANK.get(tst,0)>SECTOR_RANK.get(ist,0): use_theme=True
    if use_theme:
        return {"state":tst,"reasons":["采用历史时点题材上下文"]+tr,"basis":"题材","name":s.get("theme") or s.get("theme_code"),
                "core_rank":int(_f(s.get("theme_core_rank"),99)),"leader":int(_f(s.get("theme_core_rank"),99))==1,
                "capacity_core":bool(s.get("theme_capacity_core"))}
    return {"state":ist,"reasons":["采用历史时点行业上下文"]+ir,"basis":"行业","name":s.get("sector"),
            "core_rank":int(_f(s.get("industry_core_rank",s.get("sector_core_rank")),99)),
            "leader":int(_f(s.get("industry_core_rank",s.get("sector_core_rank")),99))==1 or bool(s.get("sector_leader")),
            "capacity_core":bool(s.get("industry_capacity_core",s.get("capacity_core")))}


def derive_position(s: Dict[str, Any], sec_state: str, *, core_rank: int | None = None,
                    leader: bool | None = None, capacity_core: bool | None = None) -> str:
    # 禁止把人工 market_position 当作排序事实；核心地位必须由全市场同板块可复现排序派生。
    core_rank=int(_f(core_rank if core_rank is not None else s.get("sector_core_rank"),99))
    market_rank=int(_f(s.get("market_height_rank"),99))
    streak=int(_f(s.get("board_streak")))
    is_leader=bool(leader if leader is not None else s.get("sector_leader"))
    cap_core=bool(capacity_core if capacity_core is not None else s.get("capacity_core"))
    if is_leader and sec_state=="强势持续" and core_rank<=2:
        return "主线核心"
    if streak>=2 and core_rank==1:
        return "板块最高板"
    if core_rank<=2 and sec_state not in {"弱势","退潮"}:
        return "板块前排"
    if market_rank<=3 and streak>=2:
        return "独立强势"
    if cap_core and sec_state not in {"弱势","退潮"}:
        return "容量核心"
    if sec_state in {"弱势","退潮"} and _f(s.get("change_pct"))>=7:
        return "弱板块孤立强股"
    if core_rank<=5 and _f(s.get("change_pct"))>=5:
        return "板块前排"
    if _f(s.get("change_pct"))>=7:
        return "独立强势"
    return "未知"

def overheat(s: Dict[str, Any], cfg: Dict[str, Any]) -> Tuple[str, List[str]]:
    c = cfg["overheat"]
    d = s.get("days_return") or {}
    r5, r10, r20 = _f(d.get("5")), _f(d.get("10")), _f(d.get("20"))
    tr = _f(s.get("turnover_rate"))
    vr = _f(s.get("volume_ratio20"))
    ext20 = s.get("distance_to_prev20_high_pct")
    ext20 = _f(ext20) if ext20 is not None else None
    streak = int(_f(s.get("board_streak")))
    tags: List[str] = []
    severe = 0
    moderate = 0
    if r20 >= c["r20_extreme"]:
        severe += 2; tags.append(f"20日涨幅{r20:.1f}%>=极端阈值")
    elif r20 >= c["r20_high"]:
        moderate += 2; tags.append(f"20日涨幅{r20:.1f}%偏高")
    if r10 >= c["r10_high"]:
        moderate += 1; tags.append(f"10日涨幅{r10:.1f}%偏高")
    if r5 >= c["r5_high"]:
        moderate += 1; tags.append(f"5日涨幅{r5:.1f}%偏高")
    if tr >= c["turnover_extreme"]:
        severe += 1; tags.append(f"换手率{tr:.1f}%极高")
    elif tr >= c["turnover_high"]:
        moderate += 1; tags.append(f"换手率{tr:.1f}%偏高")
    if vr >= c.get("volume_ratio_extreme", 5.0):
        severe += 1; tags.append(f"成交额/过去20日中位数 {vr:.2f} 倍，极端放量")
    elif vr >= c.get("volume_ratio_high", 3.5):
        moderate += 1; tags.append(f"成交额/过去20日中位数 {vr:.2f} 倍，明显放量")
    if ext20 is not None:
        if ext20 >= c.get("prev20_extension_extreme_pct",15.0):
            severe += 1; tags.append(f"收盘高于此前20日高点 {ext20:.1f}%，扩张过快")
        elif ext20 >= c.get("prev20_extension_high_pct",8.0):
            moderate += 1; tags.append(f"收盘高于此前20日高点 {ext20:.1f}%，存在透支")
    if streak >= c["streak_extreme"]:
        severe += 1; tags.append(f"连板高度{streak}偏极端")
    elif streak >= c["streak_high"]:
        moderate += 1; tags.append(f"连板高度{streak}较高")
    close_loc = s.get("close_location")
    if close_loc is not None and _f(close_loc) < 0.35 and _f(s.get("change_pct")) > 3:
        moderate += 1; tags.append("收盘位置偏低，存在冲高回落")
    if s.get("broken_limit_weak_close"):
        moderate += 2; tags.append("炸板后弱收")
    if severe >= 2 or severe + moderate >= 5:
        return "末端透支", tags
    if severe >= 1 or moderate >= 3:
        return "高位拥挤", tags
    if moderate >= 1:
        return "正常加速", tags
    return "低位/未见明显透支", tags


def lhb_evidence(s: Dict[str, Any], cfg: Dict[str, Any]) -> Tuple[str, Dict[str, float], List[str]]:
    l = s.get("lhb") or {}
    if not l.get("listed"):
        return "无龙虎榜", {}, ["未提供龙虎榜明细"]
    c = cfg["lhb"]
    turnover = _f(s.get("turnover"))
    impact_denominator = _f(l.get("impact_denominator"), turnover)
    if impact_denominator <= 0:
        impact_denominator = turnover
    buy5, sell5 = _f(l.get("buy5")), _f(l.get("sell5"))
    net = _f(l.get("net_buy"), buy5 - sell5)
    buy1 = _f(l.get("buy1"))
    inst = _f(l.get("institution_net"))
    connect = _f(l.get("connect_net"))
    broker = _f(l.get("broker_net"))
    net_ratio = net / impact_denominator if impact_denominator > 0 else 0.0
    buy_sell = buy5 / sell5 if sell5 > 0 else (999.0 if buy5 > 0 else 0.0)
    concentration = buy1 / buy5 if buy5 > 0 else 0.0
    inst_ratio = inst / impact_denominator if impact_denominator > 0 else 0.0
    free_float = _f(s.get("free_float_mcap"))
    net_ff = net / free_float if free_float > 0 else float("nan")
    trigger=str(l.get("trigger_reason") or "").strip()
    all_reasons=str(l.get("all_reasons") or trigger).strip()
    window_type=str(l.get("window_type") or "daily")
    reasons = [
        f"主披露窗口 {window_type}",
        f"上榜原因 {trigger or '未提供'}",
        f"龙虎榜净买/匹配披露窗口成交额 {net_ratio:.2%}", f"前五买/卖比 {buy_sell:.2f}",
        f"买一集中度 {concentration:.1%}", f"机构专用净额 {inst:.0f}",
        f"股通专用净额 {connect:.0f}", f"普通营业部净额 {broker:.0f}"
    ]
    dnr=l.get("daily_net_buy_ratio"); tnr=l.get("three_day_net_buy_ratio")
    if dnr is not None: reasons.append(f"单日窗口净买强度 {_f(dnr):.2%}")
    if tnr is not None: reasons.append(f"三日累计窗口净买强度 {_f(tnr):.2%}")
    if all_reasons and all_reasons!=trigger: reasons.append(f"全部上榜原因 {all_reasons}")
    if math.isfinite(net_ff):
        reasons.append(f"龙虎榜净买/自由流通市值 {net_ff:.2%}")
    trend = str(l.get("flow_trend") or "").strip()
    lifecycle_no=int(_f(l.get("lifecycle_event_no"),1))
    lifecycle_improving=bool(l.get("lifecycle_net_improving"))
    seat_q=l.get("seat_quality_pctile"); seat_n=int(_f(l.get("seat_quality_samples"),0))
    if trend: reasons.append(f"连续上榜资金趋势 {trend}")
    if lifecycle_no>1: reasons.append(f"3交易日生命周期内第{lifecycle_no}次上榜，净买改善={lifecycle_improving}")
    if seat_q is not None and seat_n>=20: reasons.append(f"成熟席位质量百分位 {_f(seat_q):.1%}，最小成熟样本 {seat_n}")

    if net_ratio <= c["negative_net_ratio"] or inst_ratio <= c["extreme_institution_sell_ratio"] or trend in {"兑现", "反手"}:
        role = "负面"
    elif concentration >= c["concentration_risk"] and net > 0:
        role = "集中风险"
    elif net_ratio >= c["confirm_net_ratio"] and buy_sell >= c["confirm_buy_sell_ratio"]:
        role = "确认"
    elif net > 0:
        role = "弱确认"
    else:
        role = "中性"
    return role, {
        "net_buy_ratio": net_ratio,
        "buy_sell_ratio": buy_sell,
        "buy1_concentration": concentration,
        "institution_net_ratio": inst_ratio,
        "net_buy_free_float_ratio": net_ff,
        "lifecycle_event_no": lifecycle_no,
        "lifecycle_net_improving": 1.0 if lifecycle_improving else 0.0,
        "seat_quality_pctile": _f(seat_q, float("nan")) if seat_q is not None else float("nan"),
        "seat_quality_samples": seat_n,
        "seat_quality_pctile_effective": (_f(seat_q) if seat_q is not None and seat_n>=20 else float("nan")),
        "daily_net_buy_ratio": (_f(dnr) if dnr is not None else float("nan")),
        "three_day_net_buy_ratio": (_f(tnr) if tnr is not None else float("nan")),
    }, reasons


def hard_vetoes(s: Dict[str, Any], position: str, sec_state: str, oh: str, lhb_role: str) -> List[str]:
    v: List[str] = []
    board = str(s.get("board") or s.get("exchange") or "")
    if "北交" in board or board.upper() in {"BSE", "BJ"} or str(s.get("code", "")).endswith(".BJ"):
        v.append("默认排除北交所")
    if s.get("risk_warning") or s.get("is_st"):
        v.append("风险警示/ST")
    if s.get("delisting_risk") or s.get("is_delisting_arrangement"):
        v.append("退市/重大退市风险")
    if _f(s.get("change_pct")) <= 0:
        v.append("非短线强势上涨样本")
    if s.get("data_conflicts"):
        v.append("关键数据存在未解决冲突")
    if s.get("data_quality") == "insufficient":
        v.append("关键数据质量不足")
    if sec_state == "退潮" and int(_f(s.get("board_streak"))) <= 1:
        v.append("板块退潮且自身仅低阶段强势")
    if oh == "末端透支" and lhb_role == "负面":
        v.append("末端透支叠加龙虎榜负面")
    if oh in {"高位拥挤", "末端透支"} and _f((s.get("lhb") or {}).get("institution_net")) < 0 and lhb_role == "负面":
        v.append("高位机构明显兑现")
    for e in s.get("post_close_events") or []:
        if isinstance(e, dict) and str(e.get("risk_level") or "").lower() in {"hard", "重大", "severe"}:
            v.append("盘后重大风险事件: " + str(e.get("title") or e.get("type") or "未命名"))
        if isinstance(e, dict) and e.get("concept_denial") is True:
            v.append("盘后重要概念澄清/证伪")
    return list(dict.fromkeys(v))


def _apply_cap(base: str, cap: str) -> str:
    return cap if CONCLUSION_RANK.get(base, -9) > CONCLUSION_RANK.get(cap, -9) else base

def _downgrade(base: str, steps: int = 1) -> str:
    ordered = ["剔除","特殊观察池","风险观察","次级观察","重点观察","重点候选B","重点候选A","核心候选"]
    try:
        i = ordered.index(base)
    except ValueError:
        return base
    return ordered[max(0, i-max(0, int(steps)))]

def event_risk_evidence(s: Dict[str, Any]) -> Tuple[int, List[str]]:
    """盘后事件只做风险降级/事实说明；正面催化不直接加预测分。"""
    level = 0
    reasons: List[str] = []
    for e in s.get("post_close_events") or []:
        if not isinstance(e, dict):
            continue
        title = str(e.get("title") or e.get("type") or "盘后事件")
        risk = _f(e.get("risk_penalty"))
        rl = str(e.get("risk_level") or "").lower()
        if e.get("concept_denial") is True or rl in {"hard","重大","severe"}:
            level = max(level, 3); reasons.append(f"重大风险/证伪: {title}")
        elif rl in {"high","高"} or risk >= 0.75:
            level = max(level, 2); reasons.append(f"高风险盘后事件: {title}")
        elif rl in {"medium","中"} or risk >= 0.50:
            level = max(level, 1); reasons.append(f"中等风险盘后事件: {title}")
        elif risk > 0:
            reasons.append(f"低风险盘后事件: {title}")
        elif e.get("independent_catalyst") is True:
            reasons.append(f"已核验独立催化（仅作事实，不直接加分）: {title}")
    return level, reasons


def model_bucket(market: str, stage: str, position: str, sec_state: str, oh: str, lhb_role: str) -> str:
    pos_group = "核心前排" if POSITION_RANK.get(position, 0) >= 5 else "独立/后排"
    oh_group = "低中位" if OVERHEAT_RISK.get(oh, 9) <= 1 else "高位"
    lhb_group = "正向" if LHB_RANK.get(lhb_role, -9) >= 1 else "非正向"
    return "|".join([market, stage, pos_group, sec_state, oh_group, lhb_group])


def validate_history_model(model: Dict[str, Any] | None, trade_date: str, cfg: Dict[str, Any]) -> Dict[str, Any]:
    if not model:
        return {"status": "未启用", "message": "历史概率模块未启用，本次仅做证据排序，不输出胜率。", "production_qualified": False}
    errors: List[str] = []
    cutoff = model.get("model_cutoff")
    if not cutoff:
        errors.append("缺少 model_cutoff")
    else:
        try:
            if date.fromisoformat(str(cutoff)) >= date.fromisoformat(trade_date):
                errors.append("model_cutoff 必须早于分析交易日")
        except Exception:
            errors.append("model_cutoff 日期格式错误")
    scheme = str(model.get("validation_scheme") or "")
    allowed = set(cfg["history"]["allowed_validation_schemes"])
    if scheme not in allowed:
        errors.append("历史模型缺少合格的时间序列样本外验证方案")
    if not isinstance(model.get("buckets"), dict):
        errors.append("历史模型缺少 buckets")
    acceptance = model.get("acceptance") or {}
    checks = acceptance.get("checks") or {}
    # 不能只相信 passed 字段；按明细检查重新计算。
    derived_passed = bool(checks) and all(bool(v) for v in checks.values())
    if bool(acceptance.get("passed")) != derived_passed:
        errors.append("acceptance.passed 与明细检查不一致")
    production_scheme = str(cfg["history"].get("production_validation_scheme") or "walk_forward_oos")
    production = derived_passed and scheme == production_scheme
    if "production_qualified" in model and bool(model.get("production_qualified")) != production:
        errors.append("production_qualified 与自动验收结果不一致，禁止手工覆盖")
    if production and not model.get("walk_forward_folds"):
        errors.append("生产模型缺少滚动样本外折叠证据")
    provenance = model.get("provenance_hash")
    if not provenance:
        errors.append("历史模型缺少 provenance_hash")
    if errors:
        return {"status":"拒绝","message":"; ".join(errors),"production_qualified":False}
    return {
        "status":"可用",
        "message":"模型通过结构校验；概率仅来自截止日前滚动样本外统计。",
        "model_cutoff":cutoff,
        "validation_scheme":scheme,
        "production_qualified":production,
        "acceptance":acceptance,
        "provenance_hash":provenance,
    }

def history_for_bucket(model: Dict[str, Any] | None, bucket: str, cfg: Dict[str, Any], model_status: Dict[str, Any]) -> Dict[str, Any]:
    if not model or model_status.get("status") != "可用":
        return {"available": False}
    stat = (model.get("buckets") or {}).get(bucket)
    if not isinstance(stat, dict):
        return {"available": False}
    n = int(_f(stat.get("sample_n")))
    if n < cfg["history"]["min_sample"]:
        return {"available": False, "sample_n": n, "reason": "相似样本不足50，不输出概率"}
    conf = "高" if n >= cfg["history"]["high_sample"] else "中" if n >= cfg["history"]["medium_sample"] else "低"
    out = {"available": True, "sample_n": n, "confidence": conf}
    for key in ("t1_positive_rate", "t3_positive_rate", "t5_ge5_rate", "avg_mae_5d", "avg_return_t5", "benchmark_excess_t5"):
        if key in stat and stat[key] is not None:
            out[key] = stat[key]
    return out


def evidence_conclusion(stage: str, position: str, sec_state: str, oh: str, lhb_role: str,
                        hard: List[str], market: str, candidate_cap: str, new_unlimited: bool,
                        recent_ipo_immature: bool, event_risk_level: int, history: Dict[str, Any],
                        model_status: Dict[str, Any]) -> Tuple[str, str]:
    if new_unlimited:
        return "特殊观察池", "C"
    if hard:
        return "剔除", "D"
    if market == "极端风险":
        return "风险观察", "C"

    pos = POSITION_RANK.get(position, 0)
    oh_risk = OVERHEAT_RISK.get(oh, 9)
    lhb = LHB_RANK.get(lhb_role, -3)
    strong_sector = sec_state == "强势持续"

    # 结构优先：连板梯队/板块地位/持续性先于龙虎榜金额。
    if stage in {"2板", "3板及以上"} and pos >= 5 and strong_sector and oh_risk <= 1 and lhb >= 0:
        base, grade = "重点候选A", "A"
    elif stage == "首板" and pos >= 7 and strong_sector and oh_risk <= 1 and lhb >= 2:
        base, grade = "重点候选A", "A"
    elif stage == "2板" and pos >= 4 and oh_risk <= 1 and lhb >= 0:
        base, grade = "重点候选B", "B+"
    elif stage == "首板" and pos >= 5 and strong_sector and lhb >= 1 and oh_risk <= 2:
        base, grade = "重点候选B", "B+"
    elif lhb_role == "负面" or oh_risk >= 3:
        base, grade = "风险观察", "C"
    elif pos >= 4 or lhb >= 1:
        base, grade = "重点观察", "B"
    else:
        base, grade = "次级观察", "B-"

    # 先应用市场/数据覆盖上限，再让个股风险在上限之下继续降级；避免“都被封顶后风险失效”。
    base = _apply_cap(base, candidate_cap)
    # 次新第6-19个交易日处于筹码成熟期，禁止按成熟样本升级。
    if recent_ipo_immature:
        base = _apply_cap(base, "重点观察")
        grade = "C+" if grade in {"A","B+"} else grade
    # 中等/高等级盘后风险必须实质影响结论，而不是只写在说明里。
    if event_risk_level >= 2:
        base = _downgrade(base, 2)
    elif event_risk_level == 1:
        base = _downgrade(base, 1)
    # 只有滚动样本外生产验收通过，且数据覆盖没有触发降级，才能把A类证据提升为核心。
    if base == "重点候选A" and candidate_cap == "核心候选" and market in {"强进攻", "正常轮动"} \
       and model_status.get("production_qualified") and history.get("available") and history.get("confidence") in {"中", "高"}:
        base = "核心候选"
    return base, grade


def analyze_stock(s: Dict[str, Any], market: str, candidate_cap: str, cfg: Dict[str, Any],
                  model: Dict[str, Any] | None, model_status: Dict[str, Any]) -> Dict[str, Any]:
    stage = classify_stage(s)
    ctx = resolve_context(s, cfg)
    sec_state, sec_reasons = ctx["state"], ctx["reasons"]
    position = derive_position(s, sec_state, core_rank=ctx.get("core_rank"), leader=ctx.get("leader"), capacity_core=ctx.get("capacity_core"))
    oh, oh_reasons = overheat(s, cfg)
    lhb_role, lhb_metrics, lhb_reasons = lhb_evidence(s, cfg)
    event_level, event_reasons = event_risk_evidence(s)
    hard = hard_vetoes(s, position, sec_state, oh, lhb_role)
    bucket = model_bucket(market, stage, position, sec_state, oh, lhb_role)
    hist = history_for_bucket(model, bucket, cfg, model_status)
    conclusion, grade = evidence_conclusion(
        stage, position, sec_state, oh, lhb_role, hard, market, candidate_cap,
        bool(s.get("new_unlimited")), bool(s.get("recent_ipo_immature")), event_level, hist, model_status
    )

    positive: List[str] = []
    negative: List[str] = []
    if stage in {"2板", "3板及以上"}:
        positive.append(f"已进入{stage}强势梯队")
    if POSITION_RANK.get(position, 0) >= 5:
        positive.append(f"市场/板块地位: {position}")
    if sec_state == "强势持续":
        positive.append(f"{ctx.get('basis','行业')}存在持续性证据")
    elif sec_state in {"弱势", "退潮"}:
        negative.append(f"{ctx.get('basis','行业')}状态: {sec_state}")
    if LHB_RANK.get(lhb_role, -9) >= 1:
        positive.append(f"龙虎榜只作为{lhb_role}证据")
    elif LHB_RANK.get(lhb_role, -9) < 0:
        negative.append(f"龙虎榜状态: {lhb_role}")
    if OVERHEAT_RISK.get(oh, 9) >= 2:
        negative.append(f"价格透支: {oh}")
    if s.get("recent_ipo_immature"):
        negative.append("上市第6-19个交易日：筹码尚未充分成熟，限制候选等级")
    if event_level > 0:
        negative.extend(event_reasons)
    else:
        # 正面催化只展示事实，不作为排序加分。
        positive.extend([x for x in event_reasons if "催化" in x])
    negative.extend(hard)

    # 席位质量只在成熟样本>=20时参与同层级细排，绝不越过阶段/地位/板块。
    seat_n = int(_f(lhb_metrics.get("seat_quality_samples")))
    seat_q = lhb_metrics.get("seat_quality_pctile_effective")
    seat_rank = _f(seat_q, -1.0) if seat_n >= 20 and seat_q is not None else -1.0
    lifecycle_rank = 1 if _f(lhb_metrics.get("lifecycle_event_no"),1) > 1 and bool(_f(lhb_metrics.get("lifecycle_net_improving"))) else 0
    hist_rank = {"高": 3, "中": 2, "低": 1}.get(hist.get("confidence"), 0)
    net_ratio = _f(lhb_metrics.get("net_buy_ratio"))
    sort_key = (
        CONCLUSION_RANK.get(conclusion, -9),
        STAGE_RANK.get(stage, 0),
        POSITION_RANK.get(position, 0),
        SECTOR_RANK.get(sec_state, 0),
        -OVERHEAT_RISK.get(oh, 9),
        -event_level,
        LHB_RANK.get(lhb_role, -9),
        seat_rank,
        lifecycle_rank,
        hist_rank,
        max(min(net_ratio, 0.20), -0.20),
    )
    return {
        "code": s.get("code"), "name": s.get("name"), "stage": stage,
        "sector": s.get("sector"), "context_basis": ctx.get("basis"), "context_name": ctx.get("name"),
        "sector_state": sec_state, "position": position,
        "lhb_role": lhb_role, "overheat": oh, "event_risk_level": event_level, "model_bucket": bucket,
        "evidence_grade": grade, "conclusion": conclusion,
        "positive_evidence": positive, "negative_evidence": negative,
        "hard_reject_reasons": hard, "history_stats": hist,
        "audit": {
            "context_reasons": sec_reasons, "overheat_reasons": oh_reasons, "lhb_reasons": lhb_reasons,
            "event_reasons": event_reasons, "lhb_metrics": lhb_metrics,
            "context": ctx, "raw_stock_feature_provenance": s.get("feature_provenance") or {},
        },
        "_sort_key": sort_key,
    }


def analyze_snapshot(data: Dict[str, Any], config: Dict[str, Any] | None = None, history_model: Dict[str, Any] | None = None) -> Dict[str, Any]:
    cfg = config or load_config()
    errors = validate_snapshot(data)
    if errors:
        raise ValueError("; ".join(errors))
    coverage = data.get("coverage") or {}
    state, candidate_cap, reasons, gate_method = resolve_market_gate(data["market"], cfg, coverage)
    pipeline=str(data.get("pipeline") or "manual/degraded")
    if pipeline != "raw-postmarket-v4.3-audited":
        candidate_cap=_cap_more_conservative(candidate_cap,"重点观察")
        reasons.append("输入不是V4.3已审计生产快照：禁止冒充完整管线，候选等级降至重点观察上限")
    model_status = validate_history_model(history_model, str(data["trade_date"]), cfg)
    rows = [analyze_stock(s, state, candidate_cap, cfg, history_model, model_status) for s in data["stocks"]]
    rows.sort(key=lambda x: x["_sort_key"], reverse=True)
    for i, r in enumerate(rows, 1):
        r["rank"] = i
        r.pop("_sort_key", None)
    workflow = list(data.get("workflow_trace") or [])
    workflow.append({"step":"市场总闸门","status":"完成","detail":f"{gate_method}；最终状态={state}；候选上限={candidate_cap}"})
    workflow.append({"step":"风险否决与最终排序","status":"完成","detail":"逐股执行事件风险、硬否决、证据字典序；无主观总分"})
    pipeline = data.get("pipeline", "manual/degraded")
    if str(pipeline)=="raw-postmarket-v4.3-audited" and bool((data.get("raw_data_audit") or {}).get("passed")):
        lookahead = "通过：原始数据审计已通过；输入字段、嵌套日期/时间通过T日截止校验；特征计算前已物理截断到T日。"
    else:
        lookahead = "仅通过输入快照字段/日期/时间检查；上游原始数据审计或生产标识不完整，已强制降级，禁止声明完整无泄漏生产链路。"
    return {
        "trade_date": data["trade_date"], "as_of": data["as_of"],
        "mode": "仅盘后；不使用盘中和集合竞价",
        "lookahead_check": lookahead,
        "pipeline": pipeline,
        "raw_data_audit": data.get("raw_data_audit") or {},
        "coverage": coverage,
        "workflow_trace": workflow,
        "market_state": state, "market_gate_method": gate_method, "market_reasons": reasons,
        "candidate_level_cap": candidate_cap,
        "history_model": model_status,
        "ranking_policy": "结构/地位/板块/透支优先，龙虎榜/成熟席位/历史样本仅在其后提供证据；证据字典序不是主观总分",
        "results": rows,
    }


def load_json(path: str | Path) -> Dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save_json(obj: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
