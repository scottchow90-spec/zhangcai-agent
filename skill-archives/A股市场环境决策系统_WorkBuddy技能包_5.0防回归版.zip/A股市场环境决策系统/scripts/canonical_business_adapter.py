"""输出本机既有回执协议，保留安装诊断与业务结论边界。"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import runtime
from local_business import validate_output_root

ROOT=Path(__file__).resolve().parents[1]
SKILL='a-share-market-environment'

def main():
    if os.environ.get('CODEX_STOCK_CANONICAL_EXECUTION')!='1':
        print(json.dumps({'status':'BLOCKED','errors':['canonical_execution_environment_missing']}));return 2
    ap=argparse.ArgumentParser(allow_abbrev=False);ap.add_argument('--run-dir',type=Path,required=True)
    ap.add_argument('--action',choices=['diagnose','validate-evidence','analyze'],required=True);ap.add_argument('--evidence-input')
    a=ap.parse_args();run=validate_output_root(a.run_dir);run.mkdir(parents=True,exist_ok=True)
    cmd=[sys.executable,'-B',str(ROOT/'scripts/legacy_codex_entry.py'),'--run-dir',str(run),'--action',a.action]
    if a.evidence_input:cmd+=['--evidence-input',a.evidence_input]
    env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',ONESTOCK_STOCK_CANONICAL_CHILD='1')
    cp=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=7200,env=env)
    stdout=run/'business_child.stdout.txt';stderr=run/'business_child.stderr.txt'
    stdout.write_text(cp.stdout,encoding='utf-8');stderr.write_text(cp.stderr,encoding='utf-8')
    errors=[]
    try:
        payload=json.loads(cp.stdout)
        persisted=json.loads((run/'local_result.json').read_text(encoding='utf-8'))
        if payload!=persisted:errors.append('child_result_readback_mismatch')
        errors.extend(payload.get('errors',[]))
    except (OSError,ValueError) as exc:payload={};errors.append(str(exc))
    if cp.returncode or payload.get('status')!='CLEAN_PASS':errors.append('child_not_clean')
    status='BLOCKED' if errors else 'CLEAN_PASS'
    manifest=run/'business_artifact_manifest.json';resultpath=run/'business_result.json'
    result={'schema':'STOCK_CANONICAL_BUSINESS_RESULT_V1','skill_id':SKILL,'status':status,
        'execution_purpose':'LOCAL_INSTALLATION_DIAGNOSTICS' if a.action=='diagnose' else ('DAILY_MARKET_RESEARCH' if a.action=='analyze' else 'EVIDENCE_FORMAT_VALIDATION'),
        'business_summary':{'action':a.action,'claim_scope':payload.get('claim_scope'),'full_workflow_completed':False},
        'business_process':{'command':cmd,'cwd':str(ROOT),'returncode':cp.returncode,'timed_out':False},
        'artifacts':{'stdout':str(stdout),'stderr':str(stderr),'local_result':str(run/'local_result.json'),'business_manifest':str(manifest)},
        'errors':errors}
    resultpath.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    paths=[stdout,stderr,resultpath,run/'local_result.json']
    if (run/'installation_tests.txt').is_file():paths.append(run/'installation_tests.txt')
    paths.extend(p for p in run.iterdir() if p.is_file() and p not in paths and p!=manifest)
    evidence=[{'name':p.stem,'path':str(p),'size':p.stat().st_size,'sha256':runtime.digest(p)} for p in paths if p.is_file()]
    manifest.write_text(json.dumps({'schema':'STOCK_BUSINESS_ARTIFACT_MANIFEST_V1','skill_id':SKILL,'status':status,
        'validation':{'status':status,'claim_scope':payload.get('claim_scope'),'full_workflow_completed':False},'artifacts':evidence,'errors':errors},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False));return 0 if status=='CLEAN_PASS' else 2

if __name__=='__main__':raise SystemExit(main())
