"""Read-only TDX daily bars and current TNF A-share universe.

No interpolation, corporate-action adjustment, historic universe inference or
network requests are performed. Volume is retained as the raw .day integer.
"""
from __future__ import annotations

import hashlib
import math
import struct
from datetime import date as calendar_date, datetime
from functools import lru_cache
from pathlib import Path

import pandas as pd

TDX_ROOT = Path(r"D:\TDX")
DAY_RECORD = struct.Struct("<IIIIIfII")
COLUMNS = ["date", "open", "high", "low", "close", "amount", "volume"]
PREFIXES = {"sh": ("600", "601", "603", "605", "688", "689"),
            "sz": ("000", "001", "002", "003", "300", "301")}


@lru_cache(maxsize=256)
def _date(value: str) -> int:
    parsed = datetime.strptime(value, "%Y-%m-%d")
    return int(parsed.strftime("%Y%m%d"))


@lru_cache(maxsize=32768)
def _validate_date(value: int) -> None:
    # The same trading dates occur in thousands of files. Cache only validated
    # calendar integers, never quotes, so all records still pass validation.
    if not 10000101 <= value <= 99991231:
        raise ValueError(f"invalid_date:{value}")
    try:
        calendar_date(value // 10000, value // 100 % 100, value % 100)
    except ValueError as exc:
        raise ValueError(f"invalid_date:{value}") from exc


def _stat_identity(stat) -> tuple:
    return (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)


def _read_stable(path: Path) -> bytes:
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    if _stat_identity(before) != _stat_identity(after) or len(raw) != after.st_size:
        raise ValueError(f"source_changed_during_read:{path}")
    return raw


def _parse_day(raw: bytes, target_date: str) -> pd.DataFrame:
    target = _date(target_date)
    if len(raw) % DAY_RECORD.size:
        raise ValueError(f"invalid_day_length:{len(raw)}")
    rows = []
    last = 0
    for values in DAY_RECORD.iter_unpack(raw):
        date, op, hi, lo, cl, amount, volume, _reserved = values
        _validate_date(date)
        if date <= last:
            raise ValueError(f"non_monotonic_or_duplicate_date:{date}")
        last = date
        # These four values are unsigned integers by the binary format.
        if op == 0 or hi == 0 or lo == 0 or cl == 0:
            raise ValueError(f"invalid_ohlc:{date}")
        if lo > min(op, cl) or hi < max(op, cl) or lo > hi:
            raise ValueError(f"inconsistent_ohlc:{date}")
        if not math.isfinite(amount) or amount < 0:
            raise ValueError(f"invalid_amount:{date}")
        if date <= target:
            rows.append((date, op / 100, hi / 100, lo / 100, cl / 100,
                         float(amount), int(volume)))
    result = pd.DataFrame(rows, columns=COLUMNS)
    return result.astype({"date": "int64", "volume": "int64"})


def read_day(path: str | Path, target_date: str, *, expected_sha256: str | None = None) -> pd.DataFrame:
    """Validate every physical record; return observed bars through target date.

    Prices are yuan (stored integer / 100), amount is the stored yuan float,
    volume is the original stored share count without lots conversion. This is
    an unadjusted quote reader, not a point-in-time adjusted-price provider.
    """
    path = Path(path)
    raw = _read_stable(path)
    source = _source(path, raw, "unadjusted_daily_bars")
    if expected_sha256 is not None and source["sha256"] != expected_sha256:
        raise ValueError(f"source_hash_changed_since_pool:{path}")
    frame = _parse_day(raw, target_date)
    frame.attrs["source"] = source
    return frame


def _source(path: Path, raw: bytes, kind: str) -> dict:
    return {"path": str(path.resolve()), "sha256": hashlib.sha256(raw).hexdigest(),
            "byte_length": len(raw), "kind": kind}


def list_current_pool(target_date: str, *, tdx_root: str | Path | None = None) -> dict:
    """Return every applicable current-TNF A-share as eligible or excluded.

    Each file hash binds precisely the bytes parsed in this invocation. Day
    frames are discarded between securities; no full-market price cache lives
    here. A source read/parse failure remains visible as exclusion evidence.
    """
    target = _date(target_date)
    root = Path(tdx_root) if tdx_root is not None else TDX_ROOT
    eligible, excluded, sources = [], [], []
    total = 0
    seen = set()
    for market in ("sh", "sz"):
        metadata = root / "T0002" / "hq_cache" / f"{market}s.tnf"
        raw = _read_stable(metadata)
        sources.append(_source(metadata, raw, "current_security_metadata"))
        if len(raw) < 50 or (len(raw) - 50) % 360:
            raise ValueError(f"invalid_tnf_length:{metadata}:{len(raw)}")
        for offset in range(50, len(raw), 360):
            record = raw[offset:offset + 360]
            code = record[:6].decode("ascii", errors="replace")
            if not (len(code) == 6 and code.isascii() and code.isdigit()
                    and code.startswith(PREFIXES[market])):
                continue
            total += 1
            symbol = f"{market}{code}"
            base = {"symbol": symbol, "metadata_path": str(metadata),
                    "metadata_offset": offset}
            if symbol in seen:
                excluded.append({**base, "reason": "duplicate_current_metadata_record"})
                continue
            seen.add(symbol)
            try:
                # Name starts at 31. Read through its NUL terminator, without
                # clipping a GBK character at an arbitrary short byte boundary.
                end = record.find(b"\0", 31, 96)
                if end < 0:
                    raise ValueError("missing_name_terminator_within_field_boundary")
                name = record[31:end].decode("gbk", errors="strict").strip()
                if not name:
                    raise ValueError("empty_name")
            except (UnicodeError, ValueError) as exc:
                excluded.append({**base, "reason": "invalid_security_name", "detail": str(exc)})
                continue
            base["name"] = name
            upper = name.upper()
            if upper.startswith(("ST", "*ST", "S")) or "退" in name:
                excluded.append({**base, "reason": "current_name_risk_or_delisting_marker"})
                continue
            path = root / "vipdoc" / market / "lday" / f"{symbol}.day"
            base["path"] = str(path)
            try:
                data = _read_stable(path)
                day_source = _source(path, data, "unadjusted_daily_bars")
                sources.append(day_source)
                frame = _parse_day(data, target_date)
            except FileNotFoundError:
                excluded.append({**base, "reason": "day_file_missing"})
                continue
            except (OSError, ValueError) as exc:
                excluded.append({**base, "reason": "day_read_or_validation_failed", "detail": str(exc)})
                continue
            if frame.empty or int(frame.iloc[-1]["date"]) != target:
                excluded.append({**base, "reason": "no_target_day_record_not_proven_suspension",
                                 "last_observed_date": None if frame.empty else int(frame.iloc[-1]["date"])})
                continue
            if len(frame) < 6:
                excluded.append({**base, "reason": "fewer_than_six_bars_initial_listing_regime_unknown",
                                 "observed_bar_count": len(frame)})
                continue
            eligible.append({"symbol": symbol, "market": market, "code": code,
                             "name": name, "path": str(path), "observed_bar_count": len(frame),
                             "sha256": day_source["sha256"]})
    return {"target_date": target_date, "eligible": eligible, "excluded": excluded,
            "sources": sources, "current_tnf_applicable_record_count": total,
            "current_tnf_unique_symbol_count": len(seen),
            "caveats": ["当前TNF只代表本次读取的证券名录，不是历史时点证券池。",
                        "名称风险标识来自当前TNF，不代表目标历史日状态。",
                        "本地首条行情不是经核验的上市日期；公司行为和复权因子未知。",
                        "无目标日记录可能是停牌、退市、数据缺失等，不能直接判定停牌。",
                        "不足六条历史记录剔除；六条及以上也不构成上市制度已独立核验。",
                        "价格为未复权元，成交额保留文件原始元值；成交量保留原始股数，不作手数转换。",
                        "逐证券字节哈希绑定读入数据；跨文件不是原子冻结快照。"]}
