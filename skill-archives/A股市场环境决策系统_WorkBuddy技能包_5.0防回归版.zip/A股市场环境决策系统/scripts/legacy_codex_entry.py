"""受保护的统一入口子进程；名称沿用本机合同接口。"""
import json
import os
import sys

def main():
    if os.environ.get('CODEX_STOCK_CANONICAL_EXECUTION')!='1' or os.environ.get('ONESTOCK_STOCK_CANONICAL_CHILD')!='1':
        print(json.dumps({'status':'BLOCKED','errors':['canonical_stock_legacy_entry_direct_execution_blocked']}))
        return 2
    from local_business import main as business_main
    return business_main()

if __name__=='__main__':raise SystemExit(main())
