"""5.0.1 包内规则与证据校验。仅标准库；不联网、不下单、不控制桌面。

数值函数校验规则一致性，不证明行情真实性或原公式解释器一致性。
CLI 成功仅代表包/证据结构校验通过，不能单独授予正式交易结论资格。
"""
import argparse
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re

VERSION = '5.0.1——原包深度审计修正版'
AXES = ('breadth', 'emotion', 'technical', 'liquidity')
WEIGHTS = dict(breadth=.25, emotion=.20, technical=.25, liquidity=.10, structure=.10, policy=.10)
TECH_WEIGHTS = (.27,.18,.10,.16,.09,.20)
CATEGORIES = ('趋势结构类','动能与强弱类','波动与关键位置类','启动与反转类','平台与突破形态类','强势股生态与情绪结构类','量价、成本与股票池辅助类')
CAPS = (0,10,30,50,70)
# 等级：0暂停/仅观察，1小仓试错/小仓观察，2谨慎，3精选，4允许。
POLICIES = {
    1: (70,[4,4,3,4,3,4]), 2: (50,[3,3,2,3,2,4]),
    3: (30,[3,2,0,3,0,3]), 4: (10,[0,0,0,0,0,1]),
    5: (10,[1,0,0,1,0,1]), 6: (0,[0]*6), 7: (0,[0]*6),
}
IDS = [f'一-{i:02}' for i in range(1,30)]+[f'二-{i:02}' for i in range(1,19)]

def number(v, lo=0, hi=100):
    if isinstance(v,bool) or not isinstance(v,(float,int)) or not math.isfinite(v) or not lo<=v<=hi:
        raise ValueError('数值非法/非有限数/越界')
    return v

def ratio(n,d):
    number(n,0,float('inf')); number(d,0,float('inf'))
    return n/d if d else None

def weighted20(ohlc):
    """按旧到新恰好20条 (O,H,L,C)，验证修正X；不是完整公式解释器。"""
    if len(ohlc)!=20:return None
    values=[]
    for o,h,l,c in ohlc:
        for x in (o,h,l,c):number(x,0,float('inf'))
        if l>min(o,c) or h<max(o,c):raise ValueError('OHLC不合法')
        values.append((3*c+l+o+h)/6)
    return sum((i+1)*v for i,v in enumerate(values))/210

def platform_breakout(closes):
    """64条以上旧到新收盘，验证PL修正及向上离开门。"""
    if len(closes)<64:return None
    for x in closes:number(x,0,float('inf'))
    def deviations(end):
        c=closes[end];m54=sum(closes[end-53:end+1])/54;m10=sum(closes[end-9:end+1])/10
        if m54<=0 or m10<=0:raise ValueError('均线分母无效')
        return (c-m54)/m54,(c-m10)/m10
    end=len(closes)-1
    ds=[deviations(i) for i in range(end-10,end)]
    a,b=deviations(end)
    return all(0<=x<.1 and 0<=y<.3 for x,y in ds) and a>=0 and b>=0 and (a>=.1 or b>=.3)

def filtered_breakout(base,confirmed,span=13):
    """X53在FILTER前：基础链与突破均为布尔输入，旧到新。"""
    if len(base)!=len(confirmed) or type(span)!=int or span<0:raise ValueError('过滤输入非法')
    result=[];last=-span-1
    for i,(a,b) in enumerate(zip(base,confirmed)):
        if type(a)!=bool or type(b)!=bool:raise ValueError('过滤输入须布尔')
        hit=a and b and i-last>span
        result.append(hit)
        if hit:last=i
    return result

def percentile(value, history):
    """history 必须由调用方提供当日前120个交易日，严禁包含当日。"""
    number(value,-float('inf'),float('inf'))
    if len(history)!=120 or any(x is None for x in history): return None
    for x in history: number(x,-float('inf'),float('inf'))
    return 100*(sum(x<value for x in history)+.5*sum(x==value for x in history))/120

def category(nodes):
    """输入固定主节点清单 (score,coverage)，缺失必须 (None,0)。"""
    if not nodes: raise ValueError('类别固定分母不能为空')
    total=weighted=0
    for score,c in nodes:
        number(c,0,1)
        if (c==0)!=(score is None): raise ValueError('缺失与分数矛盾')
        if c:
            number(score);total+=c;weighted+=c*score
    coverage=total/len(nodes)
    return {'coverage':coverage,'observed':weighted/total if total else None,
            'effective':(weighted+50*(len(nodes)-total))/len(nodes)}

def direction(score):
    number(score)
    return 1 if score>=60 else -1 if score<40 else 0

def resonance(categories):
    if len(categories)!=6: raise ValueError('必须六个方向类')
    cov=sum(w*x['coverage'] for w,x in zip(TECH_WEIGHTS,categories))
    if cov<.70 or categories[0]['coverage']<.5: return 0
    signs=[direction(x['effective']) if x['coverage']>=.5 else 0 for x in categories]
    for sign in (1,-1):
        if signs.count(sign)>=4 and signs[0]!=-sign: return sign
    return 0

def health(values):
    lower=coverage=0
    for k,w in WEIGHTS.items():
        x=values.get(k)
        if x is not None:
            number(x);lower+=w*x;coverage+=w
    coverage=round(coverage,12)
    return {'score':lower if coverage==1 else None,'coverage':coverage,
            'lower':lower,'upper':lower+100*(1-coverage)}

def speed(today,yesterday,three_days_ago):
    keys=[k for k in AXES if all(x.get(k) is not None for x in (today,yesterday,three_days_ago))]
    if len(keys)<3:return None
    means=[]
    for row in (today,yesterday,three_days_ago):
        means.append(sum(number(row[k]) for k in keys)/len(keys))
    v=.6*(means[0]-means[1])+.4*(means[0]-means[2])/3
    label='快速改善' if v>=10 else '改善' if v>=3 else '稳定' if v>-3 else '恶化' if v>-10 else '快速恶化'
    return {'value':v,'label':label,'axes':keys}

def risk_gates(up,prev_up,down_rate,down_history,down_count,count_history,weak_indices,broken_indices,amount_ratio,last3_amounts,systemic=None):
    """比例用0..1；下跌停历史不含当日；后三日成交额按旧到新。"""
    for x in (up,prev_up,down_rate):
        if x is not None:number(x,0,1)
    if type(systemic) not in (bool,type(None)):raise ValueError('事件必须三态')
    breadth=None if up is None or prev_up is None else up<=.2 and prev_up-up>=.1-1e-12
    shock=None
    if down_rate is not None and down_count is not None and len(down_history)==120 and len(count_history)==20 and all(x is not None for x in down_history+count_history):
        for x in down_history:number(x,0,1)
        for x in [down_count]+count_history:number(x,0,float('inf'))
        # 最近秩法：ceil(.95*120)=114；严格高于，不用百分位中秩代替。
        q95=sorted(down_history)[113]
        v=sorted(count_history);median=(v[9]+v[10])/2
        shock=down_rate>q95 and down_count>2*median
    broken=None
    if weak_indices is not None and broken_indices is not None and up is not None:
        for x in (weak_indices,broken_indices):
            number(x,0,8)
            if int(x)!=x:raise ValueError('指数计数必须整数')
        broken=weak_indices>=6 and broken_indices>=4 and up<=.25
    liquidity=None
    if amount_ratio is not None and up is not None and prev_up is not None and len(last3_amounts)==3 and all(x is not None for x in last3_amounts):
        number(amount_ratio,0,float('inf'))
        for x in last3_amounts:number(x,0,float('inf'))
        liquidity=amount_ratio<.7 and last3_amounts[0]>last3_amounts[1]>last3_amounts[2] and up<prev_up
    return [breadth,shock,broken,liquidity,systemic]

def candidate(h,b,e,t,s,index_nonweak,gates,repair):
    if type(repair)!=bool or type(index_nonweak) not in (bool,type(None)):raise ValueError('状态资格须布尔，指数未知用None')
    if len(gates)!=5 or any(type(x) not in (bool,type(None)) for x in gates):raise ValueError('五闸三态非法')
    for x in (h,b,e,t,s):
        if x is not None:number(x)
    if gates[4] is True or (sum(x is True for x in gates)>=2 and gates[2] is True):return 7
    if h is not None and b is not None and e is not None and h<25 and b<=20 and e<=20:return 7
    if any(x is True for x in gates):return 6
    if h is not None and h<40 and ((b is not None and b<45) or (e is not None and e<40)):return 6
    if b is not None and e is not None and b<=25 and e<=25:return 6
    if any(x is None for x in gates) or any(x is None for x in (h,b,e,t,s)):return None
    if s<=30 and (b<=45 or t<40) and index_nonweak is None:return None
    if s<=30 and index_nonweak and (b<=45 or t<40):return 4
    if repair:return 5
    if h>=75 and b>=65 and e>=60 and t>=65:return 1
    if h>=65 and b>=50 and t>=60:return 2
    if h>=50:return 3
    return 4

def permissions(state,previous,upgrade,mode,blocked):
    if type(upgrade)!=bool or type(blocked)!=bool:raise ValueError('资格字段须布尔')
    if mode not in ('final','instant','morning','backtest'):raise ValueError('模式非法')
    if blocked or state is None:return {'cap':0,'strategies':[0]*6}
    if type(state)!=int or state not in POLICIES:raise ValueError('状态非法')
    cap,strategies=POLICIES[state];strategies=list(strategies)
    if previous is None:
        return {'cap':0,'strategies':[0]*6}
    pc=previous['cap'];ps=previous['strategies']
    if pc not in CAPS or len(ps)!=6 or any(type(x)!=int or x not in range(5) for x in ps):raise ValueError('历史权限非法')
    allow=upgrade and mode=='final'
    limit=CAPS[min(CAPS.index(pc)+int(allow),len(CAPS)-1)]
    return {'cap':min(cap,limit),'strategies':[min(x,y+int(allow),4) for x,y in zip(strategies,ps)]}

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def safe_child(root,name):
    if not isinstance(name,str) or '\\' in name:raise ValueError('路径必须相对正斜线')
    p=PurePosixPath(name)
    if not name or p.is_absolute() or '..' in p.parts or ':' in name:raise ValueError('不安全路径')
    result=root.joinpath(*p.parts)
    if not result.resolve().is_relative_to(root.resolve()):raise ValueError('路径越界')
    if any(x.is_symlink() or (hasattr(x,'is_junction') and x.is_junction()) for x in [result,*list(result.parents)[:len(p.parts)-1]]):raise ValueError('拒绝重解析路径')
    return result

def package_errors(root):
    root=Path(root);errors=[]
    try:
        m=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
        if m['版本']!=VERSION:errors.append('版本不匹配')
        seen=set()
        for item in m['files']:
            name=item['path'];p=safe_child(root,name)
            if name.casefold() in seen:errors.append('重复清单路径:'+name)
            seen.add(name.casefold())
            if not p.is_file() or digest(p)!=item['sha256']:errors.append('哈希失败:'+name)
        actual={p.relative_to(root).as_posix().casefold() for p in root.rglob('*') if p.is_file() and p!=root/'manifest.json'}
        if actual!=seen:errors.append('清单与实际文件集合不同')
    except (ValueError,KeyError,TypeError,OSError) as exc:errors.append('完整性异常:'+str(exc))
    return errors

def stamp(value):
    t=datetime.fromisoformat(value)
    if t.tzinfo is None:raise ValueError('时间戳必须包含时区')
    return t

def run_errors(run,root):
    """证据格式与可复算约束。成功不代表来源真实、公式正确或人工复核通过。"""
    errors=[]
    try:
        if run['version']!=VERSION:errors.append('运行版本不匹配')
        if run['mode'] not in ('final','instant','morning','backtest'):errors.append('模式非法')
        cutoff=stamp(run['decision_at'])
        if not run['pool_id'] or not run['mapping_version'] or not run['formula_version']:errors.append('版本或池标识缺失')
        artifacts=run['artifacts'];known=set()
        if not artifacts:errors.append('无证据文件')
        for a in artifacts:
            if a['id'] in known:errors.append('证据ID重复')
            known.add(a['id'])
            p=safe_child(Path(root),a['path'])
            if not p.is_file() or digest(p)!=a['sha256']:errors.append('证据哈希失败:'+a['id'])
            if not a['source'] or stamp(a['available_at'])>cutoff or stamp(a['data_at'])>cutoff:errors.append('来源缺失或未来信息:'+a['id'])
        def linked(item):
            refs=item.get('evidence',[])
            return bool(refs) and all(x in known for x in refs)
        steps=run['steps']
        if len(steps)!=21 or {x['id'] for x in steps}!=set(range(1,22)):errors.append('21步缺失或重复')
        for step in steps:
            if step['status']!='完成' or not linked(step):errors.append('步骤未完成/缺证据:'+str(step['id']))
        nodes=run['nodes']
        if len(nodes)!=47 or {x['id'] for x in nodes}!=set(IDS):errors.append('47节点缺失或重复')
        required=('result','basis','explanation','impact','data_status')
        for node in nodes:
            if any(not isinstance(node.get(k),str) or not node[k].strip() for k in required) or not linked(node):errors.append('节点五字段/证据缺失:'+node['id'])
            if node['data_status']=='数据不足' and any(not node.get(k) for k in ('missing_fields','reason','forbidden_substitute','restriction')):errors.append('缺失说明不全:'+node['id'])
        if len(run['categories'])!=7 or {x['name'] for x in run['categories']}!=set(CATEGORIES):errors.append('七类别缺失或重复')
        gates=run['gates']
        if len(gates)!=5 or {x['id'] for x in gates}!=set(range(1,6)) or any(type(x.get('triggered'))!=bool or not linked(x) for x in gates):errors.append('风险闸门未完整核验')
        computed=health(run['scores'])
        if computed['score'] is None or not math.isclose(computed['score'],number(run['health']),abs_tol=1e-8):errors.append('健康度缺失或不一致')
        rows=run['axis_history']
        if len(rows)!=4:errors.append('须有连续四交易日的同口径四轴证据')
        else:
            dates=[x['trade_date'] for x in rows]
            if dates!=run['trading_days'][-4:] or len(set(dates))!=4:errors.append('交易日历不连续/重复')
            if any(x['mapping_version']!=run['mapping_version'] or x['pool_id']!=run['pool_id'] or not linked(x) for x in rows):errors.append('四轴口径或证据不一致')
            computed_speed=speed(rows[3]['scores'],rows[2]['scores'],rows[0]['scores'])
            if computed_speed is None or not math.isclose(computed_speed['value'],number(run['speed'],-100,100),abs_tol=1e-8):errors.append('速度缺失或不一致')
        previous=run['previous']
        if previous['trade_date']!=run['trading_days'][-2] or previous['mode']!='final' or not linked(previous):errors.append('前交易日正式基准缺失')
        if len(run['regression_checks'])!=42 or {x['id'] for x in run['regression_checks']}!=set(range(1,43)) or any(x.get('status')!='通过' or not linked(x) for x in run['regression_checks']):errors.append('42项回归检查缺失/重复/缺证据')
        if run['is_example']:errors.append('示例不得作为实跑')
    except (ValueError,KeyError,TypeError,IndexError,OSError,OverflowError) as exc:errors.append('证据格式异常:'+str(exc))
    return errors

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['check-package','check-run'])
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--run',type=Path)
    args=parser.parse_args()
    errors=package_errors(args.root)
    if args.command=='check-run':
        if args.run is None:errors.append('缺少 --run')
        else:
            try:errors+=run_errors(json.loads(args.run.read_text(encoding='utf-8')),args.run.resolve().parent)
            except (OSError,ValueError) as exc:errors.append(str(exc))
    print(json.dumps({'status':'BLOCKED' if errors else 'CHECK_PASS','errors':errors,
        'scope':'仅包完整性/证据格式校验，不是行情真实性、公式一致性、宿主安装或交易资格验收'},ensure_ascii=False,indent=2))
    return 1 if errors else 0

if __name__=='__main__':raise SystemExit(main())
