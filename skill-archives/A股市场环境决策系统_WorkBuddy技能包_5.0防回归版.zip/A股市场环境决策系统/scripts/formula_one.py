"""Formula one, engineering replay v1, NOT host-interpreter equivalence.

Input is complete available, ascending daily OHLC history. EMA/SMA seed at
first finite input; internal missing bars propagate permanently in recursion.
Volume must be lots (100 shares), amount CNY. No imputation of dynamic fields.
"""
import numpy as np
import pandas as pd

SEMANTICS = 'python-engineering-v1; EMA/SMA:first-valid; STD:ddof0; KDJ:9/3/3:seed50'

def smooth(s, alpha, seed=None):
    s=pd.to_numeric(s,errors='coerce').replace([np.inf,-np.inf],np.nan)
    valid=s.notna(); started=valid.cummax(); broken=(started & ~valid).cummax()
    values=s.copy()
    if seed is not None and valid.any():
        first=np.flatnonzero(valid.to_numpy())[0]
        values.iloc[first]=alpha*values.iloc[first]+(1-alpha)*seed
    return values.ewm(alpha=alpha,adjust=False,ignore_na=False).mean().mask(broken)

def ema(s, n): return smooth(s, 2/(n+1))
def ma(s, n): return s.rolling(n, min_periods=n).mean()
def div(a,b): return a / b.where(np.isfinite(b) & (b>0))
def cross(a,b):
    good = a.notna() & b.notna() & a.shift().notna() & b.shift().notna()
    return ((a>b)&(a.shift()<=b.shift())).astype(float).where(good)

def filtered(s, n):
    """Set-valued state: unknown triggers can suppress N following bars."""
    states={0}; out=[]
    for x in s:
        choices=[False,True] if not np.isfinite(x) else [bool(x)]
        ns=set(); emitted=set()
        for remaining in states:
            for hit in choices:
                fire=remaining==0 and hit
                emitted.add(fire); ns.add(n if fire else max(0,remaining-1))
        out.append(float(next(iter(emitted))) if len(emitted)==1 else np.nan)
        states=ns
    return pd.Series(out,index=s.index,dtype=float)

def golden(frame):
    """Exact source candidate order/spacing, evaluated only at this cutoff."""
    if len(frame)<60: return {'support':None,'resistance':None}
    c=float(frame.close.iloc[-1]); h=frame.high; l=frame.low
    vh=float(h.tail(120).max()); vl=float(l.tail(120).min()); vr=vh-vl
    if vr<=0: return {'support':None,'resistance':None}
    lo=max(.01,vl-vr*.30); hi=vh+vr*.30
    gap=max(vr*.12,c*.03); buf=max(vr*.025,c*.012)
    sets=[]
    for count in (len(frame),250,120):
        top=float(h.tail(count).max()); bot=float(l.tail(count).min())
        levels=[bot]+[bot+(top-bot)*r for r in (.236,.382,.5,.618,.786)]+[top]
        rs=[x for x in levels[1:] if x>c]
        ss=[x for x in reversed(levels[:-1]) if x<c]
        def pick(xs):
            first=xs[0] if xs else np.nan
            second=xs[1] if len(xs)>1 else np.nan
            third=xs[2] if len(xs)>2 else np.nan
            return (first,second if abs(second-first)>=gap else third)
        r1,r2=pick(rs); s1,s2=pick(ss); sets.append((r1,r2,s1,s2))
    chosen=[]
    for j in range(4):
        def ok(row):
            x=row[j]
            return lo<=x<=hi and (j not in (1,3) or (x>row[0] if j==1 else x<row[2]))
        chosen.append(next((row[j] for row in sets[:2] if ok(row)),sets[2][j]))
    r1,r2,s1,s2=chosen
    r=r1 if r1>=c+buf else r2 if r2>=c+buf else np.nan
    s=s1 if s1<=max(.01,c-buf) else s2 if s2<=max(.01,c-buf) else np.nan
    return {'support':float(s) if lo<=s<=hi else None,
            'resistance':float(r) if lo<=r<=hi else None}

def compute(frame):
    results={f'一-{i:02d}':dict(score=None,coverage=0.,value=None,
        reason='缺少该节点所需历史属性或动态字段',triggered=None) for i in range(1,30)}
    if frame.empty: return results
    f=frame.reset_index(drop=True)
    required=['open','high','low','close','volume','amount']
    if any(k not in f for k in required): return results
    if 'date' in f:
        dates=pd.to_datetime(f['date'].astype(str),errors='coerce')
        if dates.isna().any() or dates.duplicated().any() or not dates.is_monotonic_increasing:
            for r in results.values():r['reason']='日线日期无效、重复或未升序；拒绝自动重排'
            return results
    for key in required: f[key]=pd.to_numeric(f[key],errors='coerce').replace([np.inf,-np.inf],np.nan)
    o,h,l,c,v,amount=(f[k] for k in required)
    price_ok=np.isfinite(f[['open','high','low','close']]).all().all() and (f[['open','high','low','close']]>0).all().all()
    if not price_ok or ((h<l)|(h<c)|(h<o)|(l>c)|(l>o)).any():
        for r in results.values(): r['reason']='日线价格缺失、非正数或OHLC关系不合法'
        return results
    def put(n,score=None,value=None,coverage=1.,triggered=None,reason='完整可得日线连续Python工程重放；未验证宿主同源'):
        results[f'一-{n:02d}']=dict(score=score,coverage=coverage,value=value,reason=reason,triggered=triggered)
    def line(n,lines):
        valid=[s for s in lines if len(s)>1 and np.isfinite(s.iloc[-2:]).all()]
        if valid:
            scores=[50+25*(np.sign(c.iloc[-1]-s.iloc[-1])+np.sign(s.iloc[-1]-s.iloc[-2])) for s in valid]
            put(n,float(np.mean(scores)),[float(s.iloc[-1]) if np.isfinite(s.iloc[-1]) else None for s in lines],len(valid)/len(lines))
    def event(n,s,negative=False,value=None):
        if len(s) and np.isfinite(s.iloc[-1]):
            yes=bool(s.iloc[-1]);put(n,(0. if negative else 100.) if yes else 50.,value,triggered=yes)
    line(1,[ema(ema(c,10),10)])
    line(2,[ema(c,n) for n in (5,10,20)])
    line(5,[ema(c,n).where(np.arange(len(c))>=n-1) for n in (173,193,213)])
    a0=(3*c+l+o+h)/6
    x=a0.rolling(20).apply(lambda a: np.dot(a,np.arange(1,21))/210,raw=True)
    line(7,[x])
    mtm=c.diff(); dx=100*div(ema(ema(mtm,6),6),ema(ema(mtm.abs(),6),6)); dxma=ma(dx,2)
    valid=dx.rolling(7).count().eq(7)&dxma.shift().notna()
    sell=((dx.rolling(2).max()==dx.rolling(7).max()) & (dx.gt(50).rolling(2).sum()>0) & (cross(dxma,dx)==1)).astype(float).where(valid)
    buy=((dx.rolling(2).min()==dx.rolling(7).min()) & (dx.lt(0).rolling(2).sum()>0) & (cross(dx,dxma)==1)).astype(float).where(valid)
    event(8,filtered(sell,1),True);event(9,filtered(buy,5))
    control=1000*div(ema(ema(c,13),13).diff(),ema(ema(c,13),13).shift())
    if len(c)>2 and np.isfinite(control.iloc[-2:]).all():
        put(10,float(50+25*(np.sign(control.iloc[-1])+np.sign(control.iloc[-1]-control.iloc[-2]))),float(control.iloc[-1]))
    line(13,[ma(c,n) for n in (5,10,20,30,48,54,60,120)])
    hj8=(100*div(c.shift(3)-c,c.shift(3))>5).astype(float).where(c.shift(3).notna())
    hj9=filtered(hj8,10); last=None; raw=np.full(len(c),np.nan)
    for i in range(len(c)):
        if not np.isfinite(hj9.iloc[i]): last=None
        elif hj9.iloc[i]==1: last=i
        if last is None or last<2 or i<89: continue
        age=i-last; refhigh=float(h.iloc[last-2:last+1].max())
        low=float(l.iloc[:i+1].min() if age==0 else l.iloc[i-age+1:i+1].min())
        vm=v.iloc[i-4:i+1].mean()
        if not np.isfinite(v.iloc[i-4:i+1]).all() or vm<=0 or (v.iloc[i-4:i+1]<0).any(): continue
        raw[i]=float((c.iloc[i]-c.iloc[i-1])/c.iloc[i-1]*100>5 and age<150 and (o.iloc[i]-refhigh)/refhigh*100<30 and (c.iloc[i]-low)/low*100<50 and (c.iloc[i]-o.iloc[i-5])/o.iloc[i-5]*100<30 and v.iloc[i]/vm<3.5 and (c.iloc[i]-c.iloc[i-89])/c.iloc[i-89]*100<80)
    event(14,filtered(pd.Series(raw),15))
    d54=div(c-ma(c,54),ma(c,54));d10=div(c-ma(c,10),ma(c,10))
    plat=((d54>=0)&(d54<.1)&(d10>=0)&(d10<.3)).astype(float).where(d54.notna()&d10.notna())
    breakout=((plat==0)&(plat.shift()==1)&(plat.shift().rolling(10).sum()==10)&(d54>=0)&(d10>=0)&((d54>=.1)|(d10>=.3))).astype(float).where(plat.shift().rolling(10).count()==10)
    event(15,breakout)
    ratio=div(v,v.shift()); strong=((div(c,c.shift())>=1.07)&(ratio<1)).astype(float).where(ratio.notna() & c.shift().notna() & (v>=0))
    event(17,strong)
    if frame.attrs.get('volume_unit')=='lots' and frame.attrs.get('amount_unit')=='CNY' and v.iloc[-1]>0 and amount.iloc[-1]>=0 and np.isfinite(amount.iloc[-1]):
        put(18,value=float(amount.iloc[-1]/v.iloc[-1]/100))
    else: results['一-18']['reason']='成交量手/成交额元单位标记缺失或数值无效'
    line(19,[sum(ma(c,n) for n in (3,6,12,24))/4])
    strength=[100*div(smooth(mtm.clip(lower=0),1/n),smooth(mtm.abs(),1/n)) for n in (2,14)]
    scores=[];vals=[]
    for s in strength:
        z=s.iloc[-1];vals.append(float(z) if np.isfinite(z) else None)
        if np.isfinite(z): scores.append(float(np.select([z<20,z<45,z<50,z<80],[0,25,50,75],default=100)))
    if scores: put(20,float(np.mean(scores)),vals,len(scores)/2)
    boll=ma(c,20);line(23,[boll])
    if results['一-23']['coverage']:
        width=4*c.rolling(20).std(ddof=0)
        results['一-23']['value']={'mid':float(boll.iloc[-1]),'width':float(width.iloc[-1]),'expanding':bool(width.iloc[-1]>width.iloc[-2])}
    results['一-24']['reason']='日线不含历史题材行业主营文本；解释节点不评分'
    results['一-25']['reason']='原150周期混合分母随机值退出评分，按合同不执行'
    low9=l.rolling(9).min();high9=h.rolling(9).max();rsv=100*div(c-low9,high9-low9)
    k=smooth(rsv,1/3,50.);d=smooth(k,1/3,50.);j=3*k-2*d
    kd=((k>d)&(j>d)&(j>k)).astype(float).where(k.notna()&d.notna()&j.notna())
    event(26,kd,value={'K':float(k.iloc[-1]) if np.isfinite(k.iloc[-1]) else None,'D':float(d.iloc[-1]) if np.isfinite(d.iloc[-1]) else None,'J':float(j.iloc[-1]) if np.isfinite(j.iloc[-1]) else None,'config':'explicit-fixed-revision-9/3/3-seed50'})
    event(28,cross(ema(c,3),ema(c,21)))
    current=golden(f);previous=golden(f.iloc[:-1]);parts=[]
    if previous['support'] is not None: parts.append(0. if c.iloc[-1]<previous['support'] else 50.)
    if previous['resistance'] is not None: parts.append(100. if c.iloc[-1]>previous['resistance'] else 50.)
    if parts:
        # Both available boundaries form one 0/50/100 event. A single line is half coverage.
        score=0. if 0. in parts else 100. if 100. in parts else 50.
        put(29,score,{'current':current,'previous_locked':previous,'history_scope':'完整可得日线；不证明自上市完整'},len(parts)/2,
            reason='黄金全历史分支取输入全部可得记录，120/250自适应；前日截断锁线；不证明发行以来完整或宿主同源')
    else: results['一-29']['value']={'current':current,'previous_locked':previous}
    for n in (3,6,21,22):results[f'一-{n:02d}']['reason']='缺少历史合法涨跌停参考价及当时制度；不使用固定百分比伪造'
    for n in (11,12):results[f'一-{n:02d}']['reason']='缺少完整历史DYNAINFO(11)均价及其过滤递推状态'
    results['一-16']['reason']='缺少历史动态现价DYNAINFO(7)与制度输入'
    for n in (4,27):results[f'一-{n:02d}']['reason']='缺少当时流通盘CAPITAL、属性及上市资格；不能用今日快照回填'
    if not frame.attrs.get('history_complete',False):
        for n in (1,2,5,8,9,10,14,20,26,28,29):
            r=results[f'一-{n:02d}'];r['coverage']=0.
            r['reason']+='；锁定工程起点以来完整可得历史未确认，值仅展示'
    return results
