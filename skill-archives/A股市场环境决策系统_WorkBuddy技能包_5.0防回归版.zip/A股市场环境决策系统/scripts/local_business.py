"""本机安装诊断和原证据格式核验；不冒充47公式行情执行器。"""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import runtime

ROOT=Path(__file__).resolve().parents[1]
HOME=Path(r'F:\Codex\Home')

def validate_output_root(path):
    p=Path(path).resolve()
    if p==ROOT or p.is_relative_to(ROOT):raise ValueError('run_output_must_not_pollute_skill')
    return p

def machine_profile():
    profile=json.loads((ROOT/'references/local_profile.json').read_text(encoding='utf-8'))
    tdx=Path(profile['tdx_day_root'])
    counts={market:len(list((tdx/market/'lday').glob('*.day'))) for market in ('sh','sz')}
    indices=[]
    for item in profile['index_files']:
        path=tdx/item['relative'];row={'name':item['name'],'path':str(path),'exists':path.is_file()}
        if path.is_file():
            size=path.stat().st_size;row.update(bytes=size,records=size//32,aligned=size%32==0)
            if size>=32 and size%32==0:
                with path.open('rb') as f:f.seek(-32,2);tail=f.read(32)
                date=struct.unpack('<I',tail[:4])[0]
                try:datetime.strptime(str(date),'%Y%m%d');row['last_date']=str(date)
                except ValueError:row['date_error']='invalid_day_date'
        indices.append(row)
    return {'schema':'MARKET_ENVIRONMENT_LOCAL_PROFILE_V1','checked_at':datetime.now().astimezone().isoformat(),
        'home':str(HOME),'skill_root':str(ROOT),'python':sys.executable,'python_version':sys.version.split()[0],
        'tdx_day_root':str(tdx),'day_file_counts':counts,'indices':indices,
        'source_scope':'readonly_local_file_presence_and_last_record_date_not_full_pool_or_live_quote',
        'full_workflow_completed':False,'missing_formal_inputs':[
            '47节点逐对象逐公式可复核结果及锁定参数',
            '一-11/一-12/一-16历史动态快照链',
            '历史股票属性与合法涨跌停制度快照',
            '同口径120日情绪/宽度/资金与事件时间证据',
            '前一交易日正式市场状态与权限记录',
            '本技能独立完整工作流语义重放验收'],
        'not_claimed':['行情已全部取得','本地文件等于最新行情','完整股票池','公式同源','真实市场判断']}

def execute(action,run_dir,evidence_input):
    run_dir=validate_output_root(run_dir);run_dir.mkdir(parents=True,exist_ok=True)
    errors=runtime.package_errors(ROOT)
    result={'schema':'MARKET_ENVIRONMENT_CODEX_LOCAL_V1','action':action,'status':'BLOCKED',
        'full_workflow_completed':False,'claim_scope':'installation_diagnostics' if action=='diagnose' else 'evidence_format_only',
        'errors':errors}
    if errors:return result
    if action=='diagnose':
        logs=[]
        for name in ('test_runtime.py','test_codex_install.py','test_formula_one.py','test_formula_two.py','test_local_market_data.py','test_market_aggregation.py'):
            r=subprocess.run([sys.executable,'-B',str(ROOT/'tests'/name)],capture_output=True,text=True,
                encoding='utf-8',errors='replace',timeout=60,env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT/'scripts')))
            logs.append(r.stdout+r.stderr)
            if r.returncode:errors.append('test_failed:'+name)
        (run_dir/'installation_tests.txt').write_text('\n'.join(logs),encoding='utf-8')
        result['machine_profile']=machine_profile()
        result['rule_tests']=43;result['codex_adaptation_tests']=5
        result['formula_and_data_tests']=48;result['aggregation_tests']=10
        result['status']='CLEAN_PASS' if not errors else 'BLOCKED'
    elif action=='analyze':
        from market_analysis import execute as analyze
        result=analyze(run_dir)
        errors=result.get('errors',[])
    elif action=='validate-evidence':
        if not evidence_input:errors.append('真实市场证据输入缺失：不得以安装测试替代市场分析')
        else:
            path=Path(evidence_input).resolve()
            try:
                data=json.loads(path.read_text(encoding='utf-8'),parse_constant=lambda v:(_ for _ in ()).throw(ValueError('nonfinite_json:'+v)))
                errors.extend(runtime.run_errors(data,path.parent))
                result['input']={'path':str(path),'sha256':runtime.digest(path)}
            except (OSError,ValueError) as exc:errors.append(str(exc))
        result['status']='CLEAN_PASS' if not errors else 'BLOCKED'
    else:errors.append('unsupported_action')
    return result

def main():
    if os.environ.get('CODEX_STOCK_CANONICAL_EXECUTION')!='1' or os.environ.get('ONESTOCK_STOCK_CANONICAL_CHILD')!='1':
        print(json.dumps({'status':'BLOCKED','errors':['canonical_stock_legacy_entry_direct_execution_blocked']}));return 2
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--action',choices=['diagnose','validate-evidence','analyze'],required=True)
    parser.add_argument('--run-dir',type=Path,required=True)
    parser.add_argument('--evidence-input')
    a=parser.parse_args()
    result=execute(a.action,a.run_dir,a.evidence_input)
    (a.run_dir/'local_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))
    return 0 if result['status']=='CLEAN_PASS' else 2

if __name__=='__main__':raise SystemExit(main())
