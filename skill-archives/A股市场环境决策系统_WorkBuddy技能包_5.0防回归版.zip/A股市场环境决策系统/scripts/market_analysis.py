"""Read-only local-market research, not full formal decision qualification."""
from __future__ import annotations
import hashlib
import importlib.util
import json
import math
from datetime import datetime
from pathlib import Path
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import pandas as pd
import formula_one
import formula_two
import local_market_data as data

SKILL=Path(r'F:\Codex\Home\skills\a-share-market-environment')
IDS=[f'一-{i:02d}' for i in range(1,30)]+[f'二-{i:02d}' for i in range(1,19)]

def clean(x):
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [clean(v) for v in x]
    if isinstance(x,np.generic):return clean(x.item())
    if isinstance(x,float) and not math.isfinite(x):return None
    return x

def save(path,value):
    path.write_text(json.dumps(clean(value),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def rules():
    spec=importlib.util.spec_from_file_location('market_score_rules',SKILL/'scripts/runtime.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod

def matrix():
    result={}
    for line in (SKILL/'references/47个技术子系统执行矩阵.md').read_text(encoding='utf-8').splitlines():
        cols=line.strip('|').split('|')
        if cols and cols[0] in IDS:
            result[cols[0]]=dict(zip(('id','name','category','role','target','basis','impact'),cols))
    if set(result)!=set(IDS):raise ValueError('执行矩阵不是47项')
    return result

def missing_nodes(reason):
    return {k:dict(score=None,coverage=0.,value=None,triggered=None,reason=reason) for k in IDS}

def calculate_object(job):
    row,date=job
    out=dict(row)
    try:
        f=data.read_day(row['path'],date,expected_sha256=row.get('sha256'))
        before=f.attrs['source']['sha256']
        if f.empty or int(f.date.iloc[-1])!=int(date.replace('-','')):raise ValueError('目标日记录缺失')
        f.volume=f.volume/100.
        f.attrs.update(history_complete=True,volume_unit='lots',amount_unit='CNY',price_basis='unadjusted',
            first_observed_date=int(f.date.iloc[0]),date=int(f.date.iloc[-1]),
            eligible_current=row.get('kind')=='stock',current_pool_eligible=row.get('kind')=='stock')
    except (OSError,ValueError) as exc:
        out.update(nodes=missing_nodes(str(exc)),error=f'{type(exc).__name__}: {exc}',error_kind='data',recent_daily=[])
        return clean(out)
    try:
        nodes={**formula_one.compute(f),**formula_two.compute(f)}
        out.update(nodes=nodes,sha256=before,bars=len(f),first_date=int(f.date.iloc[0]),last_date=int(f.date.iloc[-1]))
        c=f.close;returns=c.pct_change();above20=c>c.rolling(20).mean();above60=c>c.rolling(60).mean()
        high20=c>c.shift().rolling(20).max();low20=c<c.shift().rolling(20).min()
        history=[]
        for i in range(max(0,len(f)-24),len(f)):
            history.append({'date':int(f.date.iloc[i]),'return':float(returns.iloc[i]) if i else None,
                'amount':float(f.amount.iloc[i]),'above20':bool(above20.iloc[i]) if i>=19 else None,
                'above60':bool(above60.iloc[i]) if i>=59 else None,
                'newhigh20':bool(high20.iloc[i]) if i>=20 else None,'newlow20':bool(low20.iloc[i]) if i>=20 else None})
        out['recent_daily']=history;out['error']=None;out['error_kind']=None
    except Exception as exc:
        out.update(nodes=missing_nodes(str(exc)),error=f'{type(exc).__name__}: {exc}',error_kind='compute',recent_daily=[])
    return clean(out)

def channel(rows,node_id,expected):
    entries=[r['nodes'][node_id] for r in rows]
    # Directional scoring only uses a finite score. Dependency/validation nodes
    # still retain original calculation coverage in object evidence.
    valid=[x for x in entries if x.get('score') is not None and x.get('coverage',0)>0]
    units=sum(x['coverage'] for x in valid)
    data_available=[x for x in entries if x.get('coverage',0)>0]
    data_units=sum(x['coverage'] for x in data_available)
    triggers=sum(x.get('triggered') is True and x.get('coverage')==1 for x in entries)
    event_valid=sum(x.get('triggered') is not None and x.get('coverage')==1 for x in entries)
    return {'expected':expected,'objects_present':len(rows),'scored_objects':len(valid),
        'data_available_objects':len(data_available),'data_effective_units':data_units,
        'data_coverage':data_units/expected if expected else 0.,
        'complete_objects':sum(x['coverage']==1 for x in valid),'effective_units':units,
        'coverage':units/expected if expected else 0.,
        'score':sum(x['coverage']*x['score'] for x in valid)/units if units else None,
        'triggered':triggers,'event_valid':event_valid,
        'observed_trigger_rate':triggers/event_valid if event_valid else None,
        'trigger_rate_bounds':[triggers/expected,(triggers+expected-event_valid)/expected] if expected else None,
        'missing_reasons':dict(Counter(x.get('reason','未知') for x in entries if x.get('coverage',0)<1))}

def aggregate(index_rows,stock_rows,stock_expected,definitions):
    result=[]
    for ident,m in definitions.items():
        target=m['target'];ic=channel(index_rows,ident,8)
        sr=[r for r in stock_rows if not r['symbol'].startswith(('sh688','sh689','sz300','sz301'))] if ident=='一-27' else stock_rows
        se=len(sr) if ident=='一-27' else stock_expected
        sc=channel(sr,ident,se)
        applicable=[(ic,.5),(sc,.5)] if target=='指数与个股广度' else [(ic,1.)] if target=='八大指数' else [(sc,1.)]
        units=sum(w*x['coverage'] for x,w in applicable)
        data_coverage=sum(w*x['data_coverage'] for x,w in applicable)
        is_scoring=m['role'] in ('评分主节点','仅实时评分节点')
        score=sum(w*x['coverage']*x['score'] for x,w in applicable if x['score'] is not None)/units if units else None
        reasons=Counter()
        for x,_ in applicable:reasons.update(x['missing_reasons'])
        why='；'.join(f'{reason}（{count}对象）' for reason,count in reasons.most_common(3))
        non_scoring_result=f'原始依赖/验证数据覆盖{data_coverage:.2%}；方向权重0；逐对象值见object_47_nodes.jsonl中的{ident}。'
        result.append({**m,'score':score,'coverage':units,'data_coverage':data_coverage,'value_evidence':{'artifact':'object_47_nodes.jsonl','node_id':ident},'index_channel':ic,'stock_channel':sc,
            'result':(f'观测分{score:.2f}；覆盖{units:.2%}' if score is not None else '方向分缺失') if is_scoring else non_scoring_result,
            'explanation':why or '按该节点数学条件计算；未触发与数据缺失分别记录。',
            'data_status':('工程日线可算单元齐备' if units==1 else '部分计算' if units else '缺失') if is_scoring else ('依赖/验证数据齐备；不计方向分' if data_coverage==1 else '依赖/验证数据部分可得；不计方向分' if data_coverage else '依赖/验证数据缺失；不计方向分')})
    return result

def fmt(v,digits=2):return '未取得' if v is None else f'{v:.{digits}f}'

def workflow_ledger(r):
    names=['交易日和运行模式','股票池和数据口径','字段质量和覆盖','政策事件核查','八指数历史可用性','47节点五字段','七类归并和去重','类别技术分与覆盖','指数共振与个股扩散','宽度评分及历史变化','短线情绪','流动性评分','结构健康','五风险闸门','六维健康度','七级状态与速度','前日正式状态与限速','最大新增仓位','逐项策略权限','回归及完整性自检','十二章交付']
    completed={1,3,6,7,8,18,19,21}
    return [{'id':i,'name':n,'status':'完成' if i in completed else '未完成',
        'evidence':['nodes.json' if i in (6,7,8,9) else 'pool.json' if i in (2,3) else 'report.md' if i==21 else 'market_summary.json'],
        'basis': '本次工程研究结果已保存；不代表完整正式资格' if i in completed else '存在已记录的必要输入或业务验收缺口，未冒充计算完成'} for i,n in enumerate(names,1)]

def observed_calendar(path):
    """Read date axis separately; historical OHLC failures remain object errors."""
    raw=path.read_bytes()
    if len(raw)%data.DAY_RECORD.size:raise ValueError('上证日期轴文件长度异常')
    today=int(datetime.now().strftime('%Y%m%d'));dates=[];previous=0;last_record=None
    for vals in data.DAY_RECORD.iter_unpack(raw):
        d=vals[0];datetime.strptime(str(d),'%Y%m%d')
        if d<=previous:raise ValueError('上证日期轴不递增')
        previous=d
        if d<=today:dates.append(d);last_record=vals
    if last_record is None:raise ValueError('上证日期轴无当前日期前记录')
    _,o,h,l,c,a,v,_=last_record
    if not (min(o,h,l,c)>0 and l<=min(o,c) and h>=max(o,c) and math.isfinite(a) and a>=0):raise ValueError('上证最新记录OHLC无效')
    return pd.DataFrame({'date':dates}),{'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'record_count':len(dates),'scope':'日期轴及最新记录验证；历史OHLC另行严格验证'}

def research_gates(daily,expected,amount_ratio):
    """Research-sample gates only. Unknown or changing denominators stay unknown."""
    gates=[None]*5
    if expected<=0 or len(daily)<3: return gates
    today,prev=daily[-1],daily[-2]
    full_sample=all(x.get('valid')==expected for x in daily[-3:])
    def finite(value):return isinstance(value,(int,float,np.number)) and math.isfinite(value)
    up_complete=all(finite(x.get('up_ratio')) and 0<=x['up_ratio']<=1 for x in (today,prev))
    if full_sample and up_complete:
        gates[0]=bool(today['up_ratio']<=.2 and prev['up_ratio']-today['up_ratio']>=.1-1e-12)
        complete_amount_history=(len(daily)>=21 and all(x.get('valid')==expected and finite(x.get('amount')) and x['amount']>=0 for x in daily[-21:]))
        if complete_amount_history and finite(amount_ratio) and amount_ratio>=0:
            gates[3]=bool(amount_ratio<.7 and daily[-3]['amount']>prev['amount']>today['amount'] and today['up_ratio']<prev['up_ratio'])
    return gates


def execute(run_dir):
    root=Path(run_dir);root.mkdir(parents=True,exist_ok=True)
    profile=json.loads((SKILL/'references/local_profile.json').read_text(encoding='utf-8'))
    tdx=Path(profile['tdx_day_root']);sh=tdx/'sh/lday/sh000001.day'
    latest,calendar_source=observed_calendar(sh)
    if latest.empty:raise RuntimeError('上证本地日线为空')
    di=int(latest.date.iloc[-1]);date=f'{di//10000:04d}-{di//100%100:02d}-{di%100:02d}'
    pool=data.list_current_pool(date,tdx_root=tdx.parent)
    exclusions=[x for x in pool['excluded'] if x['reason'] in ('current_name_risk_or_delisting_marker','duplicate_current_metadata_record')]
    missing=[x for x in pool['excluded'] if x not in exclusions]
    expected=len(pool['eligible'])+len(missing)
    pool.update(research_expected=expected,research_data_missing_members=missing,
        explicit_current_scope='沪深当前本地名录研究池，不是历史全A池；北交所按规则排除',
        qualification='不能证明历史时点池、上市制度、真实涨跌停或退市完备性')
    save(root/'pool.json',pool)
    indexes=[]
    for x in profile['index_files']:
        p=tdx/x['relative'];indexes.append(calculate_object(({'symbol':p.stem,'name':x['name'],'path':str(p),'kind':'index'},date)))
    stocks=[];jobs=[({**x,'kind':'stock'},date) for x in pool['eligible']]
    stream=root/'object_47_nodes.jsonl'
    with stream.open('w',encoding='utf-8') as output:
        for r in indexes:output.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n')
        with ProcessPoolExecutor(max_workers=8) as executor:
            for i,r in enumerate(executor.map(calculate_object,jobs,chunksize=8),1):
                stocks.append(r);output.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n')
                if i%100==0:
                    output.flush();save(root/'progress.json',{'processed':i,'expected_compute':len(jobs),'date':date})
        for x in missing:
            r={**x,'kind':'stock','nodes':missing_nodes(x['reason']),'error':x['reason'],'error_kind':'data','recent_daily':[]}
            stocks.append(r);output.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n')
    definitions=matrix();nodes=aggregate(indexes,stocks,expected,definitions);rt=rules();categories=[]
    for name in rt.CATEGORIES:
        used=[n for n in nodes if n['category']==name and n['role'] in ('评分主节点','仅实时评分节点')]
        cat=rt.category([(n['score'],n['coverage']) for n in used]) if used else {'coverage':None,'observed':None,'effective':None}
        categories.append({'name':name,**cat,'scoring_nodes':[n['id'] for n in used]})
    tech=sum(w*x['effective'] for w,x in zip(rt.TECH_WEIGHTS,categories[:6]));cov=sum(w*x['coverage'] for w,x in zip(rt.TECH_WEIGHTS,categories[:6]))
    resonance=rt.resonance(categories[:6]);dates=latest.date.tail(24).astype(int).tolist();daily=[]
    lookups=[{x['date']:x for x in r['recent_daily']} for r in stocks]
    for d in dates:
        samples=[lookup[d] for lookup in lookups if d in lookup and lookup[d]['return'] is not None]
        N=len(samples);ret=[x['return'] for x in samples];amount=sum(x['amount'] for x in samples)
        up_amount=sum(x['amount'] for x in samples if x['return']>0);down_amount=sum(x['amount'] for x in samples if x['return']<0)
        row={'date':d,'valid':N,'expected_current_pool':expected,'coverage':N/expected if expected else 0,
             'up_ratio':sum(x>0 for x in ret)/N if N else None,'median_return':float(np.median(ret)) if N else None,
             'amount':amount if N else None,'up_amount_share':up_amount/(up_amount+down_amount) if up_amount+down_amount else None}
        for k in ('above20','above60','newhigh20','newlow20'):
            vals=[x[k] for x in samples if x[k] is not None];row[k]=sum(vals)/len(vals) if vals else None;row[k+'_valid']=len(vals)
        daily.append(row)
    today=daily[-1];prev=daily[-2] if len(daily)>1 else {};hist_amount=[x['amount'] for x in daily[-21:-1]]
    amount_ratio=today['amount']/float(np.median(hist_amount)) if len(hist_amount)==20 and all(x is not None for x in hist_amount) and np.median(hist_amount)>0 else None
    # Observed current-pool data may describe a sample, never silently stand in
    # for the complete historical core pool or percentile history.
    gates=research_gates(daily,expected,amount_ratio)
    health=rt.health({'technical':tech});index_results=[]
    for r in indexes:
        last=r['recent_daily'][-1] if r['recent_daily'] else {}
        index_results.append({'name':r['name'],'symbol':r['symbol'],'return':last.get('return'),'bars':r.get('bars'),'error':r['error']})
    artifacts=['pool.json','object_47_nodes.jsonl','nodes.json','market_summary.json','report.md','workflow_21_ledger.json']
    errors=[{'symbol':x['symbol'],'error':x['error']} for x in [*indexes,*stocks] if x.get('error_kind')=='compute']
    if not any(not x['error'] for x in [*indexes,*stocks]):errors.append({'error':'没有任何对象完成计算'})
    result={'schema':'MARKET_ENVIRONMENT_DAILY_RESEARCH_V1','action':'analyze','status':'BLOCKED' if errors else 'CLEAN_PASS','errors':errors,'claim_scope':'daily_market_research','full_workflow_completed':False,
        'research_computation_completed':not bool(errors),'worker_count':8,'formal_qualification':False,'target_date':date,
        'decision_at':datetime.now().astimezone().isoformat(),'mode':'daily_market_research',
        'scope':'沪深当前本地名录完整枚举研究；不是已验证全A历史核心池',
        'pool_expected':expected,'pool_processed':len(stocks),'eligible_calculated':len(jobs),'calendar_source':calendar_source,
        'current_name_excluded':len(exclusions),'data_missing_members':len(missing),
        'object_calculation_errors':sum(bool(r['error']) for r in stocks),
        'indexes_expected':8,'indexes_available':sum(not r['error'] for r in indexes),'indexes':index_results,
        'technical':{'effective':tech,'coverage':cov,'resonance':resonance,'categories':categories},
        'daily_current_pool_sample':daily,'amount_ratio20_observed':amount_ratio,'health':health,'gates':gates,
        'candidate_state':None,'speed':None,'permissions':{'cap':0,'strategies':[0]*6},
        'missing_requirements':['真实历史股票池及上市/涨跌停制度','完整动态均价与现价序列','120日同口径五维评分历史','全市场政策人工核查','前日正式权限与连续修复证据','宿主公式同源验收'],
        'artifacts':artifacts,'semantics':{'one':formula_one.SEMANTICS,'two':formula_two.VERSION,'history':'全部本地可得日线；不截短，不证明自上市完整','price':'未复权元；原股数除100转手；成交额元'}}
    save(root/'nodes.json',nodes)
    ledger=workflow_ledger(result)
    save(root/'workflow_21_ledger.json',ledger)
    result['workflow_21_ledger']=ledger
    report=render(result,nodes,today,prev);(root/'report.md').write_text(report,encoding='utf-8')
    save(root/'market_summary.json',result)
    save(root/'artifact_hashes.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.is_file() and p.name in artifacts})
    return clean(result)

def render(r,nodes,today,prev):
    t=r['technical'];lines=[f"# A股市场环境决策系统｜{r['target_date']}本机日线研究",'',
        '**'+('研究计算已完成' if r['research_computation_completed'] else '研究计算发生程序阻断')+'；完整正式决策工作流尚未通过，实际新增权限为0。**','',
        '## 一、综合结论',f"本次实际枚举沪深当前研究池{r['pool_expected']}个对象，逐对象运行47项节点；八指数可取得{r['indexes_available']}个，缺失指数仍留分母。",
        f"技术观测覆盖{t['coverage']:.2%}，保守收缩后的技术有效分{t['effective']:.2f}。该分数不是收益概率。",
        '缺少完整情绪、政策及前日正式基准，无法完整判定七级市场状态，变化速度也不可计算。普通新开仓暂停，最大新增仓位0%。','',
        '## 二、核心状态表','|项目|当前判断|简单解释|','|---|---|---|',
        f"|数据质量|逐文件真实读取|{r['object_calculation_errors']}个研究池对象缺失或读取失败，未从分母删除|",
        '|候选市场描述|不能完整判定|所需维度并未齐备|','|正式权限|暂停，新增0%|研究计算完成不等于获得权限|',
        '|政策与事件|未核查|未知不能视为没有风险|','|环境变化速度|不可计算|缺同口径四轴连续历史|','',
        '## 三、技术分析',f"技术有效分{t['effective']:.2f}；覆盖{t['coverage']:.2%}；规则共振判定：{t['resonance']}（1偏强，-1偏弱，0未满足）。",
        '|类别|观测分|覆盖率|有效分|','|---|---:|---:|---:|']
    for c in t['categories']:lines.append(f"|{c['name']}|{fmt(c['observed'])}|{fmt(c['coverage']*100) if c['coverage'] is not None else '不计方向分'}|{fmt(c['effective'])}|")
    lines+=['','辅助类只保留原始验证值，既不添加方向分，也不重复计量成交额。','',
        '|编号|子系统|当前结果|计算依据|简单解释|对市场影响|数据状态|','|---|---|---|---|---|---|---|']
    for n in nodes:lines.append('|'+ '|'.join(str(n[k]).replace('|','／') for k in ('id','name','result','basis','explanation','impact','data_status'))+'|')
    lines+=['','## 四、政策与事件','本次没有取得并人工核验政策事件来源，不赋中性分；系统性风险闸门保持未知。','',
        '## 五、市场宽度',f"当日可观察样本{today['valid']}/{today['expected_current_pool']}；上涨占比{fmt(today['up_ratio']*100) if today['up_ratio'] is not None else '缺失'}%，前一日{fmt(prev.get('up_ratio')*100) if prev.get('up_ratio') is not None else '缺失'}%。",
        f"当日收益中位数{fmt(today['median_return']*100) if today['median_return'] is not None else '缺失'}%；20日、60日均线上方比例分别{fmt(today['above20']*100) if today['above20'] is not None else '缺失'}%、{fmt(today['above60']*100) if today['above60'] is not None else '缺失'}%。",
        '上述是当前名录固定池的逐日可观察样本，不是已验证历史全市场。近24日样本与各项有效分母见研究结果文件；无120日同口径历史，不生成完整宽度分数。','',
        '## 六、短线情绪','真实涨停、跌停、炸板、晋级和昨日涨停反馈缺少历史合法参考价及制度，全部保留缺失。不用固定9.8%或10%涨幅替代交易所涨停。','',
        '## 七、流动性',f"当日观察样本成交额{fmt(today['amount']/1e8) if today['amount'] is not None else '缺失'}亿元；相对此前20日同一当前池可观察金额中位数{fmt(r['amount_ratio20_observed'])}倍。",
        f"上涨股金额占上涨与下跌股金额合计比例{fmt(today['up_amount_share']*100) if today['up_amount_share'] is not None else '缺失'}%。因历史池及120日分位缺失，不授予正式流动性分。",'',
        '## 八、指数与个股结构','|指数|当日涨跌幅|状态|','|---|---:|---|']
    for i in r['indexes']:lines.append(f"|{i['name']}|{fmt(i['return']*100) if i['return'] is not None else '缺失'}%|{i['error'] or '读取成功'}|")
    lines+=['结构分所需指数齐备及历史分位未完整核验，保持缺失。','', '## 九、风险闸门','|闸门|结果|','|---|---|']
    for name,value in zip(('严重宽度冲击','跌停冲击','指数破位共振','流动性冲击','系统性事件'),r['gates']):lines.append(f"|{name}|{'无法判定' if value is None else '触发' if value else '当前完整研究样本未触发；非正式历史池验收'}|")
    lines+=['','## 十、最终推导与交易权限',f"健康度不能完整计分，已知技术贡献区间下界{r['health']['lower']:.2f}，含未知项上界{r['health']['upper']:.2f}；不能把区间当正式得分。",
        '前日正式权限未取得。所有新增策略（一进二、二进三、三进四、趋势突破、普通追涨、主线低吸）暂停，新增仓位上限0%。','',
        '## 十一、恢复与降级条件',*[f'- {x}' for x in r['missing_requirements']], '',
        '## 十二、完整性与回归自检', '47/47节点均有五字段执行记录；记录齐备不等于47项数据完整。',
        '行情仅使用目标日及此前实际记录；未复权口径明确；指数与个股通道各自计算后固定聚合，缺失不移出分母。',
        '未完成原21步全部业务验收、政策核查、历史四轴及前日正式基准，因此不能声明完整工作流执行完成。',
        '逐对象输入文件哈希、日线起止、全部节点值及缺失原因见object_47_nodes.jsonl；股票池与排除证据见pool.json。','',
        '|步骤|检查内容|状态|证据|','|---:|---|---|---|']
    for x in r.get('workflow_21_ledger',[]):lines.append(f"|{x['id']}|{x['name']}|{x['status']}|{','.join(x['evidence'])}|")
    lines+=['','**'+('日线研究计算已完成' if r['research_computation_completed'] else '日线研究计算发生阻断')+'；正式决策工作流未完成，不得作为正式交易结论。**','']
    return '\n'.join(lines)
