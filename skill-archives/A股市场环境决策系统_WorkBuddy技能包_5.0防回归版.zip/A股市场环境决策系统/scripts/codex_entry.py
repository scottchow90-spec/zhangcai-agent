"""本机唯一公共入口；业务执行和授权由现有统一运行器负责。"""
import os
from pathlib import Path
import sys

HOME=Path(r'F:\Codex\Home')
os.environ['PYTHONDONTWRITEBYTECODE']='1'
sys.dont_write_bytecode=True
os.environ['ONESTOCK_STOCK_DATA_ROOT']=str(HOME/'business_data'/'a-share-market-environment')
sys.path.insert(0,str(HOME/'scripts'))
from stock_canonical_runtime import facade_main

if __name__=='__main__':raise SystemExit(facade_main(__file__))
