"""Formula two, explicit engineering replay; never claims host equivalence."""
import numpy as np
import pandas as pd

VERSION = 'formula-two-engineering-1;EMA/SMA-first-valid;MACD12/26/9;OLS-endpoint'

def smooth(s, alpha):
    valid=s.notna(); started=valid.cummax()
    poisoned=(started & ~valid).cummax()
    return s.ewm(alpha=alpha,adjust=False,ignore_na=False).mean().mask(poisoned)

def ema(s,n): return smooth(s,2/(n+1))
def sma(s,n): return smooth(s,1/n)
def ratio(a,b): return a/b.where(b>0)
def cmp(a,b,op):
    b=b if isinstance(b,pd.Series) else pd.Series(b,index=a.index)
    r=getattr(a,op)(b).astype('boolean'); return r.mask(a.isna()|b.isna(),pd.NA)
def forecast(s,n):
    x=np.arange(n,dtype=float); weights=1/n+(x-x.mean())*(n-1-x.mean())/np.square(x-x.mean()).sum()
    return s.rolling(n).apply(lambda y:float(y@weights),raw=True)
def filt(s,n):
    # Set-valued countdown resolves unknown historical triggers conservatively.
    states={0}; out=[]
    for v in s:
        choices=[False,True] if pd.isna(v) else [bool(v)]; ns=set(); emitted=set()
        for k in states:
            for hit in choices:
                fire=k==0 and hit; emitted.add(fire); ns.add(n if fire else max(0,k-1))
        out.append(next(iter(emitted)) if len(emitted)==1 else pd.NA); states=ns
    return pd.Series(out,index=s.index,dtype='boolean')
def last_ref(values,event):
    out=[]; last=None
    for i,(v,e) in enumerate(zip(values,event)):
        if pd.isna(e): last=None
        elif bool(e): last=i
        out.append(values.iloc[last] if last is not None else np.nan)
    return pd.Series(out,index=values.index,dtype=float)
def all_and(*a):
    r=a[0]
    for x in a[1:]:r=r&x
    return r

def parse_date(value):
    if value is None or value is pd.NA: return pd.NaT
    if isinstance(value,(int,np.integer)): value=str(value)
    return pd.to_datetime(value,errors='coerce')

def compute(frame):
    f=frame.reset_index(drop=True); n=len(f); result={}
    if not n:return {f'二-{i:02d}':dict(score=None,coverage=0.,value=None,reason='无日线',triggered=None) for i in range(1,19)}
    def invalid(reason):
        return {f'二-{i:02d}':dict(score=None,coverage=0.,value=None,reason=reason,triggered=None) for i in range(1,19)}
    if any(k not in f for k in ('open','high','low','close','volume')): return invalid('缺少日线必需列')
    if 'date' in f:
        dates=pd.to_datetime(f['date'].astype(str),errors='coerce')
        if dates.isna().any() or dates.duplicated().any() or not dates.is_monotonic_increasing: return invalid('日线日期无效、重复或未升序；拒绝自动重排')
    c,h,l,o,v=[pd.to_numeric(f[k],errors='coerce').replace([np.inf,-np.inf],np.nan) for k in ['close','high','low','open','volume']]
    c,h,l,o=[s.where(s>0) for s in (c,h,l,o)]; v=v.where(v>=0)
    if ((h<l)|(h<c)|(h<o)|(l>c)|(l>o)).any(): return invalid('OHLC价格关系不合法')
    unknown=pd.Series(pd.NA,index=f.index,dtype='boolean')
    complete=bool(frame.attrs.get('history_complete',False))
    def put(i,value,score=None,trigger=None,coverage=None,reason='',recursive=False):
        val=value.iloc[-1] if isinstance(value,pd.Series) else value
        tri=trigger.iloc[-1] if isinstance(trigger,pd.Series) else trigger
        tri=None if tri is None or pd.isna(tri) else bool(tri)
        val=None if val is None or val is pd.NA or (np.isscalar(val) and pd.isna(val)) else (bool(val) if isinstance(val,np.bool_) else float(val) if isinstance(val,(np.floating,np.integer)) else val)
        sc=score.iloc[-1] if isinstance(score,pd.Series) else score
        sc=None if sc is None or pd.isna(sc) else float(sc)
        cov=float(val is not None) if coverage is None else coverage
        if score is not None and sc is None: cov=0.
        if recursive and not complete: cov=0.; reason+=';完整历史起点未确认，递推值仅展示'
        result[f'二-{i:02d}']=dict(score=sc,coverage=cov,value=val,triggered=tri,reason=reason or '固定工程重放，未验证宿主同源')
    def votes(line):return 50+25*(np.sign(c-line)+np.sign(line-line.shift()))
    def event(i,s,reason='',coverage=None,recursive=False,scored=True):put(i,s,None if not scored else s.astype('Float64')*50+50,s,coverage,reason,recursive)
    eh,ec=ema(h,8),ema(c,8)
    weak=cmp(eh,eh.shift(),'lt')|(cmp(ec,ec.shift(),'lt')&cmp(c,ec,'lt'))
    put(1,(eh+ec)/2,(votes(eh)+votes(ec))/2,recursive=True)
    change=c.diff(); rsi=ratio(sma(change.clip(lower=0),2),sma(change.abs(),2))*100
    dif=ema(c,12)-ema(c,26)
    x13=cmp(rsi,45,'lt')&cmp(rsi.shift(),45,'gt')&cmp(dif,0,'ne')
    x14=cmp(rsi,20,'lt')&cmp(rsi.shift(),20,'gt')
    ret=ratio(c-c.shift(),c.shift())
    lead=(cmp(weak.astype('Float64').rolling(4).sum(),3,'eq')&~weak&cmp(o,c,'lt')&cmp(ret,.089,'gt'))|(cmp(ret,.089,'gt')&(x14.shift()|x13.shift()))
    event(2,lead,'工程MACD12/26/9，非宿主同源；原两分支保留',recursive=True)
    band=rsi.map(lambda x: np.nan if pd.isna(x) else 0 if x<20 else 25 if x<45 else 50 if x<50 else 75 if x<80 else 100)
    put(3,rsi,band,recursive=True)
    e89=ema(c,89); put(4,e89.where(f.index>=88),votes(e89).where(f.index>=88),recursive=True)
    p13=ema(ema(ema(h,13),13),13); p5=ema(ema(ema(h,5),5),5)
    put(5,(p13+p5)/2,(votes(p13)+votes(p5))/2,recursive=True)
    eligibility=unknown.copy()
    first_date=frame.attrs.get('first_observed_date')
    target_date=frame.attrs.get('date')
    if 'date' in f and first_date is None: first_date=f['date'].iloc[0]
    if 'date' in f and target_date is None: target_date=f['date'].iloc[-1]
    try: age_proved=(parse_date(target_date)-parse_date(first_date)).days>120
    except (TypeError,ValueError): age_proved=False
    # Earliest observed trade proves a lower bound only; never an exact listing date.
    if age_proved and 'eligible_current' in frame.attrs:
        eligibility.iloc[-1]=bool(frame.attrs['eligible_current'])
    price_filter=cmp(c.shift(),2,'gt')&cmp(c.shift(),89,'lt')
    pool_filter=eligibility&price_filter
    filter_cov=float(pd.notna(eligibility.iloc[-1]) and pd.notna(price_filter.iloc[-1]))
    event(6,pool_filter,'首笔可得交易至今>120自然日仅证明上市年龄下界；池资格仅当日，不回填历史',coverage=filter_cov,scored=False)
    x24=cmp(c,p5,'gt')&cmp(c,p13,'gt')&cmp(c,e89,'gt')
    x26=cmp(ret*100,9.84,'ge')&cmp(ret.shift()*100,9.84,'lt')&cmp(ret.shift(2)*100,9.84,'lt')
    x27=pool_filter&x24&cmp(ratio(h,p5),1.16,'lt')&x26
    event(7,x27,'上市年龄下界与当日属性只用于当日；不回填历史',coverage=filter_cov if n>=89 and pd.notna(x27.iloc[-1]) else 0,recursive=True)
    top=pd.concat([o,c],axis=1).max(axis=1,skipna=False); bottom=pd.concat([o,c],axis=1).min(axis=1,skipna=False)
    x30=top.rolling(4).min(); x31=bottom.rolling(4).max()
    platform=all_and(*[cmp(top.shift(k),x30,'ge')&cmp(bottom.shift(k),x30,'le')&cmp(top.shift(k),x31,'ge')&cmp(bottom.shift(k),x31,'le') for k in range(4)])
    event(8,platform)
    x37=cmp(platform.astype('Float64').rolling(36).max(),0,'gt')
    x38=(o.shift(5)+c.shift(5))/2; x39=(h+l+c+o)/4
    x40=pd.concat([x38,x39,h.rolling(5).max()],axis=1).max(axis=1,skipna=False)
    x41=pd.concat([x38,x39,l.rolling(5).min()],axis=1).min(axis=1,skipna=False)
    x43=cmp(x40,x38,'eq'); x44=last_ref(x40,x43)
    put(9,x44,reason='真实历史命中后回看上沿；从未命中则缺失')
    x45=cmp(ret*100,9.85,'gt')&cmp(o,c,'ne')
    x47=cmp(x45.astype('Float64').rolling(21).sum(),1,'eq')&x45
    event(10,x47,'9.85%源涨幅事件，不是交易所涨停；至少22条',coverage=float(n>=22 and x45.iloc[-21:].notna().all()),scored=False)
    x48=last_ref(x31,platform); x49=last_ref(x40,x43)
    x52=cmp(ratio(x41,x49),1.3,'lt')&cmp(ratio(x41,x48),1.3,'lt')&x45
    known_span=bool(pd.notna(x48.iloc[-1]) and pd.notna(x49.iloc[-1]) and x48.iloc[-1]>0 and x49.iloc[-1]>0 and pd.notna(x41.iloc[-1]))
    event(11,x52,'动态回看及两个正分母必须完整；短路False仍保留缺口',coverage=float(known_span and pd.notna(x45.iloc[-1])),scored=False)
    x53=cmp(c,x44,'gt'); corrected=x27&x52&x37&x53
    swing=filt(corrected,13)&x47
    event(12,swing,'X53已在FILTER前并入；缺历史属性过滤，不计完整覆盖',coverage=0)
    linear=unknown.copy()
    capital=frame.attrs.get('capital_lots')
    if isinstance(capital,(int,float,np.number)) and np.isfinite(capital) and capital>0 and frame.attrs.get('volume_unit')=='lots':
        vr=ratio(v.rolling(2).mean(),v.rolling(10).mean()).iloc[-1]
        rr=ret.iloc[-1]*100; turnover=v.iloc[-1]/capital
        if np.isfinite(vr) and np.isfinite(rr) and np.isfinite(turnover):
            q10=.0068*rr-.0072*vr-.5676*turnover-.0105
            q11=.0015*rr-.0124*vr+1.7461*turnover-.0074
            linear.iloc[-1]=(-12.2401*q10-q11+.321)<0
    event(13,linear,'只接受当日真实CAPITAL手数，不回填历史',coverage=float(pd.notna(linear.iloc[-1])),scored=False)
    position=ratio(c-l.rolling(36).min(),h.rolling(36).max()-l.rolling(36).min())*100
    wave=sma(sma(position,3),3); seg=sma(wave,3)
    put(14,wave,50+25*(np.sign(wave-seg)+np.sign(wave-wave.shift())),recursive=True)
    fc4,fc12=forecast(v,4),forecast(v,12)
    private=filt(cmp(ratio(c,c.shift()),1.048,'gt')&cmp(c,h,'eq')&cmp(fc4,.2*fc12,'ge')&cmp(fc4,2.1*fc12,'le'),28)
    event(15,private,'FORCAST为历史OLS端点；FILTER为状态集合传播未知；至少12条',coverage=float(n>=12 and pd.notna(fc4.iloc[-1]) and pd.notna(fc12.iloc[-1]) and pd.notna(private.iloc[-1])),recursive=True)
    first=private|linear; second=swing|lead
    event(16,first,'CAPITAL仅当日；真OR未知可真但缺失分支不算完整覆盖',coverage=float(pd.notna(linear.iloc[-1]) and pd.notna(private.iloc[-1]) and complete),scored=False)
    event(17,second,'缺历史过滤；真OR未知可真但依赖覆盖不足',coverage=0,scored=False)
    event(18,first&second,'缺历史过滤及CAPITAL；保留三态短路推导，完整覆盖0',coverage=0)
    return result
