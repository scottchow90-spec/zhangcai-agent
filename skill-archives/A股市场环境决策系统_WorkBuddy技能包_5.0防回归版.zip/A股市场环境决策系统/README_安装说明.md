# 本机Codex适配说明

当前安装目标为Codex，安装修订5.0.1-codex.2。运行先看references/workflow.md；原WorkBuddy导出说明仅用于源包追溯。正常请求不直接运行原工具替代统一入口。

# 安装说明
中文名：A股市场环境决策系统
版本：5.0.1——原包深度审计修正版
本次适配目标：本机Codex。WorkBuddy为原导出来源，不声称已在WorkBuddy安装验收。

使用同一个技能文件夹，入口SKILL.md；导入整个文件夹，保留references、sources、scripts、tests、examples及manifest。包外文件名不变，内部修订号用于追溯。
两份sources为用户原始公式档案，不要直接执行包含原始缺陷的整段公式；修正转换见references/公式修正执行约定.md。修正不等于已通过通达信同源验证。

在技能根目录检查（Python 3.10及以上，仅标准库）：
```text
python -B scripts/runtime.py check-package
python -B tests/test_runtime.py
```
有实际运行证据时：`python -B scripts/runtime.py check-run --run 本次证据目录/run.json`。
详情见references/运行证据与校验.md。runtime.py只做规则校验；analyze通过统一入口只读本机日线并计算研究结果，不下单、不控制桌面。检查通过只说明对应检查范围通过。
没有所需数据/公式解释器时如实输出缺口，不用示例替代。无需安装另一套同名技能，也不修改全局环境。

本机真实计算沿用Python 3.13、NumPy 2.5.0、pandas 3.0.3。公式递推采用已锁定的工程初始化参数，保留全部可得历史，未取得的动态快照不填补。研究结果与正式交易资格分开核验。

正式调用：`python -B scripts/codex_entry.py run -- --action analyze --workflow-request-file <用户原话UTF8文件>`。输出固定落入F:/Codex/Home/business_data/a-share-market-environment，不能写进技能目录。全部106项测试已纳入diagnose，包括公式、数据及聚合回归。
