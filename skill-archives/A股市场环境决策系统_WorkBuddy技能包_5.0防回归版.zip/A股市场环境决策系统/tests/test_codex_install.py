import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
class CodexInstallation(unittest.TestCase):
    def test_canonical_facade_present(self):
        self.assertTrue((ROOT/'scripts/codex_entry.py').is_file())
    def test_legacy_direct_execution_blocked(self):
        path=ROOT/'scripts/legacy_codex_entry.py'
        self.assertTrue(path.is_file())
        env=dict(os.environ);env.pop('CODEX_STOCK_CANONICAL_EXECUTION',None)
        env.pop('ONESTOCK_STOCK_CANONICAL_CHILD',None)
        r=subprocess.run([sys.executable,'-B',str(path),'--action','diagnose'],capture_output=True,text=True,encoding='utf-8',env=env)
        self.assertEqual(r.returncode,2)
        self.assertIn('canonical_stock_legacy_entry_direct_execution_blocked',r.stdout)
    def test_machine_profile_does_not_claim_data_complete(self):
        sys.path.insert(0,str(ROOT/'scripts'))
        import local_business
        p=local_business.machine_profile()
        self.assertFalse(p['full_workflow_completed'])
        self.assertTrue(p['missing_formal_inputs'])
        self.assertEqual(p['home'],r'F:\Codex\Home')
    def test_no_evidence_not_market_success(self):
        sys.path.insert(0,str(ROOT/'scripts'))
        import local_business
        with tempfile.TemporaryDirectory() as d:
            x=local_business.execute('validate-evidence',Path(d),None)
        self.assertEqual(x['status'],'BLOCKED')
        self.assertFalse(x['full_workflow_completed'])
    def test_output_cannot_pollute_installed_skill(self):
        sys.path.insert(0,str(ROOT/'scripts'))
        import local_business
        with self.assertRaises(ValueError):local_business.validate_output_root(ROOT/'reports')

if __name__=='__main__':unittest.main(verbosity=2)
