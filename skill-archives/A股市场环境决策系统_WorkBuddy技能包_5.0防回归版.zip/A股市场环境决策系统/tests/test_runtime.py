"""合成边界数据；不代表真实市场、公式回测或收益验证。"""
import importlib.util
import math
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
AVAILABLE = importlib.util.find_spec('runtime') is not None
if AVAILABLE:
    import runtime as r

class Availability(unittest.TestCase):
    def test_executable_rules_exist(self):
        self.assertTrue(AVAILABLE, '原包只有文字断言，缺少可执行校验')

@unittest.skipUnless(AVAILABLE, '校验器尚未实现')
class Rules(unittest.TestCase):
    def test_weighted20_no_skipped_oldest(self):
        rows=[(i,i,i,i) for i in range(1,21)]
        self.assertAlmostEqual(r.weighted20(rows),sum(i*i for i in range(1,21))/210)
        self.assertIsNone(r.weighted20(rows[:-1]))

    def test_platform_downward_exit_not_breakout(self):
        self.assertFalse(r.platform_breakout([10]*63+[5]))
        self.assertTrue(r.platform_breakout([10]*63+[15]))
        self.assertFalse(r.platform_breakout([10]*64))
        self.assertIsNone(r.platform_breakout([10]*63))

    def test_confirmation_precedes_filter(self):
        self.assertEqual(r.filtered_breakout([True,True],[False,True]),[False,True])
        self.assertEqual(r.filtered_breakout([True,True],[True,True]),[True,False])

    def test_empty_category_is_not_observed_neutral(self):
        x = r.category([(None, 0), (None, 0)])
        self.assertIsNone(x['observed'])
        self.assertEqual(x['effective'], 50)
        self.assertEqual(x['coverage'], 0)

    def test_partial_weight_matches_coverage(self):
        x = r.category([(0, 1), (100, .5)])
        self.assertAlmostEqual(x['observed'], 100/3)
        self.assertAlmostEqual(x['effective'], 37.5)

    def test_missing_cannot_be_scored(self):
        with self.assertRaises(ValueError): r.category([(50, 0)])

    def test_nonfinite_rejected(self):
        for v in (math.nan, math.inf, -1, 101, True):
            with self.subTest(v=v), self.assertRaises(ValueError):
                r.category([(v, 1)])

    def test_percentile_ties(self):
        self.assertEqual(r.percentile(2, [2]*120), 50)
        self.assertEqual(r.percentile(3, [2]*120), 100)
        self.assertEqual(r.percentile(1, [2]*120), 0)

    def test_percentile_short_history(self):
        self.assertIsNone(r.percentile(1, [2]*119))

    def test_zero_denominator(self):
        self.assertIsNone(r.ratio(0, 0))
        self.assertEqual(r.ratio(0, 10), 0)

    def test_direction_gaps_closed(self):
        self.assertEqual([r.direction(x) for x in [39,39.5,40,59,59.5,60]], [-1,-1,0,0,0,1])

    def test_speed_common_axes(self):
        # 各轴实际不变；换缺失轴不能制造改善。
        a={'breadth':100,'emotion':0,'technical':50,'liquidity':50}
        b=dict(a, emotion=None)
        c=dict(a, breadth=None)
        self.assertIsNone(r.speed(b,c,a))
        self.assertEqual(r.speed(b,a,a)['value'], 0)

    def test_speed_three_day_required(self):
        a=dict.fromkeys(r.AXES, 50)
        self.assertIsNone(r.speed(a,a,{}))

    def test_speed_boundary(self):
        a=dict.fromkeys(r.AXES, 65)
        b=dict.fromkeys(r.AXES, 50)
        self.assertEqual(r.speed(a,b,b)['label'], '快速改善')

    def test_health_missing_interval(self):
        x=r.health(dict(breadth=None,emotion=100,technical=100,liquidity=100,structure=100,policy=100))
        self.assertIsNone(x['score'])
        self.assertEqual((x['lower'],x['upper'],x['coverage']), (75,100,.75))

    def test_all_state_score_boundaries(self):
        for h in [0,24.9,25,39.5,40,49.5,50,64,64.5,65,74.5,75,100]:
            for b in [0,20,45,49,50,65,100]:
                with self.subTest(h=h,b=b):
                    self.assertIn(r.candidate(h,b,50,59,50,False,[False]*5,False), range(1,8))

    def test_single_hard_gate_never_positive(self):
        for i in range(5):
            gates=[False]*5;gates[i]=True
            self.assertIn(r.candidate(90,90,90,90,90,True,gates,False), [6,7])

    def test_unknown_gate_blocks_candidate(self):
        self.assertIsNone(r.candidate(90,90,90,90,90,True,[None,False,False,False,False],False))

    def test_decimal_candidate(self):
        self.assertEqual(r.candidate(64.5,55,55,55,50,False,[False]*5,False),3)
        self.assertEqual(r.candidate(70,49,50,59,50,False,[False]*5,False),3)

    def test_unknown_history_not_invented(self):
        p=r.permissions(1, None, False, 'final',False)
        self.assertEqual(p['cap'],0)
        self.assertEqual(max(p['strategies']),0)

    def test_known_risk_survives_unrelated_missing(self):
        self.assertEqual(r.candidate(30,20,30,None,50,False,[False]*5,False),6)

    def test_systemic_not_supplied_is_unknown(self):
        self.assertIsNone(r.risk_gates(.5,.5,.0,[.0]*120,0,[0]*20,0,0,1,[1,1,1])[-1])

    def test_string_flags_rejected(self):
        with self.assertRaises(ValueError):r.candidate(90,90,90,90,90,'False',[False]*5,False)
        with self.assertRaises(ValueError):r.permissions(1,None,'False','final',False)

    def test_slow_open_one_rung(self):
        previous={'cap':0,'strategies':[0]*6}
        p=r.permissions(1,previous,True,'final',False)
        self.assertEqual(p['cap'],10)
        self.assertEqual(p['strategies'],[1]*6)

    def test_fast_close(self):
        previous={'cap':70,'strategies':[4]*6}
        self.assertEqual(r.permissions(7,previous,False,'final',False)['cap'],0)

    def test_morning_no_upgrade_any_strategy(self):
        previous={'cap':10,'strategies':[1,0,0,1,0,1]}
        self.assertEqual(r.permissions(1,previous,True,'morning',False),previous)

    def test_state_numbers_do_not_authorize_strategy(self):
        previous={'cap':10,'strategies':[1,0,0,1,0,1]}
        p=r.permissions(4,previous,False,'final',False)
        self.assertEqual(p['strategies'][:5],[0]*5)

    def test_incomplete_run_zero_new_exposure(self):
        self.assertEqual(r.permissions(1,None,True,'final',True),{'cap':0,'strategies':[0]*6})

    def test_same_baseline_same_permissions(self):
        previous={'cap':10,'strategies':[1]*6}
        self.assertEqual(r.permissions(1,previous,True,'final',False),r.permissions(1,previous,True,'final',False))

    def test_risk_units_and_boundaries(self):
        self.assertTrue(r.risk_gates(.2,.3,.02,[.001]*120,20,[1]*20,6,4,.6,[4,3,2])[0])
        self.assertTrue(r.risk_gates(.2,.3,.02,[.001]*120,20,[1]*20,6,4,.6,[4,3,2])[3])

    def test_tamper_and_path_escape(self):
        import json,hashlib
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'a.txt').write_text('a')
            m={'版本':r.VERSION,'files':[{'path':'a.txt','sha256':hashlib.sha256(b'a').hexdigest()}]}
            (p/'manifest.json').write_text(json.dumps(m))
            self.assertEqual(r.package_errors(p),[])
            (p/'a.txt').write_text('b')
            self.assertTrue(r.package_errors(p))
            m['files'][0]['path']='../a.txt'
            (p/'manifest.json').write_text(json.dumps(m))
            self.assertTrue(r.package_errors(p))

    def test_extra_file_rejected(self):
        import json
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'a.txt').write_text('x')
            (p/'manifest.json').write_text(json.dumps({'版本':r.VERSION,'files':[]}))
            self.assertTrue(r.package_errors(p))

    def test_empty_run_not_formal(self):
        self.assertTrue(r.run_errors({},ROOT))

@unittest.skipUnless(AVAILABLE, '校验器尚未实现')
class Evidence(unittest.TestCase):
    def setUp(self):
        import hashlib
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        (self.root/'synthetic.txt').write_text('SYNTHETIC - NOT MARKET EVIDENCE',encoding='utf-8')
        days=['2026-09-07','2026-09-08','2026-09-09','2026-09-10']
        self.run=dict(version=r.VERSION,mode='final',decision_at='2026-09-10T17:30:00+08:00',
            pool_id='SYNTHETIC_POOL',mapping_version='SYNTHETIC_MAP',formula_version='SYNTHETIC_FORMULA',
            artifacts=[dict(id='s',path='synthetic.txt',sha256=r.digest(self.root/'synthetic.txt'),source='TEST_ONLY',
                data_at='2026-09-10T15:00:00+08:00',available_at='2026-09-10T15:00:00+08:00')],
            steps=[dict(id=i,status='完成',evidence=['s']) for i in range(1,22)],
            nodes=[dict(id=i,result='TEST',basis='TEST',explanation='TEST',impact='TEST',data_status='精确',evidence=['s']) for i in r.IDS],
            categories=[dict(name=i) for i in r.CATEGORIES],
            gates=[dict(id=i,triggered=False,evidence=['s']) for i in range(1,6)],
            scores=dict.fromkeys(r.WEIGHTS,50),health=50,speed=0,
            axis_history=[dict(trade_date=d,scores=dict.fromkeys(r.AXES,50),mapping_version='SYNTHETIC_MAP',pool_id='SYNTHETIC_POOL',evidence=['s']) for d in days],
            trading_days=days,previous=dict(trade_date=days[-2],mode='final',evidence=['s']),
            regression_checks=[dict(id=i,status='通过',evidence=['s']) for i in range(1,43)],is_example=False)
    def tearDown(self): self.temp.cleanup()
    def test_valid_structure_only(self):
        # 验证格式能通过，不证明伪造来源真实；工具不能认证来源的边界必须保留。
        self.assertEqual(r.run_errors(self.run,self.root),[])
    def test_future_available_time(self):
        self.run['artifacts'][0]['available_at']='2026-09-10T18:00:00+08:00'
        self.assertTrue(r.run_errors(self.run,self.root))
    def test_missing_and_duplicate_records(self):
        self.run['nodes'][-1]=self.run['nodes'][0]
        self.assertTrue(r.run_errors(self.run,self.root))
    def test_unknown_gate(self):
        self.run['gates'][0]['triggered']=None
        self.assertTrue(r.run_errors(self.run,self.root))
    def test_swapped_mapping_version(self):
        self.run['axis_history'][0]['mapping_version']='OTHER'
        self.assertTrue(r.run_errors(self.run,self.root))
    def test_single_regression_not_all(self):
        self.run['regression_checks']=self.run['regression_checks'][:1]
        self.assertTrue(r.run_errors(self.run,self.root))
    def test_example_must_be_rejected(self):
        self.run['is_example']=True
        self.assertTrue(r.run_errors(self.run,self.root))
    def test_fake_health_not_accepted(self):
        self.run['health']=90
        self.assertTrue(r.run_errors(self.run,self.root))
    def test_extra_nested_manifest_detected(self):
        import json
        (self.root/'nested').mkdir()
        (self.root/'nested/manifest.json').write_text('{}')
        (self.root/'manifest.json').write_text(json.dumps({'版本':r.VERSION,'files':[]}))
        self.assertTrue(r.package_errors(self.root))

if __name__=='__main__': unittest.main(verbosity=2)
