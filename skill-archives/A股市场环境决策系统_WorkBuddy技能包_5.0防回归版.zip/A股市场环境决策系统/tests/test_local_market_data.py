import hashlib
import struct
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from local_market_data import read_day, list_current_pool


def bar(date, op=1000, hi=1100, lo=900, cl=1050, amount=105000.0, volume=10000):
    return struct.pack("<IIIIIfII", date, op, hi, lo, cl, amount, volume, 0)


def tnf_record(code, name):
    row = bytearray(360)
    row[:6] = code.encode("ascii")
    text = name.encode("gbk")
    row[31:31 + len(text)] = text
    return bytes(row)


class ReadDayTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "test.day"

    def tearDown(self):
        self.tmp.cleanup()

    def read(self, raw):
        self.path.write_bytes(raw)
        return read_day(self.path, "2026-09-11")

    def test_scaling_units_and_no_interpolation(self):
        result = self.read(bar(20260909) + bar(20260911))
        self.assertEqual(result.date.tolist(), [20260909, 20260911])
        self.assertEqual(result.iloc[0].open, 10.0)
        self.assertEqual(result.iloc[0].amount, 105000.0)
        self.assertEqual(result.iloc[0].volume, 10000)

    def test_length_rejected(self):
        with self.assertRaisesRegex(ValueError, "invalid_day_length"):
            self.read(bar(20260911) + b"x")

    def test_duplicate_and_reverse_dates_rejected(self):
        for dates in [(20260911, 20260911), (20260911, 20260910)]:
            with self.subTest(dates=dates), self.assertRaisesRegex(ValueError, "non_monotonic"):
                self.read(b"".join(bar(d) for d in dates))

    def test_future_truncated(self):
        result = self.read(bar(20260911) + bar(20260914))
        self.assertEqual(result.date.tolist(), [20260911])

    def test_future_invalid_record_still_rejected(self):
        with self.assertRaisesRegex(ValueError, "invalid_ohlc"):
            self.read(bar(20260911) + bar(20260914, op=0))

    def test_ohlc_and_amount(self):
        for kwargs in [{"op": 0}, {"hi": 1000}, {"lo": 1060}, {"amount": float("nan")}, {"amount": -1}]:
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                self.read(bar(20260911, **kwargs))

    def test_invalid_calendar_date(self):
        with self.assertRaisesRegex(ValueError, "invalid_date"):
            self.read(bar(20260230))

    def test_short_calendar_integer_rejected(self):
        with self.assertRaisesRegex(ValueError, "invalid_date"):
            self.read(bar(2026911))

    def test_expected_hash_and_source_binding(self):
        raw = bar(20260911)
        self.path.write_bytes(raw)
        digest = hashlib.sha256(raw).hexdigest()
        result = read_day(self.path, "2026-09-11", expected_sha256=digest)
        self.assertEqual(result.attrs["source"]["sha256"], digest)
        with self.assertRaisesRegex(ValueError, "source_hash_changed_since_pool"):
            read_day(self.path, "2026-09-11", expected_sha256="0" * 64)

    def test_mutation_during_read_is_rejected(self):
        self.path.write_bytes(bar(20260911))
        original = Path.read_bytes
        def changing_read(path):
            result = original(path)
            path.write_bytes(result + bar(20260914))
            return result
        with patch.object(Path, "read_bytes", changing_read):
            with self.assertRaisesRegex(ValueError, "source_changed_during_read"):
                read_day(self.path, "2026-09-11")

    def test_empty_valid(self):
        self.assertTrue(self.read(b"").empty)


class UniverseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        metadata = self.root / "T0002" / "hq_cache"
        metadata.mkdir(parents=True)
        rows = [("600000", "浦发银行"), ("600001", "*ST测试"),
                ("600002", "缺少文件"), ("600003", "日期落后"),
                ("600004", "短历史"), ("600005", "字节损坏"),
                ("600006", "中文名称超过十二个汉字也不截断"), ("510000", "非股票")]
        (metadata / "shs.tnf").write_bytes(b"\0" * 50 + b"".join(tnf_record(*r) for r in rows))
        (metadata / "szs.tnf").write_bytes(b"\0" * 50)
        self.days = self.root / "vipdoc" / "sh" / "lday"
        self.days.mkdir(parents=True)
        full = b"".join(bar(d) for d in [20260904, 20260907, 20260908, 20260909, 20260910, 20260911])
        (self.days / "sh600000.day").write_bytes(full)
        (self.days / "sh600003.day").write_bytes(bar(20260910))
        (self.days / "sh600004.day").write_bytes(bar(20260911))
        (self.days / "sh600005.day").write_bytes(b"x")
        (self.days / "sh600006.day").write_bytes(full)

    def tearDown(self):
        self.tmp.cleanup()

    def test_complete_denominator_and_exclusions(self):
        result = list_current_pool("2026-09-11", tdx_root=self.root)
        self.assertEqual(result["current_tnf_applicable_record_count"], 7)
        self.assertEqual(len(result["eligible"]), 2)
        self.assertEqual(len(result["excluded"]), 5)
        reasons = {r["symbol"]: r["reason"] for r in result["excluded"]}
        self.assertEqual(reasons["sh600003"], "no_target_day_record_not_proven_suspension")
        self.assertEqual(reasons["sh600004"], "fewer_than_six_bars_initial_listing_regime_unknown")
        self.assertEqual(reasons["sh600002"], "day_file_missing")
        self.assertEqual(reasons["sh600005"], "day_read_or_validation_failed")
        self.assertEqual(result["eligible"][1]["name"], "中文名称超过十二个汉字也不截断")
        for source in result["sources"]:
            self.assertEqual(source["sha256"], hashlib.sha256(Path(source["path"]).read_bytes()).hexdigest())

    def test_invalid_metadata_rejected(self):
        (self.root / "T0002" / "hq_cache" / "szs.tnf").write_bytes(b"bad")
        with self.assertRaisesRegex(ValueError, "invalid_tnf_length"):
            list_current_pool("2026-09-11", tdx_root=self.root)


if __name__ == "__main__":
    unittest.main()
