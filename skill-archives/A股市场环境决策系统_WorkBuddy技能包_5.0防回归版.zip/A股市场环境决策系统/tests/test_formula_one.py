import unittest
import numpy as np
import pandas as pd
from formula_one import compute, filtered, smooth, golden

def frame(close):
    c=np.asarray(close,dtype=float)
    f=pd.DataFrame({'open':c,'high':c+1,'low':c-1,'close':c,'volume':100.,'amount':c*10000})
    f.attrs.update(volume_unit='lots',amount_unit='CNY',history_complete=True)
    return f

class FormulaOneTests(unittest.TestCase):
    def test_filter_leading_unknown_not_false(self):
        r=filtered(pd.Series([np.nan,1.,0.,0.,1.]),2)
        self.assertTrue(np.isnan(r.iloc[1]));self.assertEqual(r.iloc[-1],1.)
    def test_filter_gap_recovers(self):
        r=filtered(pd.Series([0.,np.nan,0.,0.,0.,1.]),2)
        self.assertEqual(r.iloc[-1],1.)
    def test_missing_engineering_history(self):
        f=frame(np.arange(10.,310.));f.attrs.pop('history_complete')
        r=compute(f)
        for n in (1,2,5,8,9,10,14,20,26,28,29):self.assertEqual(r[f'一-{n:02d}']['coverage'],0.)
        self.assertEqual(r['一-13']['coverage'],1.)
    def test_dates_not_reordered(self):
        f=frame([10.,11.,12.]);f['date']=[20260102,20260101,20260103]
        self.assertTrue(all(x['coverage']==0 for x in compute(f).values()))
    def test_json_safe(self):
        import json
        json.dumps(compute(frame(np.arange(10.,310.))),allow_nan=False)
    def test_seed50_exact(self):
        r=smooth(pd.Series([np.nan,80.,20.]),1/3,50.)
        self.assertAlmostEqual(r.iloc[1],60.)
        self.assertAlmostEqual(r.iloc[2],140/3)
    def test_flat(self):
        out=compute(frame([100.]*300))
        self.assertEqual(len(out),29)
        for n in (1,2,5,7,10,13,19,23):
            self.assertEqual(out[f'一-{n:02d}']['score'],50.)
        self.assertIsNone(out['一-20']['score'])
        self.assertFalse(out['一-26']['triggered'])
        self.assertEqual(out['一-18']['value'],100.)
    def test_short(self):
        out=compute(frame([10.,11.]))
        for n in (5,7,13,14,15,19,23,26,29):
            self.assertEqual(out[f'一-{n:02d}']['coverage'],0.)
        self.assertIsNotNone(out['一-01']['score'])
    def test_downward_platform_not_breakout(self):
        out=compute(frame([100.]*80+[80.]))
        self.assertFalse(out['一-15']['triggered'])
    def test_upward_platform_breakout(self):
        out=compute(frame([100.]*80+[115.]))
        self.assertTrue(out['一-15']['triggered'])
    def test_dynamic_and_limit_missing(self):
        out=compute(frame(np.linspace(10,30,300)))
        for n in (3,4,6,11,12,16,21,22,27):
            self.assertIsNone(out[f'一-{n:02d}']['score'])
            self.assertEqual(out[f'一-{n:02d}']['coverage'],0.)
    def test_filter_suppresses_n(self):
        self.assertEqual(filtered(pd.Series([1.,1.,1.,1.,1.]),2).tolist(),[1.,0.,0.,1.,0.])
    def test_seed_and_gap(self):
        s=smooth(pd.Series([np.nan,10.,20.,np.nan,30.]),.5)
        self.assertEqual(s.iloc[1],10.)
        self.assertEqual(s.iloc[2],15.)
        self.assertTrue(np.isnan(s.iloc[-1]))
    def test_correct_20_weight(self):
        f=frame(np.arange(10.,40.));out=compute(f)
        self.assertAlmostEqual(out['一-07']['value'][0],np.dot(np.arange(20.,40.),np.arange(1,21))/210)
    def test_missing_unit_not_cost(self):
        f=frame([10.]*80);f.attrs={}
        self.assertEqual(compute(f)['一-18']['coverage'],0.)
    def test_golden_previous_locked(self):
        f=frame(100+15*np.sin(np.arange(200)/9));out=compute(f)
        self.assertEqual(out['一-29']['value']['previous_locked'],golden(f.iloc[:-1]))
    def test_invalid_prices(self):
        f=frame([10.]*80);f.loc[40,'close']=np.nan
        self.assertTrue(all(x['coverage']==0 for x in compute(f).values()))
    def test_zero_range_not_kdj_strength(self):
        f=frame([100.]*80);f['high']=100.;f['low']=100.
        self.assertEqual(compute(f)['一-26']['coverage'],0.)
    def test_boll_population_std(self):
        f=frame(np.arange(10.,50.));out=compute(f)
        self.assertAlmostEqual(out['一-23']['value']['width'],4*np.std(np.arange(30.,50.),ddof=0))

if __name__=='__main__': unittest.main()
