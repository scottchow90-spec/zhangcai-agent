"""Bounded aggregation regressions. Never runs a market scan."""
import inspect
import sys
import unittest
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import market_analysis as m


def object_row(symbol,score=100.,coverage=1.):
    return dict(symbol=symbol,nodes={k:dict(score=score,coverage=coverage,triggered=True,reason='synthetic') for k in m.IDS})

def sample_gate(daily,expected=10):
    history=[r['amount'] for r in daily[-21:-1]]
    amount_ratio=daily[-1]['amount']/float(np.median(history))
    return m.research_gates(daily,expected,amount_ratio)

class AggregationTests(unittest.TestCase):
    def test_liquidity_prior_twenty_missing_stays_unknown(self):
        daily=[dict(valid=5,amount=10.,up_ratio=.5) for _ in range(18)]+[dict(valid=10,amount=120.,up_ratio=.5),dict(valid=10,amount=100.,up_ratio=.5),dict(valid=10,amount=60.,up_ratio=.4)]
        self.assertIsNone(sample_gate(daily)[3])
    def test_liquidity_complete_sample_detects_shock(self):
        daily=[dict(valid=10,amount=100.,up_ratio=.5) for _ in range(18)]+[dict(valid=10,amount=120.,up_ratio=.5),dict(valid=10,amount=100.,up_ratio=.5),dict(valid=10,amount=60.,up_ratio=.4)]
        self.assertTrue(sample_gate(daily)[3])
    def test_gate_short_and_invalid_inputs(self):
        self.assertEqual(m.research_gates([],10,None),[None]*5)
        daily=[dict(valid=10,amount=100.,up_ratio=.4)]*21
        self.assertIsNone(m.research_gates(daily,10,float('nan'))[3])
        daily[0]=dict(valid=10,amount=None,up_ratio=.4)
        self.assertIsNone(m.research_gates(daily,10,.6)[3])
    def test_non_scoring_data_coverage_separate(self):
        r=object_row('sh600001');r['nodes']['一-18'].update(score=None,value=12.3,triggered=None)
        x=next(x for x in m.aggregate([], [r],1,m.matrix()) if x['id']=='一-18')
        self.assertEqual(x['coverage'],0.);self.assertIsNone(x['score'])
        self.assertEqual(x['data_coverage'],1.)
        self.assertEqual(x['stock_channel']['data_available_objects'],1)
        self.assertIn('数据齐备',x['data_status']);self.assertIn('一-18',x['result'])
    def test_fixed_index_denominator(self):
        nodes=m.aggregate([object_row(str(i)) for i in range(4)],[object_row('sh600001')],1,m.matrix())
        self.assertEqual(next(x for x in nodes if x['id']=='一-01')['coverage'],.5)
    def test_dual_channel_fixed_weights(self):
        nodes=m.aggregate([object_row(str(i)) for i in range(4)],[object_row('sh600001',50),object_row('sh600002',50)],2,m.matrix())
        x=next(x for x in nodes if x['id']=='二-02')
        self.assertEqual(x['coverage'],.75);self.assertAlmostEqual(x['score'],200/3)
    def test_missing_objects_retained(self):
        x=m.channel([object_row('sh600001')],'二-02',2)
        self.assertEqual(x['coverage'],.5);self.assertEqual(x['trigger_rate_bounds'],[.5,1.])
    def test_dependencies_not_scored_twice(self):
        definitions=m.matrix();used=[k for k,v in definitions.items() if v['role'] in ('评分主节点','仅实时评分节点')]
        self.assertEqual(len(used),len(set(used)))
        self.assertTrue(all(k not in used for k in ['二-09','二-10','二-11','二-13','二-16','二-17']))
    def test_fixed_category_missing_shrinkage(self):
        x=m.rules().category([(100,1),(None,0)])
        self.assertEqual(x['coverage'],.5);self.assertEqual(x['effective'],75)
    def test_separate_formal_permission_and_compute_error(self):
        source=inspect.getsource(m.execute)
        for text in ["'formal_qualification':False","'cap':0,'strategies':[0]*6","'full_workflow_completed':False","if x.get('error_kind')=='compute'","'BLOCKED' if errors else 'CLEAN_PASS'"]:
            self.assertIn(text,source)

if __name__=='__main__':unittest.main()
