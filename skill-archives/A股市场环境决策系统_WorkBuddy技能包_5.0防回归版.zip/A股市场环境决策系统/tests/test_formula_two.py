import unittest
import numpy as np
import pandas as pd
from formula_two import compute,forecast,filt,last_ref,cmp

def frame(n=100):
    c=np.linspace(10,20,n)
    f=pd.DataFrame(dict(open=c-.1,high=c+.3,low=c-.3,close=c,volume=np.arange(n)+100,amount=(np.arange(n)+100)*c*100))
    f.attrs.update(history_complete=True,volume_unit='lots')
    return f

class FormulaTwoTest(unittest.TestCase):
    def test_json_serializable(self):
        import json
        json.dumps(compute(frame()),allow_nan=False)
    def test_current_metadata(self):
        f=frame();f.attrs.update(first_observed_date='2020-01-01',date='2026-09-11',eligible_current=True,capital_lots=100000)
        r=compute(f);self.assertEqual(r['二-06']['coverage'],1);self.assertTrue(r['二-06']['triggered']);self.assertEqual(r['二-13']['coverage'],1);self.assertEqual(r['二-12']['coverage'],0)
    def test_integer_date_metadata(self):
        f=frame();f.attrs.update(first_observed_date=20200101,date=20260911,eligible_current=True)
        self.assertEqual(compute(f)['二-06']['coverage'],1)
    def test_short_coverage(self):
        r=compute(frame(1));self.assertEqual(r['二-01']['coverage'],0);self.assertEqual(r['二-10']['coverage'],0);self.assertEqual(r['二-15']['coverage'],0)
    def test_dates_rejected(self):
        f=frame(3);f['date']=[20260102,20260101,20260103]
        self.assertTrue(all(x['coverage']==0 for x in compute(f).values()))
    def test_capital_unit_required(self):
        f=frame();f.attrs.update(capital_lots=10000);f.attrs.pop('volume_unit')
        self.assertEqual(compute(f)['二-13']['coverage'],0)
    def test_short(self):
        r=compute(frame(3)); self.assertIsNone(r['二-04']['score']);self.assertIsNone(r['二-14']['score']);self.assertEqual(len(r),18)
    def test_flat_zero_range(self):
        f=frame();f[['open','high','low','close']]=10
        r=compute(f);self.assertIsNone(r['二-03']['score']);self.assertIsNone(r['二-14']['score']);self.assertEqual(r['二-01']['score'],50)
    def test_missing_filter(self):
        r=compute(frame());self.assertEqual(r['二-12']['coverage'],0);self.assertEqual(r['二-18']['coverage'],0);self.assertEqual(r['二-06']['coverage'],0)
    def test_three_valued_or_and(self):
        u=pd.Series([pd.NA],dtype='boolean');t=pd.Series([True],dtype='boolean');f=~t
        self.assertTrue((t|u).iloc[0]);self.assertFalse((f&u).iloc[0]);self.assertTrue(pd.isna((f|u).iloc[0]))
    def test_forecast_endpoint(self):
        a=forecast(pd.Series([1.,2.,3.,4.,5.]),4);self.assertTrue(pd.isna(a.iloc[2]));self.assertAlmostEqual(a.iloc[3],4);self.assertAlmostEqual(a.iloc[4],5)
    def test_filter_suppression(self):
        s=pd.Series([True]*6,dtype='boolean');self.assertEqual(filt(s,2).tolist(),[True,False,False,True,False,False])
    def test_filter_unknown_resolves(self):
        s=pd.Series([pd.NA,False,False,False,True],dtype='boolean');r=filt(s,2);self.assertTrue(pd.isna(r.iloc[0]));self.assertTrue(r.iloc[-1])
    def test_barslast_no_hit(self):
        s=pd.Series([1.,2.,3.]);r=last_ref(s,pd.Series([False]*3,dtype='boolean'));self.assertTrue(r.isna().all())
    def test_history_not_verified(self):
        f=frame();f.attrs.clear();r=compute(f);self.assertEqual(r['二-01']['coverage'],0)
    def test_four_day_platform(self):
        f=frame(4);f['open']=10;f['close']=11;f['high']=12;f['low']=9
        self.assertTrue(compute(f)['二-08']['triggered'])

if __name__=='__main__':unittest.main()
