# Codex本机安装与执行衔接

本机安装修订5.0.1-codex.2。原包是规则/证据指令包，不包含行情采集及47公式执行器；本修订补入本机日线读取与两套公式工程重放，明确缺失依赖。

## 唯一路由与入口
- 技能ID：a-share-market-environment；中文名：A股市场环境决策系统。ID、名称仅以stock_skill_ids.json为登记权威。
- 自检：`python -B scripts/codex_entry.py selftest`，只证明配置/语法/绑定。
- 本机调试：`python -B scripts/codex_entry.py run -- --action diagnose`。实际检查包完整性、43条原规则测试、5条Codex适配测试、Python身份及通达信本地指数文件日期。诊断成功不是最新行情/全池/公式/市场结论成功。
- 证据校验：`python -B scripts/codex_entry.py run -- --action validate-evidence --evidence-input <绝对run.json路径>`；仍受原运行证据契约限制。
- 分析：`python -B scripts/codex_entry.py run -- --action analyze`；自动取最新本地交易日执行真实研究计算；报告计算完成情况和正式资格，不能用diagnose代替。
- 每次完成绑定用户原话：增加 `--workflow-request-file <UTF-8原始用户请求文件>`，不改写请求适配简化模式。
- 核验与授权：`verify --receipt <回执>`；诊断/格式验收仅 `authorize --receipt <回执> --scope contract_execution`。默认workflow授权仍拒绝完整语义未证明，保留边界。

## 本机路径
唯一安装目录为F:/Codex/Home/skills/a-share-market-environment；C盘.codex是同物理目录的兼容junction，不再安装第二份。
数据和执行回执在F:/Codex/Home/business_data/a-share-market-environment。参数及只读通达信目录见local_profile.json；不存在或日期陈旧就报告，不擅自启动/控制通达信。
全部文件清单绑定manifest，运行产物禁止进入安装目录。Python和进程沿用本机现有环境，不增加自动化、重启或下单。

## 完整业务仍需的真实输入
47节点逐对象公式结果及参数、动态快照链、历史股票属性/涨停制度、同口径120日宽度/情绪/流动性与事件、前日正式状态，以及独立完整语义重放。缺失时交明确缺口，禁止编造交易权限。
原七类、21步、47表、十二章、五风险及限速规则见SKILL和原评分引用；本安装入口不替代或简化这些规则。
