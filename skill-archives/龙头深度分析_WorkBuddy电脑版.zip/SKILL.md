---
name: a-share-leader-deep-research-workbuddy
description: 在 Windows 电脑版 WorkBuddy 中执行龙头深度研究或龙头深度分析。实时核对最新交易日涨停池，完成八类板块唯一归属、龙头性质榜和地位榜、封板时间、板块逻辑及可复算龙虎榜研究；数据冲突或接口异常时明确阻断。
agent_created: true
entry: scripts/workbuddy_entry.py
display_name: 龙头深度分析（电脑版）
---

# 龙头深度分析（WorkBuddy 电脑版）

中文备注：龙头深度研究、龙头深度分析、龙头分析。

## 调用

先运行 `python scripts/workbuddy_entry.py verify` 和 `python scripts/workbuddy_entry.py selftest`。实战运行使用：

```powershell
python scripts/workbuddy_entry.py run --output .local/runs/current
python scripts/workbuddy_entry.py authorize --receipt .local/runs/current/workbuddy-receipt.json
```

WorkBuddy 收到“龙头深度分析”“龙头深度研究”或“龙头分析”时，必须调用本入口的 `run`，不能仅根据技能说明生成结论。只有 `run` 返回 `CLEAN_PASS` 且随后 `authorize` 返回 `AUTHORIZED`，才可展示最终研究结果。

## 数据源

- 腾讯与新浪指数行情：共同确认最新交易日和盘中/盘后阶段。
- 东方财富：涨停池、封板时间、行业、龙虎榜汇总和席位明细。
- 短线侠：`ztpool`、`ztplate`、`ztcount`，与东方财富涨停代码逐只对账。
- 连板网：市场情绪、题材和梯队补充；失败时明确降级，不替代主来源。
- 本地通达信 `ZTC.blk`：只读旁证；缺失或日期过期时明确降级，不影响双公开源主结论。

三项主闸保持不变：腾讯/新浪交易日必须一致；东方财富和短线侠涨停集合必须逐只一致；龙虎榜只有买入、卖出和净额均能由披露席位复算一致时才进入榜单。接口限流、权限失败、字段异常、日期冲突和未知分类均不得伪装成正常结果。

默认输出 JSON、Markdown 和 HTML 研究资料，不启动或接管 Word、通达信或其他桌面程序，不读取账户、Cookie、密钥或交易凭据，不生成自动下单指令。
