[CmdletBinding()]
param([string]$PythonPath = '', [string]$TdxRoot = '')
$ErrorActionPreference = 'Stop'
$python = if ($PythonPath) { $PythonPath } else { (Get-Command python.exe -ErrorAction Stop).Source }
$entry = Join-Path $PSScriptRoot 'scripts\workbuddy_entry.py'
Push-Location -LiteralPath $PSScriptRoot
try {
    & $python $entry 'verify'
    if ($LASTEXITCODE -ne 0) { throw '技能包完整性校验未通过。' }
    $configArgs = @($entry, 'configure')
    if ($TdxRoot) { $configArgs += @('--tdx-root', $TdxRoot) }
    & $python @configArgs
    if ($LASTEXITCODE -ne 0) { throw '配置检查未通过。' }
    & $python $entry 'selftest'
    if ($LASTEXITCODE -ne 0) { throw '技能自检未通过。' }
    Write-Host '首次检查通过。运行 run 才会访问实时股票数据源。'
}
finally { Pop-Location }
