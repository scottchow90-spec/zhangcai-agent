"""Render audited leader research without any desktop application dependency."""
from __future__ import annotations

import hashlib
import html
import json
import re
from pathlib import Path

from audit_payload import audit_payload

BOARDS = ('大消费', '医药生物', '大科技', '高端制造', '新能源', '基建公用', '金融地产', '周期资源')
TEMPLATE = Path(__file__).resolve().parents[1] / 'references' / 'structured_report_template.md'


def record(path):
    path = Path(path).resolve()
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'size': path.stat().st_size}


def structured_payload(payload):
    return {**payload, 'schema': 'LEADER_STRUCTURED_RESEARCH_V1', 'status': 'CLEAN_PASS',
            'qualification': 'research_only', 'action_allowed': False,
            'delivery_mode': 'structured_only', 'desktop_application_used': False,
            'word_delivery_verified': False}


def _text(value):
    if isinstance(value, list):
        return '、'.join(_text(item) for item in value)
    if isinstance(value, dict):
        return _text(value.get('text') or value.get('name') or '')
    text = str(value if value is not None else '')
    text = re.sub(r'(\d+)天(\d+)板', r'\1天内有\2天达到当天上限', text)
    text = re.sub(r'(?:标准)?连板(\d+)板', r'连续\1天达到当天上限', text)
    for old, new in (
        ('换手回封核心', '回落后又达到当天上限的主要股票'),
        ('高度抱团、多分支并行型', '持续上涨的代表较突出，同时涉及多个方向'),
        ('主机制集中型', '多数股票围绕相同产业联系上涨'),
        ('机制锚', '共同产业联系的代表'), ('高度锚', '持续上涨天数较多的代表'),
        ('容量核心', '买卖金额较大的代表'), ('容量承接', '较大买卖金额'),
        ('时序领先', '较早达到当天上限'), ('时序共振', '先后出现的相似上涨表现'),
        ('共同机制', '共同产业联系'), ('共同产业机制', '共同产业联系'),
        ('题材直接性', '与该方向的直接联系'), ('同题材', '同一方向'),
        ('共享题材成员', '同一方向的股票'), ('题材共现', '股票属于相同方向'),
        ('外生事件因果', '外部事件导致上涨'), ('盘面时序', '市场上涨的先后顺序'),
        ('盘面结构证据强度', '相关市场证据的充分程度'),
        ('盘面验证', '市场实际表现'), ('盘面事实', '市场实际表现'),
        ('结构约束', '仍需注意的问题'), ('结构解释', '市场表现解释'),
        ('连板梯队', '连续多日达到当天上限的股票'),
        ('提供高度', '体现持续上涨表现'), ('高度', '持续上涨表现'),
        ('零开板', '达到当天上限后没有回落'),
        ('开板', '涨到上限后又回落'), ('首次封板', '首次涨到当天上限'),
        ('最终封板', '最后保持当天上限'), ('封板', '保持当天上限'),
        ('涨停', '涨到当天上限'), ('连板', '连续多日达到当天上限'),
        ('龙虎榜', '公开的大额买卖记录'), ('净买入', '买入减去卖出'),
        ('板块', '行业方向'), ('梯队', '连续上涨天数分布'),
        ('分歧较大', '价格反复较明显'), ('龙头', '带头股票'),
    ):
        text = text.replace(old, new)
    return text


def _table(headers, rows):
    clean = [[_text(item) for item in row] for row in rows]
    escaped = [[item.replace('|', '／').replace('\n', ' ') for item in row] for row in clean]
    markdown = ['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join('---' for _ in headers) + ' |']
    markdown.extend('| ' + ' | '.join(row) + ' |' for row in escaped)
    web = '<div class="table-wrap"><table><thead><tr>' + ''.join('<th>' + html.escape(item) + '</th>' for item in headers) + '</tr></thead><tbody>'
    web += ''.join('<tr>' + ''.join('<td>' + html.escape(item) + '</td>' for item in row) + '</tr>' for row in clean)
    web += '</tbody></table></div>'
    return '\n'.join(markdown), web


def render_sections(payload):
    stocks = payload.get('stocks', [])
    by_code = {row['stock_code']: row for row in stocks}
    concepts = payload.get('concept_summary', [])
    concept_map = {row['concept']: row for row in concepts}
    date = str(payload.get('trade_date', ''))
    cutoff = str(payload.get('data_cutoff', ''))
    intraday = payload.get('data_mode') == 'intraday'
    time_label = '截至时点最后保持当天上限' if intraday else '收盘时保持当天上限'
    markdown = [f'# 当天强势股票研究 · {date}', f'截至：{cutoff}', '']
    web = [f'<h1>当天强势股票研究</h1><p class="date">{html.escape(date)} · 截至 {html.escape(cutoff)}</p>']

    def heading(title):
        markdown.extend(['', '## ' + title, ''])
        web.append('<h2>' + html.escape(title) + '</h2>')

    def paragraph(text):
        markdown.extend([_text(text), ''])
        web.append('<p>' + html.escape(_text(text)) + '</p>')

    def table(headers, rows):
        md, fragment = _table(headers, rows)
        markdown.extend([md, ''])
        web.append(fragment)

    heading('当日判断')
    for claim in payload.get('report_claims', []):
        paragraph(f"{claim.get('label', '当日事实')}：{claim.get('text', '')}")
    paragraph(f"涨到当天上限的股票{len(stocks)}只，其中上午已达到当天上限{len(payload.get('morning_limit_ups', []))}只。")
    heading('八类行业方向')
    table(['行业方向', '达到当天上限的股票数', '最早达到当天上限的时间'], [[name, concept_map.get(name, {}).get('verified_limit_up_count', 0),
           concept_map.get(name, {}).get('earliest_first_limit_time', '')] for name in BOARDS])
    for board in concepts[:3]:
        name = board['concept']
        heading(name + ' · 产业联系与当日表现')
        for key in ('logic_summary', 'mechanism_evidence', 'validation_constraints'):
            paragraph(board.get(key, ''))
        heading(name + ' · 当天带头作用排名')
        nature = []
        for row in board.get('nature_top', []):
            stock = by_code[row['stock_code']]
            labels = row.get('nature_names') or [item.get('name', '') for item in stock.get('leader_roles', [])]
            nature.append([row['rank'], stock['stock_name'], row['stock_code'], labels, row.get('reason', '')])
        table(['顺序', '名称', '代码', '当日作用', '事实依据'], nature)
        heading(name + ' · 持续上涨表现排名')
        positions = []
        for row in board.get('position_top', []):
            stock = by_code[row['stock_code']]
            positions.append([row['rank'], stock['stock_name'], row['stock_code'], stock.get('recent_limit_up_label', ''),
                stock.get('first_limit_time', ''), stock.get('latest_seal_time_at_cutoff' if intraday else 'final_limit_time', ''), row.get('reason', '')])
        table(['顺序', '名称', '代码', '最近达到当天上限次数', '首次涨到当天上限', time_label, '事实依据'], positions)
    heading('全部达到当天上限的股票')
    table(['名称', '代码', '行业方向', '细分方向', '当日推动因素', '最近达到当天上限次数', '首次涨到当天上限', time_label, '涨到上限后又回落次数'],
          [[stock['stock_name'], stock['stock_code'], stock['primary_concept'], stock.get('secondary_concepts', []),
            stock.get('event_drivers', []), stock.get('recent_limit_up_label', ''), stock.get('first_limit_time', ''),
            stock.get('latest_seal_time_at_cutoff' if intraday else 'final_limit_time', ''), stock.get('open_count', '')] for stock in stocks])
    heading('上午达到当天上限的股票')
    morning = []
    for value in payload.get('morning_limit_ups', []):
        code = value.get('stock_code') if isinstance(value, dict) else value
        stock = by_code[code]
        morning.append([stock['stock_name'], code, stock['primary_concept'], stock.get('first_limit_time'),
                        stock.get('latest_seal_time_at_cutoff' if intraday else 'final_limit_time')])
    table(['名称', '代码', '行业方向', '首次涨到当天上限', time_label], morning)
    heading('公开的大额买卖记录')
    if payload.get('lhb_status') == 'not_published':
        paragraph('截至上述时点，当日公开名单尚未发布。')
    else:
        lhb = []
        for row in payload.get('lhb_net_buy_ge_100m', []):
            code = row['stock_code']
            stock = by_code[code]
            lhb.append([stock['stock_name'], code, stock['primary_concept'],
                        f"{float(row.get('buy_amount', 0)) / 100000000:.2f}",
                        f"{float(row.get('sell_amount', 0)) / 100000000:.2f}",
                        f"{float(row.get('net_amount', 0)) / 100000000:.2f}"])
        table(['名称', '代码', '行业方向', '买入额（亿元）', '卖出额（亿元）', '买入减去卖出（亿元）'], lhb)
        if not lhb:
            paragraph('当日已公开资料中没有符合条件的记录。')
    css = 'body{font-family:"Microsoft YaHei",sans-serif;color:#18231e;background:#fff;margin:0;line-height:1.65;letter-spacing:0}main{max-width:1240px;margin:auto;padding:32px 24px}h1{font-size:28px;margin:0;color:#164b37}h2{font-size:20px;margin:30px 0 12px;border-bottom:2px solid #d4e6da;padding-bottom:8px}.date{color:#626862}table{width:100%;border-collapse:collapse;font-size:14px}th,td{text-align:left;vertical-align:top;padding:9px;border-bottom:1px solid #dce3df;overflow-wrap:anywhere}th{background:#edf5f0;color:#164b37}tr:nth-child(even){background:#f7f8fa}.table-wrap{overflow-x:auto}p{overflow-wrap:anywhere}@media(max-width:600px){main{padding:20px 12px}h1{font-size:24px}table{min-width:620px}}'
    document = '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>当天强势股票研究</title><style>' + css + '</style></head><body><main>' + ''.join(web) + '</main></body></html>'
    return '\n'.join(markdown), document


def validate_structured_delivery(payload, payload_path, artifacts, validation):
    payload_path = Path(payload_path)
    source = record(payload_path)
    if validation.get('status') != 'PASS' or validation.get('input_sha256') != source['sha256']:
        raise ValueError('original_freshness_validation_not_bound')
    if json.loads(payload_path.read_text(encoding='utf-8-sig')) != payload:
        raise ValueError('structured_delivery_source_content_mismatch')
    audit = audit_payload(payload)
    for binding in artifacts:
        if record(binding['path']) != binding:
            raise ValueError('structured_delivery_artifact_hash_mismatch')
    paths = [Path(binding['path']) for binding in artifacts]
    if len(paths) != 3 or {path.suffix for path in paths} != {'.json', '.md', '.html'}:
        raise ValueError('structured_delivery_required_artifacts_missing')
    json_path = next(path for path in paths if path.suffix == '.json')
    if json.loads(json_path.read_text(encoding='utf-8')) != structured_payload(payload):
        raise ValueError('structured_delivery_result_content_mismatch')
    expected_codes = {str(row['stock_code']) for row in payload['stocks']}
    for binding in artifacts:
        path = Path(binding['path'])
        if path.suffix in {'.md', '.html'}:
            text = path.read_text(encoding='utf-8')
            if not expected_codes.issubset(set(re.findall(r'(?<!\d)\d{6}(?!\d)', text))):
                raise ValueError('structured_delivery_stock_coverage_incomplete')
            if any(label not in text for label in ('当天带头作用排名', '持续上涨表现排名', '全部达到当天上限的股票', '上午达到当天上限的股票', '公开的大额买卖记录')):
                raise ValueError('structured_delivery_sections_incomplete')
    return {'status': 'PASS', 'errors': [], 'stock_count': len(expected_codes),
            'source_payload': source, 'structural_audit': audit,
            'freshness_validation': validation, 'all_stock_codes_covered': True,
            'desktop_application_used': False, 'word_delivery_verified': False}


def write_structured_delivery(payload, payload_path, manifest_path, validation, workflow_dir):
    workflow_dir = Path(workflow_dir).resolve()
    payload_path = Path(payload_path).resolve()
    manifest_path = Path(manifest_path).resolve()
    source_manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if (source_manifest.get('result_sha256') != record(payload_path)['sha256']
            or source_manifest.get('trade_date') != payload.get('trade_date')
            or Path(source_manifest.get('result_path', '')).resolve() != payload_path):
        raise ValueError('collection_manifest_payload_mismatch')
    if validation.get('status') != 'PASS' or validation.get('input_sha256') != record(payload_path)['sha256']:
        raise ValueError('original_freshness_validation_not_bound')
    if json.loads(payload_path.read_text(encoding='utf-8-sig')) != payload:
        raise ValueError('structured_delivery_source_content_mismatch')
    audit_payload(payload)
    markdown, html_text = render_sections(payload)
    date = payload['trade_date']
    json_path = workflow_dir / 'leader_research.json'
    md_path = workflow_dir / f'当天强势股票研究_{date}.md'
    html_path = workflow_dir / f'当天强势股票研究_{date}.html'
    structured = structured_payload(payload)
    json_path.write_text(json.dumps(structured, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    md_path.write_text(markdown, encoding='utf-8')
    html_path.write_text(html_text, encoding='utf-8')
    artifacts = [record(path) for path in (json_path, md_path, html_path)]
    check = validate_structured_delivery(payload, payload_path, artifacts, validation)
    validation_path = workflow_dir / 'leader_structured_validation.json'
    validation_path.write_text(json.dumps(check, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    source_files = [payload_path, manifest_path, workflow_dir / 'payload_validation.json', TEMPLATE]
    for path_value in payload.get('collection_artifacts', {}).values():
        if path_value:
            source_files.append(Path(path_value))
    artifacts.extend(record(path) for path in [*source_files, validation_path])
    manifest = {'schema': 'LEADER_STRUCTURED_DELIVERY_MANIFEST_V1', 'status': 'CLEAN_PASS',
                'trade_date': date, 'validation': {'status': 'PASS', 'errors': []},
                'artifacts': artifacts, 'qualification': 'research_only', 'action_allowed': False}
    delivery_manifest = workflow_dir / 'leader_structured_manifest.json'
    delivery_manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    result = {'status': 'PASS', 'workflow_name': '龙头深度研究', 'delivery_mode': 'structured_only',
              'trade_date': date, 'data_mode': payload['data_mode'], 'data_cutoff': payload['data_cutoff'],
              'payload': str(payload_path), 'payload_sha256': record(payload_path)['sha256'],
              'structured_result': record(json_path), 'delivery_manifest': record(delivery_manifest),
              'stock_count': len(payload['stocks']), 'concept_count': len(payload['concept_summary']),
              'morning_count': len(payload['morning_limit_ups']), 'lhb_count': len(payload['lhb_net_buy_ge_100m']),
              'qualification': 'research_only', 'action_allowed': False,
              'desktop_application_used': False, 'word_delivery_verified': False, 'validation': check}
    (workflow_dir / 'run_result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return result
