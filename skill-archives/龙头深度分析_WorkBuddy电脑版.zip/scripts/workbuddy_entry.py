from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
CONFIG = ROOT / ".local" / "config.json"
PACKAGE_MANIFEST = ROOT / "package-manifest.json"
REQUIRED = (
    "legacy_codex_entry.py", "live_data_pipeline.py", "market_data.py",
    "audit_payload.py", "logic_analysis.py", "leader_structured_delivery.py",
    "duanxianxia_client.ps1", "lianban_daily_client.py",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit(value: dict) -> int:
    print(json.dumps(value, ensure_ascii=False, indent=2))
    return 0 if value.get("status") in {"PASS", "READY", "CONFIGURED", "CLEAN_PASS", "AUTHORIZED"} else 2


def discover_tdx() -> list[Path]:
    found: dict[str, Path] = {}
    for drive in "CDEFGHIJKLMNOPQRSTUVWXYZ":
        for name in ("TDX", "通达信", "通达信金融终端"):
            path = Path(f"{drive}:/{name}")
            if (path / "T0002" / "blocknew").is_dir() or (path / "vipdoc").is_dir():
                found.setdefault(os.path.normcase(str(path.resolve())), path.resolve())
    return list(found.values())


def read_config() -> dict:
    if not CONFIG.is_file():
        return {}
    value = json.loads(CONFIG.read_text(encoding="utf-8"))
    return value if isinstance(value, dict) else {}


def configure(tdx_root: str | None) -> int:
    candidates = [Path(tdx_root).resolve()] if tdx_root else discover_tdx()
    selected = candidates[0] if len(candidates) == 1 else None
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    value = {"schema": "WORKBUDDY_LEADER_CONFIG_V1", "tdx_root": str(selected) if selected else "", "read_only": True}
    CONFIG.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return emit({"status": "CONFIGURED", "config": str(CONFIG), "tdx_root": value["tdx_root"], "tdx_candidates": [str(x) for x in candidates], "note": "通达信仅作只读旁证，可为空。"})


def environment() -> dict[str, str]:
    env = {**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1", "ONESTOCK_STOCK_CANONICAL_CHILD": "1"}
    tdx_root = str(read_config().get("tdx_root") or "").strip()
    if tdx_root:
        env["WORKBUDDY_TDX_ROOT"] = tdx_root
    return env


def run_child(command: list[str], timeout: int = 960) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, cwd=ROOT, env=environment(), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)


def selftest() -> int:
    errors = []
    for name in REQUIRED:
        if not (SCRIPTS / name).is_file():
            errors.append("missing:" + name)
    parsed = 0
    for path in ROOT.rglob("*.py"):
        try:
            ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
            parsed += 1
        except Exception as exc:
            errors.append(f"syntax:{path.name}:{exc}")
    for module in ("requests", "docx", "PIL"):
        try:
            __import__(module)
        except ImportError:
            errors.append("dependency_missing:" + module)
    return emit({"schema": "WORKBUDDY_LEADER_SELFTEST_V1", "status": "READY" if not errors else "BLOCKED", "python": sys.version.split()[0], "python_files_parsed": parsed, "errors": errors, "network_checked": False})


def verify_package() -> int:
    errors = []
    checked = 0
    try:
        manifest = json.loads(PACKAGE_MANIFEST.read_text(encoding="utf-8-sig"))
        for row in manifest.get("files", []):
            relative = str(row.get("path") or "")
            parts = relative.replace("\\", "/").split("/")
            if not relative or any(part in {"", ".", ".."} for part in parts):
                errors.append("unsafe_path:" + relative)
                continue
            path = ROOT.joinpath(*parts)
            checked += 1
            if not path.is_file() or path.stat().st_size != row.get("bytes") or sha256(path) != row.get("sha256"):
                errors.append("mismatch:" + relative)
    except Exception as exc:
        errors.append(f"{type(exc).__name__}:{exc}")
    return emit({"schema": "WORKBUDDY_LEADER_PACKAGE_VERIFY_V1", "status": "CLEAN_PASS" if not errors else "BLOCKED", "checked": checked, "errors": errors})


def collect_lianban(run_dir: Path) -> dict:
    output = run_dir / "lianban-daily.json"
    child = run_child([sys.executable, str(SCRIPTS / "lianban_daily_client.py"), "--latest", "--output", str(output)], 150)
    return {"returncode": child.returncode, "output": str(output), "available": child.returncode == 0 and output.is_file(), "stderr": child.stderr[-500:]}


def run(output: Path) -> int:
    run_dir = output.resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    lianban = collect_lianban(run_dir)
    child = run_child([sys.executable, str(SCRIPTS / "legacy_codex_entry.py"), "run", "--data-only", "--run-dir", str(run_dir)])
    (run_dir / "business.stdout.txt").write_text(child.stdout, encoding="utf-8")
    (run_dir / "business.stderr.txt").write_text(child.stderr, encoding="utf-8")
    workflow = run_dir / "leader_workflow"
    result_path = workflow / "run_result.json"
    if child.returncode or not result_path.is_file():
        return emit({"schema": "WORKBUDDY_LEADER_RUN_V1", "status": "BLOCKED", "returncode": child.returncode, "lianban": lianban, "stdout": child.stdout[-2000:], "stderr": child.stderr[-2000:]})
    result = json.loads(result_path.read_text(encoding="utf-8"))
    files = [path for path in workflow.rglob("*") if path.is_file()]
    receipt = {"schema": "WORKBUDDY_LEADER_RECEIPT_V1", "status": "CLEAN_PASS", "created_at": datetime.now().astimezone().isoformat(timespec="seconds"), "result": str(result_path), "lianban": lianban, "files": [{"path": str(p), "bytes": p.stat().st_size, "sha256": sha256(p)} for p in sorted(files)]}
    receipt_path = run_dir / "workbuddy-receipt.json"
    receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return emit({"schema": "WORKBUDDY_LEADER_RUN_V1", "status": "CLEAN_PASS", "trade_date": result.get("trade_date"), "stock_count": result.get("stock_count"), "concept_count": result.get("concept_count"), "lhb_count": result.get("lhb_count"), "receipt": str(receipt_path), "html": next((str(p) for p in files if p.suffix.lower() == ".html"), "")})


def authorize(receipt_path: Path) -> int:
    errors = []
    try:
        receipt = json.loads(receipt_path.resolve().read_text(encoding="utf-8"))
        if receipt.get("schema") != "WORKBUDDY_LEADER_RECEIPT_V1" or receipt.get("status") != "CLEAN_PASS":
            errors.append("receipt_status_invalid")
        for row in receipt.get("files", []):
            path = Path(row["path"]).resolve()
            if not path.is_file() or path.stat().st_size != row["bytes"] or sha256(path) != row["sha256"]:
                errors.append("artifact_changed:" + path.name)
        result = json.loads(Path(receipt["result"]).read_text(encoding="utf-8"))
        validation = result.get("validation") or {}
        if result.get("status") != "PASS" or validation.get("status") != "PASS" or validation.get("all_stock_codes_covered") is not True:
            errors.append("business_result_not_complete")
    except Exception as exc:
        errors.append(f"{type(exc).__name__}:{exc}")
    return emit({"schema": "WORKBUDDY_LEADER_AUTHORIZATION_V1", "status": "AUTHORIZED" if not errors else "BLOCKED", "receipt": str(receipt_path.resolve()), "errors": errors})


def main() -> int:
    parser = argparse.ArgumentParser(description="龙头深度分析 WorkBuddy 电脑版入口")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("info")
    config = sub.add_parser("configure"); config.add_argument("--tdx-root")
    sub.add_parser("selftest")
    sub.add_parser("verify")
    run_parser = sub.add_parser("run"); run_parser.add_argument("--output", type=Path, default=ROOT / ".local" / "runs" / datetime.now().strftime("%Y%m%d-%H%M%S"))
    auth = sub.add_parser("authorize"); auth.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "info":
        return emit({"status": "PASS", "skill_id": "a-share-leader-deep-research-workbuddy", "display_name": "龙头深度分析（电脑版）", "entry": str(Path(__file__).resolve()), "sources": ["腾讯", "新浪", "东方财富", "短线侠", "连板网", "本地通达信只读旁证"]})
    if args.command == "configure": return configure(args.tdx_root)
    if args.command == "selftest": return selftest()
    if args.command == "verify": return verify_package()
    if args.command == "run": return run(args.output)
    return authorize(args.receipt)


if __name__ == "__main__":
    raise SystemExit(main())
