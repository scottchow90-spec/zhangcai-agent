from pathlib import Path
import ast
import unittest

ROOT = Path(__file__).resolve().parents[1]

class PackageTests(unittest.TestCase):
    def test_root_metadata_and_entry_exist(self):
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("entry: scripts/workbuddy_entry.py", text)
        self.assertIn("龙头深度分析（电脑版）", text)
        self.assertTrue((ROOT / "scripts" / "workbuddy_entry.py").is_file())

    def test_package_has_no_codex_absolute_dependency(self):
        forbidden = ("F:" + "\\Codex\\Home", "C:" + "\\Users\\25296", "TieRobot", "OneStockAgent")
        for path in ROOT.rglob("*"):
            if path.resolve() == Path(__file__).resolve():
                continue
            if path.is_file() and path.suffix.lower() in {".py", ".md", ".json", ".yaml", ".ps1", ".txt"}:
                content = path.read_text(encoding="utf-8-sig", errors="ignore")
                for value in forbidden:
                    self.assertNotIn(value, content, str(path))

    def test_python_files_parse(self):
        for path in ROOT.rglob("*.py"):
            ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))

if __name__ == "__main__": unittest.main()
