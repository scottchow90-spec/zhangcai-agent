连板晋级量化决策系统 V4.4｜深度审计与训练交付包

使用顺序：
1. 安装 01_技能安装包_连板晋级量化决策系统_V4.4_WorkBuddy.zip
2. 安装后先运行 python scripts/selftest.py，必须全部通过。
3. 盘后正式使用严格按技能内 references/install.md 执行，不得跳过独立涨停总数证据。
4. 正式训练只允许 train_pipeline.py；model_train.py train 会主动拒绝。
5. 历史训练模型只能到RESEARCH；最终保留集通过只能到OBSERVATION；至少120个未来交易日后才可能FORMAL。
6. 正式日跑必须生成完整中文盘后报告，不允许只输出Top1。

本交付包中的合成测试结果只用于工程验收，不是A股真实回测收益或胜率。

7. 最终二次验收结果见 05_最终验收报告_V4.4.md；只有该报告标记通过的01技能包才是正式交付件。
