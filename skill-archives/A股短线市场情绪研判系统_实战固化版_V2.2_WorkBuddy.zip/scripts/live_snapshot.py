#!/usr/bin/env python3
"""Build a validated live snapshot from Lianban, Duanxianxia and local TDX."""
from __future__ import annotations
# ONESTOCK_EMBEDDED_LOCAL_IMPORT_BOOTSTRAP
import sys as _onestock_embedded_sys
from pathlib import Path as _OneStockEmbeddedPath
_onestock_embedded_dir = str(_OneStockEmbeddedPath(__file__).resolve().parent)
if _onestock_embedded_dir not in _onestock_embedded_sys.path:
    _onestock_embedded_sys.path.insert(0, _onestock_embedded_dir)

import argparse
import hashlib
import json
import math
import struct
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


DAY = struct.Struct("<IIIIIfII")


def read_last(path: Path, count: int) -> list[tuple[int, int, float]]:
    if not path.is_file() or path.stat().st_size < DAY.size * count:
        return []
    with path.open("rb") as handle:
        handle.seek(-DAY.size * count, 2)
        rows = []
        for _ in range(count):
            date_i, _o, _h, _l, close_i, amount, _v, _u = DAY.unpack(handle.read(DAY.size))
            rows.append((date_i, close_i, float(amount)))
        return rows


def is_equity(path: Path) -> bool:
    name = path.stem.lower()
    return (
        name.startswith(("sh600", "sh601", "sh603", "sh605", "sh688"))
        or name.startswith(("sz000", "sz001", "sz002", "sz003", "sz300", "sz301"))
        or name.startswith(("bj4", "bj8", "bj9"))
    )


def collect_current_tq_rows(tdx_root: Path, symbols: list[str]) -> dict[str, list[tuple[int, int, float]]]:
    user_dir = tdx_root / "PYPlugins" / "user"
    sys.path.insert(0, str(user_dir))
    previous_argv = sys.argv[:]
    sys.argv = ["tqcenter", "--run_tdx", "0"]
    tq = None
    result: dict[str, list[tuple[int, int, float]]] = {}
    try:
        from tqcenter import tq
        tq.initialize(str(user_dir / "tdxdata_test.py"))
        for offset in range(0, len(symbols), 200):
            batch = symbols[offset:offset + 200]
            data = tq.get_market_data(
                field_list=["Close", "Amount"], stock_list=batch,
                period="1d", count=3, dividend_type="none", fill_data=False,
            )
            if not isinstance(data, dict) or "Close" not in data or "Amount" not in data:
                raise ValueError("tongdaxin_current_day_fields_missing")
            for symbol in batch:
                rows = []
                if symbol not in data["Close"] or symbol not in data["Amount"]:
                    result[symbol] = rows
                    continue
                for stamp, close in data["Close"][symbol].items():
                    amount = data["Amount"][symbol].get(stamp)
                    if amount is None or not math.isfinite(float(close)) or not math.isfinite(float(amount)):
                        continue
                    if not hasattr(stamp, "strftime"):
                        raise ValueError("tongdaxin_current_day_timestamp_missing")
                    rows.append((int(stamp.strftime("%Y%m%d")), round(float(close) * 100), float(amount) * 10000))
                result[symbol] = rows
    finally:
        if tq is not None:
            tq.close()
        sys.argv = previous_argv
    return result


def tdx_intraday_market(
    tdx_root: Path, target_date: str, files: list[Path], index_rows: list[tuple[int, int, float]],
    *, fetcher=collect_current_tq_rows, now: datetime | None = None,
) -> dict[str, Any]:
    observed_at = now or datetime.now(timezone(timedelta(hours=8)))
    target_i = int(target_date.replace("-", ""))
    if observed_at.strftime("%Y%m%d") != str(target_i) or len(index_rows) != 2 or index_rows[-1][0] >= target_i:
        raise ValueError("tongdaxin_index_date_mismatch")
    prior_date = index_rows[-1][0]
    local = {f"{path.stem[2:]}.{path.stem[:2].upper()}": read_last(path, 2) for path in files}
    records = fetcher(tdx_root, list(local) + ["999999.SH"])
    completed_at = now or datetime.now(timezone(timedelta(hours=8)))
    index_live = records.get("999999.SH", [])
    current_index = [row for row in index_live if row[0] == target_i]
    previous_index = [row for row in index_live if row[0] == prior_date]
    if len(current_index) != 1 or len(previous_index) != 1:
        raise ValueError("tongdaxin_current_index_date_unverified")
    if previous_index[0][1] != index_rows[-1][1]:
        raise ValueError("tongdaxin_current_index_previous_close_mismatch")
    advancers = decliners = flat = previous_advancers = previous_decliners = previous_flat = 0
    current_amount = previous_amount = 0.0
    evidence_rows = []
    excluded = []
    for symbol, history in local.items():
        current = [row for row in records.get(symbol, []) if row[0] == target_i]
        previous = [row for row in records.get(symbol, []) if row[0] == prior_date]
        if len(history) != 2 or history[-1][0] != prior_date or len(current) != 1 or len(previous) != 1:
            excluded.append({"symbol": symbol, "reason": "current_or_previous_dated_record_missing"})
            continue
        if previous[0][1] != history[-1][1]:
            raise ValueError(f"tongdaxin_current_previous_close_mismatch:{symbol}")
        if current[0][1] <= 0 or current[0][2] <= 0:
            excluded.append({"symbol": symbol, "reason": "no_valid_current_trade"})
            continue
        current_amount += current[0][2]
        previous_amount += history[-1][2]
        delta = current[0][1] - history[-1][1]
        prior_delta = history[-1][1] - history[-2][1]
        advancers += delta > 0
        decliners += delta < 0
        flat += delta == 0
        previous_advancers += prior_delta > 0
        previous_decliners += prior_delta < 0
        previous_flat += prior_delta == 0
        evidence_rows.append({"symbol": symbol, "current": current[0], "previous_tq": previous[0], "previous_local": history[-1]})
    if len(evidence_rows) < 3000:
        raise ValueError(f"tongdaxin_coverage_insufficient:{len(evidence_rows)}")
    if current_amount <= 0 or previous_amount <= 0:
        raise ValueError("tongdaxin_amount_missing")
    proof = {"index_current": current_index[0], "index_previous_tq": previous_index[0], "index_previous_local": index_rows[-1], "rows": evidence_rows, "excluded": excluded}
    encoded = json.dumps(proof, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return {
        "trading_date": target_date, "covered": len(evidence_rows),
        "advancers": advancers, "decliners": decliners, "flat": flat,
        "previous_advancers": previous_advancers, "previous_decliners": previous_decliners, "previous_flat": previous_flat,
        "index_change_pct": round((current_index[0][1] / index_rows[-1][1] - 1) * 100, 3),
        "total_amount_billion": round(current_amount / 100_000_000, 1),
        "previous_total_amount_billion": round(previous_amount / 100_000_000, 1),
        "amount_change_pct": None,
        "amount_comparison_mode": "intraday_vs_previous_full_day_not_comparable",
        "source_mode": "tq_current_day_with_persisted_previous_close",
        "observed_at": completed_at.isoformat(timespec="seconds"),
        "collection_started_at": observed_at.isoformat(timespec="seconds"),
        "amount_unit": "CNY",
        "previous_trading_date": str(prior_date),
        "date_and_price_proof": proof,
        "date_and_price_proof_sha256": hashlib.sha256(encoded).hexdigest(),
    }


def tdx_market(tdx_root: Path, target_date: str) -> dict[str, Any]:
    target_i = int(target_date.replace("-", ""))
    files = [p for market in ("sh", "sz", "bj") for p in (tdx_root / "vipdoc" / market / "lday").glob("*.day") if is_equity(p)]
    index_rows = read_last(tdx_root / "vipdoc" / "sh" / "lday" / "sh000001.day", 2)
    if len(index_rows) != 2 or index_rows[-1][0] != target_i:
        return tdx_intraday_market(tdx_root, target_date, files, index_rows)
    advancers = decliners = flat = 0
    previous_advancers = previous_decliners = previous_flat = 0
    current_amount = previous_amount = 0.0
    covered = 0
    for path in files:
        rows = read_last(path, 3)
        if len(rows) != 3 or rows[-1][0] != target_i:
            continue
        covered += 1
        before_previous, previous, current = rows
        current_amount += max(0.0, current[2])
        previous_amount += max(0.0, previous[2])
        if current[1] > previous[1]:
            advancers += 1
        elif current[1] < previous[1]:
            decliners += 1
        else:
            flat += 1
        if previous[1] > before_previous[1]:
            previous_advancers += 1
        elif previous[1] < before_previous[1]:
            previous_decliners += 1
        else:
            previous_flat += 1
    index_rows = read_last(tdx_root / "vipdoc" / "sh" / "lday" / "sh000001.day", 2)
    if len(index_rows) != 2 or index_rows[1][0] != target_i:
        raise ValueError("tongdaxin_index_date_mismatch")
    if covered < 3000:
        raise ValueError(f"tongdaxin_coverage_insufficient:{covered}")
    index_change = (index_rows[1][1] / index_rows[0][1] - 1) * 100
    if previous_amount <= 0:
        raise ValueError("tongdaxin_previous_amount_missing")
    if current_amount <= 0:
        raise ValueError("tongdaxin_current_amount_missing")
    amount_change = (current_amount / previous_amount - 1) * 100
    return {
        "trading_date": target_date,
        "covered": covered,
        "advancers": advancers,
        "decliners": decliners,
        "flat": flat,
        "previous_advancers": previous_advancers,
        "previous_decliners": previous_decliners,
        "previous_flat": previous_flat,
        "index_change_pct": round(index_change, 3),
        "total_amount_billion": round(current_amount / 100_000_000, 1),
        "amount_change_pct": round(amount_change, 2),
    }




def read_last_up_to(path: Path, count: int) -> list[tuple[int, int, float]]:
    """Read up to count records instead of requiring the file to contain all of them."""
    if not path.is_file() or path.stat().st_size < DAY.size:
        return []
    available = path.stat().st_size // DAY.size
    take = min(max(1, count), available)
    with path.open("rb") as handle:
        handle.seek(-DAY.size * take, 2)
        rows = []
        for _ in range(take):
            chunk = handle.read(DAY.size)
            if len(chunk) != DAY.size:
                break
            date_i, _o, _h, _l, close_i, amount, _v, _u = DAY.unpack(chunk)
            rows.append((date_i, close_i, float(amount)))
        return rows


def _date_int(value: str) -> int:
    return int(value.replace("-", ""))


def tdx_history_market(tdx_root: Path, dates: list[str], current_market: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Build breadth/amount history from local TDX for the requested trading dates.

    The current date may be intraday and therefore absent from local .day files; in that
    case current_market (already validated by TQ + persisted previous close) is used.
    """
    wanted = {_date_int(x): x for x in dates}
    if not wanted:
        return {}
    files = [p for market in ("sh", "sz", "bj") for p in (tdx_root / "vipdoc" / market / "lday").glob("*.day") if is_equity(p)]
    stats = {d: {"advancers": 0, "decliners": 0, "flat": 0, "amount": 0.0, "coverage": 0} for d in wanted}
    for path in files:
        rows = read_last_up_to(path, 30)
        if len(rows) < 2:
            continue
        by_date = {row[0]: idx for idx, row in enumerate(rows)}
        for d in wanted:
            idx = by_date.get(d)
            if idx is None or idx == 0:
                continue
            previous, current = rows[idx - 1], rows[idx]
            if current[1] <= 0:
                continue
            s = stats[d]
            s["coverage"] += 1
            s["amount"] += max(0.0, current[2])
            delta = current[1] - previous[1]
            s["advancers"] += delta > 0
            s["decliners"] += delta < 0
            s["flat"] += delta == 0
    index_rows = read_last_up_to(tdx_root / "vipdoc" / "sh" / "lday" / "sh000001.day", 40)
    index_by_date = {row[0]: idx for idx, row in enumerate(index_rows)}
    result: dict[str, dict[str, Any]] = {}
    target_i = _date_int(str(current_market["trading_date"]))
    for d, iso in wanted.items():
        if d == target_i and stats[d]["coverage"] < 3000:
            result[iso] = {
                "date": iso,
                "advancers": int(current_market["advancers"]),
                "decliners": int(current_market["decliners"]),
                "flat": int(current_market.get("flat", 0)),
                "index_change_pct": float(current_market["index_change_pct"]),
                "total_amount_billion": float(current_market["total_amount_billion"]),
                "amount_change_pct": current_market.get("amount_change_pct"),
                "coverage": int(current_market["covered"]),
                "source_mode": current_market.get("source_mode", "tdx_current"),
            }
            continue
        s = stats[d]
        if s["coverage"] < 3000:
            raise ValueError(f"tongdaxin_history_coverage_insufficient:{iso}:{s['coverage']}")
        idx = index_by_date.get(d)
        if idx is None or idx == 0:
            raise ValueError(f"tongdaxin_history_index_missing:{iso}")
        prev_idx, cur_idx = index_rows[idx - 1], index_rows[idx]
        prev_date = prev_idx[0]
        previous_amount = stats.get(prev_date, {}).get("amount") if prev_date in stats else None
        amount_change = None
        if previous_amount and previous_amount > 0:
            amount_change = round((s["amount"] / previous_amount - 1) * 100, 2)
        result[iso] = {
            "date": iso,
            "advancers": s["advancers"], "decliners": s["decliners"], "flat": s["flat"],
            "index_change_pct": round((cur_idx[1] / prev_idx[1] - 1) * 100, 3),
            "total_amount_billion": round(s["amount"] / 100_000_000, 1),
            "amount_change_pct": amount_change,
            "coverage": s["coverage"], "source_mode": "tdx_local_history",
        }
    return result


def _leaders_from_lianban(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    details = snapshot.get("page_details") if isinstance(snapshot.get("page_details"), dict) else {}
    rows = details.get("stock_items") if isinstance(details, dict) else []
    leaders = []
    if isinstance(rows, list):
        for item in rows:
            if not isinstance(item, dict):
                continue
            try:
                board = int(float(item.get("board_count") or 0))
            except (TypeError, ValueError):
                board = 0
            if board >= 2:
                leaders.append({"code": str(item.get("code") or ""), "name": item.get("name"), "board_count": board, "theme": item.get("theme")})
    leaders.sort(key=lambda x: x["board_count"], reverse=True)
    return leaders[:30]


def _validate_history_payload(payload: dict[str, Any], target: str) -> list[dict[str, Any]]:
    if not isinstance(payload, dict) or payload.get("status") != "CLEAN_PASS":
        raise ValueError("lianban_history_not_verified")
    rows = payload.get("snapshots")
    if not isinstance(rows, list):
        raise ValueError("lianban_history_missing")
    clean = []
    seen = set()
    for row in rows:
        if not isinstance(row, dict) or row.get("status") != "CLEAN_PASS" or not row.get("target_date"):
            continue
        day = str(row["target_date"])
        if day in seen:
            continue
        seen.add(day)
        market = row.get("market")
        if not isinstance(market, dict):
            continue
        required = ("limit_up", "limit_down", "consecutive", "max_board", "seal_rate", "broken_board")
        if any(market.get(k) is None for k in required):
            continue
        clean.append(row)
    clean.sort(key=lambda x: str(x["target_date"]))
    clean = [x for x in clean if str(x["target_date"]) <= target]
    if not clean or str(clean[-1]["target_date"]) != target:
        raise ValueError("lianban_history_current_missing")
    if len(clean) < 3:
        raise ValueError(f"lianban_history_insufficient:{len(clean)}")
    return clean[-5:]


def _metric_compare(name: str, a: float, b: float, *, abs_tolerance: float, rel_tolerance: float) -> dict[str, Any]:
    diff = a - b
    abs_diff = abs(diff)
    scale = max(abs(a), abs(b), 1.0)
    tolerance = max(abs_tolerance, scale * rel_tolerance)
    if abs_diff <= tolerance:
        status = "一致"
    elif abs_diff <= tolerance * 2:
        status = "轻微差异"
    else:
        status = "较大差异"
    return {"metric": name, "duanxianxia": a, "lianban": b, "difference": round(diff, 3), "tolerance": round(tolerance, 3), "status": status}


def _dataset_evidence(duan: dict[str, Any], required: tuple[str, ...]) -> dict[str, Any]:
    result = {}
    for name in required:
        item = duan.get("datasets", {}).get(name, {})
        result[name] = {
            "success": item.get("success") is True,
            "fetched_at": item.get("fetched_at"),
            "status_code": item.get("status_code"),
            "content_length": item.get("content_length"),
            "role": {
                "ztcount": "涨停统计补充与历史口径旁证",
                "ztpool": "涨停/连板/炸板/封板率主交叉验证",
                "jinjidata": "交易日显式校验与晋级生态旁证",
                "amount": "在线成交额数据集存在性与采集时点旁证；主成交额仍以本地通达信为准",
            }[name],
        }
    return result


def build_snapshot(lianban_path: Path, duanxian_path: Path, tdx_root: Path, lianban_history_path: Path | None = None) -> dict[str, Any]:
    lianban = json.loads(lianban_path.read_text(encoding="utf-8"))
    duan = json.loads(duanxian_path.read_text(encoding="utf-8"))
    target = str(lianban.get("target_date", ""))
    if lianban.get("status") != "CLEAN_PASS" or not target:
        raise ValueError("lianban_not_verified")
    for key in ("open_data", "page"):
        if lianban.get("sources", {}).get(key, {}).get("status_code") != 200:
            raise ValueError(f"lianban_source_failed:{key}")
    required = ("ztcount", "ztpool", "jinjidata", "amount")
    datasets = duan.get("datasets", {})
    failed = [key for key in required if not datasets.get(key, {}).get("success")]
    if failed:
        raise ValueError("duanxianxia_failed:" + ",".join(failed))
    duan_date = str(datasets["jinjidata"].get("data", {}).get("date", ""))
    if duan_date != target:
        raise ValueError(f"duanxianxia_date_mismatch:{duan_date}:{target}")
    fetched_times = [str(datasets[k].get("fetched_at") or "") for k in required]
    if any(not x for x in fetched_times):
        raise ValueError("duanxianxia_dataset_timestamp_missing")

    if lianban_history_path is None:
        history_payload = {"status": "CLEAN_PASS", "snapshots": [lianban]}
    else:
        history_payload = json.loads(lianban_history_path.read_text(encoding="utf-8"))
    lianban_history = _validate_history_payload(history_payload, target)

    tdx = tdx_market(tdx_root, target)
    market = lianban["market"]
    pool_count = datasets["ztpool"]["data"].get("count", {})
    limit_up_count = pool_count.get("limit_up_count", {})
    limit_down_count = pool_count.get("limit_down_count", {})
    today_limit_up = limit_up_count.get("today", {})
    previous_limit_up = limit_up_count.get("yesterday", {})
    today_limit_down = limit_down_count.get("today", {})
    previous_limit_down = limit_down_count.get("yesterday", {})
    if not isinstance(today_limit_up, dict) or today_limit_up.get("num") is None or pool_count.get("zt") is None:
        raise ValueError("duanxianxia_current_metrics_missing")
    missing_prev = [k for k in ("num", "lbnum", "open_num", "rate") if not isinstance(previous_limit_up, dict) or previous_limit_up.get(k) is None]
    if not isinstance(previous_limit_down, dict) or previous_limit_down.get("num") is None:
        missing_prev.append("limit_down.num")
    if missing_prev:
        raise ValueError("duanxianxia_previous_metrics_missing:" + ",".join(missing_prev))

    topics = lianban.get("topics")
    if not isinstance(topics, list) or any(not isinstance(row, dict) or row.get("name") is None or row.get("count") is None for row in topics):
        raise ValueError("lianban_topics_missing_or_invalid")
    snapshot_market = {
        "index_change_pct": tdx["index_change_pct"], "advancers": tdx["advancers"], "decliners": tdx["decliners"],
        "total_amount_billion": tdx["total_amount_billion"], "amount_change_pct": tdx["amount_change_pct"],
        "limit_up": int(market["limit_up"]), "limit_down": int(market["limit_down"]), "consecutive": int(market["consecutive"]),
        "max_board": int(market["max_board"]), "seal_rate": float(market["seal_rate"]), "broken_board": int(market["broken_board"]),
        "topic_top_count": max((int(row["count"]) for row in topics), default=0),
        "topic_count_ge3": sum(int(row["count"]) >= 3 for row in topics),
    }
    for key in ("previous_total_amount_billion", "amount_comparison_mode", "observed_at"):
        if key in tdx:
            snapshot_market[key] = tdx[key]

    dates = [str(x["target_date"]) for x in lianban_history]
    tdx_hist = tdx_history_market(tdx_root, dates, tdx)
    history = []
    for lb in lianban_history:
        day = str(lb["target_date"])
        tm = tdx_hist[day]
        lm = lb["market"]
        day_topics = lb.get("topics") if isinstance(lb.get("topics"), list) else []
        history.append({
            "date": day, "advancers": int(tm["advancers"]), "decliners": int(tm["decliners"]),
            "index_change_pct": float(tm["index_change_pct"]), "total_amount_billion": float(tm["total_amount_billion"]),
            "amount_change_pct": tm.get("amount_change_pct"), "coverage": int(tm["coverage"]),
            "limit_up": int(lm["limit_up"]), "limit_down": int(lm["limit_down"]), "consecutive": int(lm["consecutive"]),
            "max_board": int(lm["max_board"]), "seal_rate": float(lm["seal_rate"]), "broken_board": int(lm["broken_board"]),
            "topic_top_count": max((int(x["count"]) for x in day_topics if isinstance(x, dict) and x.get("count") is not None), default=0),
            "topic_count_ge3": sum(int(x["count"]) >= 3 for x in day_topics if isinstance(x, dict) and x.get("count") is not None),
            "topics": day_topics, "leaders": _leaders_from_lianban(lb),
            "reported_stage": str(lm.get("emotion_stage") or "").strip() or None,
        })
    if history[-1]["date"] != target:
        raise ValueError("history_target_mismatch")

    # Cross-validate every current metric that Duanxianxia exposes with a stable schema.
    current_duan = {
        "limit_up": float(today_limit_up["num"]),
        "consecutive": float(today_limit_up.get("lbnum")) if today_limit_up.get("lbnum") is not None else None,
        "broken_board": float(today_limit_up.get("open_num")) if today_limit_up.get("open_num") is not None else None,
        "seal_rate": float(today_limit_up.get("rate")) * 100 if today_limit_up.get("rate") is not None else None,
        "limit_down": float(today_limit_down.get("num")) if isinstance(today_limit_down, dict) and today_limit_down.get("num") is not None else None,
    }
    tolerances = {"limit_up": (2, .05), "limit_down": (2, .10), "consecutive": (1, .10), "broken_board": (2, .15), "seal_rate": (3, .03)}
    metric_rows = []
    for name, value in current_duan.items():
        if value is None:
            continue
        row = _metric_compare(name, value, float(snapshot_market[name]), abs_tolerance=tolerances[name][0], rel_tolerance=tolerances[name][1])
        metric_rows.append(row)
    # Previous-day values are independently available from Duanxianxia and our Lianban rolling history.
    if len(history) >= 2:
        prev_lb = history[-2]
        previous_duan = {
            "limit_up": float(previous_limit_up["num"]), "limit_down": float(previous_limit_down["num"]),
            "consecutive": float(previous_limit_up["lbnum"]), "broken_board": float(previous_limit_up["open_num"]),
            "seal_rate": float(previous_limit_up["rate"]) * 100,
        }
        for name, value in previous_duan.items():
            row = _metric_compare("previous_" + name, value, float(prev_lb[name]), abs_tolerance=tolerances[name][0], rel_tolerance=tolerances[name][1])
            metric_rows.append(row)
    major = [x for x in metric_rows if x["status"] == "较大差异"]
    minor = [x for x in metric_rows if x["status"] == "轻微差异"]
    severe = False
    for x in major:
        scale = max(abs(float(x["duanxianxia"])), abs(float(x["lianban"])), 1.0)
        if abs(float(x["difference"])) > max(float(x["tolerance"]) * 3, scale * .30):
            severe = True
    overall = "严重冲突" if severe or len(major) >= 3 else "较大差异" if major else "轻微差异" if minor else "一致"
    conflicts = [f"{x['metric']}：短线侠{x['duanxianxia']}，连板网{x['lianban']}，差异{x['difference']}（{x['status']}）" for x in metric_rows if x["status"] != "一致"]

    previous_history = history[-2]
    previous = {
        "advancers": previous_history["advancers"], "decliners": previous_history["decliners"],
        "limit_up": int(previous_limit_up["num"]), "limit_down": int(previous_limit_down["num"]),
        "consecutive": int(previous_limit_up["lbnum"]), "broken_board": int(previous_limit_up["open_num"]),
        "seal_rate": round(float(previous_limit_up["rate"]) * 100, 1),
    }
    tdx_source = {"verified": True, "trading_date": target, "root": str(tdx_root), "coverage": tdx["covered"], "history_dates": dates}
    for key in ("source_mode", "observed_at", "previous_trading_date", "date_and_price_proof", "date_and_price_proof_sha256"):
        if key in tdx:
            tdx_source[key] = tdx[key]
    return {
        "schema": "SHORT_TERM_SENTIMENT_SNAPSHOT_V2", "trading_date": target, "market": snapshot_market, "topics": topics, "history": history,
        "sources": {
            "tongdaxin": tdx_source,
            "duanxianxia": {"verified": True, "trading_date": target, "source_url": duan.get("source_page"), "datasets": list(required), "dataset_evidence": _dataset_evidence(duan, required), "date_basis": "jinjidata显式交易日+四数据集同批抓取时间"},
            "lianban": {"verified": True, "trading_date": target, "reported_stage": market.get("emotion_stage"), "source_url": lianban["sources"]["page"]["url"], "attribution": "连板网", "license": "CC BY 4.0", "history_dates": dates},
        },
        "cross_validation": {
            "overall_status": overall, "metrics": metric_rows, "conflicts": conflicts,
            "limit_up_difference": float(today_limit_up["num"]) - float(snapshot_market["limit_up"]),
            "duanxianxia_limit_up": int(today_limit_up["num"]), "lianban_limit_up": int(snapshot_market["limit_up"]),
        },
        "comparisons": {
            "previous_trading_day": previous,
            "current_trading_day": {"limit_up": int(today_limit_up["num"]), "limit_down": int(snapshot_market["limit_down"]), "consecutive": int(snapshot_market["consecutive"]), "broken_board": int(snapshot_market["broken_board"]), "seal_rate": float(snapshot_market["seal_rate"])},
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lianban", required=True)
    parser.add_argument("--duanxian", required=True)
    parser.add_argument("--lianban-history")
    parser.add_argument("--tdx-root", default=r"D:\TDX")
    parser.add_argument("--output")
    args = parser.parse_args()
    result = build_snapshot(Path(args.lianban), Path(args.duanxian), Path(args.tdx_root), Path(args.lianban_history) if args.lianban_history else None)
    encoded = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(encoded, encoding="utf-8")
    print(encoded, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
