#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import date, datetime, timedelta
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
LOCAL = ROOT / ".local"
CONFIG = LOCAL / "config.json"
MANIFEST = ROOT / "package-manifest.json"
REQUIRED = (
    "sentiment_engine.py", "live_snapshot.py", "lianban_daily_client.py",
    "duanxianxia_client.ps1",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit(payload: dict[str, Any]) -> int:
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload.get("status") in {"PASS", "READY", "CONFIGURED", "CLEAN_PASS", "AUTHORIZED"} else 2


def load_module(filename: str, name: str):
    path = SCRIPTS / filename
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"module_load_failed:{filename}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify_package_manifest() -> dict[str, Any]:
    if not MANIFEST.is_file():
        return {"status": "BLOCKED", "errors": ["manifest_missing"]}
    try:
        payload = json.loads(MANIFEST.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"status": "BLOCKED", "errors": [f"manifest_invalid:{type(exc).__name__}:{exc}"]}
    errors = []
    checked = []
    if payload.get("schema") != "WORKBUDDY_DESKTOP_SKILL_PACKAGE_V2":
        errors.append("manifest_schema_invalid")
    if payload.get("entry") != "scripts/workbuddy_entry.py":
        errors.append("manifest_entry_mismatch")
    files = payload.get("files") if isinstance(payload, dict) else None
    if not isinstance(files, list) or not files:
        errors.append("manifest_files_missing")
        files = []
    if payload.get("file_count") != len(files):
        errors.append("manifest_file_count_mismatch")
    for item in files:
        if not isinstance(item, dict) or not item.get("path"):
            errors.append("manifest_entry_invalid")
            continue
        rel = Path(str(item["path"]))
        if rel.is_absolute() or ".." in rel.parts:
            errors.append(f"manifest_path_unsafe:{rel}")
            continue
        path = ROOT / rel
        if not path.is_file():
            errors.append(f"manifest_missing_file:{rel.as_posix()}")
            continue
        actual_hash = sha256(path)
        actual_bytes = path.stat().st_size
        if actual_hash != item.get("sha256"):
            errors.append(f"manifest_hash_mismatch:{rel.as_posix()}")
        if actual_bytes != item.get("bytes"):
            errors.append(f"manifest_size_mismatch:{rel.as_posix()}")
        checked.append(rel.as_posix())
    # Production package is closed-world: an unexpected file must not silently enter the skill.
    managed = set(checked)
    actual_managed = set()
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if rel.as_posix() == "package-manifest.json" or ".local" in rel.parts or "__pycache__" in rel.parts or path.suffix.lower() == ".pyc":
            continue
        actual_managed.add(rel.as_posix())
    for rel in sorted(actual_managed - managed):
        errors.append(f"manifest_unexpected_file:{rel}")
    for rel in sorted(managed - actual_managed):
        errors.append(f"manifest_listed_file_not_in_package:{rel}")
    return {
        "status": "CLEAN_PASS" if not errors else "BLOCKED",
        "manifest_sha256": sha256(MANIFEST), "checked_files": len(checked), "errors": errors,
    }


def valid_tdx_root(path: Path) -> bool:
    return path.is_dir() and (path / "vipdoc" / "sh" / "lday" / "sh000001.day").is_file()


def discover_tdx(explicit: str | None = None) -> list[Path]:
    values = []
    if explicit:
        values.append(Path(os.path.expandvars(explicit)).expanduser())
    if os.environ.get("TDX_ROOT"):
        values.append(Path(os.path.expandvars(os.environ["TDX_ROOT"])))
    for drive in "CDEFGHIJKLMNOPQRSTUVWXYZ":
        values.extend((Path(f"{drive}:/{name}") for name in ("TDX", "通达信", "通达信金融终端")))
    unique: dict[str, Path] = {}
    for value in values:
        try:
            path = value.resolve()
        except OSError:
            continue
        if valid_tdx_root(path):
            unique.setdefault(os.path.normcase(str(path)), path)
    return list(unique.values())


def read_config(config_path: Path = CONFIG) -> dict[str, Any]:
    if not config_path.is_file():
        return {}
    data = json.loads(config_path.read_text(encoding="utf-8"))
    return data if isinstance(data, dict) else {}


def resolve_tdx(explicit: str | None, config_path: Path) -> Path:
    configured = read_config(config_path).get("tdx_root")
    candidates = discover_tdx(explicit or configured)
    if len(candidates) != 1:
        raise RuntimeError(f"tdx_root_not_unique:{len(candidates)}")
    return candidates[0]


def powershell() -> str:
    value = shutil.which("powershell.exe") or shutil.which("powershell")
    if not value:
        raise RuntimeError("powershell_missing")
    return value


def ps_quote(value: Path) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    json.loads(temporary.read_text(encoding="utf-8"))
    temporary.replace(path)


def collect_lianban_history(current_path: Path, run_dir: Path, *, target_days: int = 5, minimum_days: int = 3) -> Path:
    current = json.loads(current_path.read_text(encoding="utf-8"))
    target = str(current.get("target_date") or "")
    if current.get("status") != "CLEAN_PASS" or not target:
        raise RuntimeError("lianban_current_not_clean")
    client = load_module("lianban_daily_client.py", "wb_lianban_history")
    target_date = date.fromisoformat(target)
    snapshots: dict[str, dict[str, Any]] = {target: current}
    attempts = []
    # Look back through business days. Holidays/404s are skipped; only exact-date CLEAN_PASS rows are accepted.
    for offset in range(1, 18):
        if len(snapshots) >= target_days:
            break
        candidate = target_date - timedelta(days=offset)
        if candidate.weekday() >= 5:
            continue
        day = candidate.isoformat()
        try:
            payload = client.collect_snapshot(day, latest=False, timeout=15)
            accepted = payload.get("status") == "CLEAN_PASS" and str(payload.get("target_date")) == day
            attempts.append({"date": day, "status": payload.get("status"), "accepted": accepted})
            if accepted:
                snapshots[day] = payload
        except Exception as exc:
            attempts.append({"date": day, "status": "FAILED", "error": f"{type(exc).__name__}:{exc}"})
    ordered = [snapshots[k] for k in sorted(snapshots)][-target_days:]
    if len(ordered) < minimum_days:
        raise RuntimeError(f"lianban_history_insufficient:{len(ordered)}:minimum={minimum_days}")
    history_path = run_dir / "lianban-history.json"
    _write_json(history_path, {
        "schema": "LIANBAN_ROLLING_HISTORY_V2", "status": "CLEAN_PASS", "target_date": target,
        "history_days": len(ordered), "minimum_days": minimum_days, "target_days": target_days,
        "snapshots": ordered, "attempts": attempts,
    })
    return history_path


def collect_sources(run_dir: Path) -> tuple[Path, Path, Path, dict[str, Any]]:
    run_dir.mkdir(parents=True, exist_ok=True)
    lianban = run_dir / "lianban-daily.json"
    duanxian = run_dir / "duanxianxia.json"
    lianban_child = subprocess.run(
        [sys.executable, str(SCRIPTS / "lianban_daily_client.py"), "--latest", "--output", str(lianban)],
        cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120,
    )
    duanxian_command = (
        f"& {ps_quote(SCRIPTS / 'duanxianxia_client.ps1')} "
        "-Dataset @('ztcount','ztpool','jinjidata','amount') "
        f"-Output {ps_quote(duanxian)}"
    )
    duanxian_child = subprocess.run(
        [powershell(), "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", duanxian_command],
        cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120,
    )
    checks = {
        "lianban": {"returncode": lianban_child.returncode, "stderr": lianban_child.stderr[-1000:]},
        "duanxianxia": {"returncode": duanxian_child.returncode, "stderr": duanxian_child.stderr[-1000:]},
    }
    if lianban_child.returncode or duanxian_child.returncode or not lianban.is_file() or not duanxian.is_file():
        raise RuntimeError("public_source_collection_failed:" + json.dumps(checks, ensure_ascii=False))
    history = collect_lianban_history(lianban, run_dir)
    checks["history"] = {"path": str(history), "history_days": json.loads(history.read_text(encoding="utf-8")).get("history_days")}
    return lianban, duanxian, history, checks




def _extract_date_tokens(value: Any) -> list[str]:
    import re
    found: set[str] = set()
    def walk(obj: Any) -> None:
        if isinstance(obj, dict):
            for v in obj.values(): walk(v)
        elif isinstance(obj, list):
            for v in obj: walk(v)
        elif isinstance(obj, str):
            for y,m,d in re.findall(r"(20\d{2})[-/](\d{1,2})[-/](\d{1,2})", obj):
                try: found.add(date(int(y), int(m), int(d)).isoformat())
                except ValueError: pass
            for raw in re.findall(r"(?<!\d)(20\d{6})(?!\d)", obj):
                try: found.add(datetime.strptime(raw, "%Y%m%d").date().isoformat())
                except ValueError: pass
        elif isinstance(obj, int) and 20000101 <= obj <= 20991231:
            try: found.add(datetime.strptime(str(obj), "%Y%m%d").date().isoformat())
            except ValueError: pass
    walk(value)
    return sorted(found)

def validate_public_sources(lianban: Path, duanxian: Path, history: Path) -> dict[str, Any]:
    lb = json.loads(lianban.read_text(encoding="utf-8"))
    dx = json.loads(duanxian.read_text(encoding="utf-8"))
    hist = json.loads(history.read_text(encoding="utf-8"))
    datasets = dx.get("datasets", {})
    required = ("ztcount", "ztpool", "jinjidata", "amount")
    errors = []
    failed = [name for name in required if not datasets.get(name, {}).get("success")]
    if failed:
        errors.append("duanxianxia_failed:" + ",".join(failed))
    target = str(lb.get("target_date") or "")
    if lb.get("status") != "CLEAN_PASS" or not target:
        errors.append("lianban_not_clean")
    duan_date = str(datasets.get("jinjidata", {}).get("data", {}).get("date", ""))
    if not duan_date:
        errors.append("duanxianxia_explicit_date_missing")
    elif duan_date != target:
        errors.append(f"source_date_mismatch:duanxianxia={duan_date}:lianban={target}")
    timestamps = [datasets.get(name, {}).get("fetched_at") for name in required]
    parsed_times = []
    if any(not value for value in timestamps):
        errors.append("duanxianxia_batch_timestamp_missing")
    else:
        try:
            parsed_times = [datetime.fromisoformat(str(x).replace("Z", "+00:00")) for x in timestamps]
            if (max(parsed_times) - min(parsed_times)).total_seconds() > 600:
                errors.append("duanxianxia_batch_not_atomic_over_10min")
        except ValueError:
            errors.append("duanxianxia_batch_timestamp_invalid")
    dataset_date_evidence = {}
    for name in required:
        item = datasets.get(name, {})
        if item.get("status_code") not in (200, None):
            errors.append(f"duanxianxia_http_failed:{name}:{item.get('status_code')}")
        tokens = _extract_date_tokens(item.get("data"))
        dataset_date_evidence[name] = tokens[-8:]
        if name != "amount" and tokens and max(tokens) != target:
            errors.append(f"duanxianxia_dataset_latest_date_mismatch:{name}:{max(tokens)}:{target}")
    if hist.get("status") != "CLEAN_PASS" or hist.get("target_date") != target or int(hist.get("history_days") or 0) < 3:
        errors.append("lianban_history_invalid")
    return {
        "status": "CLEAN_PASS" if not errors else "BLOCKED", "trading_date": target,
        "duanxianxia_trading_date": duan_date, "history_days": hist.get("history_days"),
        "failed_datasets": failed, "dataset_date_evidence": dataset_date_evidence, "errors": errors,
    }


def command_info() -> int:
    return emit({
        "schema": "WORKBUDDY_SENTIMENT_SKILL_INFO_V2", "status": "PASS",
        "skill_id": "a-share-short-term-market-sentiment-workbuddy",
        "display_name": "短线市场情绪研判系统（实战固化版 V2.2）", "entry": str(Path(__file__).resolve()),
        "sources": ["本地通达信日线/TQ", "短线侠公开数据", "连板网公开数据和日期页"],
        "history_requirement": "至少3个交易日，目标5个交易日；不足则阻断生产研判",
    })


def command_configure(tdx_root: str | None, config_path: Path) -> int:
    candidates = discover_tdx(tdx_root)
    if len(candidates) != 1:
        return emit({"status": "BLOCKED", "errors": [f"tdx_root_not_unique:{len(candidates)}"], "candidates": [str(x) for x in candidates]})
    config_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"schema": "WORKBUDDY_SENTIMENT_CONFIG_V2", "tdx_root": str(candidates[0]), "read_only": True}
    config_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return emit({"status": "CONFIGURED", "config": str(config_path), "tdx_root": str(candidates[0])})


def command_selftest(config_path: Path) -> int:
    errors = []
    manifest = verify_package_manifest()
    if manifest["status"] != "CLEAN_PASS":
        errors.extend(manifest["errors"])
    for name in REQUIRED:
        if not (SCRIPTS / name).is_file():
            errors.append(f"missing:{name}")
    parsed = 0
    for path in ROOT.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        try:
            ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
            parsed += 1
        except Exception as exc:
            errors.append(f"syntax:{path.name}:{exc}")
    try:
        engine = load_module("sentiment_engine.py", "wb_sentiment_selftest")
        strong = engine.analyze_snapshot(engine.example_snapshot("strong"))
        retreat = engine.analyze_snapshot(engine.example_snapshot("retreat"))
        mixed = engine.analyze_snapshot(engine.example_snapshot("mixed"))
        if strong["short_term_stage_conclusion"]["stage"] not in {"发酵期", "加速期", "高潮期"}:
            errors.append("regression:strong_not_strong_stage")
        if retreat["short_term_stage_conclusion"]["stage"] != "退潮期":
            errors.append("regression:retreat_not_retreat")
        if mixed["short_term_stage_conclusion"]["stage"] == "启动期":
            errors.append("regression:stable_weak_falsely_startup")
    except Exception as exc:
        errors.append(f"engine:{type(exc).__name__}:{exc}")
    regression_suite = {"returncode": None, "summary": "not_run"}
    try:
        child = subprocess.run(
            [sys.executable, "-m", "unittest", "discover", "-s", str(ROOT / "tests"), "-q"],
            cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60,
        )
        regression_suite = {"returncode": child.returncode, "summary": (child.stderr or child.stdout)[-1200:]}
        if child.returncode != 0:
            errors.append("regression_suite_failed")
    except Exception as exc:
        regression_suite = {"returncode": -1, "summary": f"{type(exc).__name__}:{exc}"}
        errors.append("regression_suite_error")
    try:
        tdx = resolve_tdx(None, config_path)
        if not valid_tdx_root(tdx):
            errors.append("tdx_layout_invalid")
    except Exception as exc:
        errors.append(str(exc))
    try:
        import requests  # noqa: F401
    except ImportError as exc:
        errors.append(f"dependency_missing:{exc.name}")
    return emit({
        "schema": "WORKBUDDY_SENTIMENT_SELFTEST_V2", "status": "READY" if not errors else "BLOCKED",
        "python": sys.version.split()[0], "python_files_parsed": parsed, "manifest": manifest, "errors": errors,
        "regression_suite": regression_suite,
        "network_checked": False, "note": "运行 sources 或 run 才会真实检查公开数据接口与多日历史。",
    })


def command_sources(output: Path) -> int:
    try:
        lianban, duanxian, history, checks = collect_sources(output)
        validation = validate_public_sources(lianban, duanxian, history)
        return emit({
            "schema": "WORKBUDDY_SENTIMENT_SOURCE_CHECK_V2", "status": validation["status"],
            "trading_date": validation["trading_date"], "duanxianxia_trading_date": validation["duanxianxia_trading_date"],
            "history_days": validation["history_days"], "lianban": checks["lianban"], "duanxianxia": checks["duanxianxia"],
            "failed_datasets": validation["failed_datasets"], "errors": validation["errors"],
        })
    except Exception as exc:
        return emit({"schema": "WORKBUDDY_SENTIMENT_SOURCE_CHECK_V2", "status": "BLOCKED", "errors": [f"{type(exc).__name__}:{exc}"]})


def command_run(output: Path, tdx_root: str | None, config_path: Path) -> int:
    try:
        package_integrity = verify_package_manifest()
        if package_integrity["status"] != "CLEAN_PASS":
            raise RuntimeError("package_integrity_failed:" + ",".join(package_integrity["errors"]))
        tdx = resolve_tdx(tdx_root, config_path)
        run_dir = output.resolve()
        lianban, duanxian, history, source_checks = collect_sources(run_dir)
        source_validation = validate_public_sources(lianban, duanxian, history)
        if source_validation["status"] != "CLEAN_PASS":
            raise RuntimeError("source_validation_failed:" + ",".join(source_validation["errors"]))
        live = load_module("live_snapshot.py", "wb_live_snapshot")
        engine = load_module("sentiment_engine.py", "wb_sentiment_engine")
        snapshot = live.build_snapshot(lianban, duanxian, tdx, history)
        result = engine.analyze_snapshot(snapshot)
        snapshot_path = run_dir / "sentiment_snapshot.json"
        result_path = run_dir / "sentiment_result.json"
        report_path = run_dir / "sentiment_report.md"
        snapshot_path.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        result["artifacts"] = {"snapshot": str(snapshot_path), "result": str(result_path), "report": str(report_path)}
        result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        report_path.write_text(engine.render_text_report(snapshot, result), encoding="utf-8")
        files = [snapshot_path, result_path, report_path, lianban, duanxian, history]
        run_status = "CLEAN_PASS"
        errors = []
        receipt = {
            "schema": "WORKBUDDY_SENTIMENT_RECEIPT_V2", "status": run_status,
            "created_at": datetime.now().astimezone().isoformat(timespec="seconds"), "trading_date": result["trading_date"],
            "tdx_root": str(tdx), "source_checks": source_checks, "source_validation": source_validation,
            "output_mode": "text_only",
            "report_template": result.get("report_template"),
            "package_integrity": package_integrity,
            "files": [{"path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)} for path in files],
            "errors": errors,
        }
        receipt_path = run_dir / "receipt.json"
        receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return emit({
            "schema": "WORKBUDDY_SENTIMENT_RUN_V2", "status": run_status, "trading_date": result["trading_date"],
            "stage": result["short_term_stage_conclusion"]["stage"], "intermediate_stage": result["single_stage_conclusion"]["stage"],
            "confidence": result["short_term_stage_conclusion"]["confidence"], "source_consistency": snapshot["cross_validation"]["overall_status"],
            "history_days": len(snapshot["history"]), "receipt": str(receipt_path), "result": str(result_path),
            "report": str(report_path), "report_template": result.get("report_template"),
            "output_mode": "text_only", "errors": errors,
        })
    except Exception as exc:
        return emit({"schema": "WORKBUDDY_SENTIMENT_RUN_V2", "status": "BLOCKED", "errors": [f"{type(exc).__name__}:{exc}"]})


def _validate_receipt(receipt_path: Path) -> tuple[list[str], Path | None]:
    errors: list[str] = []
    report_path: Path | None = None
    try:
        receipt = json.loads(receipt_path.resolve().read_text(encoding="utf-8"))
        if receipt.get("schema") != "WORKBUDDY_SENTIMENT_RECEIPT_V2" or receipt.get("status") != "CLEAN_PASS":
            errors.append("receipt_status_invalid")
        if receipt.get("output_mode") != "text_only":
            errors.append("output_mode_not_text_only")
        if receipt.get("report_template") != "WORKBUDDY_SENTIMENT_TEXT_REPORT_V1":
            errors.append("report_template_invalid")
        current_integrity = verify_package_manifest()
        if current_integrity.get("status") != "CLEAN_PASS":
            errors.append("package_integrity_current_failed")
        recorded_integrity = receipt.get("package_integrity") if isinstance(receipt.get("package_integrity"), dict) else {}
        if recorded_integrity.get("manifest_sha256") != current_integrity.get("manifest_sha256"):
            errors.append("package_manifest_changed_after_run")
        for item in receipt.get("files", []):
            path = Path(item["path"]).resolve()
            if not path.is_file() or path.stat().st_size != item["bytes"] or sha256(path) != item["sha256"]:
                errors.append(f"artifact_changed:{path.name}")
        result_item = next((x for x in receipt.get("files", []) if Path(x["path"]).name == "sentiment_result.json"), None)
        report_item = next((x for x in receipt.get("files", []) if Path(x["path"]).name == "sentiment_report.md"), None)
        if not result_item:
            errors.append("sentiment_result_missing")
        else:
            result = json.loads(Path(result_item["path"]).read_text(encoding="utf-8"))
            if result.get("status") != "CLEAN_PASS" or not result.get("current_response") or not result.get("outlook"):
                errors.append("sentiment_result_not_complete")
            if result.get("schema") != "SHORT_TERM_MARKET_SENTIMENT_PRODUCTION_V2":
                errors.append("result_schema_not_production_v2")
            if result.get("report_template") != "WORKBUDDY_SENTIMENT_TEXT_REPORT_V1":
                errors.append("report_template_invalid")
        if not report_item:
            errors.append("sentiment_report_missing")
        else:
            report_path = Path(report_item["path"]).resolve()
            report_text = report_path.read_text(encoding="utf-8")
            required_sections = (
                "## 一、核心状态", "## 二、当日真实盘面输入", "## 三、",
                "## 四、短线七阶段判定", "## 五、中级五阶段判定", "## 六、题材与梯队结构",
                "## 七、实战操作结论", "## 八、下一交易日条件推演", "## 九、最终实跑结论",
            )
            if any(section not in report_text for section in required_sections):
                errors.append("sentiment_report_template_incomplete")
    except Exception as exc:
        errors.append(f"{type(exc).__name__}:{exc}")
    return errors, report_path


def command_authorize(receipt_path: Path) -> int:
    errors, _ = _validate_receipt(receipt_path)
    return emit({
        "schema": "WORKBUDDY_SENTIMENT_AUTHORIZATION_V2",
        "status": "AUTHORIZED" if not errors else "BLOCKED", "receipt": str(receipt_path.resolve()), "errors": errors,
    })


def command_present(receipt_path: Path) -> int:
    """Print only the canonical fixed-template report after full authorization validation."""
    errors, report_path = _validate_receipt(receipt_path)
    if errors or report_path is None:
        return emit({"schema": "WORKBUDDY_SENTIMENT_PRESENT_V1", "status": "BLOCKED", "errors": errors or ["sentiment_report_missing"]})
    report_text = report_path.read_text(encoding="utf-8")
    sys.stdout.write(report_text)
    if not report_text.endswith("\n"):
        sys.stdout.write("\n")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="短线市场情绪研判系统 WorkBuddy 实战固化版 V2.2 入口")
    parser.add_argument("--config", type=Path, default=CONFIG)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("info")
    configure = sub.add_parser("configure")
    configure.add_argument("--tdx-root")
    sub.add_parser("selftest")
    sources = sub.add_parser("sources")
    sources.add_argument("--output", type=Path, default=LOCAL / "source-check")
    run = sub.add_parser("run")
    run.add_argument("--output", type=Path, default=LOCAL / "runs" / datetime.now().strftime("%Y%m%d-%H%M%S"))
    run.add_argument("--tdx-root")
    authorize = sub.add_parser("authorize")
    authorize.add_argument("--receipt", type=Path, required=True)
    present = sub.add_parser("present")
    present.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "info": return command_info()
    if args.command == "configure": return command_configure(args.tdx_root, args.config)
    if args.command == "selftest": return command_selftest(args.config)
    if args.command == "sources": return command_sources(args.output)
    if args.command == "run": return command_run(args.output, args.tdx_root, args.config)
    if args.command == "authorize": return command_authorize(args.receipt)
    return command_present(args.receipt)


if __name__ == "__main__":
    raise SystemExit(main())
