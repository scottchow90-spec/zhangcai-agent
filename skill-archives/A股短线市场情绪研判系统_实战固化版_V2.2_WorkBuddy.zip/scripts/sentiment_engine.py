#!/usr/bin/env python3
"""WorkBuddy A-share short-term sentiment engine, production ruleset V2.

The engine deliberately avoids a single sentiment score.  It classifies market state
from a rolling evidence sequence and blocks snapshots that do not contain enough
history or have critical source conflicts.
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
from pathlib import Path
from typing import Any, Iterable

_BOOT = str(Path(__file__).resolve().parent)
if _BOOT not in sys.path:
    sys.path.insert(0, _BOOT)

REQUIRED_MARKET = (
    "index_change_pct", "advancers", "decliners", "total_amount_billion",
    "amount_change_pct", "limit_up", "limit_down", "consecutive",
    "max_board", "seal_rate", "broken_board", "topic_top_count", "topic_count_ge3",
)
REQUIRED_SOURCES = ("tongdaxin", "duanxianxia", "lianban")
REQUIRED_PREVIOUS = ("limit_up", "limit_down", "consecutive", "seal_rate", "broken_board")
HISTORY_REQUIRED_FIELDS = (
    "date", "advancers", "decliners", "limit_up", "limit_down", "consecutive",
    "max_board", "seal_rate", "broken_board", "topic_top_count", "topic_count_ge3",
)
MARKET_STAGES = ("赚钱效应回暖", "赚钱效应低迷", "赚钱效应高潮", "亏钱效应出现", "亏钱效应炸裂")
SHORT_TERM_STAGES = ("启动期", "确认期", "发酵期", "加速期", "高潮期", "分歧期", "退潮期")


class SnapshotValidationError(ValueError):
    pass


def _num(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _format_metric(value: Any, precision: int = 0) -> str:
    return f"{float(value):.{precision}f}" if precision else str(int(float(value)))


def _transition(label: str, previous: Any, current: Any, unit: str, *, precision: int = 0) -> str:
    a, b = float(previous), float(current)
    direction = "升至" if b > a else "降至" if b < a else "持平于"
    return f"{label}由{_format_metric(a, precision)}{unit}{direction}{_format_metric(b, precision)}{unit}"


def intraday_amount_not_comparable(market: dict[str, Any]) -> bool:
    return (
        market.get("amount_comparison_mode") == "intraday_vs_previous_full_day_not_comparable"
        and market.get("amount_change_pct") is None
        and isinstance(market.get("observed_at"), str)
        and isinstance(market.get("previous_total_amount_billion"), (int, float))
        and market["previous_total_amount_billion"] > 0
    )


def amount_observation(market: dict[str, Any]) -> str:
    if intraday_amount_not_comparable(market):
        return (
            f"截至{market['observed_at'][11:16]}成交额{market['total_amount_billion']:.1f}亿元，"
            f"前一交易日全天{market['previous_total_amount_billion']:.1f}亿元；时段不同，不判增减"
        )
    return f"成交额{market['total_amount_billion']:.1f}亿元，较前日{market['amount_change_pct']:+.2f}%"


def _dynamic_conclusion(stage: str, market: dict[str, Any], previous: dict[str, Any], *, short_term: bool) -> str:
    facts = "、".join((
        _transition("涨停", previous["limit_up"], market["limit_up"], "家"),
        _transition("封板率", previous["seal_rate"], market["seal_rate"], "%", precision=1),
        _transition("炸板", previous["broken_board"], market["broken_board"], "家"),
        _transition("跌停", previous["limit_down"], market["limit_down"], "家"),
        _transition("连板", previous["consecutive"], market["consecutive"], "只"),
    ))
    prefix = f"当前短线市场情绪处于{stage}" if short_term else f"当前中级周期处于{stage}阶段"
    return f"{prefix}。{facts}。"


def _reported_stage_to_intermediate(value: Any) -> str | None:
    label = str(value or "").strip()
    mappings = (
        (("冰点", "退潮"), "亏钱效应炸裂"),
        (("降温", "分歧"), "亏钱效应出现"),
        (("高潮",), "赚钱效应高潮"),
        (("升温", "修复", "回暖"), "赚钱效应回暖"),
        (("低迷", "混沌", "轮动"), "赚钱效应低迷"),
    )
    for tokens, stage in mappings:
        if any(token in label for token in tokens):
            return stage
    return None


def _reported_stage_to_short(value: Any) -> str | None:
    label = str(value or "").strip()
    mappings = (
        (("冰点", "退潮"), "退潮期"),
        (("降温", "分歧"), "分歧期"),
        (("高潮",), "高潮期"),
        (("升温", "发酵"), "发酵期"),
        (("确认",), "确认期"),
        (("修复", "启动"), "启动期"),
    )
    for tokens, stage in mappings:
        if any(token in label for token in tokens):
            return stage
    return None


def _history(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    rows = snapshot.get("history")
    if not isinstance(rows, list):
        return []
    return sorted((dict(row) for row in rows if isinstance(row, dict)), key=lambda x: str(x.get("date", "")))


def _median_previous(rows: list[dict[str, Any]], field: str, lookback: int = 4) -> float:
    prior = rows[:-1][-lookback:]
    vals = [_num(row.get(field)) for row in prior if row.get(field) is not None]
    return statistics.median(vals) if vals else _num(rows[-2].get(field))


def _breadth_ratio(row: dict[str, Any]) -> float:
    a, d = _num(row.get("advancers")), _num(row.get("decliners"))
    return a / (a + d) if a + d > 0 else 0.5


def _trend_count(rows: list[dict[str, Any]], field: str, direction: str, span: int = 3, tolerance: float = 0.0) -> int:
    seq = rows[-(span + 1):]
    count = 0
    for a, b in zip(seq, seq[1:]):
        av, bv = _num(a.get(field)), _num(b.get(field))
        if direction == "up" and bv > av + tolerance:
            count += 1
        elif direction == "down" and bv < av - tolerance:
            count += 1
    return count


def _topic_sequence(rows: list[dict[str, Any]]) -> dict[str, Any]:
    current_topics = rows[-1].get("topics") if rows else []
    current_map: dict[str, int] = {}
    if isinstance(current_topics, list):
        for item in current_topics:
            if isinstance(item, dict) and str(item.get("name", "")).strip():
                current_map[str(item["name"]).strip()] = int(_num(item.get("count")))
    persistence = []
    for name, current_count in current_map.items():
        days = 0
        counts: list[int] = []
        for row in reversed(rows):
            found = 0
            for item in row.get("topics", []) if isinstance(row.get("topics"), list) else []:
                if isinstance(item, dict) and str(item.get("name", "")).strip() == name:
                    found = int(_num(item.get("count")))
                    break
            if found >= 3:
                days += 1
                counts.append(found)
            else:
                break
        persistence.append({"name": name, "days_ge3": days, "current_count": current_count, "max_count": max(counts or [current_count])})
    persistence.sort(key=lambda x: (x["days_ge3"], x["current_count"]), reverse=True)
    previous_names = set()
    if len(rows) >= 2:
        for item in rows[-2].get("topics", []) if isinstance(rows[-2].get("topics"), list) else []:
            if isinstance(item, dict) and _num(item.get("count")) >= 3:
                previous_names.add(str(item.get("name", "")).strip())
    new_current = [name for name, count in current_map.items() if count >= 3 and name not in previous_names]
    return {
        "persistent_topics_ge2": [x for x in persistence if x["days_ge3"] >= 2],
        "persistent_topics_ge3": [x for x in persistence if x["days_ge3"] >= 3],
        "max_persistence_days": max((x["days_ge3"] for x in persistence), default=0),
        "new_topics_ge3": new_current,
        "details": persistence[:10],
    }


def _leader_sequence(rows: list[dict[str, Any]]) -> dict[str, Any]:
    current_codes: set[str] = set()
    repeated = set()
    day_code_sets: list[set[str]] = []
    for row in rows:
        codes = set()
        for item in row.get("leaders", []) if isinstance(row.get("leaders"), list) else []:
            if isinstance(item, dict) and _num(item.get("board_count")) >= 2:
                code = str(item.get("code", "")).strip()
                if code:
                    codes.add(code)
        day_code_sets.append(codes)
    if day_code_sets:
        current_codes = day_code_sets[-1]
        for code in current_codes:
            if sum(code in codes for codes in day_code_sets[-3:]) >= 2:
                repeated.add(code)
    return {
        "current_front_codes": sorted(current_codes),
        "repeated_front_codes_3d": sorted(repeated),
        "front_rank_continuity": bool(repeated),
        "max_board_series": [int(_num(row.get("max_board"))) for row in rows],
        "consecutive_series": [int(_num(row.get("consecutive"))) for row in rows],
    }


def _signal_context(snapshot: dict[str, Any]) -> dict[str, Any]:
    rows = _history(snapshot)
    current, previous = rows[-1], rows[-2]
    med = {f: _median_previous(rows, f) for f in ("limit_up", "limit_down", "consecutive", "seal_rate", "broken_board", "topic_count_ge3")}
    cur_breadth, prev_breadth = _breadth_ratio(current), _breadth_ratio(previous)
    topic = _topic_sequence(rows)
    leader = _leader_sequence(rows)
    improving = {
        "涨停扩张": _num(current["limit_up"]) >= max(_num(previous["limit_up"]) + 3, med["limit_up"] * 1.08),
        "跌停收敛": _num(current["limit_down"]) <= min(_num(previous["limit_down"]) - 2, med["limit_down"] * 0.85) if med["limit_down"] >= 3 else _num(current["limit_down"]) < _num(previous["limit_down"]),
        "连板增强": _num(current["consecutive"]) >= max(_num(previous["consecutive"]) + 2, med["consecutive"] * 1.08),
        "封板改善": _num(current["seal_rate"]) >= _num(previous["seal_rate"]) + 3.0,
        "炸板下降": _num(current["broken_board"]) <= max(0, _num(previous["broken_board"]) - 3),
        "宽度改善": cur_breadth >= prev_breadth + 0.06,
    }
    deteriorating = {
        "涨停收缩": _num(current["limit_up"]) <= min(_num(previous["limit_up"]) - 4, med["limit_up"] * 0.88),
        "跌停扩散": _num(current["limit_down"]) >= max(_num(previous["limit_down"]) + 3, med["limit_down"] * 1.25),
        "连板退化": _num(current["consecutive"]) <= min(_num(previous["consecutive"]) - 2, med["consecutive"] * 0.82),
        "封板恶化": _num(current["seal_rate"]) <= _num(previous["seal_rate"]) - 4.0,
        "炸板上升": _num(current["broken_board"]) >= max(_num(previous["broken_board"]) + 4, med["broken_board"] * 1.25),
        "宽度恶化": cur_breadth <= prev_breadth - 0.08,
    }
    current_weak = (
        cur_breadth < 0.38
        and _num(current["limit_down"]) >= max(8, _num(current["limit_up"]) * 0.35)
        and _num(current["seal_rate"]) < 65
    )
    baseline_weak = (
        statistics.median([_breadth_ratio(r) for r in rows[:-1][-3:]]) < 0.46
        or med["seal_rate"] < 65
        or med["limit_down"] >= max(8, med["limit_up"] * 0.30)
    )
    return {
        "rows": rows, "current": current, "previous": previous, "median": med,
        "breadth": cur_breadth, "previous_breadth": prev_breadth,
        "improving": improving, "deteriorating": deteriorating,
        "improve_count": sum(improving.values()), "deteriorate_count": sum(deteriorating.values()),
        "current_weak": current_weak, "baseline_weak": baseline_weak,
        "topic": topic, "leader": leader,
    }


def _confidence(snapshot: dict[str, Any], ctx: dict[str, Any], conflicts: Iterable[str] = ()) -> str:
    history_days = len(ctx["rows"])
    consistency = str(snapshot.get("cross_validation", {}).get("overall_status", "一致"))
    if consistency == "严重冲突":
        return "低"
    if history_days >= 5 and consistency == "一致" and not list(conflicts):
        return "高"
    if history_days >= 3 and consistency in {"一致", "轻微差异"}:
        return "中"
    return "低"


def determine_market_stage(snapshot: dict[str, Any]) -> dict[str, Any]:
    ctx = _signal_context(snapshot)
    c, p = ctx["current"], ctx["previous"]
    imp, det = ctx["improve_count"], ctx["deteriorate_count"]
    breadth = ctx["breadth"]
    persistent2 = len(ctx["topic"]["persistent_topics_ge2"])

    severe_loss = (
        # 绝对冰点优先：即便较昨日有局部修复，只要市场宽度极差且亏钱生态仍重，
        # 也不能因为“恶化项不够多”而降级为普通亏钱效应。
        (breadth <= 0.22
         and _num(c["limit_down"]) >= max(12, _num(c["limit_up"]) * 0.40)
         and (
            _num(c["broken_board"]) >= 18
            or _num(c["seal_rate"]) < 72
            or _num(c["limit_down"]) >= 18
         ))
        or (breadth <= 0.32 and det >= 3)
        or (det >= 4 and _num(c["limit_down"]) >= _num(c["limit_up"]) * 0.45)
        or (ctx["current_weak"] and _trend_count(ctx["rows"], "limit_down", "up", 2) >= 2)
    )
    emerging_loss = not severe_loss and (
        det >= 2
        and (breadth < 0.50 or _num(c["limit_down"]) > _num(p["limit_down"]) or _num(c["broken_board"]) > _num(p["broken_board"]))
    )
    climax = not (severe_loss or emerging_loss) and (
        breadth >= 0.62
        and persistent2 >= 2
        and _num(c["seal_rate"]) >= max(75, ctx["median"]["seal_rate"])
        and _num(c["limit_down"]) <= max(5, _num(c["limit_up"]) * 0.12)
        and _num(c["limit_up"]) >= ctx["median"]["limit_up"] * 1.18
        and ctx["deteriorate_count"] == 0
    )
    recovery = not (severe_loss or emerging_loss or climax) and (
        ctx["baseline_weak"] and imp >= 3 and det == 0 and breadth >= 0.48
    )
    if severe_loss:
        stage = "亏钱效应炸裂"
    elif emerging_loss:
        stage = "亏钱效应出现"
    elif climax:
        stage = "赚钱效应高潮"
    elif recovery:
        stage = "赚钱效应回暖"
    else:
        stage = "赚钱效应低迷"

    m = snapshot["market"]
    prev = snapshot["comparisons"]["previous_trading_day"]
    evidence = [
        f"最近{len(ctx['rows'])}个交易日连续序列参与判定，当前上涨/下跌={int(c['advancers'])}/{int(c['decliners'])}，宽度={breadth:.1%}",
        f"改善证据：{('、'.join(k for k,v in ctx['improving'].items() if v) or '无')}；恶化证据：{('、'.join(k for k,v in ctx['deteriorating'].items() if v) or '无')}",
        f"当前涨停{int(c['limit_up'])}、跌停{int(c['limit_down'])}、连板{int(c['consecutive'])}、封板率{_num(c['seal_rate']):.1f}%、炸板{int(c['broken_board'])}",
        f"连续至少2日保持3家以上涨停的题材={persistent2}个；最长持续={ctx['topic']['max_persistence_days']}日",
        amount_observation(m),
    ]
    return {
        "status": "DETERMINED", "stage": stage, "confidence": "中",
        "conclusion": _dynamic_conclusion(stage, m, prev, short_term=False),
        "evidence": evidence,
        "method": "滚动时序证据状态机：宽度、涨跌停、连板、封板/炸板、题材持续性联合判定；不生成情绪总分",
        "diagnostics": {"improving": ctx["improving"], "deteriorating": ctx["deteriorating"], "history_days": len(ctx["rows"])},
    }


def determine_short_term_stage(snapshot: dict[str, Any]) -> dict[str, Any]:
    ctx = _signal_context(snapshot)
    c, p, rows = ctx["current"], ctx["previous"], ctx["rows"]
    breadth = ctx["breadth"]
    imp, det = ctx["improve_count"], ctx["deteriorate_count"]
    topic2 = len(ctx["topic"]["persistent_topics_ge2"])
    topic3 = len(ctx["topic"]["persistent_topics_ge3"])
    persistence = ctx["topic"]["max_persistence_days"]
    new_topics = len(ctx["topic"]["new_topics_ge3"])
    ladder_up = _trend_count(rows, "consecutive", "up", 2) >= 1 or _num(c["consecutive"]) >= ctx["median"]["consecutive"] * 1.08
    ladder_down = _trend_count(rows, "consecutive", "down", 2) >= 2 or ctx["deteriorating"]["连板退化"]
    strong_seal = _num(c["seal_rate"]) >= max(72, ctx["median"]["seal_rate"] - 1)
    amount_ok = intraday_amount_not_comparable(snapshot["market"]) or snapshot["market"].get("amount_change_pct") is None or _num(snapshot["market"].get("amount_change_pct")) >= -5

    retreat = (
        ctx["current_weak"]
        or (det >= 4 and ladder_down)
        or (breadth <= 0.34 and ctx["deteriorating"]["跌停扩散"])
    )
    divergence = not retreat and (
        det >= 2
        or (ladder_down and (ctx["deteriorating"]["封板恶化"] or ctx["deteriorating"]["炸板上升"]))
        or (breadth < 0.48 and _num(c["limit_down"]) > _num(p["limit_down"]))
    )
    climax = not (retreat or divergence) and (
        topic3 >= 2
        and persistence >= 3
        and breadth >= 0.64
        and strong_seal
        and _num(c["limit_up"]) >= ctx["median"]["limit_up"] * 1.25
        and _num(c["limit_down"]) <= max(5, _num(c["limit_up"]) * 0.10)
        and _num(c["topic_count_ge3"]) >= max(4, ctx["median"]["topic_count_ge3"])
    )
    acceleration = not (retreat or divergence or climax) and (
        topic3 >= 1 and topic2 >= 2 and persistence >= 3
        and breadth >= 0.55 and ladder_up and strong_seal and amount_ok
        and not ctx["deteriorating"]["炸板上升"]
    )
    fermentation = not (retreat or divergence or climax or acceleration) and (
        topic2 >= 2 and persistence >= 2
        and breadth >= 0.52
        and _num(c["limit_up"]) >= _num(p["limit_up"]) * 0.95
        and not ladder_down
    )
    confirmation = not (retreat or divergence or climax or acceleration or fermentation) and (
        topic2 >= 1 and persistence >= 2
        and strong_seal
        and _num(c["limit_down"]) <= _num(p["limit_down"]) + 1
        and (ladder_up or ctx["leader"]["front_rank_continuity"] or imp >= 2)
    )
    startup = not any((retreat, divergence, climax, acceleration, fermentation, confirmation)) and (
        ctx["baseline_weak"]
        and new_topics >= 1
        and imp >= 2
        and det <= 1
        and breadth >= 0.44
    )

    if retreat:
        stage = "退潮期"
    elif divergence:
        stage = "分歧期"
    elif climax:
        stage = "高潮期"
    elif acceleration:
        stage = "加速期"
    elif fermentation:
        stage = "发酵期"
    elif confirmation:
        stage = "确认期"
    elif startup:
        stage = "启动期"
    else:
        # Conservative fallback: stable weakness is retreat; mixed/stalled markets are divergence.
        stage = "退潮期" if (ctx["baseline_weak"] and breadth < 0.46) else "分歧期"

    m = snapshot["market"]
    prev = snapshot["comparisons"]["previous_trading_day"]
    evidence = [
        f"最近{len(rows)}个交易日参与状态机，当前宽度={breadth:.1%}，改善证据{imp}项、恶化证据{det}项",
        f"题材持续：至少2日={topic2}个、至少3日={topic3}个、最长={persistence}日；当日新出现3家以上涨停题材={new_topics}个",
        f"梯队序列={ctx['leader']['consecutive_series']}，最高板序列={ctx['leader']['max_board_series']}，前排身份连续={ctx['leader']['front_rank_continuity']}",
        f"当前涨停{int(c['limit_up'])}、跌停{int(c['limit_down'])}、连板{int(c['consecutive'])}、封板率{_num(c['seal_rate']):.1f}%、炸板{int(c['broken_board'])}",
        amount_observation(m),
    ]
    return {
        "status": "DETERMINED", "stage": stage, "confidence": "中",
        "conclusion": _dynamic_conclusion(stage, m, prev, short_term=True),
        "evidence": evidence,
        "method": "七阶段滚动时序状态机；强阶段必须有题材持续与梯队延续，启动必须有弱基底后的新题材和多项改善；无证据时不默认启动",
        "diagnostics": {
            "history_days": len(rows), "improving": ctx["improving"], "deteriorating": ctx["deteriorating"],
            "topic_sequence": ctx["topic"], "leader_sequence": ctx["leader"],
            "fallback_used": not any((retreat, divergence, climax, acceleration, fermentation, confirmation, startup)),
        },
    }


def build_current_response_and_outlook(snapshot: dict[str, Any], short_stage: str, intermediate_stage: str) -> tuple[dict[str, Any], dict[str, Any]]:
    m = snapshot["market"]
    previous = snapshot["comparisons"]["previous_trading_day"]
    playbook = {
        "启动期": ("小仓位观察与试错，必须等待次日确认", "新题材持续、核心承接和首个自然梯队", "单日脉冲、无连续性的跟风扩散"),
        "确认期": ("确认持续性后再提高参与强度", "自然接力、梯队完整、核心换手承接", "一致性过强后的追高和边缘跟风"),
        "发酵期": ("围绕主线核心参与，同时预留分歧空间", "题材连续扩散、核心/跟风层级和封板质量", "脱离主线的补涨和连续加速追高"),
        "加速期": ("管理已有优势，明显减少新增追高", "前排换手、封板质量、成交承接", "缩量一致后的盲目接力"),
        "高潮期": ("保护已有成果，等待分歧后的重新确认", "核心承接、炸板、后排掉队速度", "情绪极致时继续扩大风险暴露"),
        "分歧期": ("降低参与强度，等待修复证据", "核心是否回封、亏钱效应是否收敛、题材是否保留前排", "无承接反抽和后排弱势股"),
        "退潮期": ("防守和等待为主，不抢无确认的修复", "跌停/炸板收敛、新核心试盘、旧高位止跌", "补跌中的旧周期高位股"),
    }
    posture, focus, avoid = playbook[short_stage]
    if intermediate_stage in {"亏钱效应出现", "亏钱效应炸裂"} and short_stage not in {"分歧期", "退潮期"}:
        posture += "；中级亏钱效应已抬头，短线局部强势不得外推为全面转强"
    if intermediate_stage == "赚钱效应高潮" and short_stage not in {"高潮期", "分歧期", "退潮期"}:
        posture += "；中级赚钱效应处高位，避免把当前扩散机械外推为继续加速"
    base_next = {
        "启动期": "确认期或重新回到退潮/分歧", "确认期": "发酵期或分歧期", "发酵期": "加速期或分歧期",
        "加速期": "高潮期或分歧期", "高潮期": "分歧期", "分歧期": "修复到确认/发酵，或继续退潮", "退潮期": "退潮延续或出现新的启动证据",
    }[short_stage]
    return ({
        "stage": short_stage, "posture": posture, "focus": focus, "avoid": avoid,
        "invalidation_signals": ["封板率明显恶化且炸板扩散", "连板梯队连续两日退化并出现前排补跌", "跌停扩散且市场宽度转为明显劣势", "主线题材连续性中断"],
    }, {
        "basis": f"当前为{short_stage}，中级周期为{intermediate_stage}；仅按条件演化，不预测必然涨跌。",
        "base_case": {"next_stage": base_next, "conditions": "当前主线和梯队按自然节奏演化，既未出现多项强化，也未出现多项恶化。"},
        "stronger_case": {"next_stage": "向更强阶段推进或维持强势", "conditions": "连续题材增加、涨停/连板扩张、封板率改善、炸板/跌停不扩散，市场宽度同步确认。"},
        "weaker_case": {"next_stage": "转入分歧期或退潮期", "conditions": "题材持续性中断，涨停/连板收缩，封板率下降，炸板/跌停扩散，并伴随前排掉队。"},
        "next_session_watchlist": ["题材连续天数与前排身份是否延续", "涨停、跌停、连板、最高板的连续变化", "封板率与炸板是否同向改善", "市场宽度与成交额是否共同确认", "短线侠与连板网关键字段差异是否扩大"],
        "uncertainty_statement": "条件变化后必须重新运行引擎；历史阶段标签不得沿用替代新证据。",
    })


REPORT_TEMPLATE = "WORKBUDDY_SENTIMENT_TEXT_REPORT_V1"


def _md(value: Any) -> str:
    return str(value if value is not None else "-").replace("|", "\\|").replace("\n", " ").strip() or "-"


def _cn_date(value: str) -> str:
    try:
        y, m, d = [int(x) for x in value.split("-")]
        return f"{y}年{m}月{d}日"
    except Exception:
        return value


def _yesno(value: Any) -> str:
    return "是" if bool(value) else "否"


def _market_nature(snapshot: dict[str, Any], result: dict[str, Any]) -> str:
    short = result["short_term_stage_conclusion"]["stage"]
    intermediate = result["single_stage_conclusion"]["stage"]
    reported = str(snapshot.get("sources", {}).get("lianban", {}).get("reported_stage") or "")
    topic = result["short_term_stage_conclusion"].get("diagnostics", {}).get("topic_sequence", {})
    new_topics = topic.get("new_topics_ge3") if isinstance(topic, dict) else []
    if short == "退潮期":
        if "冰点" in reported and new_topics:
            return "退潮/冰点环境中的局部题材试盘，尚不属于正式情绪反转。"
        if intermediate == "亏钱效应炸裂":
            return "退潮环境中的高亏钱效应阶段，局部修复不能外推为全面转强。"
        return "退潮环境，优先等待亏钱效应收敛与新周期连续证据。"
    if short == "分歧期":
        return "主线与赚钱效应进入分歧，是否修复取决于前排承接、梯队和亏钱效应能否同步改善。"
    if short == "启动期":
        return "弱基底后出现新方向试盘，仅属于启动证据，仍需下一交易日确认。"
    if short == "确认期":
        return "新周期获得初步连续性确认，但尚未进入全面发酵。"
    if short == "发酵期":
        return "主线连续性与梯队扩散已建立，市场进入发酵阶段。"
    if short == "加速期":
        return "主线、梯队和市场宽度共同加速，新增追高风险同步上升。"
    return "赚钱效应处于高位扩散，后续重点防范由一致转分歧。"


def render_text_report(snapshot: dict[str, Any], result: dict[str, Any]) -> str:
    """Render the single canonical WorkBuddy text report.

    WorkBuddy should present this report without re-ordering, compressing or inventing
    extra conclusions. JSON remains an audit artifact; this Markdown is the user-facing
    production template.
    """
    market = snapshot["market"]
    rows = _history(snapshot)
    short = result["short_term_stage_conclusion"]
    intermediate = result["single_stage_conclusion"]
    current_response = result["current_response"]
    outlook = result["outlook"]
    cross = snapshot.get("cross_validation", {})
    reported = snapshot.get("sources", {}).get("lianban", {}).get("reported_stage") or "未提供"
    breadth = _breadth_ratio(rows[-1]) if rows else 0.0
    fallback = short.get("diagnostics", {}).get("fallback_used", False)
    lines: list[str] = []
    lines.append(f"# {_cn_date(str(snapshot['trading_date']))} A股短线市场情绪研判实跑结果")
    lines.append("")
    lines.append(f"> 固定模板：`{REPORT_TEMPLATE}`。本报告只陈述已验证数据、状态机结论和条件路径，不把条件推演写成确定涨跌。")
    lines.append("")
    lines.append("## 一、核心状态")
    lines.append("")
    lines.append("| 项目 | 实跑结果 |")
    lines.append("|---|---|")
    lines.append(f"| 运行状态 | 通过（{_md(result.get('status'))}） |")
    lines.append(f"| 短线七阶段 | **{_md(short['stage'])}** |")
    lines.append(f"| 短线阶段置信度 | **{_md(short['confidence'])}** |")
    lines.append(f"| 中级五阶段 | **{_md(intermediate['stage'])}** |")
    lines.append(f"| 中级阶段置信度 | **{_md(intermediate['confidence'])}** |")
    lines.append(f"| 使用历史 | **{len(rows)}个交易日** |")
    lines.append(f"| 跨源一致性 | **{_md(cross.get('overall_status', '未提供'))}** |")
    lines.append(f"| 连板网外部阶段 | **{_md(reported)}** |")
    lines.append(f"| 状态机是否使用兜底 | **{_yesno(fallback)}** |")
    lines.append(f"| 最终市场姿态 | **{_md(current_response['posture'])}** |")
    lines.append("")
    lines.append("## 二、当日真实盘面输入")
    lines.append("")
    lines.append("| 指标 | 数值 |")
    lines.append("|---|---:|")
    lines.append(f"| 上证日线涨跌 | {float(market['index_change_pct']):+.2f}% |")
    lines.append(f"| 上涨 / 下跌 | {int(market['advancers'])} / {int(market['decliners'])} |")
    lines.append(f"| 红盘宽度 | {breadth:.1%} |")
    lines.append(f"| 涨停 / 跌停 | {int(market['limit_up'])} / {int(market['limit_down'])} |")
    lines.append(f"| 连板 / 最高板 | {int(market['consecutive'])} / {int(market['max_board'])}板 |")
    lines.append(f"| 封板率 | {float(market['seal_rate']):.1f}% |")
    lines.append(f"| 炸板 | {int(market['broken_board'])} |")
    lines.append(f"| 成交 | {_md(amount_observation(market))} |")
    lines.append("")
    lines.append(f"## 三、{len(rows)}日情绪演化")
    lines.append("")
    lines.append("| 日期 | 指数涨跌 | 上涨/下跌 | 涨停 | 跌停 | 连板 | 最高板 | 封板率 | 炸板 | 外部阶段旁证 |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---|")
    for row in rows:
        ext = row.get("reported_stage") or (reported if row is rows[-1] else "-")
        lines.append(
            f"| {_md(row.get('date'))} | {_num(row.get('index_change_pct')):+.2f}% | "
            f"{int(_num(row.get('advancers')))}/{int(_num(row.get('decliners')))} | {int(_num(row.get('limit_up')))} | "
            f"{int(_num(row.get('limit_down')))} | {int(_num(row.get('consecutive')))} | {int(_num(row.get('max_board')))} | "
            f"{_num(row.get('seal_rate')):.1f}% | {int(_num(row.get('broken_board')))} | {_md(ext)} |"
        )
    lines.append("")
    lines.append("## 四、短线七阶段判定")
    lines.append("")
    lines.append(f"**结论：{_md(short['stage'])}〔{_md(short['confidence'])}置信度〕**")
    lines.append("")
    for item in short.get("evidence", []):
        lines.append(f"- {_md(item)}")
    diag = short.get("diagnostics", {})
    improving = [k for k, v in diag.get("improving", {}).items() if v]
    deteriorating = [k for k, v in diag.get("deteriorating", {}).items() if v]
    lines.append(f"- 改善项：{_md('、'.join(improving) if improving else '无')}；恶化项：{_md('、'.join(deteriorating) if deteriorating else '无')}。")
    lines.append(f"- 阶段冲突：{_md(short.get('conflict_statement'))}")
    lines.append("")
    lines.append("## 五、中级五阶段判定")
    lines.append("")
    lines.append(f"**结论：{_md(intermediate['stage'])}〔{_md(intermediate['confidence'])}置信度〕**")
    lines.append("")
    for item in intermediate.get("evidence", []):
        lines.append(f"- {_md(item)}")
    lines.append(f"- 阶段冲突：{_md(intermediate.get('conflict_statement'))}")
    lines.append("")
    lines.append("## 六、题材与梯队结构")
    lines.append("")
    topic = diag.get("topic_sequence", {}) if isinstance(diag, dict) else {}
    details = topic.get("details", []) if isinstance(topic, dict) else []
    if details:
        lines.append("| 当前题材 | 当日涨停数 | 连续达到3家以上天数 |")
        lines.append("|---|---:|---:|")
        for item in details[:8]:
            lines.append(f"| {_md(item.get('name'))} | {int(_num(item.get('current_count')))} | {int(_num(item.get('days_ge3')))} |")
    else:
        lines.append("当前未识别到可形成连续性判断的题材结构。")
    leader = diag.get("leader_sequence", {}) if isinstance(diag, dict) else {}
    lines.append("")
    lines.append(f"- 连板梯队序列：{_md(leader.get('consecutive_series'))}")
    lines.append(f"- 最高板序列：{_md(leader.get('max_board_series'))}")
    lines.append(f"- 前排身份连续：{_yesno(leader.get('front_rank_continuity'))}")
    lines.append(f"- 环境性质：**{_md(_market_nature(snapshot, result))}**")
    lines.append("")
    lines.append("## 七、实战操作结论")
    lines.append("")
    lines.append(f"- **当前应对：** {_md(current_response['posture'])}")
    lines.append(f"- **重点观察：** {_md(current_response['focus'])}")
    lines.append(f"- **重点回避：** {_md(current_response['avoid'])}")
    lines.append("- **失效/重新评估信号：** " + "；".join(_md(x) for x in current_response.get("invalidation_signals", [])))
    lines.append("")
    lines.append("## 八、下一交易日条件推演")
    lines.append("")
    lines.append(f"- **基准路径：** {_md(outlook['base_case']['next_stage'])}。{_md(outlook['base_case']['conditions'])}")
    lines.append(f"- **强化路径：** {_md(outlook['stronger_case']['next_stage'])}。{_md(outlook['stronger_case']['conditions'])}")
    lines.append(f"- **转弱路径：** {_md(outlook['weaker_case']['next_stage'])}。{_md(outlook['weaker_case']['conditions'])}")
    lines.append("- **下一交易日观察清单：** " + "；".join(_md(x) for x in outlook.get("next_session_watchlist", [])))
    lines.append("")
    lines.append("## 九、最终实跑结论")
    lines.append("")
    lines.append(f"> **短线市场阶段：{_md(short['stage'])}〔{_md(short['confidence'])}置信度〕**  ")
    lines.append(f"> **中级赚钱效应阶段：{_md(intermediate['stage'])}〔{_md(intermediate['confidence'])}置信度〕**  ")
    lines.append(f"> **环境性质：{_md(_market_nature(snapshot, result))}**  ")
    lines.append(f"> **策略权限：{_md(current_response['posture'])}**")
    lines.append("")
    lines.append("---")
    lines.append("生产纪律：只有 `run=CLEAN_PASS` 且对应回执经 `authorize=AUTHORIZED` 后，WorkBuddy 才能把本报告作为正式结论展示；禁止绕过数据门禁手工补阶段。")
    return "\n".join(lines).rstrip() + "\n"


def validate_snapshot(snapshot: dict[str, Any]) -> None:
    if not isinstance(snapshot, dict) or not snapshot.get("trading_date"):
        raise SnapshotValidationError("missing:trading_date")
    market = snapshot.get("market")
    if not isinstance(market, dict):
        raise SnapshotValidationError("missing:market")
    missing = [k for k in REQUIRED_MARKET if (k not in market or market[k] is None) and not (k == "amount_change_pct" and intraday_amount_not_comparable(market))]
    if missing:
        raise SnapshotValidationError("missing_market_fields:" + ",".join(missing))
    comparisons = snapshot.get("comparisons")
    if not isinstance(comparisons, dict) or not isinstance(comparisons.get("previous_trading_day"), dict):
        raise SnapshotValidationError("missing:previous_trading_day")
    previous = comparisons["previous_trading_day"]
    missing_previous = [k for k in REQUIRED_PREVIOUS if previous.get(k) is None]
    if missing_previous:
        raise SnapshotValidationError("missing_previous_metrics:" + ",".join(missing_previous))
    sources = snapshot.get("sources")
    if not isinstance(sources, dict):
        raise SnapshotValidationError("missing:sources")
    dates = set()
    for name in REQUIRED_SOURCES:
        source = sources.get(name)
        if not isinstance(source, dict) or source.get("verified") is not True:
            raise SnapshotValidationError(f"source_not_verified:{name}")
        dates.add(str(source.get("trading_date", "")))
    if dates != {str(snapshot["trading_date"])}:
        raise SnapshotValidationError("source_date_mismatch:" + ",".join(sorted(dates)))
    rows = _history(snapshot)
    if len(rows) < 3:
        raise SnapshotValidationError(f"history_insufficient:{len(rows)}:minimum=3")
    if rows[-1].get("date") != snapshot["trading_date"]:
        raise SnapshotValidationError("history_current_date_mismatch")
    for row in rows:
        missing_row = [k for k in HISTORY_REQUIRED_FIELDS if row.get(k) is None]
        if missing_row:
            raise SnapshotValidationError(f"history_missing:{row.get('date')}:{','.join(missing_row)}")
    cross = snapshot.get("cross_validation")
    if not isinstance(cross, dict) or not cross.get("overall_status"):
        raise SnapshotValidationError("missing_cross_validation_status")
    if cross.get("overall_status") == "严重冲突":
        raise SnapshotValidationError("critical_source_conflict")


def analyze_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    validate_snapshot(snapshot)
    m = snapshot["market"]
    ctx = _signal_context(snapshot)
    stage = determine_market_stage(snapshot)
    short = determine_short_term_stage(snapshot)
    lianban_stage = snapshot["sources"]["lianban"].get("reported_stage")
    short_conflicts: list[str] = []
    market_conflicts: list[str] = []
    mapped_short = _reported_stage_to_short(lianban_stage)
    mapped_market = _reported_stage_to_intermediate(lianban_stage)
    if lianban_stage and mapped_short and mapped_short != short["stage"]:
        short_conflicts.append(f"连板网外部标签={lianban_stage}，映射为{mapped_short}，与内部{short['stage']}不一致；外部标签仅作旁证")
    if lianban_stage and mapped_market and mapped_market != stage["stage"]:
        market_conflicts.append(f"连板网外部标签={lianban_stage}，映射为{mapped_market}，与内部{stage['stage']}不一致；外部标签仅作旁证")
    cross = snapshot.get("cross_validation", {})
    for item in cross.get("conflicts", []) if isinstance(cross.get("conflicts"), list) else []:
        text = str(item)
        short_conflicts.append(text)
        market_conflicts.append(text)
    short["confidence"] = _confidence(snapshot, ctx, short_conflicts)
    stage["confidence"] = _confidence(snapshot, ctx, market_conflicts)
    short["conflicts"] = list(dict.fromkeys(short_conflicts))
    stage["conflicts"] = list(dict.fromkeys(market_conflicts))
    short["conflict_statement"] = "；".join(short["conflicts"]) if short["conflicts"] else "未发现足以改变短线情绪阶段判定的直接冲突。"
    stage["conflict_statement"] = "；".join(stage["conflicts"]) if stage["conflicts"] else "未发现足以改变中级周期阶段判定的直接冲突。"
    current_response, outlook = build_current_response_and_outlook(snapshot, short["stage"], stage["stage"])
    topic_names = [x["name"] for x in ctx["topic"]["details"][:4]]
    cycles = {
        "index_cycle": {"stage_status": "仅观察", "judgement": "只确认指数日线与市场宽度，不用单一指数方向替代全市场情绪", "observations": [f"上证日线{m['index_change_pct']:+.3f}%", f"上涨{m['advancers']}家、下跌{m['decliners']}家"], "evidence_limit": "缺少五类指数分时背离/共振，禁止单独命名指数周期阶段"},
        "theme_cycle": {"stage_status": "已判定", "judgement": short["conclusion"], "observations": short["evidence"], "evidence_limit": f"使用{len(ctx['rows'])}日题材序列；历史不足5日时置信度不会提升为高"},
        "leader_cycle": {"stage_status": "已观察", "judgement": f"连板序列{ctx['leader']['consecutive_series']}；最高板序列{ctx['leader']['max_board_series']}；前排身份连续={ctx['leader']['front_rank_continuity']}", "observations": [f"重复前排代码={','.join(ctx['leader']['repeated_front_codes_3d']) or '未确认'}"], "evidence_limit": "前排身份来自连板网页面；若历史页面缺失则只能用梯队数量和高度，不推断具体龙头个股周期"},
        "profit_loss_cycle": {"stage_status": "已判定", "judgement": stage["conclusion"], "observations": stage["evidence"], "evidence_limit": "中级阶段为市场结构分类，不代表未来收益保证"},
        "intermediate_cycle": {"stage_status": "已判定", "judgement": stage["conclusion"], "observations": stage["evidence"], "evidence_limit": "保留题材、龙头、宽度与涨跌停生态之间的错位，不生成单一情绪分值"},
    }
    conflicts = list(dict.fromkeys(short["conflicts"] + stage["conflicts"]))
    return {
        "schema": "SHORT_TERM_MARKET_SENTIMENT_PRODUCTION_V2",
        "status": "CLEAN_PASS", "trading_date": snapshot["trading_date"], "analysis_mode": "rolling_evidence_state_machine",
        "report_template": REPORT_TEMPLATE,
        "single_stage_conclusion": stage, "short_term_stage_conclusion": short,
        "current_response": current_response, "outlook": outlook, "cycles": cycles,
        "observed_relationship": f"{len(ctx['rows'])}日序列显示：题材{('、'.join(topic_names) or '无连续主线')}，宽度{ctx['breadth']:.1%}，连板{m['consecutive']}只；短线={short['stage']}，中级={stage['stage']}。",
        "conflicts": conflicts,
        "evidence_limits": [v["evidence_limit"] for v in cycles.values()],
        "risk_boundary": [f"当日炸板{m['broken_board']}家、跌停{m['limit_down']}家", amount_observation(m), "阶段判定需要连续证据；单日扩散不得直接升级为发酵/加速/高潮", "市场结构研判不构成个股推荐、收益保证或自动交易指令"],
        "sources": snapshot["sources"],
        "source_consistency": snapshot.get("cross_validation"),
    }


def example_snapshot(name: str) -> dict[str, Any]:
    date = "2026-08-14"
    if name == "strong":
        hist = [
            ("2026-08-10", 2800, 2200, 45, 8, 10, 4, 72, 17, 8, 3),
            ("2026-08-11", 3100, 1900, 55, 6, 14, 5, 76, 14, 10, 4),
            ("2026-08-12", 3450, 1550, 70, 5, 18, 6, 81, 11, 12, 5),
            ("2026-08-13", 3800, 1200, 85, 4, 23, 7, 84, 9, 14, 6),
            (date, 4100, 900, 110, 3, 30, 8, 88, 7, 17, 8),
        ]
    elif name == "retreat":
        hist = [
            ("2026-08-10", 3000, 2000, 62, 5, 18, 6, 80, 10, 12, 5),
            ("2026-08-11", 2600, 2400, 52, 8, 14, 5, 73, 16, 9, 4),
            ("2026-08-12", 2100, 2900, 41, 12, 10, 4, 66, 21, 7, 3),
            ("2026-08-13", 1600, 3400, 31, 18, 7, 3, 58, 28, 5, 2),
            (date, 900, 4100, 20, 29, 3, 2, 45, 39, 3, 1),
        ]
    else:
        hist = [
            ("2026-08-10", 1300, 3700, 25, 9, 5, 3, 63, 20, 4, 1),
            ("2026-08-11", 1350, 3650, 26, 9, 5, 3, 63, 20, 4, 1),
            ("2026-08-12", 1400, 3600, 25, 8, 5, 3, 64, 19, 4, 1),
            ("2026-08-13", 1380, 3620, 25, 8, 5, 3, 64, 19, 4, 1),
            (date, 1420, 3580, 26, 8, 5, 3, 64, 19, 4, 1),
        ]
    rows = []
    topics = [{"name": "主线A", "count": 5}, {"name": "主线B", "count": 4}] if name == "strong" else [{"name": "零散题材", "count": 3}]
    for i, row in enumerate(hist):
        d,a,dec,lu,ld,con,maxb,seal,broken,top,ge3 = row
        rows.append({"date": d, "advancers": a, "decliners": dec, "index_change_pct": 0.2, "total_amount_billion": 11000+i*300, "amount_change_pct": 2.0, "limit_up": lu, "limit_down": ld, "consecutive": con, "max_board": maxb, "seal_rate": seal, "broken_board": broken, "topic_top_count": top, "topic_count_ge3": ge3, "topics": topics if name == "strong" else ([{"name":"零散题材","count":3}] if i == len(hist)-1 else []), "leaders": []})
    cur, prev = rows[-1], rows[-2]
    market = {k: cur[k] for k in REQUIRED_MARKET}
    return {
        "schema": "SHORT_TERM_SENTIMENT_SNAPSHOT_V2", "trading_date": date, "market": market, "topics": cur["topics"], "history": rows,
        "sources": {k: {"verified": True, "trading_date": date, "reported_stage": None} for k in REQUIRED_SOURCES},
        "cross_validation": {"overall_status": "一致", "metrics": {}, "conflicts": []},
        "comparisons": {"previous_trading_day": {k: prev[k] for k in REQUIRED_PREVIOUS}},
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("snapshot", nargs="?")
    parser.add_argument("--example", choices=("strong", "mixed", "retreat"))
    args = parser.parse_args()
    snap = example_snapshot(args.example) if args.example else json.loads(Path(args.snapshot).read_text(encoding="utf-8"))
    print(json.dumps(analyze_snapshot(snap), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
