# 生产执行协议 V2.2——实战固化版

## 1. 启动前完整性校验

统一入口读取 `package-manifest.json`，逐文件验证字节数和 SHA-256。核心脚本、文档、测试任一受管文件与清单不一致，`selftest`、`run`、`authorize`、`present` 均不得形成正式交付。

## 2. 当前源采集

一次运行必须取得连板网最新数据与日期页、短线侠 `ztcount/ztpool/jinjidata/amount`、本地通达信目标交易日行情。四组短线侠数据必须同批成功；可提取交易日的字段必须与目标日一致。

## 3. 多日历史

目标5日，最低3日。历史日期必须为有效交易日。通达信对同一组日期计算全市场上涨/下跌、成交额和指数变化；任一历史日股票覆盖不足3000只阻断。

## 4. 标准快照

快照至少包含：交易日、市场数据、题材、历史、三源证明、跨源校验、前日比较。历史按日期升序，同时保留每个历史日可获得的外部阶段旁证，但旁证不参与强制覆盖内部阶段。

## 5. 跨源验证

涨停、跌停、连板、炸板、封板率按绝对+相对容差校验。严重冲突阻断；轻微差异只降低证据完整度，不机械打成最低可信度。

## 6. 阶段状态机

顺序：绝对宽度与亏钱扩散 → 改善/恶化证据 → 题材持续 → 梯队延续 → 七阶段/五阶段双判定。稳定弱势不能判启动；单日爆发不能越级；绝对冰点不能因封板率局部改善被误判回暖。

## 7. 标准文字报告

`run` 必须生成：

- `sentiment_snapshot.json`：审计快照；
- `sentiment_result.json`：结构化判定；
- `sentiment_report.md`：唯一面向用户的标准文字报告；
- `receipt.json`：运行回执。

`sentiment_report.md` 必须符合 `WORKBUDDY_SENTIMENT_TEXT_REPORT_V1` 九段模板。

## 8. 授权与展示

固定顺序：

```powershell
python scripts/workbuddy_entry.py run --output .local/runs/current
python scripts/workbuddy_entry.py authorize --receipt .local/runs/current/receipt.json
python scripts/workbuddy_entry.py present --receipt .local/runs/current/receipt.json
```

只有 `run=CLEAN_PASS`、`authorize=AUTHORIZED` 后，`present` 才能输出标准报告。WorkBuddy 最终回答必须直接采用 `present` 输出，不自行压缩或改写。

## 9. 黄金回归锁

2026-09-11 用户认可实跑作为生产黄金样本，测试固定检查：短线=退潮期、高置信度；中级=亏钱效应炸裂、高置信度；策略姿态包含防守等待。任何后续重构破坏该样本，都视为回归失败。
