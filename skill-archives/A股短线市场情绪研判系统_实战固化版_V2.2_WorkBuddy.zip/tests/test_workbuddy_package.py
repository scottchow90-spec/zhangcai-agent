from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class WorkBuddyPackageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.engine = load(ROOT / "scripts" / "sentiment_engine.py", "wb_package_engine")

    def test_engine_delivers_complete_production_output(self) -> None:
        result = self.engine.analyze_snapshot(self.engine.example_snapshot("strong"))
        self.assertEqual(result["schema"], "SHORT_TERM_MARKET_SENTIMENT_PRODUCTION_V2")
        self.assertEqual(result["status"], "CLEAN_PASS")
        self.assertTrue(result["short_term_stage_conclusion"]["stage"])
        self.assertTrue(result["single_stage_conclusion"]["stage"])
        self.assertTrue(result["current_response"]["posture"])
        self.assertTrue(result["outlook"]["base_case"]["conditions"])
        self.assertTrue(result["outlook"]["stronger_case"]["conditions"])
        self.assertTrue(result["outlook"]["weaker_case"]["conditions"])
        self.assertEqual(result["report_template"], "WORKBUDDY_SENTIMENT_TEXT_REPORT_V1")
        report = self.engine.render_text_report(self.engine.example_snapshot("strong"), result)
        for section in ("## 一、核心状态", "## 二、当日真实盘面输入", "## 四、短线七阶段判定", "## 七、实战操作结论", "## 九、最终实跑结论"):
            self.assertIn(section, report)

    def test_stable_weak_market_is_not_falsely_startup(self) -> None:
        result = self.engine.analyze_snapshot(self.engine.example_snapshot("mixed"))
        self.assertNotEqual(result["short_term_stage_conclusion"]["stage"], "启动期")
        self.assertIn(result["short_term_stage_conclusion"]["stage"], {"分歧期", "退潮期"})
        self.assertNotEqual(result["single_stage_conclusion"]["stage"], "赚钱效应回暖")

    def test_retreat_case_is_retreat_and_loss_burst(self) -> None:
        result = self.engine.analyze_snapshot(self.engine.example_snapshot("retreat"))
        self.assertEqual(result["short_term_stage_conclusion"]["stage"], "退潮期")
        self.assertEqual(result["single_stage_conclusion"]["stage"], "亏钱效应炸裂")

    def test_one_day_spike_cannot_jump_to_acceleration_or_climax(self) -> None:
        snap = self.engine.example_snapshot("mixed")
        # Four weak/flat days, then one very strong day with entirely new topics.
        current = snap["history"][-1]
        current.update({
            "advancers": 3900, "decliners": 1100, "limit_up": 90, "limit_down": 3,
            "consecutive": 18, "max_board": 6, "seal_rate": 86, "broken_board": 7,
            "topic_top_count": 16, "topic_count_ge3": 7,
            "topics": [{"name": "新主线甲", "count": 16}, {"name": "新主线乙", "count": 8}],
        })
        snap["market"].update({k: current[k] for k in self.engine.REQUIRED_MARKET})
        snap["comparisons"]["previous_trading_day"] = {k: snap["history"][-2][k] for k in self.engine.REQUIRED_PREVIOUS}
        result = self.engine.analyze_snapshot(snap)
        self.assertNotIn(result["short_term_stage_conclusion"]["stage"], {"发酵期", "加速期", "高潮期"})

    def test_startup_requires_weak_base_new_topic_and_multiple_improvements(self) -> None:
        snap = self.engine.example_snapshot("mixed")
        cur = snap["history"][-1]
        prev = snap["history"][-2]
        cur.update({
            "advancers": 2500, "decliners": 2500, "limit_up": 35, "limit_down": 5,
            "consecutive": 8, "max_board": 4, "seal_rate": 70, "broken_board": 14,
            "topic_top_count": 6, "topic_count_ge3": 1,
            "topics": [{"name": "新试盘方向", "count": 6}],
        })
        snap["market"].update({k: cur[k] for k in self.engine.REQUIRED_MARKET})
        snap["comparisons"]["previous_trading_day"] = {k: prev[k] for k in self.engine.REQUIRED_PREVIOUS}
        result = self.engine.analyze_snapshot(snap)
        self.assertEqual(result["short_term_stage_conclusion"]["stage"], "启动期")

    def test_history_less_than_three_days_is_blocked(self) -> None:
        snap = self.engine.example_snapshot("strong")
        snap["history"] = snap["history"][-2:]
        with self.assertRaises(self.engine.SnapshotValidationError):
            self.engine.analyze_snapshot(snap)

    def test_critical_source_conflict_is_blocked(self) -> None:
        snap = self.engine.example_snapshot("strong")
        snap["cross_validation"]["overall_status"] = "严重冲突"
        with self.assertRaises(self.engine.SnapshotValidationError):
            self.engine.analyze_snapshot(snap)

    def test_lianban_six_stage_labels_are_mapped(self) -> None:
        short_map = {
            "修复": "启动期", "升温": "发酵期", "高潮": "高潮期",
            "降温": "分歧期", "退潮": "退潮期", "冰点": "退潮期",
        }
        for label, expected in short_map.items():
            self.assertEqual(self.engine._reported_stage_to_short(label), expected)
        self.assertEqual(self.engine._reported_stage_to_intermediate("升温"), "赚钱效应回暖")
        self.assertEqual(self.engine._reported_stage_to_intermediate("降温"), "亏钱效应出现")
        self.assertEqual(self.engine._reported_stage_to_intermediate("冰点"), "亏钱效应炸裂")

    def test_confidence_not_lowered_by_tiny_unreported_difference(self) -> None:
        snap = self.engine.example_snapshot("strong")
        snap["cross_validation"] = {"overall_status": "轻微差异", "metrics": [], "conflicts": ["涨停差1家，处于容差范围外沿"]}
        result = self.engine.analyze_snapshot(snap)
        self.assertIn(result["short_term_stage_conclusion"]["confidence"], {"中", "高"})
        self.assertNotEqual(result["short_term_stage_conclusion"]["confidence"], "低")


    def test_source_precheck_blocks_date_mismatch(self) -> None:
        entry = load(ROOT / "scripts" / "workbuddy_entry.py", "wb_entry_source_test")
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            lb = td / "lb.json"
            dx = td / "dx.json"
            hist = td / "hist.json"
            lb.write_text(json.dumps({"status":"CLEAN_PASS","target_date":"2026-09-11"}), encoding="utf-8")
            datasets = {}
            for name in ("ztcount","ztpool","jinjidata","amount"):
                datasets[name] = {"success":True,"status_code":200,"fetched_at":"2026-09-11T16:00:00+08:00","data":{}}
            datasets["jinjidata"]["data"] = {"date":"2026-09-10"}
            dx.write_text(json.dumps({"datasets":datasets}), encoding="utf-8")
            hist.write_text(json.dumps({"status":"CLEAN_PASS","target_date":"2026-09-11","history_days":5}), encoding="utf-8")
            result = entry.validate_public_sources(lb, dx, hist)
            self.assertEqual(result["status"], "BLOCKED")
            self.assertTrue(any("source_date_mismatch" in x for x in result["errors"]))

    def test_field_tolerance_does_not_treat_one_stock_difference_as_major(self) -> None:
        live = load(ROOT / "scripts" / "live_snapshot.py", "wb_live_compare_test")
        row = live._metric_compare("limit_up", 27, 26, abs_tolerance=2, rel_tolerance=.05)
        self.assertEqual(row["status"], "一致")

    def test_skill_is_portable_and_has_workbuddy_entry(self) -> None:
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("entry: scripts/workbuddy_entry.py", text)
        forbidden = ("F:" + "\\Codex\\Home", "C:" + "\\Users\\25296")
        for path in ROOT.rglob("*"):
            if path.is_file() and path.suffix.lower() in {".py", ".md", ".yaml", ".json", ".txt", ".ps1"}:
                content = path.read_text(encoding="utf-8-sig", errors="ignore")
                for value in forbidden:
                    self.assertNotIn(value, content, str(path))

    def test_text_only_package_has_no_poster_code_or_flags(self) -> None:
        entry_text = (ROOT / "scripts" / "workbuddy_entry.py").read_text(encoding="utf-8")
        self.assertNotIn("--poster", entry_text)
        self.assertNotIn("--visual-inspected", entry_text)
        self.assertFalse((ROOT / "scripts" / "poster_template.py").exists())
        self.assertFalse((ROOT / "scripts" / "poster_validator.py").exists())
        self.assertNotIn("Pillow", (ROOT / "requirements.txt").read_text(encoding="utf-8"))

    def test_absolute_ice_point_remains_loss_burst_even_with_partial_repair(self) -> None:
        snap = self.engine.example_snapshot("retreat")
        # 模拟绝对冰点：较昨日有局部修复，但市场宽度仍极差、跌停仍高。
        cur = snap["history"][-1]
        prev = snap["history"][-2]
        cur.update({
            "advancers": 643, "decliners": 4870, "limit_up": 40, "limit_down": 21,
            "consecutive": 7, "max_board": 4, "seal_rate": 69, "broken_board": 18,
            "topic_top_count": 7, "topic_count_ge3": 1,
            "topics": [{"name": "零散修复", "count": 4}],
        })
        # 前一日某些指标更差，让传统“继续恶化”条件不充分。
        prev.update({"limit_down": 24, "broken_board": 22, "seal_rate": 65, "limit_up": 35})
        snap["market"].update({k: cur[k] for k in self.engine.REQUIRED_MARKET})
        snap["comparisons"]["previous_trading_day"] = {k: prev[k] for k in self.engine.REQUIRED_PREVIOUS}
        result = self.engine.analyze_snapshot(snap)
        self.assertEqual(result["single_stage_conclusion"]["stage"], "亏钱效应炸裂")



    def test_accepted_20260911_run_is_golden_standard(self) -> None:
        dates = ["2026-09-07", "2026-09-08", "2026-09-09", "2026-09-10", "2026-09-11"]
        raw = [
            # adv, dec, index, amount(亿元), lu, ld, con, maxb, seal, broken, ext, topics
            (3167, 2196, +0.8, 18600, 93, 2, 13, 6, 83.0, 19, "高潮", [{"name":"智能电网","count":5},{"name":"消费电子","count":4}]),
            (3417, 2026, +0.4, 19000, 73, 0, 18, 7, 66.4, 37, "降温", [{"name":"智能电网","count":5},{"name":"消费电子","count":3}]),
            (1794, 3642, -0.6, 17600, 48, 7, 15, 6, 64.0, 27, "退潮", [{"name":"智能电网","count":4}]),
            (955, 4512, -1.0, 16500, 35, 11, 9, 5, 61.4, 22, "冰点", [{"name":"智能电网","count":4}]),
            (643, 4870, -1.18, 19700, 40, 21, 7, 4, 69.0, 18, "冰点期，第2天", [{"name":"PCB","count":12},{"name":"智能电网","count":5},{"name":"被动元件","count":3}]),
        ]
        rows = []
        prev_amt = None
        for d, item in zip(dates, raw):
            adv, dec, idx, amount, lu, ld, con, maxb, seal, broken, ext, topics = item
            amount_chg = 0.0 if prev_amt is None else (amount / prev_amt - 1.0) * 100
            rows.append({
                "date": d, "advancers": adv, "decliners": dec, "index_change_pct": idx,
                "total_amount_billion": amount, "amount_change_pct": amount_chg,
                "limit_up": lu, "limit_down": ld, "consecutive": con, "max_board": maxb,
                "seal_rate": seal, "broken_board": broken,
                "topic_top_count": max(x["count"] for x in topics),
                "topic_count_ge3": sum(x["count"] >= 3 for x in topics),
                "topics": topics, "leaders": [], "reported_stage": ext,
            })
            prev_amt = amount
        cur, prev = rows[-1], rows[-2]
        market = {k: cur[k] for k in self.engine.REQUIRED_MARKET}
        snap = {
            "schema": "SHORT_TERM_SENTIMENT_SNAPSHOT_V2", "trading_date": dates[-1],
            "market": market, "topics": cur["topics"], "history": rows,
            "sources": {
                "tongdaxin": {"verified": True, "trading_date": dates[-1]},
                "duanxianxia": {"verified": True, "trading_date": dates[-1]},
                "lianban": {"verified": True, "trading_date": dates[-1], "reported_stage": "冰点期，第2天"},
            },
            "cross_validation": {"overall_status": "一致", "metrics": [], "conflicts": []},
            "comparisons": {"previous_trading_day": {k: prev[k] for k in self.engine.REQUIRED_PREVIOUS}},
        }
        result = self.engine.analyze_snapshot(snap)
        self.assertEqual(result["short_term_stage_conclusion"]["stage"], "退潮期")
        self.assertEqual(result["short_term_stage_conclusion"]["confidence"], "高")
        self.assertEqual(result["single_stage_conclusion"]["stage"], "亏钱效应炸裂")
        self.assertEqual(result["single_stage_conclusion"]["confidence"], "高")
        report = self.engine.render_text_report(snap, result)
        for token in ("2026年9月11日", "退潮期〔高置信度〕", "亏钱效应炸裂〔高置信度〕", "防守和等待为主", "PCB", "冰点期，第2天", "下一交易日条件推演"):
            self.assertIn(token, report)
        self.assertNotIn("海报", report)

    def test_workbuddy_fixed_delivery_command_is_documented(self) -> None:
        entry = (ROOT / "scripts" / "workbuddy_entry.py").read_text(encoding="utf-8")
        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn('sub.add_parser("present")', entry)
        self.assertIn("present --receipt", skill)
        self.assertIn("sentiment_report.md", skill)


if __name__ == "__main__":
    unittest.main()
