[CmdletBinding()]
param(
    [string]$PythonPath = '',
    [string]$TdxRoot = ''
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$entry = Join-Path $root 'scripts\workbuddy_entry.py'
$python = if ($PythonPath) { $PythonPath } else { (Get-Command python.exe -ErrorAction Stop).Source }
$common = @($entry)
$configArgs = @('configure')
if ($TdxRoot) { $configArgs += @('--tdx-root', $TdxRoot) }

Push-Location -LiteralPath $root
try {
    & $python @common @configArgs
    if ($LASTEXITCODE -ne 0) { throw '通达信路径配置未通过。' }
    & $python @common 'selftest'
    if ($LASTEXITCODE -ne 0) { throw '技能自检未通过。' }
    & $python @common 'sources' '--output' '.local/source-check'
    if ($LASTEXITCODE -ne 0) { throw '公开数据接口检查未通过。' }
    Write-Host '首次检查通过。尚未执行最终市场研判。'
}
finally {
    Pop-Location
}
