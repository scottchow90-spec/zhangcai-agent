---
name: a-share-short-term-market-sentiment-workbuddy
description: 在 Windows 电脑版 WorkBuddy 中使用本地通达信、短线侠和连板网，对 A 股短线情绪进行至少3日、目标5日的滚动时序研判。按固化实战模板输出短线七阶段、中级五阶段、当日盘面、5日演化、题材/梯队、操作结论与下一交易日条件树。缺源、历史不足、日期冲突、严重跨源冲突或包完整性失败时阻断；固定仅输出文字，不生成海报。
agent_created: true
entry: scripts/workbuddy_entry.py
display_name: 短线市场情绪研判系统（实战固化版 V2.2）
---

# 短线市场情绪研判系统（实战固化版 V2.2）

用途：供 WorkBuddy 电脑版盘后/盘中研判 A 股短线市场情绪。系统是**滚动时序证据状态机**，不是单日打分器。

## 已固化的实战标准

1. 短线七阶段固定为：启动、确认、发酵、加速、高潮、分歧、退潮。
2. 中级五阶段固定为：赚钱效应回暖、赚钱效应低迷、赚钱效应高潮、亏钱效应出现、亏钱效应炸裂。
3. 至少3个交易日、目标5个交易日参与判定；3—4日不能给高置信度。
4. 启动必须有弱基底、新题材和多项改善；不得“无法分类=启动”。
5. 发酵、加速、高潮必须有跨日题材持续和梯队延续；单日扩散不得越级。
6. 先判市场宽度和亏钱扩散，再判局部题材强弱；局部修复不能掩盖绝对冰点。
7. 外部阶段标签只作旁证，不覆盖内部状态机。
8. 固定纯文字输出，不生成海报，不输出单一情绪总分，不生成自动下单指令。
9. **2026-09-11 已认可实跑被固化为黄金回归样本**：退潮期〔高〕、亏钱效应炸裂〔高〕、防守等待。后续改动破坏该结果时自检失败。

## 首次导入

```powershell
python scripts/workbuddy_entry.py configure
python scripts/workbuddy_entry.py selftest
python scripts/workbuddy_entry.py sources --output .local/source-check
```

通达信目录无法唯一识别时：

```powershell
python scripts/workbuddy_entry.py configure --tdx-root "D:\TDX"
```

`selftest` 同时检查 Python 语法、包清单哈希、核心反例和黄金实跑回归。

## 正式实战工作流（禁止删步骤）

```powershell
python scripts/workbuddy_entry.py run --output .local/runs/current
python scripts/workbuddy_entry.py authorize --receipt .local/runs/current/receipt.json
python scripts/workbuddy_entry.py present --receipt .local/runs/current/receipt.json
```

- `run`：采集三源、多日历史、构建快照、执行状态机，同时生成 `sentiment_report.md`。
- `authorize`：再次校验包清单、数据/结果/报告哈希和固定输出模板。
- `present`：**只有授权通过后才打印唯一正式文字报告**。

WorkBuddy 对用户展示时必须采用 `present` 的原始输出。禁止自行改写、删节、重排、压缩为几句话，也禁止直接把 `sentiment_result.json` 当最终展示。

## 固定标准报告

唯一正式报告：`.local/runs/current/sentiment_report.md`，模板标识 `WORKBUDDY_SENTIMENT_TEXT_REPORT_V1`。

固定九段，顺序不得改变：

1. 核心状态；
2. 当日真实盘面输入；
3. 3—5日情绪演化；
4. 短线七阶段判定；
5. 中级五阶段判定；
6. 题材与梯队结构；
7. 实战操作结论；
8. 下一交易日条件推演；
9. 最终实跑结论。

详细模板见 `references/output-template.md`。

## 固定数据链

- **通达信**：指数日线、全市场涨跌家数、成交额与历史宽度基准；只读。
- **短线侠**：强制获取 `ztcount`、`ztpool`、`jinjidata`、`amount`；关键涨跌停生态参与跨源核对。
- **连板网**：当日及历史日期页/开放数据，提供涨跌停生态、题材、梯队、前排身份及外部阶段旁证。

三源当前交易日必须一致；通达信覆盖少于3000只、短线侠任一强制数据集失败、连板网失败、多日历史不足、关键字段严重跨源冲突均阻断。
